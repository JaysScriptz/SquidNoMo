-- Generated SquidNoMo verified source bundle.
-- Upload this file together with BuildManifest.lua and Main.lua.
return {
    BuildToken = [====[1_1_beta_6-stability-gameplay-rebuild-r6]====],
    Sources = {
        [ [====[BuildManifest.lua]====] ] = [====[-- SquidNoMo deployment manifest.
-- BuildNumber is advanced automatically by repository workflows whenever feature code changes.

local Manifest = {
    Release = "1.1",
    Channel = "beta",
    BuildNumber = 6,
    Revision = "stability-gameplay-rebuild-r6",
    FeatureRuntimeRevision = "gameplay-runtime-r6",
    PlayerRuntimeRevision = "player-runtime-r4",
    FarmingRuntimeRevision = "farming-runtime-r2",
    CatalogFeatureCount = 68,
    PlayerFeatureCount = 26,
    UIFeatureCount = 23,
    ExpectedRegistryTotal = 117,
    StartupBundle = "SourceBundle.lua",
    StartupTimeoutSeconds = 30,
    RequiredSharedFiles = {
        "Features/Shared/Runtime.lua",
        "Features/Shared/PlayerRuntime.lua",
        "Features/Shared/RoleService.lua",
        "Features/Farming/FarmingRuntime.lua",
        "Features/Player/AutoPickUpBaby.lua",
    },
}

Manifest.Version = string.format(
    "%s %s %d",
    tostring(Manifest.Release),
    tostring(Manifest.Channel),
    tonumber(Manifest.BuildNumber) or 0
)
Manifest.DisplayVersion = Manifest.Version
Manifest.BuildToken = string.gsub(
    Manifest.Version .. "-" .. tostring(Manifest.Revision),
    "[^%w_%-]",
    "_"
)

return Manifest
]====],
        [ [====[Config.lua]====] ] = [====[local Config = {}

Config.Debug = true

-- Improve readability on phones and tablets without requiring fullscreen.
Config.MobileTextBoost = true

Config.Repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"

return Config
]====],
        [ [====[Core/App.lua]====] ] = [====[-- Runtime patch: navigation selection uses Lua closures, not custom TextButton methods.
--//========================================================--
--// SquidNoMo - Universal App Runtime (Mobile V2)
--// Core/App.lua
--// Designed for Roblox Studio and common client executors
--// Mobile-first target: Delta landscape
--//========================================================--

--[[
    PURPOSE
    -------
    This file owns only the application shell:
      • top-layer ScreenGui creation
      • mobile safe-zone placement
      • full-suite uniform scaling
      • mouse + touch dragging
      • navigation and page mounting
      • visible error reporting
      • compatibility with the existing modular Loader

    It does not contain game automation or feature logic.

    EXPECTED LOADER CALL
    --------------------
        local App = loadstring(game:HttpGet(URL_TO_THIS_FILE))()
        App:Build(Loader)

    DIRECT UI TEST
    --------------
        local App = loadstring(game:HttpGet(URL_TO_THIS_FILE))()
        App:Build({})
]]

----------------------------------------------------------
-- Services
----------------------------------------------------------

local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")
local TweenService = game:GetService("TweenService")
local RunService = game:GetService("RunService")
local GuiService = game:GetService("GuiService")
local CoreGui = game:GetService("CoreGui")
local Stats = game:GetService("Stats")

local LocalPlayer = Players.LocalPlayer

local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end
local BuildManifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local DISPLAY_VERSION = tostring(BuildManifest.DisplayVersion or BuildManifest.Version or "1.1 beta")
local BUILD_TOKEN = tostring(BuildManifest.BuildToken or DISPLAY_VERSION)

----------------------------------------------------------
-- App
----------------------------------------------------------

local App = {}
App.__index = App

App.Name = "SquidNoMo"
App.Version = DISPLAY_VERSION
App.Runtime = "Universal Injector / Studio"

----------------------------------------------------------
-- Easy configuration
-- These values are intentionally grouped in one place.
----------------------------------------------------------

App.Config = {
    DeviceProfiles = {
        Phone = {
            DesignWidth = 1225,
            DesignHeight = 690,
            SidebarWidth = 260,
            TopbarHeight = 58,
            StatusbarHeight = 36,
            SafeFill = 1.0,
            RestoreFill = 0.90,
            WindowRadius = 14,
            ContentPadding = 10,
            HomeGap = 9,
            HeroHeight = 136,
            FeatureHeight = 196,
            BottomStatsHeight = 242,
            NavigationButtonHeight = 41,
            NavigationPadding = 4,
            SupportPanelHeight = 188,
            Margins = {Left = 0.008, Right = 0.008, Top = 0.010, Bottom = 0.010},
        },
        Tablet = {
            DesignWidth = 1280,
            DesignHeight = 800,
            SidebarWidth = 252,
            TopbarHeight = 58,
            StatusbarHeight = 36,
            SafeFill = 0.985,
            RestoreFill = 0.84,
            WindowRadius = 17,
            ContentPadding = 12,
            HomeGap = 10,
            HeroHeight = 168,
            FeatureHeight = 220,
            BottomStatsHeight = 274,
            NavigationButtonHeight = 42,
            NavigationPadding = 5,
            SupportPanelHeight = 196,
            Margins = {Left = 0.018, Right = 0.018, Top = 0.020, Bottom = 0.020},
        },
        Desktop = {
            DesignWidth = 1320,
            DesignHeight = 820,
            SidebarWidth = 260,
            TopbarHeight = 60,
            StatusbarHeight = 38,
            SafeFill = 0.96,
            RestoreFill = 0.86,
            WindowRadius = 18,
            ContentPadding = 14,
            HomeGap = 11,
            HeroHeight = 176,
            FeatureHeight = 224,
            BottomStatsHeight = 272,
            NavigationButtonHeight = 44,
            NavigationPadding = 6,
            SupportPanelHeight = 204,
            Margins = {Left = 0.020, Right = 0.020, Top = 0.025, Bottom = 0.025},
        },
    },

    -- Compatibility values are replaced by ApplyDeviceProfile before UI creation.
    DesignWidth = 1225,
    DesignHeight = 690,
    SidebarWidth = 232,
    TopbarHeight = 56,
    StatusbarHeight = 34,
    CornerRadius = 14,

    MinimumScale = 0.10,
    MaximumScale = 1.50,
    DisplayOrder = 999999,
    WindowEdgePadding = 6,
    AllowPartialOffscreenDrag = true,
    DragVisiblePixels = 48,
    FreeRoamAutoMinimizeVisibleRatio = 0.28,
    FreeRoamMinimumTitleWidth = 120,
    FreeRoamMinimumTitleHeight = 18,
    ForceMobile = false,
    AssetVersion = BUILD_TOKEN,
    MobileTextBoost = true,
    RespectGuiInset = false,
    ShowHomeFooter = false,

    Support = {
        CashApp = "$thepettyqueen98",
        PayPal = "@thepettyqueen98",
        CashAppQR = "Images/CashAppQR.png",
        PayPalQR = "Images/PayPalQR.png",
    },

    Assets = {
        Logo = "Images/SquidNoMoLogo.png",
        BannerGuards = "Images/BannerGuards.png",
        Tabs = {
            Home = "Images/TabIcons/Home.png",
            Games = "Images/TabIcons/Games.png",
            Players = "Images/TabIcons/Players.png",
            Guards = "Images/TabIcons/Guards.png",
            Detective = "Images/TabIcons/Detective.png",
            Farming = "Images/TabIcons/Farming.png",
            UI = "Images/TabIcons/UI.png",
            Settings = "Images/TabIcons/Settings.png",
        },
    },
}

----------------------------------------------------------
-- Canonical palette from the approved rendering
----------------------------------------------------------

App.Colors = {
    Backdrop = Color3.fromRGB(8, 6, 12),
    Window = Color3.fromRGB(11, 9, 16),
    Sidebar = Color3.fromRGB(12, 10, 18),
    Topbar = Color3.fromRGB(14, 10, 20),
    Card = Color3.fromRGB(18, 13, 25),
    CardAlt = Color3.fromRGB(24, 18, 32),
    CardHover = Color3.fromRGB(34, 24, 44),
    Border = Color3.fromRGB(255, 58, 145),
    BorderSoft = Color3.fromRGB(92, 47, 77),
    Accent = Color3.fromRGB(255, 58, 145),
    AccentDark = Color3.fromRGB(194, 30, 109),
    AccentSoft = Color3.fromRGB(105, 39, 74),
    Pink = Color3.fromRGB(255, 58, 145),
    PinkDark = Color3.fromRGB(171, 26, 95),
    Warning = Color3.fromRGB(255, 196, 64),
    Error = Color3.fromRGB(255, 63, 86),
    Success = Color3.fromRGB(45, 232, 98),
    Info = Color3.fromRGB(0, 170, 255),
    Minimize = Color3.fromRGB(106, 78, 176),
    Maximize = Color3.fromRGB(0, 139, 214),
    Close = Color3.fromRGB(211, 42, 68),
    CashApp = Color3.fromRGB(0, 224, 106),
    PayPal = Color3.fromRGB(0, 99, 214),
    Text = Color3.fromRGB(244, 240, 246),
    Muted = Color3.fromRGB(177, 163, 184),
    Dim = Color3.fromRGB(116, 102, 126),
    Black = Color3.fromRGB(0, 0, 0),
}

App.PageAccents = {
    Home = Color3.fromRGB(255, 58, 145),
    Games = Color3.fromRGB(0, 205, 255),
    Players = Color3.fromRGB(166, 92, 255),
    Guards = Color3.fromRGB(255, 63, 86),
    Detective = Color3.fromRGB(50, 138, 255),
    Farming = Color3.fromRGB(45, 232, 98),
    UI = Color3.fromRGB(232, 67, 255),
    Settings = Color3.fromRGB(255, 196, 64),
}

----------------------------------------------------------
-- Runtime state
----------------------------------------------------------

App.Loader = nil
App.Theme = nil
App.Components = nil
App.Navigation = nil
App.Utilities = nil
App.Notifications = nil
App.Features = nil
App.FeatureManager = nil
App.Session = nil
App.DeviceClass = "Desktop"
App.Profile = nil

App.Gui = nil
App.Host = nil
App.Window = nil
App.WindowScale = nil
App.Sidebar = nil
App.Topbar = nil
App.Statusbar = nil
App.FooterLabels = {}
App.FeatureWidgets = {}
App.PageContainer = nil
App.ReopenButton = nil

App.Pages = {}
App.PageDefinitions = {}
App.NavigationButtons = {}
App.Connections = {}
App.ModuleErrors = {}
App.AssetCache = {}

App.CurrentPage = nil
App.CurrentScale = 1
App.CurrentDesignSize = Vector2.new(App.Config.DesignWidth, App.Config.DesignHeight)
App.CurrentVisualSize = App.CurrentDesignSize
App.CurrentSafePosition = Vector2.new(0, 0)
App.CurrentSafeSize = App.CurrentDesignSize
App.HasBeenDragged = false
App.IsMinimized = false
App.IsMaximized = false
App.IsFullScreen = false
App.FreeRoamEnabled = true
App.ButtonGlowEnabled = true
App.NavigationGlowEnabled = true
App.CloseConfirmationEnabled = true
App.ReducedMotionEnabled = false
App.RememberLastPageEnabled = true
App.AutoCenterOnResizeEnabled = true
App.AutoApplyPerGameEnabled = false
App.LightweightModeEnabled = true
App.UserScale = 1.0
App.BubbleSize = nil
App.WindowOpacity = 0
App.LastSafePosition = nil
App.MinimizedByFreeRoam = false
App.WindowSettingsWidgets = {}
App.DetectionStatus = "UNKNOWN"
App.DetectionDetail = "No status signal has been reported."
App.AppStatus = "STARTING"
App.ReopenButtonHasBeenDragged = false
App._building = false

----------------------------------------------------------
-- Small utilities
----------------------------------------------------------

local function isGuiObject(value)
    return typeof(value) == "Instance" and value:IsA("GuiObject")
end

local function makeCorner(parent, radius)
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, radius)
    corner.Parent = parent
    return corner
end

local function makeStroke(parent, color, thickness, transparency)
    local stroke = Instance.new("UIStroke")
    stroke.Color = color
    stroke.Thickness = thickness or 1
    stroke.Transparency = transparency or 0
    stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
    stroke.Parent = parent
    return stroke
end

local function makePadding(parent, left, right, top, bottom)
    local padding = Instance.new("UIPadding")
    padding.PaddingLeft = UDim.new(0, left or 0)
    padding.PaddingRight = UDim.new(0, right or 0)
    padding.PaddingTop = UDim.new(0, top or 0)
    padding.PaddingBottom = UDim.new(0, bottom or 0)
    padding.Parent = parent
    return padding
end

local function makeGradient(parent, colorSequence, rotation)
    local gradient = Instance.new("UIGradient")
    gradient.Color = colorSequence
    gradient.Rotation = rotation or 0
    gradient.Parent = parent
    return gradient
end

local function safeDisconnect(connection)
    if connection then
        pcall(function()
            connection:Disconnect()
        end)
    end
end

function App:Track(connection)
    table.insert(self.Connections, connection)
    return connection
end

function App:Tween(instance, properties, duration)
    if not instance or not instance.Parent then
        return nil
    end

    if self.ReducedMotionEnabled then
        for property, value in pairs(properties or {}) do
            pcall(function()
                instance[property] = value
            end)
        end
        return nil
    end

    local animationSpeed = tonumber(
        self:GetUIStyleForInstance(instance, "AnimationSpeed")
    ) or 100
    local adjustedDuration = (duration or 0.18)
        * (100 / math.clamp(animationSpeed, 50, 200))

    local tween = TweenService:Create(
        instance,
        TweenInfo.new(
            adjustedDuration,
            Enum.EasingStyle.Quint,
            Enum.EasingDirection.Out
        ),
        properties
    )

    tween:Play()
    return tween
end

function App:GetUIStyleContext(instance)
    local pageName = nil
    local context = "MainPage"

    if instance and self.Pages then
        for name, page in pairs(self.Pages) do
            local ok, belongs = pcall(function()
                return instance == page
                    or instance:IsDescendantOf(page)
            end)
            if ok and belongs then
                pageName = name
                break
            end
        end
    end

    local current = instance
    while current do
        if current:GetAttribute("SquidNoMoSubpage") then
            context = "Subpage"
            break
        end
        current = current.Parent
    end

    return pageName, context
end

function App:GetUIStyleValue(pageName, key, context)
    if not self.UIStyleManager or not self.UIStyleProfile then
        return nil
    end

    return self.UIStyleManager:GetValue(
        self.UIStyleProfile,
        pageName,
        key,
        context or "MainPage"
    )
end

function App:GetUIStyleForInstance(instance, key)
    local pageName, context = self:GetUIStyleContext(instance)
    return self:GetUIStyleValue(pageName, key, context)
end

function App:SetUIStyleProfile(profile, rebuild)
    if not self.UIStyleManager then
        return false
    end

    self.UIStyleProfile = self.UIStyleManager:Normalize(
        self.UIStyleManager:Clone(profile)
    )

    if self.Session then
        self.Session.UIStyles = self.UIStyleProfile
        local scale = self.UIStyleManager:GetValue(
            self.UIStyleProfile,
            nil,
            "AppScale",
            "Global"
        )
        if scale then
            self.Session.UserScale = scale
        end
        self.Session.LastPage = "UI"
    end

    self:SavePersistentSettingsNow(false)

    if rebuild then
        self:RebuildForUIStyle()
    end

    return true
end

function App:RebuildForUIStyle()
    local loader = self.Loader
    local manager = self.FeatureManager
    local features = self.Features

    task.defer(function()
        self:Build(loader)
        self:AttachFeatureManager(manager, features)
    end)
end

function App:GetPageAccent(pageName)
    return self.PageAccents[pageName] or self.Colors.Accent
end

function App:PulseGlow(guiObject, color)
    if not self.ButtonGlowEnabled then
        return
    end

    if not guiObject or not guiObject.Parent then
        return
    end

    local intensity = tonumber(
        self:GetUIStyleForInstance(guiObject, "GlowIntensity")
    ) or 70
    if intensity <= 0 then
        return
    end

    local pulse = Instance.new("Frame")
    pulse.Name = "ClickGlow"
    pulse.AnchorPoint = Vector2.new(0.5, 0.5)
    pulse.Position = UDim2.fromScale(0.5, 0.5)
    pulse.Size = UDim2.new(1, 2, 1, 2)
    pulse.BackgroundTransparency = 1
    pulse.BorderSizePixel = 0
    pulse.ZIndex = math.max(1, guiObject.ZIndex - 1)
    pulse.Parent = guiObject
    makeCorner(pulse, 12)

    local strength = math.clamp(intensity / 100, 0, 1)
    local stroke = makeStroke(
        pulse,
        color or self.Colors.Accent,
        1 + (3 * strength),
        0.18 - (0.14 * strength)
    )

    if self.ReducedMotionEnabled then
        task.delay(0.08, function()
            if pulse then
                pcall(function()
                    pulse:Destroy()
                end)
            end
        end)
        return
    end

    self:Tween(pulse, {Size = UDim2.new(1, 18, 1, 18)}, 0.22)
    self:Tween(stroke, {Transparency = 1, Thickness = 1}, 0.22)

    task.delay(0.24, function()
        if pulse then
            pcall(function()
                pulse:Destroy()
            end)
        end
    end)
end

function App:BindButtonFeedback(button, color)
    if not button or button:GetAttribute("SquidNoMoFeedback") then
        return
    end

    button:SetAttribute("SquidNoMoFeedback", true)

    local buttonStyle = self:GetUIStyleForInstance(
        button,
        "ButtonStyle"
    ) or "Soft Glow"

    if button.BackgroundTransparency < 0.98 then
        if buttonStyle == "Filled" then
            button.BackgroundTransparency = math.min(
                button.BackgroundTransparency,
                0.06
            )
        elseif buttonStyle == "Outline" then
            button.BackgroundTransparency = math.max(
                button.BackgroundTransparency,
                0.72
            )
        elseif buttonStyle == "Flat" then
            button.BackgroundTransparency = math.max(
                button.BackgroundTransparency,
                0.16
            )
        elseif buttonStyle == "Glass" then
            button.BackgroundTransparency = 0.34
        end
    end

    local baseTransparency = button.BackgroundTransparency

    local function isPressInput(input)
        return input.UserInputType == Enum.UserInputType.MouseButton1
            or input.UserInputType == Enum.UserInputType.Touch
    end

    self:Track(button.InputBegan:Connect(function(input)
        if not isPressInput(input) then
            return
        end

        self:PulseGlow(button, color or self.Colors.Accent)

        -- Transparent hit targets stay transparent. Visible buttons receive
        -- only a subtle pressed-state fade.
        if baseTransparency < 0.98 then
            self:Tween(
                button,
                {
                    BackgroundTransparency = math.min(
                        1,
                        baseTransparency + 0.08
                    ),
                },
                0.08
            )
        end
    end))

    self:Track(button.InputEnded:Connect(function(input)
        if not isPressInput(input) then
            return
        end

        if button and button.Parent then
            self:Tween(
                button,
                {BackgroundTransparency = baseTransparency},
                0.12
            )
        end
    end))
end

function App:SafeCall(label, callback)
    local ok, result = xpcall(callback, function(message)
        return debug.traceback(tostring(message), 2)
    end)

    if not ok then
        self.ModuleErrors[label] = result
        warn("[SquidNoMo][" .. tostring(label) .. "] " .. tostring(result))
    end

    return ok, result
end

----------------------------------------------------------
-- Parent selection
-- Studio uses PlayerGui. Executors prefer gethui/CoreGui.
----------------------------------------------------------

function App:GetSessionEnvironment()
    if type(getgenv) == "function" then
        local ok, environment = pcall(getgenv)
        if ok and type(environment) == "table" then
            return environment
        end
    end

    return _G
end

function App:GetOrCreateSession()
    local environment = self:GetSessionEnvironment()
    local session = environment.__SquidNoMoSession
    local acceptedByServer = environment.__SquidNoMoTermsAcceptedByServer
    if type(acceptedByServer) ~= "table" then
        acceptedByServer = {}
        environment.__SquidNoMoTermsAcceptedByServer = acceptedByServer
    end

    if type(session) ~= "table" or session.JobId ~= game.JobId then
        if type(session) == "table" and session.CharacterConnection then
            pcall(function()
                session.CharacterConnection:Disconnect()
            end)
        end

        session = {
            JobId = game.JobId,
            TermsAccepted = acceptedByServer[game.JobId] == true,
            UserClosed = false,
            DetectionStatus = "UNKNOWN",
            DetectionDetail = "No status signal has been reported.",
            FreeRoamEnabled = true,
            FullScreenEnabled = false,
            ButtonGlowEnabled = true,
            NavigationGlowEnabled = true,
            CloseConfirmationEnabled = true,
            ReducedMotionEnabled = false,
            RememberLastPageEnabled = true,
            AutoCenterOnResizeEnabled = true,
            AutoApplyPerGameEnabled = true,
            LightweightModeEnabled = true,
            UserScale = 1.0,
            BubbleSize = nil,
            WindowOpacity = 0,
            LastPage = "Home",
            SelectedDetectiveCategory = "Island Navigation",
            SelectedUICategory = "Layout & Scale",
            UIEditScope = "Entire App",
            UIEditTargetPage = "Players",
            UIStyles = nil,
            LastSafePosition = nil,
        }
        environment.__SquidNoMoSession = session
    end

    if acceptedByServer[game.JobId] == true then
        session.TermsAccepted = true
    end
    return session
end

function App:GetDeviceClass(viewport)
    viewport = viewport or self:GetViewportSize()

    if not (self.Config.ForceMobile or UserInputService.TouchEnabled) then
        return "Desktop"
    end

    local shortSide = math.min(viewport.X, viewport.Y)
    if shortSide < 760 then
        return "Phone"
    end

    return "Tablet"
end

function App:ApplyDeviceProfile(viewport)
    viewport = viewport or self:GetViewportSize()
    local deviceClass = self:GetDeviceClass(viewport)
    local sourceProfile = self.Config.DeviceProfiles[deviceClass]
        or self.Config.DeviceProfiles.Desktop
    local profile = {}

    for key, value in pairs(sourceProfile) do
        if type(value) == "table" then
            local copy = {}
            for nestedKey, nestedValue in pairs(value) do
                copy[nestedKey] = nestedValue
            end
            profile[key] = copy
        else
            profile[key] = value
        end
    end

    if self.UIStyleManager and self.UIStyleProfile then
        self.UIStyleManager:ApplyProfileMetrics(
            profile,
            self.UIStyleProfile
        )
    end

    self.DeviceClass = deviceClass
    self.Profile = profile
    self.Config.DesignWidth = profile.DesignWidth
    self.Config.DesignHeight = profile.DesignHeight
    self.Config.SidebarWidth = profile.SidebarWidth
    self.Config.TopbarHeight = profile.TopbarHeight
    self.Config.StatusbarHeight = profile.StatusbarHeight
    self.Config.CornerRadius = profile.WindowRadius

    return profile
end

function App:GetLayoutMetric(name, fallback)
    local profile = self.Profile or self:ApplyDeviceProfile()
    local value = profile and profile[name]
    if value == nil then
        return fallback
    end
    return value
end

function App:AttachFeatureManager(manager, features)
    if manager then
        self.FeatureManager = manager
    end
    if features then
        self.Features = features
    end

    if self.FeatureManager
        and type(self.FeatureManager.SetPersistenceCallback)
            == "function"
    then
        self.FeatureManager:SetPersistenceCallback(function()
            self:QueueSettingsSave()
        end)
    end

    self:StartFeatureTracking()
    self:RefreshFeatureDashboard()
end

function App:GetPlayerGui()
    if not LocalPlayer then
        LocalPlayer = Players.LocalPlayer
    end

    if not LocalPlayer then
        return nil
    end

    return LocalPlayer:FindFirstChildOfClass("PlayerGui")
        or LocalPlayer:WaitForChild("PlayerGui", 10)
end

function App:GetGuiParent()
    if RunService:IsStudio() then
        return self:GetPlayerGui()
    end

    local executorParent = nil

    if type(gethui) == "function" then
        pcall(function()
            executorParent = gethui()
        end)
    end

    if executorParent then
        return executorParent
    end

    local protectedCoreGui = CoreGui

    if type(cloneref) == "function" then
        pcall(function()
            protectedCoreGui = cloneref(CoreGui)
        end)
    end

    if protectedCoreGui then
        return protectedCoreGui
    end

    return self:GetPlayerGui()
end

function App:DestroyOldCopies()
    local parents = {}

    local function addParent(parent)
        if parent and not table.find(parents, parent) then
            table.insert(parents, parent)
        end
    end

    addParent(self:GetPlayerGui())
    addParent(CoreGui)

    if type(gethui) == "function" then
        pcall(function()
            addParent(gethui())
        end)
    end

    for _, parent in ipairs(parents) do
        local existing = parent:FindFirstChild(self.Name)
        if existing then
            pcall(function()
                existing:Destroy()
            end)
        end
    end
end

----------------------------------------------------------
-- Loader and component compatibility
----------------------------------------------------------

function App:Init(loader)
    self.Loader = loader or {}

    self.Theme = self.Loader.Theme
    self.Components = self.Loader.Components
    self.Navigation = self.Loader.Navigation
    self.Utilities = self.Loader.Utilities
    self.Notifications = self.Loader.Notifications
    self.SettingsStore = self.Loader.SettingsStore
    self.UIStyleManager = self.Loader.UIStyleManager
    self.FeatureManager = self.Loader.FeatureManager
    self.Features = self.Loader.Features or {}

    self.Session = self:GetOrCreateSession()
    self.Session.UserClosed = false

    if self.UIStyleManager then
        self.UIStyleProfile = self.UIStyleManager:Normalize(
            self.Session.UIStyles
        )
        self.Session.UIStyles = self.UIStyleProfile
        self.Colors, self.PageAccents =
            self.UIStyleManager:BuildPalette(
                self.UIStyleProfile
            )
    end

    self.TermsAccepted = self.Session.TermsAccepted == true
    self.DetectionStatus = self.Session.DetectionStatus or "UNKNOWN"
    self.DetectionDetail = self.Session.DetectionDetail
        or "No status signal has been reported."
    self.FreeRoamEnabled = self.Session.FreeRoamEnabled ~= false
    self.IsFullScreen = self.Session.FullScreenEnabled == true
    self.ButtonGlowEnabled = self.Session.ButtonGlowEnabled ~= false
    self.NavigationGlowEnabled = self.Session.NavigationGlowEnabled ~= false
    self.CloseConfirmationEnabled =
        self.Session.CloseConfirmationEnabled ~= false
    self.ReducedMotionEnabled =
        self.Session.ReducedMotionEnabled == true
    self.RememberLastPageEnabled =
        self.Session.RememberLastPageEnabled ~= false
    self.AutoCenterOnResizeEnabled =
        self.Session.AutoCenterOnResizeEnabled ~= false
    self.AutoApplyPerGameEnabled =
        self.Session.AutoApplyPerGameEnabled ~= false
    self.LightweightModeEnabled =
        self.Session.LightweightModeEnabled ~= false

    if self.FeatureManager then
        if type(self.FeatureManager.SetLightweightModeEnabled) == "function" then
            self.FeatureManager:SetLightweightModeEnabled(self.LightweightModeEnabled)
        end
        if type(self.FeatureManager.SetAutoApplyPerGameEnabled) == "function" then
            self.FeatureManager:SetAutoApplyPerGameEnabled(self.AutoApplyPerGameEnabled)
        end
    end

    local styleScale = 1.0
    if self.UIStyleManager and self.UIStyleProfile then
        styleScale = self.UIStyleManager:GetValue(
            self.UIStyleProfile,
            nil,
            "AppScale",
            "Global"
        ) or 1.0
    end

    self.UserScale = math.clamp(
        tonumber(self.Session.UserScale) or styleScale,
        0.75,
        1.15
    )
    self.BubbleSize = tonumber(self.Session.BubbleSize)
    self.WindowOpacity = math.clamp(
        tonumber(self.Session.WindowOpacity) or 0,
        0,
        0.35
    )
    self.LastSafePosition = self.Session.LastSafePosition
    self.MinimizedByFreeRoam = false
    self.AppStatus = "STARTING"

    self:ApplyDeviceProfile()

    if self.Loader.Home and type(self.Loader.Home.Load) ~= "function" then
        self.Loader.Home.Load = function()
            return true
        end
    end

    self:PatchComponents()
end

function App:PatchComponents()
    local components = self.Components

    if not components then
        return
    end

    if type(components.Initialize) == "function" then
        pcall(function()
            components:Initialize(self.Theme or self.Colors)
        end)
    else
        components.Theme = self.Theme or self.Colors
    end

    if components.__SquidNoMoUniversalCompatibility then
        return
    end

    components.__SquidNoMoUniversalCompatibility = true
    components.__SquidNoMoRawMethods = components.__SquidNoMoRawMethods or {}

    local raw = components.__SquidNoMoRawMethods

    local function save(name)
        if type(components[name]) == "function" and not raw[name] then
            raw[name] = components[name]
        end
    end

    save("CreateCard")
    save("CreateSection")
    save("CreateButton")
    save("CreateToggle")
    save("CreateSlider")
    save("CreateDropdown")
    save("CreateTextbox")
    save("CreateLabel")
    save("CreateSpacer")
    save("CreateDivider")

    if raw.CreateCard then
        components.CreateCard = function(this, parent, second, third)
            local size = nil

            if typeof(second) == "UDim2" then
                size = second
            elseif typeof(third) == "UDim2" then
                size = third
            end

            size = size or UDim2.new(1, 0, 0, 120)
            return raw.CreateCard(this, parent, size)
        end
    end

    if raw.CreateSection then
        components.CreateSection = function(this, parent, second, third)
            local title = type(second) == "string" and second or third
            return raw.CreateSection(this, parent, tostring(title or "Section"))
        end
    end

    if raw.CreateButton then
        components.CreateButton = function(this, parent, second, third)
            local text = type(second) == "string" and second or third
            return raw.CreateButton(this, parent, tostring(text or "Button"))
        end
    end

    if raw.CreateToggle then
        components.CreateToggle = function(this, parent, second, third)
            local text = type(second) == "string" and second or third
            return raw.CreateToggle(this, parent, tostring(text or "Toggle"))
        end
    end

    if raw.CreateSlider then
        components.CreateSlider = function(this, parent, a, b, c, d, e)
            if type(a) == "string" then
                return raw.CreateSlider(this, parent, a, b, c, d)
            end

            return raw.CreateSlider(this, parent, b, c, d, e)
        end
    end

    if raw.CreateDropdown then
        components.CreateDropdown = function(this, parent, a, b, c)
            if type(a) == "string" then
                return raw.CreateDropdown(this, parent, a, b)
            end

            return raw.CreateDropdown(this, parent, b, c)
        end
    end

    if raw.CreateTextbox then
        components.CreateTextbox = function(this, parent, second, third)
            local placeholder = type(second) == "string" and second or third
            return raw.CreateTextbox(this, parent, tostring(placeholder or "Enter text"))
        end
    end

    if raw.CreateLabel then
        components.CreateLabel = function(this, parent, second, third)
            local text = type(second) == "string" and second or third
            return raw.CreateLabel(this, parent, tostring(text or ""))
        end
    end

    if raw.CreateSpacer then
        components.CreateSpacer = function(this, parent, second, third)
            local height = type(second) == "number" and second or third
            return raw.CreateSpacer(this, parent, height)
        end
    end

    if raw.CreateDivider then
        components.CreateDivider = function(this, parent)
            return raw.CreateDivider(this, parent)
        end
    end

    if type(components.CreateTitle) ~= "function" then
        function components:CreateTitle(parent, second, third)
            local theme = self.Theme or App.Theme or App.Colors
            local text = type(second) == "string" and second or third

            local label = Instance.new("TextLabel")
            label.Name = "Title"
            label.BackgroundTransparency = 1
            label.Position = UDim2.fromOffset(18, 14)
            label.Size = UDim2.new(1, -36, 0, 26)
            label.Font = theme.FontBlack or Enum.Font.GothamBold
            label.Text = tostring(text or "")
            label.TextSize = 19
            label.TextColor3 = theme.Text or App.Colors.Text
            label.TextXAlignment = Enum.TextXAlignment.Left
            label.Parent = parent
            return label
        end
    end
end

----------------------------------------------------------
-- Screen and safe region calculations
----------------------------------------------------------

function App:GetViewportSize()
    local camera = workspace.CurrentCamera

    if camera and camera.ViewportSize.X > 0 and camera.ViewportSize.Y > 0 then
        return camera.ViewportSize
    end

    return Vector2.new(1280, 720)
end

function App:IsMobile(viewport)
    viewport = viewport or self:GetViewportSize()
    return self.Config.ForceMobile or UserInputService.TouchEnabled
end

function App:GetDesignSize(viewport)
    viewport = viewport or self:GetViewportSize()
    local expectedClass = self:GetDeviceClass(viewport)

    if not self.Profile or expectedClass ~= self.DeviceClass then
        self:ApplyDeviceProfile(viewport)
    end

    return Vector2.new(self.Profile.DesignWidth, self.Profile.DesignHeight)
end

function App:GetSafeRect()
    local viewport = self:GetViewportSize()
    local expectedClass = self:GetDeviceClass(viewport)

    if not self.Profile or expectedClass ~= self.DeviceClass then
        self:ApplyDeviceProfile(viewport)
    end

    local margins = self.Profile.Margins
    local left = viewport.X * margins.Left
    local right = viewport.X * margins.Right
    local top = viewport.Y * margins.Top
    local bottom = viewport.Y * margins.Bottom

    if self.Config.RespectGuiInset then
        local ok, insetTopLeft, insetBottomRight = pcall(function()
            return GuiService:GetGuiInset()
        end)

        if ok then
            left = math.max(left, insetTopLeft.X)
            top = math.max(top, insetTopLeft.Y)
            right = math.max(right, insetBottomRight.X)
            bottom = math.max(bottom, insetBottomRight.Y)
        end
    end

    local position = Vector2.new(math.floor(left), math.floor(top))
    local size = Vector2.new(
        math.max(260, math.floor(viewport.X - left - right)),
        math.max(240, math.floor(viewport.Y - top - bottom))
    )

    return position, size
end

function App:CalculateScale()
    local viewport = self:GetViewportSize()
    local safePosition, safeSize = self:GetSafeRect()
    local baseDesignSize = self:GetDesignSize(viewport)

    if self.IsFullScreen then
        local scale = viewport.Y / baseDesignSize.Y
        local dynamicWidth = viewport.X / scale
        local designSize = Vector2.new(dynamicWidth, baseDesignSize.Y)

        if dynamicWidth < baseDesignSize.X then
            scale = viewport.X / baseDesignSize.X
            designSize = Vector2.new(baseDesignSize.X, viewport.Y / scale)
        end

        return scale, Vector2.new(0, 0), viewport, viewport, designSize
    end

    local targetPosition = safePosition
    local targetSize = safeSize
    local fill = self.Profile.RestoreFill

    if self.IsMaximized then
        targetPosition = Vector2.new(0, 0)
        targetSize = viewport
        fill = 1
    end

    local targetWidth = targetSize.X * fill
    local targetHeight = targetSize.Y * fill
    local fitScale = math.min(
        targetWidth / baseDesignSize.X,
        targetHeight / baseDesignSize.Y
    )

    local scale = math.min(fitScale, self.Config.MaximumScale)
    scale = math.max(scale, math.min(self.Config.MinimumScale, fitScale))

    local userScale = math.clamp(tonumber(self.UserScale) or 1.0, 0.75, 1.15)
    scale = math.min(fitScale, scale * userScale)

    local visualSize = Vector2.new(
        math.max(1, math.floor(baseDesignSize.X * scale)),
        math.max(1, math.floor(baseDesignSize.Y * scale))
    )

    if self.IsMaximized then
        scale = viewport.Y / baseDesignSize.Y
        visualSize = Vector2.new(
            math.floor(baseDesignSize.X * scale),
            viewport.Y
        )
    end

    return scale, targetPosition, targetSize, visualSize, baseDesignSize
end

function App:GetBoundedHostPosition(position)
    local viewport = self:GetViewportSize()
    local visualSize = self.CurrentVisualSize
    local padding = self.Config.WindowEdgePadding or 4

    local minX = padding
    local minY = padding
    local maxX = math.max(minX, viewport.X - visualSize.X - padding)
    local maxY = math.max(minY, viewport.Y - visualSize.Y - padding)

    return Vector2.new(
        math.clamp(position.X, minX, maxX),
        math.clamp(position.Y, minY, maxY)
    )
end

function App:IsPositionFullyUsable(position)
    local viewport = self:GetViewportSize()
    local visualSize = self.CurrentVisualSize
    local padding = self.Config.WindowEdgePadding or 4

    return position.X >= padding
        and position.Y >= padding
        and position.X + visualSize.X <= viewport.X - padding
        and position.Y + visualSize.Y <= viewport.Y - padding
end

function App:SaveLastSafePosition(position)
    if not position or self.IsFullScreen or self.IsMaximized then
        return
    end

    local safe = self:GetBoundedHostPosition(position)
    self.LastSafePosition = safe

    if self.Session then
        self.Session.LastSafePosition = safe
    end
end

function App:GetRecoveryPosition()
    if typeof(self.LastSafePosition) == "Vector2" then
        return self:GetBoundedHostPosition(self.LastSafePosition)
    end

    local viewport = self:GetViewportSize()
    local visualSize = self.CurrentVisualSize
    return self:GetBoundedHostPosition(Vector2.new(
        (viewport.X - visualSize.X) / 2,
        (viewport.Y - visualSize.Y) / 2
    ))
end

function App:GetVisibleWindowRatio(position)
    local viewport = self:GetViewportSize()
    local visualSize = self.CurrentVisualSize

    local left = math.max(0, position.X)
    local top = math.max(0, position.Y)
    local right = math.min(viewport.X, position.X + visualSize.X)
    local bottom = math.min(viewport.Y, position.Y + visualSize.Y)
    local width = math.max(0, right - left)
    local height = math.max(0, bottom - top)
    local totalArea = math.max(1, visualSize.X * visualSize.Y)

    return (width * height) / totalArea
end

function App:ShouldAutoMinimizeFreeRoam(position)
    if not self.FreeRoamEnabled or self.IsFullScreen or self.IsMaximized then
        return false
    end

    local viewport = self:GetViewportSize()
    local visualSize = self.CurrentVisualSize
    local titleHeight = math.max(1, self.Config.TopbarHeight * self.CurrentScale)

    local titleLeft = math.max(0, position.X)
    local titleTop = math.max(0, position.Y)
    local titleRight = math.min(viewport.X, position.X + visualSize.X)
    local titleBottom = math.min(viewport.Y, position.Y + titleHeight)
    local visibleTitleWidth = math.max(0, titleRight - titleLeft)
    local visibleTitleHeight = math.max(0, titleBottom - titleTop)

    return self:GetVisibleWindowRatio(position) < self.Config.FreeRoamAutoMinimizeVisibleRatio
        or visibleTitleWidth < self.Config.FreeRoamMinimumTitleWidth
        or visibleTitleHeight < self.Config.FreeRoamMinimumTitleHeight
end

function App:ClampHostPosition(position)
    local viewport = self:GetViewportSize()
    local visualSize = self.CurrentVisualSize

    if self.IsFullScreen then
        return Vector2.new(0, 0)
    end

    if self.IsMaximized then
        local maxX = math.max(0, viewport.X - visualSize.X)
        return Vector2.new(math.clamp(position.X, 0, maxX), 0)
    end

    if not self.FreeRoamEnabled then
        return self:GetBoundedHostPosition(position)
    end

    local visible = self.Config.DragVisiblePixels or 48
    return Vector2.new(
        math.clamp(position.X, -visualSize.X + visible, viewport.X - visible),
        math.clamp(position.Y, -visualSize.Y + visible, viewport.Y - visible)
    )
end

function App:UpdateResponsive(forceCenter)
    if not self.Host or not self.WindowScale then
        return
    end

    local viewport = self:GetViewportSize()
    local expectedClass = self:GetDeviceClass(viewport)

    if expectedClass ~= self.DeviceClass and not self._building then
        task.defer(function()
            if self.Gui and not self._building then
                self:Build(self.Loader)
            end
        end)
        return
    end

    local scale, safePosition, safeSize, visualSize, designSize = self:CalculateScale()

    self.CurrentScale = scale
    self.CurrentDesignSize = designSize
    self.CurrentSafePosition = safePosition
    self.CurrentSafeSize = safeSize
    self.CurrentVisualSize = visualSize

    self.Window.Size = UDim2.fromOffset(designSize.X, designSize.Y)
    self.WindowScale.Scale = scale
    self.Host.Size = UDim2.fromOffset(visualSize.X, visualSize.Y)

    local targetPosition

    if self.IsFullScreen then
        targetPosition = Vector2.new(0, 0)
    elseif self.IsMaximized then
        targetPosition = Vector2.new(
            (viewport.X - visualSize.X) / 2,
            0
        )
    elseif forceCenter or not self.HasBeenDragged then
        targetPosition = Vector2.new(
            (viewport.X - visualSize.X) / 2,
            (viewport.Y - visualSize.Y) / 2
        )
    else
        targetPosition = Vector2.new(
            self.Host.Position.X.Offset,
            self.Host.Position.Y.Offset
        )
    end

    targetPosition = self:ClampHostPosition(targetPosition)
    self.Host.Position = UDim2.fromOffset(targetPosition.X, targetPosition.Y)

    if self:IsPositionFullyUsable(targetPosition) then
        self:SaveLastSafePosition(targetPosition)
    end

    if self.ReopenButton and self.ReopenButton.Visible then
        self:PositionReopenButton(false)
    end
end

function App:CreateGui()
    self:DestroyOldCopies()

    local gui = Instance.new("ScreenGui")
    gui.Name = self.Name
    gui.ResetOnSpawn = false
    gui.IgnoreGuiInset = true
    gui.DisplayOrder = self.Config.DisplayOrder
    gui.ZIndexBehavior = Enum.ZIndexBehavior.Global

    pcall(function()
        gui.ScreenInsets = Enum.ScreenInsets.None
    end)

    pcall(function()
        gui.SafeAreaCompatibility = Enum.SafeAreaCompatibility.None
    end)

    pcall(function()
        gui.ClipToDeviceSafeArea = false
    end)

    if type(syn) == "table" and type(syn.protect_gui) == "function" then
        pcall(function()
            syn.protect_gui(gui)
        end)
    end

    local parent = self:GetGuiParent()
    assert(parent, "No valid GUI parent was available")

    gui.Parent = parent
    self.Gui = gui

    if self.Notifications and type(self.Notifications.Init) == "function" then
        pcall(function()
            self.Notifications:Init(gui, self.Theme or self.Colors)
        end)
    end
end

function App:CreateWindow()
    local host = Instance.new("Frame")
    host.Name = "FloatingHost"
    host.BackgroundTransparency = 1
    host.BorderSizePixel = 0
    host.Active = true
    host.ZIndex = 1000
    host.Parent = self.Gui
    self.Host = host

    local designSize = self:GetDesignSize()
    self.CurrentDesignSize = designSize

    local window = Instance.new("Frame")
    window.Name = "Window"
    window.Size = UDim2.fromOffset(designSize.X, designSize.Y)
    window.BackgroundColor3 = self.Colors.Window
    window.BackgroundTransparency = self.WindowOpacity or 0
    window.BorderSizePixel = 0
    window.ClipsDescendants = true
    window.Active = true
    window.ZIndex = 1001
    window.Parent = host
    makeCorner(window, self.Config.CornerRadius)
    makeStroke(window, self.Colors.Border, 1, 0.15)

    local scale = Instance.new("UIScale")
    scale.Name = "ResponsiveScale"
    scale.Scale = 1
    scale.Parent = window

    local blocker = Instance.new("Frame")
    blocker.Name = "InputShield"
    blocker.Size = UDim2.fromScale(1, 1)
    blocker.BackgroundTransparency = 1
    blocker.BorderSizePixel = 0
    blocker.Active = true
    blocker.ZIndex = 1001
    blocker.Parent = window

    self.Window = window
    self.WindowScale = scale
end

----------------------------------------------------------
-- Topbar, dragging, minimize, close
----------------------------------------------------------

function App:CreateTopbar()
    local topbar = Instance.new("Frame")
    topbar.Name = "Topbar"
    topbar.Position = UDim2.fromOffset(self.Config.SidebarWidth, 0)
    topbar.Size = UDim2.new(1, -self.Config.SidebarWidth, 0, self.Config.TopbarHeight)
    topbar.BackgroundColor3 = self.Colors.Topbar
    topbar.BackgroundTransparency = math.min(0.45, 0.10 + ((self.WindowOpacity or 0) * 0.65))
    topbar.BorderSizePixel = 0
    topbar.ZIndex = 1020
    topbar.Parent = self.Window

    local accentLine = Instance.new("Frame")
    accentLine.AnchorPoint = Vector2.new(0, 1)
    accentLine.Position = UDim2.new(0, 0, 1, 0)
    accentLine.Size = UDim2.new(1, 0, 0, 1)
    accentLine.BackgroundColor3 = self.Colors.BorderSoft
    accentLine.BorderSizePixel = 0
    accentLine.ZIndex = 1021
    accentLine.Parent = topbar

    local mobile = self:IsMobile()
    local buttonSize = mobile and 44 or 40
    local gap = mobile and 10 or 9
    local rightPadding = mobile and 14 or 12

    local closeOffset = rightPadding
    local maximizeOffset = rightPadding + buttonSize + gap
    local minimizeOffset = rightPadding + (buttonSize + gap) * 2

    local moveHandle = Instance.new("TextButton")
    moveHandle.Name = "MoveHandle"
    moveHandle.Position = UDim2.fromOffset(8, 4)
    moveHandle.Size = UDim2.new(1, -(minimizeOffset + buttonSize + 16), 1, -8)
    moveHandle.BackgroundTransparency = 1
    moveHandle.BorderSizePixel = 0
    moveHandle.AutoButtonColor = false
    moveHandle.Text = ""
    moveHandle.ZIndex = 1022
    moveHandle.Parent = topbar

    local grip = Instance.new("Frame")
    grip.Name = "DragGrip"
    grip.AnchorPoint = Vector2.new(0.5, 0.5)
    grip.Position = UDim2.fromScale(0.5, 0.5)
    grip.Size = UDim2.fromOffset(30, 16)
    grip.BackgroundTransparency = 1
    grip.BorderSizePixel = 0
    grip.ZIndex = 1023
    grip.Parent = moveHandle

    for row = 0, 1 do
        for column = 0, 2 do
            local dot = Instance.new("Frame")
            dot.Position = UDim2.fromOffset(5 + (column * 9), 3 + (row * 9))
            dot.Size = UDim2.fromOffset(4, 4)
            dot.BackgroundColor3 = self.Colors.Muted
            dot.BackgroundTransparency = 0.22
            dot.BorderSizePixel = 0
            dot.ZIndex = 1024
            dot.Parent = grip
            makeCorner(dot, 999)
        end
    end

    self:EnableDragging(moveHandle)

    local minimize = self:CreateTopbarButton(topbar, "Minimize", "—", minimizeOffset, self.Colors.Minimize)
    local maximize = self:CreateTopbarButton(topbar, "MaximizeRestore", (self.IsMaximized or self.IsFullScreen) and "❐" or "□", maximizeOffset, self.Colors.Maximize)
    local close = self:CreateTopbarButton(topbar, "Close", "×", closeOffset, self.Colors.Close)

    minimize.MouseButton1Click:Connect(function()
        self:SetMinimized(true)
    end)

    maximize.MouseButton1Click:Connect(function()
        if self.IsFullScreen then
            self:SetFullScreen(false)
        else
            self:SetMaximized(not self.IsMaximized)
        end
    end)

    close.MouseButton1Click:Connect(function()
        self:ShowCloseConfirmation()
    end)

    self.Topbar = topbar
    self.MaximizeButton = maximize
    self:RefreshWindowModeControls()
end

function App:CreateTopbarButton(parent, name, textValue, rightOffset, baseColor)
    local mobile = self:IsMobile()
    local preferredHeight = tonumber(
        self:GetUIStyleValue(nil, "ButtonHeight", "Global")
    ) or (mobile and 40 or 34)
    local height = math.clamp(preferredHeight, 34, 52)
    local width = math.max(mobile and 44 or 40, height)

    local button = Instance.new("TextButton")
    button.Name = name
    button.AnchorPoint = Vector2.new(1, 0.5)
    button.Position = UDim2.new(1, -rightOffset, 0.5, 0)
    button.Size = UDim2.fromOffset(width, height)
    button.BackgroundColor3 = baseColor
    button.BorderSizePixel = 0
    button.AutoButtonColor = false
    button.Font = Enum.Font.GothamBlack
    button.Text = textValue
    button.TextSize = mobile and 21 or 19
    button.TextColor3 = Color3.fromRGB(255, 255, 255)
    button.ZIndex = 1030
    button.Parent = parent
    makeCorner(
        button,
        self:GetUIStyleValue(nil, "ButtonRadius", "Global") or 9
    )
    makeStroke(button, Color3.fromRGB(255, 255, 255), 1, 0.72)

    button.MouseEnter:Connect(function()
        self:Tween(button, {BackgroundTransparency = 0.12}, 0.12)
    end)

    button.MouseLeave:Connect(function()
        self:Tween(button, {BackgroundTransparency = 0}, 0.12)
    end)

    self:BindButtonFeedback(button, baseColor)
    return button
end

function App:EnableDragging(dragBar)
    if not dragBar then
        return
    end

    dragBar.Active = true

    local dragging = false
    local dragInput = nil
    local dragStart = nil
    local startPosition = nil
    local shouldAutoMinimize = false

    self:Track(dragBar.InputBegan:Connect(function(input)
        local inputType = input.UserInputType
        if inputType ~= Enum.UserInputType.MouseButton1
            and inputType ~= Enum.UserInputType.Touch then
            return
        end

        if self.IsFullScreen or self.IsMaximized or self.IsMinimized then
            return
        end

        dragging = true
        shouldAutoMinimize = false
        dragStart = Vector2.new(input.Position.X, input.Position.Y)
        startPosition = Vector2.new(
            self.Host.Position.X.Offset,
            self.Host.Position.Y.Offset
        )

        if self:IsPositionFullyUsable(startPosition) then
            self:SaveLastSafePosition(startPosition)
        end

        if inputType == Enum.UserInputType.Touch then
            dragInput = input
        end

        self:Track(input.Changed:Connect(function()
            if input.UserInputState == Enum.UserInputState.End then
                dragging = false
                dragInput = nil

                if shouldAutoMinimize then
                    task.defer(function()
                        self:AutoMinimizeFromFreeRoam()
                    end)
                end
            end
        end))
    end))

    self:Track(dragBar.InputChanged:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseMovement
            or input.UserInputType == Enum.UserInputType.Touch then
            dragInput = input
        end
    end))

    self:Track(UserInputService.InputChanged:Connect(function(input)
        if not dragging or input ~= dragInput or not dragStart or not startPosition then
            return
        end

        local current = Vector2.new(input.Position.X, input.Position.Y)
        local delta = current - dragStart
        local target = self:ClampHostPosition(startPosition + delta)

        self.Host.Position = UDim2.fromOffset(target.X, target.Y)
        self.HasBeenDragged = true

        if self:IsPositionFullyUsable(target) then
            self:SaveLastSafePosition(target)
        end

        shouldAutoMinimize = self:ShouldAutoMinimizeFreeRoam(target)
    end))
end

function App:AutoMinimizeFromFreeRoam()
    if not self.FreeRoamEnabled or self.IsMinimized then
        return
    end

    self.MinimizedByFreeRoam = true
    self:SetMinimized(true)
end

function App:ClampReopenButtonPosition(position)
    local viewport = self:GetViewportSize()
    local size = 64
    local padding = 8

    if self.ReopenButton then
        size = math.max(
            self.ReopenButton.AbsoluteSize.X,
            self.ReopenButton.AbsoluteSize.Y,
            size
        )
    end

    return Vector2.new(
        math.clamp(position.X, padding, math.max(padding, viewport.X - size - padding)),
        math.clamp(position.Y, padding, math.max(padding, viewport.Y - size - padding))
    )
end

function App:EnableReopenButtonDragging(button)
    local dragging = false
    local activeInput = nil
    local startInput = nil
    local startPosition = nil
    local moved = false

    self:Track(button.InputBegan:Connect(function(input)
        local inputType = input.UserInputType
        if inputType ~= Enum.UserInputType.MouseButton1
            and inputType ~= Enum.UserInputType.Touch then
            return
        end

        dragging = true
        moved = false
        activeInput = input
        startInput = Vector2.new(input.Position.X, input.Position.Y)
        startPosition = Vector2.new(button.Position.X.Offset, button.Position.Y.Offset)
    end))

    self:Track(UserInputService.InputChanged:Connect(function(input)
        if not dragging or not activeInput then
            return
        end

        local correctInput = input == activeInput
            or (activeInput.UserInputType == Enum.UserInputType.MouseButton1
                and input.UserInputType == Enum.UserInputType.MouseMovement)

        if not correctInput then
            return
        end

        local current = Vector2.new(input.Position.X, input.Position.Y)
        local delta = current - startInput

        if delta.Magnitude >= 7 then
            moved = true
        end

        local target = self:ClampReopenButtonPosition(startPosition + delta)
        button.Position = UDim2.fromOffset(target.X, target.Y)
    end))

    self:Track(UserInputService.InputEnded:Connect(function(input)
        if not dragging then
            return
        end

        local finished = input == activeInput
            or input.UserInputType == Enum.UserInputType.MouseButton1
            or input.UserInputType == Enum.UserInputType.Touch

        if not finished then
            return
        end

        dragging = false
        activeInput = nil

        if moved then
            self.ReopenButtonHasBeenDragged = true
        else
            self:SetMinimized(false)
        end
    end))
end

function App:CreateReopenButton()
    local mobile = self:IsMobile()
    local defaultSize = mobile and 66 or 60
    local buttonSize = math.clamp(math.floor(tonumber(self.BubbleSize) or defaultSize), 48, 92)

    local button = Instance.new("TextButton")
    button.Name = "Reopen"
    button.Size = UDim2.fromOffset(buttonSize, buttonSize)
    button.BackgroundColor3 = self.Colors.Window
    button.BorderSizePixel = 0
    button.AutoButtonColor = false
    button.Text = ""
    button.Visible = false
    button.Active = true
    button.ZIndex = 5000
    button.Parent = self.Gui
    makeCorner(button, 999)
    makeStroke(button, self.Colors.Accent, 2, 0.02)

    local logo = Instance.new("ImageLabel")
    logo.Name = "Logo"
    logo.AnchorPoint = Vector2.new(0.5, 0.5)
    logo.Position = UDim2.fromScale(0.5, 0.5)
    logo.Size = UDim2.new(1, -8, 1, -8)
    logo.BackgroundTransparency = 1
    logo.ScaleType = Enum.ScaleType.Fit
    logo.Image = ""
    logo.ZIndex = 5002
    logo.Parent = button
    self:SetImageFromAsset(logo, self.Config.Assets and self.Config.Assets.Logo, "SN")

    self.ReopenButton = button
    self:EnableReopenButtonDragging(button)
end

function App:PositionReopenButton(forceDefault)
    if not self.ReopenButton then
        return
    end

    if self.ReopenButtonHasBeenDragged and not forceDefault then
        local current = Vector2.new(
            self.ReopenButton.Position.X.Offset,
            self.ReopenButton.Position.Y.Offset
        )
        local clamped = self:ClampReopenButtonPosition(current)
        self.ReopenButton.Position = UDim2.fromOffset(clamped.X, clamped.Y)
        return
    end

    local safePosition, safeSize = self:GetSafeRect()
    local buttonSize = self.ReopenButton.Size.X.Offset
    local defaultPosition = Vector2.new(
        safePosition.X + 10,
        safePosition.Y + math.max(10, (safeSize.Y - buttonSize) / 2)
    )
    local clamped = self:ClampReopenButtonPosition(defaultPosition)
    self.ReopenButton.Position = UDim2.fromOffset(clamped.X, clamped.Y)
end

function App:SetMinimized(state)
    self.IsMinimized = state and true or false

    if not self.IsMinimized and self.MinimizedByFreeRoam and self.Host then
        local recovery = self:GetRecoveryPosition()
        self.Host.Position = UDim2.fromOffset(recovery.X, recovery.Y)
        self.HasBeenDragged = true
        self.MinimizedByFreeRoam = false
    end

    if self.Host then
        self.Host.Visible = not self.IsMinimized
    end

    if self.ReopenButton then
        self.ReopenButton.Visible = self.IsMinimized
        if self.IsMinimized then
            self:PositionReopenButton(false)
        end
    end
end

----------------------------------------------------------
-- Sidebar and important notice
----------------------------------------------------------

function App:RefreshWindowModeControls()
    if self.MaximizeButton then
        self.MaximizeButton.Text = (self.IsMaximized or self.IsFullScreen) and "❐" or "□"
    end

    self:RefreshWindowSettings()
end

function App:SetFreeRoamEnabled(state)
    self.FreeRoamEnabled = state and true or false

    if self.Session then
        self.Session.FreeRoamEnabled = self.FreeRoamEnabled
    end

    if not self.FreeRoamEnabled and self.Host and not self.IsMaximized and not self.IsFullScreen then
        local current = Vector2.new(self.Host.Position.X.Offset, self.Host.Position.Y.Offset)
        local bounded = self:GetBoundedHostPosition(current)
        self.Host.Position = UDim2.fromOffset(bounded.X, bounded.Y)
        self:SaveLastSafePosition(bounded)
    end

    self:RefreshWindowSettings()
end

function App:SetFullScreen(state)
    local desired = state and true or false
    local recovery = nil

    if desired and self.Host and not self.IsMaximized then
        local current = Vector2.new(self.Host.Position.X.Offset, self.Host.Position.Y.Offset)
        if self:IsPositionFullyUsable(current) then
            self:SaveLastSafePosition(current)
        end
    elseif not desired then
        recovery = self:GetRecoveryPosition()
    end

    self.IsFullScreen = desired
    if desired then
        self.IsMaximized = false
    end

    if self.Session then
        self.Session.FullScreenEnabled = self.IsFullScreen
    end

    self.HasBeenDragged = false
    self:UpdateResponsive(true)

    if not desired and self.Host and recovery then
        local bounded = self:GetBoundedHostPosition(recovery)
        self.Host.Position = UDim2.fromOffset(bounded.X, bounded.Y)
        self.HasBeenDragged = true
        self:SaveLastSafePosition(bounded)
    end

    self:RefreshWindowModeControls()
end

function App:SetMaximized(state)
    local desired = state and true or false
    local recovery = nil

    if desired and self.Host and not self.IsFullScreen then
        local current = Vector2.new(self.Host.Position.X.Offset, self.Host.Position.Y.Offset)
        if self:IsPositionFullyUsable(current) then
            self:SaveLastSafePosition(current)
        end
    elseif not desired then
        recovery = self:GetRecoveryPosition()
    end

    self.IsMaximized = desired
    if desired then
        self.IsFullScreen = false
        if self.Session then
            self.Session.FullScreenEnabled = false
        end
    end

    self.HasBeenDragged = false
    self:UpdateResponsive(true)

    if not desired and self.Host and recovery then
        local bounded = self:GetBoundedHostPosition(recovery)
        self.Host.Position = UDim2.fromOffset(bounded.X, bounded.Y)
        self.HasBeenDragged = true
        self:SaveLastSafePosition(bounded)
    end

    self:RefreshWindowModeControls()
end

function App:ResetWindowPosition()
    if self.IsFullScreen then
        self:SetFullScreen(false)
    elseif self.IsMaximized then
        self:SetMaximized(false)
    end

    self.HasBeenDragged = false
    self:UpdateResponsive(true)

    if self.Host then
        local position = Vector2.new(self.Host.Position.X.Offset, self.Host.Position.Y.Offset)
        self:SaveLastSafePosition(position)
    end

    self:RefreshWindowSettings()
end

function App:BringToFront()
    if self.Gui then
        self.Gui.DisplayOrder = self.Config.DisplayOrder + 1
        task.defer(function()
            if self.Gui then
                self.Gui.DisplayOrder = self.Config.DisplayOrder
            end
        end)
    end

    self:SetMinimized(false)
end

function App:ShowCloseConfirmation()
    if not self.Window then
        return
    end

    if not self.CloseConfirmationEnabled then
        if self.Session then
            self.Session.UserClosed = true
        end
        self:Destroy(true)
        return
    end

    if self.CloseModal and self.CloseModal.Parent then
        self.CloseModal:Destroy()
    end

    local overlay = Instance.new("Frame")
    overlay.Name = "CloseConfirmation"
    overlay.Size = UDim2.fromScale(1, 1)
    overlay.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
    overlay.BackgroundTransparency = 0.30
    overlay.BorderSizePixel = 0
    overlay.Active = true
    overlay.ZIndex = 3600
    overlay.Parent = self.Window

    local panel = Instance.new("Frame")
    panel.AnchorPoint = Vector2.new(0.5, 0.5)
    panel.Position = UDim2.fromScale(0.5, 0.5)
    panel.Size = UDim2.fromOffset(self:IsMobile() and 470 or 440, 210)
    panel.BackgroundColor3 = self.Colors.Card
    panel.BorderSizePixel = 0
    panel.ZIndex = 3601
    panel.Parent = overlay
    makeCorner(panel, 18)
    makeStroke(panel, self.Colors.Close, 2, 0.04)

    self:CreateText(panel, "CLOSE SQUIDNOMO?", UDim2.new(1, -40, 0, 34), UDim2.fromOffset(20, 22), {
        Font = Enum.Font.GothamBlack,
        TextSize = 21,
        Color = self.Colors.Close,
        XAlignment = Enum.TextXAlignment.Center,
        ZIndex = 3602,
    })

    self:CreateText(panel, "The app will stay closed until you run the loader again in this server.", UDim2.new(1, -48, 0, 54), UDim2.fromOffset(24, 66), {
        Font = Enum.Font.Gotham,
        TextSize = 14,
        Color = self.Colors.Text,
        Wrapped = true,
        XAlignment = Enum.TextXAlignment.Center,
        ZIndex = 3602,
    })

    local cancel = Instance.new("TextButton")
    cancel.Position = UDim2.fromOffset(24, 142)
    cancel.Size = UDim2.new(0.5, -30, 0, 46)
    cancel.BackgroundColor3 = self.Colors.CardAlt
    cancel.BorderSizePixel = 0
    cancel.Font = Enum.Font.GothamBold
    cancel.Text = "CANCEL"
    cancel.TextSize = 15
    cancel.TextColor3 = self.Colors.Text
    cancel.ZIndex = 3602
    cancel.Parent = panel
    makeCorner(cancel, 11)

    local confirm = Instance.new("TextButton")
    confirm.Position = UDim2.new(0.5, 6, 0, 142)
    confirm.Size = UDim2.new(0.5, -30, 0, 46)
    confirm.BackgroundColor3 = self.Colors.Close
    confirm.BorderSizePixel = 0
    confirm.Font = Enum.Font.GothamBold
    confirm.Text = "CLOSE APP"
    confirm.TextSize = 15
    confirm.TextColor3 = Color3.fromRGB(255, 255, 255)
    confirm.ZIndex = 3602
    confirm.Parent = panel
    makeCorner(confirm, 11)
    self:BindButtonFeedback(cancel, self.Colors.Muted)
    self:BindButtonFeedback(confirm, self.Colors.Close)

    cancel.MouseButton1Click:Connect(function()
        overlay:Destroy()
        self.CloseModal = nil
    end)

    confirm.MouseButton1Click:Connect(function()
        if self.Session then
            self.Session.UserClosed = true
        end
        overlay:Destroy()
        self.CloseModal = nil
        self:Destroy(true)
    end)

    self.CloseModal = overlay
end

function App:SetDetectionStatus(status, detail)
    local normalized = string.upper(tostring(status or "UNKNOWN"))
    local allowed = {
        UNKNOWN = true,
        NO_DETECTION_SIGNALS = true,
        POSSIBLE_DETECTION = true,
        DETECTED = true,
    }

    if not allowed[normalized] then
        normalized = "UNKNOWN"
    end

    self.DetectionStatus = normalized
    self.DetectionDetail = tostring(detail or "")

    if self.Session then
        self.Session.DetectionStatus = normalized
        self.Session.DetectionDetail = self.DetectionDetail
    end

    self:RefreshStatusbar()
end

function App:ReportDetectionSignal(level, detail)
    local normalized = string.upper(tostring(level or "UNKNOWN"))
    if normalized == "POSSIBLE" then
        normalized = "POSSIBLE_DETECTION"
    elseif normalized == "NONE" or normalized == "CLEAR" then
        normalized = "NO_DETECTION_SIGNALS"
    end

    self:SetDetectionStatus(normalized, detail)
end

function App:SetAppStatus(status)
    self.AppStatus = string.upper(tostring(status or "READY"))
    self:RefreshStatusbar()
end

function App:RefreshStatusbar()
    if not self.FooterLabels then
        return
    end

    local display = {
        UNKNOWN = {Text = "STATUS: UNKNOWN", Color = self.Colors.Muted},
        NO_DETECTION_SIGNALS = {Text = "STATUS: NO DETECTION SIGNALS", Color = self.Colors.Success},
        POSSIBLE_DETECTION = {Text = "STATUS: POSSIBLE DETECTION", Color = self.Colors.Warning},
        DETECTED = {Text = "STATUS: DETECTED", Color = self.Colors.Error},
    }

    local current = display[self.DetectionStatus] or display.UNKNOWN

    if self.FooterLabels.Detection then
        self.FooterLabels.Detection.Text = current.Text
        self.FooterLabels.Detection.TextColor3 = current.Color
    end

    if self.FooterLabels.App then
        self.FooterLabels.App.Text = "APP: " .. tostring(self.AppStatus or "READY")
        self.FooterLabels.App.TextColor3 = self.AppStatus == "READY" and self.Colors.Success or self.Colors.Warning
    end
end

function App:CreateStatusbar()
    local bar = Instance.new("Frame")
    bar.Name = "Statusbar"
    bar.AnchorPoint = Vector2.new(0, 1)
    bar.Position = UDim2.new(0, 0, 1, 0)
    bar.Size = UDim2.new(1, 0, 0, self.Config.StatusbarHeight)
    bar.BackgroundColor3 = self.Colors.Topbar
    bar.BackgroundTransparency = math.min(0.45, 0.03 + ((self.WindowOpacity or 0) * 0.65))
    bar.BorderSizePixel = 0
    bar.ZIndex = 1040
    bar.Parent = self.Window

    local line = Instance.new("Frame")
    line.Size = UDim2.new(1, 0, 0, 1)
    line.BackgroundColor3 = self.Colors.BorderSoft
    line.BorderSizePixel = 0
    line.ZIndex = 1041
    line.Parent = bar

    local copyright = self:CreateText(bar, "© 2026 SquidNoMo. All rights reserved.", UDim2.fromOffset(self.Config.SidebarWidth - 16, self.Config.StatusbarHeight), UDim2.fromOffset(16, 0), {
        Font = Enum.Font.Gotham,
        TextSize = self:IsMobile() and 9 or 10,
        Color = self.Colors.Muted,
        ZIndex = 1042,
    })

    local keyless = self:CreateText(bar, "FULLY KEYLESS", UDim2.fromOffset(180, self.Config.StatusbarHeight), UDim2.fromOffset(self.Config.SidebarWidth + 24, 0), {
        Font = Enum.Font.GothamBold,
        TextSize = self:IsMobile() and 10 or 11,
        Color = self.Colors.Success,
        XAlignment = Enum.TextXAlignment.Center,
        ZIndex = 1042,
    })

    local detection = self:CreateText(bar, "STATUS: UNKNOWN", UDim2.new(1, -(self.Config.SidebarWidth + 390), 1, 0), UDim2.fromOffset(self.Config.SidebarWidth + 205, 0), {
        Font = Enum.Font.GothamBold,
        TextSize = self:IsMobile() and 10 or 11,
        Color = self.Colors.Muted,
        XAlignment = Enum.TextXAlignment.Center,
        ZIndex = 1042,
    })

    local appStatus = self:CreateText(bar, "APP: STARTING", UDim2.fromOffset(180, self.Config.StatusbarHeight), UDim2.new(1, -196, 0, 0), {
        Font = Enum.Font.GothamBold,
        TextSize = self:IsMobile() and 10 or 11,
        Color = self.Colors.Warning,
        XAlignment = Enum.TextXAlignment.Center,
        ZIndex = 1042,
    })

    self.Statusbar = bar
    self.FooterLabels = {
        Copyright = copyright,
        Keyless = keyless,
        Detection = detection,
        App = appStatus,
    }
    self:RefreshStatusbar()
end

function App:StartDetectionMonitor()
    pcall(function()
        self:Track(GuiService.ErrorMessageChanged:Connect(function(message)
            local value = string.lower(tostring(message or ""))
            if value == "" then
                return
            end

            if string.find(value, "detected", 1, true)
                or string.find(value, "anti-cheat", 1, true)
                or string.find(value, "exploit", 1, true)
                or string.find(value, "unauthorized", 1, true) then
                self:SetDetectionStatus("DETECTED", message)
            elseif string.find(value, "banned", 1, true)
                or string.find(value, "suspended", 1, true)
                or string.find(value, "kicked", 1, true) then
                self:SetDetectionStatus("POSSIBLE_DETECTION", message)
            end
        end))
    end)

    task.delay(2, function()
        if self.Gui and self.DetectionStatus == "UNKNOWN" then
            self:SetDetectionStatus("NO_DETECTION_SIGNALS", "No explicit detection message has been observed.")
        end
    end)
end

function App:CreateSidebar()
    local mobile = self:IsMobile()
    local sidebarWidth = self.Config.SidebarWidth
    local headerHeight = mobile and 84 or 92

    local sidebar = Instance.new("Frame")
    sidebar.Name = "Sidebar"
    sidebar.Size = UDim2.new(0, sidebarWidth, 1, -self.Config.StatusbarHeight)
    sidebar.BackgroundColor3 = self.Colors.Sidebar
    sidebar.BackgroundTransparency = (self.WindowOpacity or 0) * 0.65
    sidebar.BorderSizePixel = 0
    sidebar.ZIndex = 1010
    sidebar.Parent = self.Window

    local rightBorder = Instance.new("Frame")
    rightBorder.AnchorPoint = Vector2.new(1, 0)
    rightBorder.Position = UDim2.new(1, 0, 0, 0)
    rightBorder.Size = UDim2.new(0, 1, 1, 0)
    rightBorder.BackgroundColor3 = self.Colors.BorderSoft
    rightBorder.BorderSizePixel = 0
    rightBorder.ZIndex = 1011
    rightBorder.Parent = sidebar

    local logoSize = mobile and 54 or 60
    local logoFrame = Instance.new("Frame")
    logoFrame.Position = UDim2.fromOffset(16, mobile and 13 or 16)
    logoFrame.Size = UDim2.fromOffset(logoSize, logoSize)
    logoFrame.BackgroundColor3 = Color3.fromRGB(14, 10, 21)
    logoFrame.BorderSizePixel = 0
    logoFrame.ZIndex = 1012
    logoFrame.Parent = sidebar
    makeCorner(logoFrame, 999)
    makeStroke(logoFrame, self.Colors.Accent, 2, 0.04)

    local logoImage = Instance.new("ImageLabel")
    logoImage.Name = "LogoImage"
    logoImage.AnchorPoint = Vector2.new(0.5, 0.5)
    logoImage.Position = UDim2.fromScale(0.5, 0.5)
    logoImage.Size = UDim2.new(1, -6, 1, -6)
    logoImage.BackgroundTransparency = 1
    logoImage.ScaleType = Enum.ScaleType.Fit
    logoImage.Image = ""
    logoImage.ZIndex = 1014
    logoImage.Parent = logoFrame
    self:SetImageFromAsset(logoImage, self.Config.Assets and self.Config.Assets.Logo, "SN")

    local brandX = 82
    local brand = Instance.new("TextLabel")
    brand.BackgroundTransparency = 1
    brand.Position = UDim2.fromOffset(brandX, mobile and 16 or 18)
    brand.Size = UDim2.new(1, -(brandX + 10), 0, 27)
    brand.Font = Enum.Font.GothamBlack
    brand.Text = "SQUIDNOMO"
    brand.TextSize = mobile and 18 or 17
    brand:SetAttribute("SquidReadableText", true)
    brand.TextColor3 = self.Colors.Text
    brand.TextXAlignment = Enum.TextXAlignment.Left
    brand.ZIndex = 1012
    brand.Parent = sidebar

    local keyless = Instance.new("TextLabel")
    keyless.BackgroundTransparency = 1
    keyless.Position = UDim2.fromOffset(brandX, mobile and 40 or 44)
    keyless.Size = UDim2.new(1, -(brandX + 10), 0, 16)
    keyless.Font = Enum.Font.GothamBold
    keyless.Text = "FULLY KEYLESS"
    keyless.TextSize = mobile and 12 or 11
    keyless:SetAttribute("SquidReadableText", true)
    keyless.TextColor3 = self.Colors.Accent
    keyless.TextXAlignment = Enum.TextXAlignment.Left
    keyless.ZIndex = 1012
    keyless.Parent = sidebar

    local version = Instance.new("TextLabel")
    version.BackgroundTransparency = 1
    version.Position = UDim2.fromOffset(brandX, mobile and 56 or 61)
    version.Size = UDim2.new(1, -(brandX + 10), 0, 15)
    version.Font = Enum.Font.GothamMedium
    version.Text = self.Version
    version.TextSize = mobile and 11 or 10
    version:SetAttribute("SquidReadableText", true)
    version.TextColor3 = self.Colors.Muted
    version.TextXAlignment = Enum.TextXAlignment.Left
    version.ZIndex = 1012
    version.Parent = sidebar

    local sidebarDragHandle = Instance.new("TextButton")
    sidebarDragHandle.Name = "SidebarDragHandle"
    sidebarDragHandle.Position = UDim2.fromOffset(0, 0)
    sidebarDragHandle.Size = UDim2.fromOffset(sidebarWidth, headerHeight)
    sidebarDragHandle.BackgroundTransparency = 1
    sidebarDragHandle.BorderSizePixel = 0
    sidebarDragHandle.AutoButtonColor = false
    sidebarDragHandle.Text = ""
    sidebarDragHandle.ZIndex = 1018
    sidebarDragHandle.Parent = sidebar
    self:EnableDragging(sidebarDragHandle)

    self.NavigationButtonHeight = self.Profile.NavigationButtonHeight
    self.NavigationButtonPadding = self.Profile.NavigationPadding

    local navTop = headerHeight + 6
    local panelHeight = self.Profile.SupportPanelHeight
    local supportTop = self.Profile.DesignHeight
        - self.Config.StatusbarHeight
        - 10
        - panelHeight
    local availableNavHeight = math.max(280, supportTop - navTop - 12)
    local requestedNavHeight = (self.NavigationButtonHeight * 8)
        + (self.NavigationButtonPadding * 7)

    if requestedNavHeight > availableNavHeight then
        self.NavigationButtonHeight = math.max(
            36,
            math.floor(
                (availableNavHeight - (self.NavigationButtonPadding * 7)) / 8
            )
        )
        requestedNavHeight = (self.NavigationButtonHeight * 8)
            + (self.NavigationButtonPadding * 7)
    end

    local nav = Instance.new("Frame")
    nav.Name = "Navigation"
    nav.Position = UDim2.fromOffset(12, navTop)
    nav.Size = UDim2.new(1, -24, 0, requestedNavHeight)
    nav.BackgroundTransparency = 1
    nav.ZIndex = 1012
    nav.Parent = sidebar

    local layout = Instance.new("UIListLayout")
    layout.Padding = UDim.new(0, self.NavigationButtonPadding)
    layout.SortOrder = Enum.SortOrder.LayoutOrder
    layout.Parent = nav

    self.Sidebar = sidebar
    self.NavigationHolder = nav
    self:CreateSidebarNotice(sidebar)
end

function App:ResolveImageAsset(relativePath)
    if not relativePath or relativePath == "" then
        return nil
    end

    if self.AssetCache[relativePath] then
        return self.AssetCache[relativePath]
    end

    local customAsset = nil
    if type(getcustomasset) == "function" then
        customAsset = getcustomasset
    elseif type(getsynasset) == "function" then
        customAsset = getsynasset
    end

    if not customAsset or type(writefile) ~= "function" then
        return nil
    end

    local folder = "SquidNoMo"
    local imageFolder = folder .. "/Images"
    local filename = string.match(relativePath, "([^/]+)$") or "Asset.png"
    local cacheVersion = tostring(self.Config.AssetVersion or self.Version or "current")
        :gsub("[^%w_%-]", "_")
    local localPath = imageFolder .. "/" .. cacheVersion .. "_" .. filename

    pcall(function()
        if type(isfolder) == "function" and type(makefolder) == "function" then
            if not isfolder(folder) then makefolder(folder) end
            if not isfolder(imageFolder) then makefolder(imageFolder) end
        end
    end)

    local shouldDownload = true
    if type(isfile) == "function" then
        pcall(function()
            shouldDownload = not isfile(localPath)
        end)
    end

    if shouldDownload then
        local base = self.Loader and self.Loader.Config and self.Loader.Config.Repository
        if not base then
            return nil
        end

        local ok, data = pcall(function()
            return game:HttpGet(base .. relativePath)
        end)

        if not ok or type(data) ~= "string" or #data == 0 then
            return nil
        end

        local wrote = pcall(function()
            writefile(localPath, data)
        end)

        if not wrote then
            return nil
        end
    end

    local ok, asset = pcall(function()
        return customAsset(localPath)
    end)

    if ok and asset then
        self.AssetCache[relativePath] = asset
        return asset
    end

    return nil
end

function App:ResolveSupportImage(relativePath)
    return self:ResolveImageAsset(relativePath)
end

function App:SetImageFromAsset(imageLabel, relativePath, fallbackText)
    if not imageLabel then
        return
    end

    local fallback = nil
    if fallbackText and fallbackText ~= "" then
        fallback = Instance.new("TextLabel")
        fallback.Name = "AssetFallback"
        fallback.Size = UDim2.fromScale(1, 1)
        fallback.BackgroundTransparency = 1
        fallback.Font = Enum.Font.GothamBold
        fallback.Text = fallbackText
        fallback.TextScaled = true
        fallback.TextColor3 = self.Colors.Text
        fallback.ZIndex = imageLabel.ZIndex + 1
        fallback.Parent = imageLabel
    end

    task.spawn(function()
        local asset = self:ResolveImageAsset(relativePath)
        if not imageLabel.Parent then
            return
        end

        if asset then
            imageLabel.Image = asset
            imageLabel.Visible = true
            if fallback then
                fallback:Destroy()
            end
        else
            imageLabel.Visible = true
        end
    end)
end

function App:ShowSupportQR(serviceName, tag, relativePath, accentColor)
    if not self.Window then
        return
    end

    if self.SupportModal and self.SupportModal.Parent then
        self.SupportModal:Destroy()
    end

    local overlay = Instance.new("Frame")
    overlay.Name = "SupportOverlay"
    overlay.Size = UDim2.fromScale(1, 1)
    overlay.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
    overlay.BackgroundTransparency = 0.36
    overlay.BorderSizePixel = 0
    overlay.Active = true
    overlay.ZIndex = 3200
    overlay.Parent = self.Window

    local modalWidth = self:IsMobile() and 430 or 420
    local qrHolderSize = modalWidth - 56
    local qrHolderY = 62
    local tagY = qrHolderY + qrHolderSize + 8
    local buttonY = tagY + 36
    local modalHeight = buttonY + 48

    local modal = Instance.new("Frame")
    modal.AnchorPoint = Vector2.new(0.5, 0.5)
    modal.Position = UDim2.fromScale(0.5, 0.52)
    modal.Size = UDim2.fromOffset(modalWidth, modalHeight)
    modal.BackgroundColor3 = Color3.fromRGB(15, 11, 23)
    modal.BorderSizePixel = 0
    modal.ZIndex = 3201
    modal.Parent = overlay
    makeCorner(modal, 20)
    makeStroke(modal, accentColor or self.Colors.Accent, 1.5, 0.02)

    local supportDragHandle = Instance.new("TextButton")
    supportDragHandle.Name = "SupportDragHandle"
    supportDragHandle.Position = UDim2.fromOffset(0, 0)
    supportDragHandle.Size = UDim2.new(1, -74, 0, 58)
    supportDragHandle.BackgroundTransparency = 1
    supportDragHandle.BorderSizePixel = 0
    supportDragHandle.AutoButtonColor = false
    supportDragHandle.Text = ""
    supportDragHandle.ZIndex = 3204
    supportDragHandle.Parent = modal
    self:EnableDragging(supportDragHandle)

    self:CreateText(modal, "SUPPORT VIA " .. string.upper(serviceName), UDim2.new(1, -80, 0, 34), UDim2.fromOffset(24, 18), {
        Font = Enum.Font.GothamBlack,
        TextSize = 20,
        Color = accentColor or self.Colors.Accent,
        ZIndex = 3202,
    })

    local close = Instance.new("TextButton")
    close.AnchorPoint = Vector2.new(1, 0)
    close.Position = UDim2.new(1, -18, 0, 16)
    close.Size = UDim2.fromOffset(36, 36)
    close.BackgroundColor3 = self.Colors.CardAlt
    close.BorderSizePixel = 0
    close.AutoButtonColor = false
    close.Font = Enum.Font.GothamBold
    close.Text = "×"
    close.TextSize = 20
    close.TextColor3 = self.Colors.Text
    close.ZIndex = 3202
    close.Parent = modal
    makeCorner(close, 10)

    local imageHolder = Instance.new("Frame")
    imageHolder.Position = UDim2.fromOffset(28, qrHolderY)
    imageHolder.Size = UDim2.fromOffset(qrHolderSize, qrHolderSize)
    imageHolder.BackgroundColor3 = Color3.fromRGB(255,255,255)
    imageHolder.BorderSizePixel = 0
    imageHolder.ClipsDescendants = true
    imageHolder.ZIndex = 3202
    imageHolder.Parent = modal
    makeCorner(imageHolder, 16)

    local qrImage = Instance.new("ImageLabel")
    qrImage.BackgroundTransparency = 1
    qrImage.Position = UDim2.fromOffset(4, 4)
    qrImage.Size = UDim2.new(1, -8, 1, -8)
    qrImage.ScaleType = Enum.ScaleType.Fit
    pcall(function()
        qrImage.ResampleMode = Enum.ResamplerMode.Pixelated
    end)
    qrImage.Image = ""
    qrImage.ZIndex = 3203
    qrImage.Parent = imageHolder

    local loading = self:CreateText(imageHolder, "Loading QR code...", UDim2.fromScale(1, 1), UDim2.fromOffset(0, 0), {
        Font = Enum.Font.GothamMedium,
        TextSize = 14,
        Color = self.Colors.Dim,
        XAlignment = Enum.TextXAlignment.Center,
        ZIndex = 3204,
    })

    self:CreateText(modal, serviceName .. ": " .. tostring(tag or ""), UDim2.new(1, -56, 0, 28), UDim2.fromOffset(28, tagY), {
        Font = Enum.Font.GothamBold,
        TextSize = 15,
        Color = self.Colors.Text,
        XAlignment = Enum.TextXAlignment.Center,
        ZIndex = 3202,
    })

    local copyButton = Instance.new("TextButton")
    copyButton.Position = UDim2.fromOffset(28, buttonY)
    copyButton.Size = UDim2.new(1, -56, 0, 34)
    copyButton.BackgroundColor3 = accentColor or self.Colors.Accent
    copyButton.BorderSizePixel = 0
    copyButton.AutoButtonColor = false
    copyButton.Font = Enum.Font.GothamBold
    copyButton.Text = "COPY " .. string.upper(serviceName)
    copyButton.TextSize = 13
    copyButton.TextColor3 = Color3.fromRGB(255,255,255)
    copyButton.ZIndex = 3202
    copyButton.Parent = modal
    makeCorner(copyButton, 10)
    self:BindButtonFeedback(close, self.Colors.Close)
    self:BindButtonFeedback(copyButton, accentColor or self.Colors.Accent)

    close.MouseButton1Click:Connect(function()
        overlay:Destroy()
        self.SupportModal = nil
    end)

    copyButton.MouseButton1Click:Connect(function()
        local copied = false
        if type(setclipboard) == "function" then
            pcall(function()
                setclipboard(tostring(tag or ""))
                copied = true
            end)
        end

        if self.Notifications then
            if copied and type(self.Notifications.Success) == "function" then
                self.Notifications:Success("Support", serviceName .. " copied to clipboard", 3)
            elseif type(self.Notifications.Info) == "function" then
                self.Notifications:Info("Support", serviceName .. ": " .. tostring(tag or ""), 4)
            end
        end
    end)

    task.spawn(function()
        local asset = self:ResolveSupportImage(relativePath)
        if not imageHolder.Parent then
            return
        end

        if asset then
            qrImage.Image = asset
            loading.Visible = false
        else
            loading.Text = "QR image unavailable in this runtime. Use the tag below."
            loading.TextWrapped = true
            loading.Size = UDim2.new(1, -40, 1, -40)
            loading.Position = UDim2.fromOffset(20, 20)
        end
    end)

    self.SupportModal = overlay
end

function App:CreateSidebarNotice(sidebar)
    local mobile = self:IsMobile()
    local panelHeight = self.Profile.SupportPanelHeight

    local panel = Instance.new("Frame")
    panel.Name = "SupportPanel"
    panel.AnchorPoint = Vector2.new(0, 1)
    panel.Position = UDim2.new(0, 12, 1, -10)
    panel.Size = UDim2.new(1, -24, 0, panelHeight)
    panel.BackgroundColor3 = Color3.fromRGB(16, 12, 24)
    panel.BorderSizePixel = 0
    panel.ZIndex = 1012
    panel.Parent = sidebar
    makeCorner(panel, 14)
    makeStroke(panel, self.Colors.Border, 1.2, 0.10)

    local title = Instance.new("TextLabel")
    title.BackgroundTransparency = 1
    title.Position = UDim2.fromOffset(14, 11)
    title.Size = UDim2.new(1, -28, 0, 22)
    title.Font = Enum.Font.GothamBold
    title.Text = "SUPPORT THE PROJECT"
    title.TextSize = mobile and 13 or 13
    title:SetAttribute("SquidReadableText", true)
    title.TextColor3 = self.Colors.Accent
    title.TextXAlignment = Enum.TextXAlignment.Left
    title.ZIndex = 1013
    title.Parent = panel

    local body = Instance.new("TextLabel")
    body.BackgroundTransparency = 1
    body.Position = UDim2.fromOffset(14, 37)
    body.Size = UDim2.new(1, -28, 0, mobile and 58 or 70)
    body.Font = Enum.Font.Gotham
    body.Text = "Your support helps fund updates, hosting, and testing. Every contribution keeps SquidNoMo improving."
    body.TextWrapped = true
    body.TextSize = mobile and 12 or 11
    body:SetAttribute("SquidReadableText", true)
    body.TextColor3 = self.Colors.Text
    body.TextXAlignment = Enum.TextXAlignment.Left
    body.TextYAlignment = Enum.TextYAlignment.Top
    body.ZIndex = 1013
    body.Parent = panel

    local function notifySupport(titleText, message, kind)
        if self.Notifications and type(self.Notifications[kind or "Info"]) == "function" then
            pcall(function()
                self.Notifications[kind or "Info"](self.Notifications, titleText, message, 4)
            end)
        end
    end

    local buttonHeight = mobile and 32 or 34
    local gap = 6
    local paypalY = panelHeight - 12 - buttonHeight
    local cashY = paypalY - gap - buttonHeight

    local function createSupportButton(y, labelText, buttonColor, value, qrPath)
        local button = Instance.new("TextButton")
        button.Position = UDim2.fromOffset(14, y)
        button.Size = UDim2.new(1, -28, 0, buttonHeight)
        button.BackgroundColor3 = buttonColor
        button.BorderSizePixel = 0
        button.AutoButtonColor = false
        button.Font = Enum.Font.GothamBold
        button.Text = labelText
        button.TextSize = mobile and 13 or 12
        button:SetAttribute("SquidReadableText", true)
        button.TextColor3 = Color3.fromRGB(255,255,255)
        button.ZIndex = 1013
        button.Parent = panel
        makeCorner(button, 9)
        makeStroke(button, buttonColor, 1, 0.25)

        button.Activated:Connect(function()
            if value and value ~= "" and not string.find(value, "REPLACE_") then
                self:ShowSupportQR(labelText, value, qrPath, buttonColor)
            else
                notifySupport("Support", "Update App.Config.Support with your real " .. labelText .. " details.", "Warning")
            end
        end)
    end

    createSupportButton(cashY, "Cash App", self.Colors.CashApp, self.Config.Support and self.Config.Support.CashApp, self.Config.Support and self.Config.Support.CashAppQR)
    createSupportButton(paypalY, "PayPal", self.Colors.PayPal, self.Config.Support and self.Config.Support.PayPal, self.Config.Support and self.Config.Support.PayPalQR)
end

function App:CreateNavigationButton(definition)
    local button = Instance.new("TextButton")
    button.Name = definition.Name
    local mobile = self:IsMobile()
    local buttonHeight = self.NavigationButtonHeight or 48
    local accent = self:GetPageAccent(definition.Name)

    button.Size = UDim2.new(1, 0, 0, buttonHeight)
    button.BackgroundColor3 = self.Colors.Sidebar
    button.BackgroundTransparency = 0
    button.BorderSizePixel = 0
    button.AutoButtonColor = false
    button.Text = ""
    button.LayoutOrder = definition.Order or 0
    button.ZIndex = 1014
    button.Parent = self.NavigationHolder
    makeCorner(button, 12)

    local selectedStroke = makeStroke(button, accent, 2, 1)

    local selectedGlow = Instance.new("Frame")
    selectedGlow.Name = "SelectedGlow"
    selectedGlow.AnchorPoint = Vector2.new(0.5, 0.5)
    selectedGlow.Position = UDim2.fromScale(0.5, 0.5)
    selectedGlow.Size = UDim2.new(1, 8, 1, 8)
    selectedGlow.BackgroundColor3 = accent
    selectedGlow.BackgroundTransparency = 0.86
    selectedGlow.BorderSizePixel = 0
    selectedGlow.Visible = false
    selectedGlow.ZIndex = 1013
    selectedGlow.Parent = button
    makeCorner(selectedGlow, 14)

    local icon = Instance.new("Frame")
    local iconSize = mobile and 28 or 30
    icon.Position = UDim2.fromOffset(12, math.floor((buttonHeight - iconSize) / 2))
    icon.Size = UDim2.fromOffset(iconSize, iconSize)
    icon.BackgroundColor3 = self.Colors.CardAlt
    icon.BorderSizePixel = 0
    icon.ZIndex = 1015
    icon.Parent = button
    makeCorner(icon, 9)

    local iconImage = Instance.new("ImageLabel")
    iconImage.Name = "TabIcon"
    iconImage.AnchorPoint = Vector2.new(0.5, 0.5)
    iconImage.Position = UDim2.fromScale(0.5, 0.5)
    iconImage.Size = UDim2.new(1, -7, 1, -7)
    iconImage.BackgroundTransparency = 1
    iconImage.Image = ""
    iconImage.ImageColor3 = self.Colors.Text
    iconImage.ScaleType = Enum.ScaleType.Fit
    iconImage.ZIndex = 1016
    iconImage.Parent = icon

    local tabPath = self.Config.Assets
        and self.Config.Assets.Tabs
        and self.Config.Assets.Tabs[definition.Name]
    self:SetImageFromAsset(iconImage, tabPath, string.sub(definition.Name, 1, 1))

    local label = Instance.new("TextLabel")
    label.BackgroundTransparency = 1
    label.Position = UDim2.fromOffset(52, 0)
    label.Size = UDim2.new(1, -62, 1, 0)
    label.Font = Enum.Font.GothamMedium
    label.Text = definition.Name
    label.TextSize = mobile and 18 or 15
    label:SetAttribute("SquidReadableText", true)
    label.TextColor3 = self.Colors.Text
    label.TextXAlignment = Enum.TextXAlignment.Left
    label.ZIndex = 1015
    label.Parent = button

    local function setSelected(selected)
        selectedGlow.Visible = selected and self.NavigationGlowEnabled
        self:Tween(button, {
            BackgroundColor3 = selected and accent or self.Colors.Sidebar,
            BackgroundTransparency = selected and 0.72 or 0,
        }, 0.16)
        self:Tween(selectedStroke, {
            Color = accent,
            Transparency = selected and 0.04 or 1,
            Thickness = selected and 2 or 1,
        }, 0.16)
        self:Tween(icon, {
            BackgroundColor3 = selected and Color3.fromRGB(255, 255, 255) or self.Colors.CardAlt,
        }, 0.16)
        self:Tween(iconImage, {
            ImageColor3 = selected and accent or self.Colors.Text,
        }, 0.16)
        self:Tween(label, {
            TextColor3 = selected and Color3.fromRGB(255, 255, 255) or self.Colors.Text,
        }, 0.16)
    end

    button.MouseEnter:Connect(function()
        if self.CurrentPage ~= definition.Name then
            self:Tween(button, {BackgroundColor3 = self.Colors.Card}, 0.12)
        end
    end)

    button.MouseLeave:Connect(function()
        if self.CurrentPage ~= definition.Name then
            self:Tween(button, {
                BackgroundColor3 = self.Colors.Sidebar,
                BackgroundTransparency = 0,
            }, 0.12)
        end
    end)

    button.Activated:Connect(function()
        self:PulseGlow(button, accent)
        self:OpenPage(definition.Name)
    end)

    self.NavigationButtons[definition.Name] = {
        Instance = button,
        SetSelected = setSelected,
        Accent = accent,
    }
end

----------------------------------------------------------
-- Page container and modular registry
----------------------------------------------------------

function App:CreatePageContainer()
    local container = Instance.new("Frame")
    container.Name = "PageContainer"
    container.Position = UDim2.fromOffset(
        self.Config.SidebarWidth,
        self.Config.TopbarHeight
    )
    container.Size = UDim2.new(
        1,
        -self.Config.SidebarWidth,
        1,
        -(self.Config.TopbarHeight + self.Config.StatusbarHeight)
    )
    container.BackgroundColor3 = self.Colors.Backdrop
    container.BackgroundTransparency = (self.WindowOpacity or 0) * 0.65
    container.BorderSizePixel = 0
    container.ClipsDescendants = true
    container.ZIndex = 1005
    container.Parent = self.Window

    self.PageContainer = container
end

function App:RegisterPage(name, icon, builder, order)
    for index, definition in ipairs(self.PageDefinitions) do
        if definition.Name == name then
            definition.Icon = icon or definition.Icon
            definition.Builder = builder or definition.Builder
            definition.Order = order or definition.Order
            return definition
        end
    end

    local definition = {
        Name = name,
        Icon = icon or string.sub(name, 1, 1),
        Builder = builder,
        Order = order or (#self.PageDefinitions + 1),
    }

    table.insert(self.PageDefinitions, definition)
    return definition
end

function App:InstallPageTouchScroll(page)
    if not page or page:GetAttribute("SquidNoMoUniversalScroll") then return end
    page:SetAttribute("SquidNoMoUniversalScroll", true)

    -- Roblox's native ScrollingFrame gesture can fight sliders and nested horizontal
    -- category bars on some mobile executors. This direction-locked handler only
    -- takes control after a clear vertical gesture and restores native scrolling at
    -- the end of the touch.
    local activeTouch = nil
    local touchOrigin = nil
    local dragOrigin = nil
    local canvasOrigin = nil
    local vertical = false
    local priorScrollingEnabled = true

    local function inside(position)
        local point = Vector2.new(position.X, position.Y)
        local minimum = page.AbsolutePosition
        local maximum = minimum + page.AbsoluteSize
        return point.X >= minimum.X and point.X <= maximum.X
            and point.Y >= minimum.Y and point.Y <= maximum.Y
    end

    local function maxCanvasY()
        local canvasHeight = math.max(
            page.AbsoluteCanvasSize.Y,
            page.CanvasSize.Y.Offset + page.CanvasSize.Y.Scale * page.AbsoluteSize.Y
        )
        local windowHeight = page.AbsoluteWindowSize.Y > 0
            and page.AbsoluteWindowSize.Y
            or page.AbsoluteSize.Y
        return math.max(0, canvasHeight - windowHeight)
    end

    local function beginTouch(input)
        if input.UserInputType ~= Enum.UserInputType.Touch
            or not page.Visible
            or activeTouch
            or not inside(input.Position)
        then
            return
        end
        activeTouch = input
        touchOrigin = input.Position
        dragOrigin = nil
        canvasOrigin = nil
        vertical = false
        priorScrollingEnabled = page.ScrollingEnabled
    end

    local function moveTouch(input)
        if not activeTouch or input ~= activeTouch or not page.Visible then return end
        local delta = input.Position - (touchOrigin or input.Position)
        if not vertical then
            if math.abs(delta.Y) < 10 then return end
            if math.abs(delta.Y) <= math.abs(delta.X) * 1.08 then return end
            vertical = true
            dragOrigin = input.Position
            canvasOrigin = page.CanvasPosition
            page.ScrollingEnabled = false
            page:SetAttribute("SquidNoMoTouchDragging", true)
        end
        local travel = input.Position - dragOrigin
        page.CanvasPosition = Vector2.new(
            0,
            math.clamp(canvasOrigin.Y - travel.Y, 0, maxCanvasY())
        )
    end

    local function endTouch(input)
        if not activeTouch or input ~= activeTouch then return end
        activeTouch = nil
        touchOrigin = nil
        dragOrigin = nil
        canvasOrigin = nil
        vertical = false
        page.ScrollingEnabled = priorScrollingEnabled ~= false
        task.delay(0.05, function()
            if page and page.Parent then
                page:SetAttribute("SquidNoMoTouchDragging", false)
            end
        end)
    end

    self:Track(UserInputService.InputBegan:Connect(beginTouch))
    self:Track(UserInputService.InputChanged:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.Touch then
            moveTouch(input)
        elseif input.UserInputType == Enum.UserInputType.MouseWheel
            and page.Visible
            and inside(input.Position)
        then
            page.CanvasPosition = Vector2.new(
                0,
                math.clamp(page.CanvasPosition.Y - input.Position.Z * 64, 0, maxCanvasY())
            )
        end
    end))
    self:Track(UserInputService.InputEnded:Connect(endTouch))
end

function App:CreatePage(name)
    local page = Instance.new("ScrollingFrame")
    page.Name = name
    page.Size = UDim2.fromScale(1, 1)
    page.BackgroundTransparency = 1
    page.BorderSizePixel = 0
    page.CanvasSize = UDim2.new(0, 0, 0, 0)
    page.AutomaticCanvasSize = Enum.AutomaticSize.Y
    page.ScrollBarThickness = math.max(
        self:IsMobile() and 6 or 5,
        tonumber(self:GetUIStyleValue(
            name,
            "ScrollbarThickness",
            "MainPage"
        )) or 5
    )
    page.ScrollBarImageColor3 = self:GetPageAccent(name)
    page.ScrollBarImageTransparency = 0.12
    page.ScrollingDirection = Enum.ScrollingDirection.Y
    page.ScrollingEnabled = true
    page.ElasticBehavior = Enum.ElasticBehavior.WhenScrollable
    page.Active = true
    page.Visible = false
    page.ZIndex = 1006
    page.Parent = self.PageContainer
    self:InstallPageTouchScroll(page)

    self.Pages[name] = page
    return page
end

function App:BuildPageDefinitions()
    self.PageDefinitions = {}

    self:RegisterPage("Home", "H", function(page)
        self:BuildHome(page)
    end, 1)

    self:RegisterPage("Games", "GM", function(page)
        self:BuildExternalPage(page, self.Loader.Games, "Games")
    end, 2)

    self:RegisterPage("Players", "PL", function(page)
        self:BuildExternalPage(page, self.Loader.Players, "Players")
    end, 3)

    self:RegisterPage("Guards", "GD", function(page)
        self:BuildExternalPage(page, self.Loader.Guards, "Guards")
    end, 4)

    self:RegisterPage("Detective", "DT", function(page)
        self:BuildExternalPage(page, self.Loader.Detective, "Detective")
    end, 5)

    self:RegisterPage("Farming", "FM", function(page)
        self:BuildExternalPage(page, self.Loader.Farming, "Farming")
    end, 6)

    self:RegisterPage("UI", "UI", function(page)
        self:BuildExternalPage(page, self.Loader.UI or self.Loader.VIP, "UI")
    end, 7)

    self:RegisterPage("Settings", "ST", function(page)
        self:BuildSettingsPage(page)
    end, 8)

    if type(self.Loader.Pages) == "table" then
        for _, entry in ipairs(self.Loader.Pages) do
            if type(entry) == "table" and entry.Name then
                self:RegisterPage(entry.Name, entry.Icon, entry.Builder, entry.Order)
            end
        end
    end

    table.sort(self.PageDefinitions, function(a, b)
        return (a.Order or 0) < (b.Order or 0)
    end)
end

function App:BuildPages()
    for _, definition in ipairs(self.PageDefinitions) do
        self:CreateNavigationButton(definition)
        local page = self:CreatePage(definition.Name)

        local ok, err = self:SafeCall(definition.Name .. " page", function()
            if type(definition.Builder) == "function" then
                definition.Builder(page, self)
            else
                self:BuildPlaceholder(page, definition.Name, "No page builder was registered.")
            end
        end)

        if not ok then
            page:ClearAllChildren()
            self:BuildErrorPage(page, definition.Name, err)
        end
    end
end

function App:BuildExternalPage(page, module, pageName)
    if type(module) == "table" and type(module.Create) == "function" then
        module:Create(page, self)
        return
    end

    self:BuildPlaceholder(
        page,
        pageName,
        "This module has not been connected yet. The universal app shell is running correctly."
    )
end

function App:CreateWindowToggleCard(parent, title, description, color, layoutOrder, getter, setter)
    local phone = self.DeviceClass == "Phone"
    local card = self:CreateCard(parent, UDim2.new(0.333333, -8, 1, 0), {
        Color = Color3.fromRGB(17, 12, 24),
        BorderColor = color,
        BorderTransparency = 0.14,
        Radius = phone and 12 or 15,
    })
    card.LayoutOrder = layoutOrder

    self:CreateText(card, title, UDim2.new(1, -94, 0, 24), UDim2.fromOffset(16, phone and 12 or 14), {
        Font = Enum.Font.GothamBlack,
        TextSize = phone and 12 or 14,
        Color = color,
        ZIndex = 1013,
    })

    local descriptionLabel = self:CreateText(card, description, UDim2.new(1, -32, 0, phone and 50 or 64), UDim2.fromOffset(16, phone and 40 or 46), {
        Font = Enum.Font.GothamMedium,
        TextSize = phone and 9 or 10,
        Color = self.Colors.Text,
        Wrapped = true,
        YAlignment = Enum.TextYAlignment.Top,
        ZIndex = 1013,
    })

    local switch = Instance.new("Frame")
    switch.AnchorPoint = Vector2.new(1, 0)
    switch.Position = UDim2.new(1, -16, 0, phone and 12 or 14)
    local toggleWidth = math.floor(
        tonumber(self:GetUIStyleValue(
            "Settings",
            "ToggleWidth",
            "MainPage"
        )) or (phone and 48 or 52)
    )
    local toggleHeight = math.floor(
        tonumber(self:GetUIStyleValue(
            "Settings",
            "ToggleHeight",
            "MainPage"
        )) or (phone and 26 or 28)
    )
    switch.Size = UDim2.fromOffset(toggleWidth, toggleHeight)
    switch.BackgroundColor3 = Color3.fromRGB(68, 64, 78)
    switch.BorderSizePixel = 0
    switch.ZIndex = 1013
    switch.Parent = card
    makeCorner(switch, 999)

    local knob = Instance.new("Frame")
    knob.Position = UDim2.fromOffset(3, 3)
    local knobSize = math.max(16, toggleHeight - 6)
    knob.Size = UDim2.fromOffset(knobSize, knobSize)
    knob.BackgroundColor3 = Color3.fromRGB(245, 242, 248)
    knob.BorderSizePixel = 0
    knob.ZIndex = 1014
    knob.Parent = switch
    makeCorner(knob, 999)

    local stateLabel = self:CreateText(card, "OFF", UDim2.new(1, -32, 0, 22), UDim2.new(0, 16, 1, phone and -30 or -34), {
        Font = Enum.Font.GothamBold,
        TextSize = phone and 10 or 11,
        Color = self.Colors.Muted,
        ZIndex = 1013,
    })

    local button = Instance.new("TextButton")
    button.Size = UDim2.fromScale(1, 1)
    button.BackgroundTransparency = 1
    button.BorderSizePixel = 0
    button.AutoButtonColor = false
    button.Text = ""
    button.ZIndex = 1015
    button.Parent = card

    button.Activated:Connect(function()
        self:PulseGlow(card, color)
        setter(not getter())
    end)

    return {
        Card = card,
        Switch = switch,
        Knob = knob,
        State = stateLabel,
        Color = color,
        Getter = getter,
        Description = descriptionLabel,
    }
end

function App:CreateWindowActionCard(parent, title, description, color, layoutOrder, buttonText, callback)
    local phone = self.DeviceClass == "Phone"
    local card = self:CreateCard(parent, UDim2.new(0.333333, -8, 1, 0), {
        Color = Color3.fromRGB(17, 12, 24),
        BorderColor = color,
        BorderTransparency = 0.14,
        Radius = phone and 12 or 15,
    })
    card.LayoutOrder = layoutOrder

    self:CreateText(card, title, UDim2.new(1, -32, 0, 24), UDim2.fromOffset(16, phone and 12 or 14), {
        Font = Enum.Font.GothamBlack,
        TextSize = phone and 12 or 14,
        Color = color,
        ZIndex = 1013,
    })

    self:CreateText(card, description, UDim2.new(1, -32, 0, phone and 50 or 60), UDim2.fromOffset(16, phone and 40 or 46), {
        Font = Enum.Font.GothamMedium,
        TextSize = phone and 9 or 10,
        Color = self.Colors.Text,
        Wrapped = true,
        YAlignment = Enum.TextYAlignment.Top,
        ZIndex = 1013,
    })

    local action = Instance.new("TextButton")
    action.AnchorPoint = Vector2.new(0.5, 1)
    action.Position = UDim2.new(0.5, 0, 1, phone and -10 or -14)
    action.Size = UDim2.new(
        1,
        -32,
        0,
        math.clamp(
            tonumber(self:GetUIStyleValue(
                "Settings",
                "ButtonHeight",
                "MainPage"
            )) or (phone and 34 or 40),
            34,
            58
        )
    )
    action.BackgroundColor3 = color
    action.BackgroundTransparency = 0.08
    action.BorderSizePixel = 0
    action.AutoButtonColor = false
    action.Font = Enum.Font.GothamBold
    action.Text = buttonText
    action.TextSize = phone and 10 or 11
    action.TextColor3 = Color3.fromRGB(255, 255, 255)
    action.ZIndex = 1014
    action.Parent = card
    makeCorner(action, 10)
    makeStroke(action, Color3.fromRGB(255, 255, 255), 1, 0.70)
    self:BindButtonFeedback(action, color)

    action.Activated:Connect(function()
        callback()
    end)

    return {Card = card, Button = action}
end

function App:CreateWindowSliderCard(parent, title, description, color, layoutOrder, minimum, maximum, getter, setter, formatter)
    local phone = self.DeviceClass == "Phone"
    local card = self:CreateCard(parent, UDim2.new(0.333333, -8, 1, 0), {
        Color = Color3.fromRGB(17, 12, 24),
        BorderColor = color,
        BorderTransparency = 0.14,
        Radius = phone and 12 or 15,
    })
    card.LayoutOrder = layoutOrder

    self:CreateText(card, title, UDim2.new(1, -92, 0, 24), UDim2.fromOffset(16, 12), {
        Font = Enum.Font.GothamBlack,
        TextSize = phone and 12 or 14,
        Color = color,
        ZIndex = 1013,
    })

    self:CreateText(card, description, UDim2.new(1, -32, 0, phone and 46 or 50), UDim2.fromOffset(16, 39), {
        Font = Enum.Font.GothamMedium,
        TextSize = phone and 8 or 9,
        Color = self.Colors.Text,
        Wrapped = true,
        YAlignment = Enum.TextYAlignment.Top,
        ZIndex = 1013,
    })

    local valueLabel = self:CreateText(card, "", UDim2.fromOffset(78, 22), UDim2.new(1, -94, 0, phone and 87 or 91), {
        Font = Enum.Font.GothamBlack,
        TextSize = phone and 10 or 11,
        Color = color,
        XAlignment = Enum.TextXAlignment.Right,
        ZIndex = 1014,
    })

    local track = Instance.new("Frame")
    track.Position = UDim2.new(0, 16, 1, phone and -30 or -32)
    track.Size = UDim2.new(
        1,
        -32,
        0,
        self:GetUIStyleValue(
            "Settings",
            "SliderTrack",
            "MainPage"
        ) or 8
    )
    track.BackgroundColor3 = Color3.fromRGB(55, 48, 65)
    track.BorderSizePixel = 0
    track.ZIndex = 1013
    track.Parent = card
    makeCorner(track, 999)

    local fill = Instance.new("Frame")
    fill.Size = UDim2.new(0, 0, 1, 0)
    fill.BackgroundColor3 = color
    fill.BorderSizePixel = 0
    fill.ZIndex = 1014
    fill.Parent = track
    makeCorner(fill, 999)

    local knob = Instance.new("Frame")
    knob.AnchorPoint = Vector2.new(0.5, 0.5)
    knob.Position = UDim2.new(0, 0, 0.5, 0)
    local sliderKnob = self:GetUIStyleValue(
        "Settings",
        "SliderKnob",
        "MainPage"
    ) or (phone and 16 or 18)
    knob.Size = UDim2.fromOffset(sliderKnob, sliderKnob)
    knob.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    knob.BorderSizePixel = 0
    knob.ZIndex = 1015
    knob.Parent = track
    makeCorner(knob, 999)
    makeStroke(knob, color, 2, 0.05)

    local hitbox = Instance.new("TextButton")
    hitbox.Position = UDim2.fromOffset(0, -14)
    hitbox.Size = UDim2.new(1, 0, 0, 36)
    hitbox.BackgroundTransparency = 1
    hitbox.BorderSizePixel = 0
    hitbox.AutoButtonColor = false
    hitbox.Text = ""
    hitbox.ZIndex = 1016
    hitbox.Parent = track

    local dragging = false

    local function render(value)
        value = math.clamp(tonumber(value) or minimum, minimum, maximum)
        local alpha = (value - minimum) / math.max(0.001, maximum - minimum)
        fill.Size = UDim2.new(alpha, 0, 1, 0)
        knob.Position = UDim2.new(alpha, 0, 0.5, 0)
        if type(formatter) == "function" then
            valueLabel.Text = tostring(formatter(value))
        else
            valueLabel.Text = tostring(math.floor(value + 0.5))
        end
    end

    local function updateFromInput(input)
        local width = math.max(1, track.AbsoluteSize.X)
        local alpha = math.clamp((input.Position.X - track.AbsolutePosition.X) / width, 0, 1)
        local value = minimum + ((maximum - minimum) * alpha)
        setter(value)
        render(getter())
    end

    self:Track(hitbox.InputBegan:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
            dragging = true
            updateFromInput(input)
        end
    end))

    self:Track(hitbox.InputEnded:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
            dragging = false
        end
    end))

    self:Track(UserInputService.InputChanged:Connect(function(input)
        if dragging and (input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch) then
            updateFromInput(input)
        end
    end))

    render(getter())

    return {
        Card = card,
        Fill = fill,
        Knob = knob,
        Value = valueLabel,
        Color = color,
        Minimum = minimum,
        Maximum = maximum,
        Getter = getter,
        Formatter = formatter,
        Render = render,
    }
end

function App:RefreshNavigationAppearance()
    for pageName, entry in pairs(self.NavigationButtons or {}) do
        if type(entry) == "table" and type(entry.SetSelected) == "function" then
            entry.SetSelected(pageName == self.CurrentPage)
        end
    end
end

function App:GetPersistentSettingsSnapshot()
    local session = self.Session or {}
    local features = {}

    if self.FeatureManager
        and type(self.FeatureManager.ExportSettings)
            == "function"
    then
        features = self.FeatureManager:ExportSettings()
    end

    return {
        BuildVersion = self.Version,
        App = {
            FreeRoamEnabled = self.FreeRoamEnabled == true,
            FullScreenEnabled = self.IsFullScreen == true,
            ButtonGlowEnabled =
                self.ButtonGlowEnabled == true,
            NavigationGlowEnabled =
                self.NavigationGlowEnabled == true,
            CloseConfirmationEnabled =
                self.CloseConfirmationEnabled == true,
            ReducedMotionEnabled =
                self.ReducedMotionEnabled == true,
            RememberLastPageEnabled =
                self.RememberLastPageEnabled == true,
            AutoCenterOnResizeEnabled =
                self.AutoCenterOnResizeEnabled == true,
            AutoApplyPerGameEnabled =
                self.AutoApplyPerGameEnabled == true,
            LightweightModeEnabled =
                self.LightweightModeEnabled ~= false,
            UserScale = self.UserScale,
            BubbleSize = self.BubbleSize,
            WindowOpacity = self.WindowOpacity,
            LastPage = session.LastPage or "Home",
            SelectedGameCategory =
                session.SelectedGameCategory
                or "Red Light, Green Light",
            SelectedGuardCategory =
                session.SelectedGuardCategory
                or "Game Moderation",
            SelectedPlayerCategory =
                session.SelectedPlayerCategory
                or "Movement & Camera",
            SelectedFarmingCategory =
                session.SelectedFarmingCategory
                or "Player Farming",
            SelectedDetectiveCategory =
                session.SelectedDetectiveCategory
                or "Island Navigation",
            SelectedUICategory =
                session.SelectedUICategory
                or "Layout & Scale",
            UIEditScope =
                session.UIEditScope
                or "Entire App",
            UIEditTargetPage =
                session.UIEditTargetPage
                or "Players",
            UIStyles = self.UIStyleManager
                and self.UIStyleManager:Clone(
                    self.UIStyleProfile
                )
                or session.UIStyles,
        },
        Features = features,
    }
end

function App:SavePersistentSettingsNow(notify)
    if self._suspendSettingsSave
        or not self.SettingsStore
    then
        return false
    end

    local ok, mode = self.SettingsStore:Save(
        self:GetPersistentSettingsSnapshot()
    )

    if notify and self.Notifications then
        if ok then
            self.Notifications:Success(
                "Settings",
                "Settings saved using "
                    .. tostring(mode)
                    .. " storage.",
                3
            )
        else
            self.Notifications:Warning(
                "Settings",
                "Settings could not be saved.",
                3
            )
        end
    end

    return ok
end

function App:QueueSettingsSave()
    if self._suspendSettingsSave
        or not self.SettingsStore
    then
        return
    end

    self._settingsSaveRevision =
        (self._settingsSaveRevision or 0) + 1
    local revision = self._settingsSaveRevision

    task.delay(0.45, function()
        if revision == self._settingsSaveRevision
            and not self._suspendSettingsSave
        then
            self:SavePersistentSettingsNow(false)
        end
    end)
end

function App:ApplyPersistentSettingsSnapshot(saved)
    if type(saved) ~= "table" then
        return false
    end

    self._suspendSettingsSave = true
    local values = saved.App

    if type(values) == "table" then
        if values.FreeRoamEnabled ~= nil then
            self:SetFreeRoamEnabled(
                values.FreeRoamEnabled
            )
        end
        if values.FullScreenEnabled ~= nil then
            self:SetFullScreen(values.FullScreenEnabled)
        end
        if values.ButtonGlowEnabled ~= nil then
            self:SetButtonGlowEnabled(
                values.ButtonGlowEnabled
            )
        end
        if values.NavigationGlowEnabled ~= nil then
            self:SetNavigationGlowEnabled(
                values.NavigationGlowEnabled
            )
        end
        if values.CloseConfirmationEnabled ~= nil then
            self:SetCloseConfirmationEnabled(
                values.CloseConfirmationEnabled
            )
        end
        if values.ReducedMotionEnabled ~= nil then
            self:SetReducedMotionEnabled(
                values.ReducedMotionEnabled
            )
        end
        if values.RememberLastPageEnabled ~= nil then
            self:SetRememberLastPageEnabled(
                values.RememberLastPageEnabled
            )
        end
        if values.AutoCenterOnResizeEnabled ~= nil then
            self:SetAutoCenterOnResizeEnabled(
                values.AutoCenterOnResizeEnabled
            )
        end
        if values.LightweightModeEnabled ~= nil then
            self:SetLightweightModeEnabled(values.LightweightModeEnabled)
        end
        if values.AutoApplyPerGameEnabled ~= nil then
            self:SetAutoApplyPerGameEnabled(values.AutoApplyPerGameEnabled)
        end
        if values.UserScale ~= nil then
            self:SetUserScale(values.UserScale)
        end
        if values.BubbleSize ~= nil then
            self:SetBubbleSize(values.BubbleSize)
        end
        if values.WindowOpacity ~= nil then
            self:SetWindowOpacity(values.WindowOpacity)
        end

        if self.Session then
            self.Session.LastPage =
                values.LastPage or "Home"
            self.Session.SelectedGameCategory =
                values.SelectedGameCategory
                or "Red Light, Green Light"
            self.Session.SelectedGuardCategory =
                values.SelectedGuardCategory
                or "Game Moderation"
            self.Session.SelectedPlayerCategory =
                values.SelectedPlayerCategory
                or "Movement & Camera"
            self.Session.SelectedFarmingCategory =
                values.SelectedFarmingCategory
                or "Player Farming"
            self.Session.SelectedDetectiveCategory =
                values.SelectedDetectiveCategory
                or "Island Navigation"
            self.Session.SelectedUICategory =
                values.SelectedUICategory
                or "Layout & Scale"
            self.Session.UIEditScope =
                values.UIEditScope
                or "Entire App"
            self.Session.UIEditTargetPage =
                values.UIEditTargetPage
                or "Players"

            if values.UIStyles and self.UIStyleManager then
                self.UIStyleProfile =
                    self.UIStyleManager:Normalize(
                        self.UIStyleManager:Clone(
                            values.UIStyles
                        )
                    )
                self.Session.UIStyles = self.UIStyleProfile
            end
        end
    end

    if self.FeatureManager
        and type(self.FeatureManager.ApplySettings)
            == "function"
    then
        self.FeatureManager:ApplySettings(
            saved.Features
        )
    end

    self._suspendSettingsSave = false
    self:RefreshWindowSettings()
    self:RefreshFeatureDashboard()

    if values and values.UIStyles then
        self:RebuildForUIStyle()
    elseif self.RememberLastPageEnabled
        and self.Session
        and self.Pages[self.Session.LastPage]
    then
        self:OpenPage(self.Session.LastPage)
    end

    return true
end

function App:ReloadPersistentSettings()
    if not self.SettingsStore then
        return false
    end

    local ok = self:ApplyPersistentSettingsSnapshot(
        self.SettingsStore:Load()
    )

    if self.Notifications then
        if ok then
            self.Notifications:Success(
                "Settings",
                "Saved settings restored.",
                3
            )
        else
            self.Notifications:Warning(
                "Settings",
                "No saved settings were found.",
                3
            )
        end
    end

    return ok
end

function App:ResetAllSettingsToOff()
    self._suspendSettingsSave = true

    if self.FeatureManager
        and type(self.FeatureManager.ResetAll)
            == "function"
    then
        self.FeatureManager:ResetAll()
    end

    self:SetFullScreen(false)
    self:SetFreeRoamEnabled(false)
    self:SetButtonGlowEnabled(false)
    self:SetNavigationGlowEnabled(false)
    self:SetCloseConfirmationEnabled(false)
    self:SetReducedMotionEnabled(false)
    self:SetRememberLastPageEnabled(false)
    self:SetAutoCenterOnResizeEnabled(false)
    self:SetAutoApplyPerGameEnabled(false)
    self:SetLightweightModeEnabled(true)
    self:SetUserScale(1.0)
    self:SetBubbleSize(self:IsMobile() and 66 or 60)
    self:SetWindowOpacity(0)

    if self.Session then
        self.Session.LastPage = "Home"
        self.Session.SelectedGameCategory =
            "Red Light, Green Light"
        self.Session.SelectedGuardCategory = "Game Moderation"
        self.Session.SelectedPlayerCategory =
            "Movement & Camera"
        self.Session.SelectedFarmingCategory = "Player Farming"
        self.Session.SelectedDetectiveCategory = "Island Navigation"
        self.Session.SelectedUICategory = "Layout & Scale"
        self.Session.UIEditScope = "Entire App"
        self.Session.UIEditTargetPage = "Players"
        if self.UIStyleManager then
            self.UIStyleProfile =
                self.UIStyleManager:CreateDefaultProfile()
            self.Session.UIStyles = self.UIStyleProfile
        end
    end

    self:ResetWindowPosition()

    if self.SettingsStore then
        self.SettingsStore:Clear()
    end

    self._suspendSettingsSave = false
    self:SavePersistentSettingsNow(false)
    self:RefreshWindowSettings()
    self:RefreshFeatureDashboard()
    self:OpenPage("Settings")

    if self.Notifications then
        self.Notifications:Success(
            "Settings",
            "All features and optional settings "
                .. "were reset to OFF.",
            4
        )
    end
end

function App:SetButtonGlowEnabled(state)
    self.ButtonGlowEnabled = state and true or false
    if self.Session then self.Session.ButtonGlowEnabled = self.ButtonGlowEnabled end
    self:RefreshWindowSettings()
end

function App:SetNavigationGlowEnabled(state)
    self.NavigationGlowEnabled = state and true or false
    if self.Session then self.Session.NavigationGlowEnabled = self.NavigationGlowEnabled end
    self:RefreshNavigationAppearance()
    self:RefreshWindowSettings()
end

function App:SetCloseConfirmationEnabled(state)
    self.CloseConfirmationEnabled = state and true or false
    if self.Session then self.Session.CloseConfirmationEnabled = self.CloseConfirmationEnabled end
    self:RefreshWindowSettings()
end

function App:SetReducedMotionEnabled(state)
    self.ReducedMotionEnabled = state and true or false
    if self.Session then self.Session.ReducedMotionEnabled = self.ReducedMotionEnabled end
    self:RefreshWindowSettings()
end

function App:SetRememberLastPageEnabled(state)
    self.RememberLastPageEnabled = state and true or false
    if self.Session then
        self.Session.RememberLastPageEnabled = self.RememberLastPageEnabled
        if not self.RememberLastPageEnabled then
            self.Session.LastPage = "Home"
        elseif self.CurrentPage then
            self.Session.LastPage = self.CurrentPage
        end
    end
    self:RefreshWindowSettings()
end

function App:SetAutoCenterOnResizeEnabled(state)
    self.AutoCenterOnResizeEnabled = state and true or false
    if self.Session then self.Session.AutoCenterOnResizeEnabled = self.AutoCenterOnResizeEnabled end
    self:RefreshWindowSettings()
end


function App:SetAutoApplyPerGameEnabled(state)
    self.AutoApplyPerGameEnabled = state == true
    if self.Session then self.Session.AutoApplyPerGameEnabled = self.AutoApplyPerGameEnabled end
    if self.FeatureManager and type(self.FeatureManager.SetAutoApplyPerGameEnabled) == "function" then
        self.FeatureManager:SetAutoApplyPerGameEnabled(self.AutoApplyPerGameEnabled)
    end
    self:RefreshWindowSettings()
end

function App:SetLightweightModeEnabled(state)
    self.LightweightModeEnabled = state ~= false
    if self.Session then self.Session.LightweightModeEnabled = self.LightweightModeEnabled end
    if self.FeatureManager and type(self.FeatureManager.SetLightweightModeEnabled) == "function" then
        self.FeatureManager:SetLightweightModeEnabled(self.LightweightModeEnabled)
    end
    self:RefreshWindowSettings()
end

function App:ClearGameAutoApplyProfiles()
    local count = 0
    if self.FeatureManager and type(self.FeatureManager.ClearGameProfiles) == "function" then
        count = self.FeatureManager:ClearGameProfiles()
    end
    if self.Notifications then
        self.Notifications:Success("Game profiles", "Cleared " .. tostring(count) .. " saved game feature choices.", 3)
    end
    self:RefreshWindowSettings()
end

function App:SetUserScale(value)
    self.UserScale = math.clamp(tonumber(value) or 1.0, 0.75, 1.15)
    if self.Session then
        self.Session.UserScale = self.UserScale
        if self.UIStyleManager and self.UIStyleProfile then
            self.UIStyleManager:SetValue(
                self.UIStyleProfile,
                "Entire App",
                nil,
                "AppScale",
                self.UserScale
            )
            self.Session.UIStyles = self.UIStyleProfile
        end
    end
    if self.Host and not self.IsFullScreen and not self.IsMaximized then
        self:UpdateResponsive(true)
    end
    self:RefreshWindowSettings()
end

function App:SetBubbleSize(value)
    local defaultSize = self:IsMobile() and 66 or 60
    self.BubbleSize = math.clamp(math.floor(tonumber(value) or defaultSize), 48, 92)
    if self.Session then self.Session.BubbleSize = self.BubbleSize end
    if self.ReopenButton then
        self.ReopenButton.Size = UDim2.fromOffset(self.BubbleSize, self.BubbleSize)
        self:PositionReopenButton(false)
    end
    self:RefreshWindowSettings()
end

function App:SetWindowOpacity(value)
    self.WindowOpacity = math.clamp(tonumber(value) or 0, 0, 0.35)
    if self.Session then self.Session.WindowOpacity = self.WindowOpacity end
    if self.Window then
        self.Window.BackgroundTransparency = self.WindowOpacity
    end
    if self.Sidebar then
        self.Sidebar.BackgroundTransparency = self.WindowOpacity * 0.65
    end
    if self.Topbar then
        self.Topbar.BackgroundTransparency = math.min(0.45, 0.10 + (self.WindowOpacity * 0.65))
    end
    if self.Statusbar then
        self.Statusbar.BackgroundTransparency = math.min(0.45, 0.03 + (self.WindowOpacity * 0.65))
    end
    if self.PageContainer then
        self.PageContainer.BackgroundTransparency = self.WindowOpacity * 0.65
    end
    self:RefreshWindowSettings()
end

function App:ResetApplicationPreferences()
    self:SetFreeRoamEnabled(true)
    self:SetFullScreen(false)
    self:SetButtonGlowEnabled(true)
    self:SetNavigationGlowEnabled(true)
    self:SetCloseConfirmationEnabled(true)
    self:SetReducedMotionEnabled(false)
    self:SetRememberLastPageEnabled(true)
    self:SetAutoCenterOnResizeEnabled(true)
    self:SetAutoApplyPerGameEnabled(false)
    self:SetLightweightModeEnabled(true)
    self:SetUserScale(1.0)
    self:SetBubbleSize(self:IsMobile() and 66 or 60)
    self:SetWindowOpacity(0)
    self:ResetWindowPosition()
end

function App:RefreshWindowSettings()
    local widgets = self.WindowSettingsWidgets
    if not widgets then
        return
    end

    local function refreshToggle(refs, enabled)
        if not refs or not refs.Card or not refs.Card.Parent then
            return
        end

        local trackWidth = refs.Switch.Size.X.Offset
        local knobWidth = refs.Knob.Size.X.Offset
        refs.Switch.BackgroundColor3 = enabled and refs.Color or Color3.fromRGB(68, 64, 78)
        refs.Knob.Position = UDim2.fromOffset(enabled and (trackWidth - knobWidth - 3) or 3, 3)
        refs.State.Text = enabled and "ON" or "OFF"
        refs.State.TextColor3 = enabled and refs.Color or self.Colors.Muted
    end

    local function refreshSlider(refs, value)
        if refs and refs.Card and refs.Card.Parent and type(refs.Render) == "function" then
            refs.Render(value)
        end
    end

    refreshToggle(widgets.FreeRoam, self.FreeRoamEnabled)
    refreshToggle(widgets.FullScreen, self.IsFullScreen)
    refreshToggle(widgets.ButtonGlow, self.ButtonGlowEnabled)
    refreshToggle(widgets.NavigationGlow, self.NavigationGlowEnabled)
    refreshToggle(widgets.CloseConfirmation, self.CloseConfirmationEnabled)
    refreshToggle(widgets.ReducedMotion, self.ReducedMotionEnabled)
    refreshToggle(widgets.RememberLastPage, self.RememberLastPageEnabled)
    refreshToggle(widgets.AutoCenter, self.AutoCenterOnResizeEnabled)
    refreshToggle(widgets.AutoApplyPerGame, self.AutoApplyPerGameEnabled)
    refreshToggle(widgets.LightweightMode, self.LightweightModeEnabled)

    refreshSlider(widgets.UserScale, self.UserScale)
    refreshSlider(widgets.BubbleSize, self.BubbleSize or (self:IsMobile() and 66 or 60))
    refreshSlider(widgets.WindowOpacity, self.WindowOpacity)

    self:QueueSettingsSave()
end

function App:BuildSettingsPage(page)
    page:ClearAllChildren()

    local padding = self.Profile.ContentPadding
    local phone = self.DeviceClass == "Phone"
    local settingsLayout = phone and {
        RootHeight = 1260,
        WindowRowY = 58,
        WindowRowHeight = 146,
        InterfaceHeaderY = 218,
        InterfaceDescriptionY = 244,
        InterfaceRowY = 270,
        InterfaceRowHeight = 126,
        AccessibilityHeaderY = 408,
        AccessibilityDescriptionY = 434,
        AccessibilityRowY = 458,
        AccessibilityRowHeight = 126,
        GameHeaderY = 610,
        GameDescriptionY = 636,
        GameRowY = 662,
        GameRowHeight = 126,
        SizeHeaderY = 810,
        SizeDescriptionY = 836,
        SizeRowY = 862,
        SizeRowHeight = 146,
        SavedHeaderY = 1030,
        SavedDescriptionY = 1056,
        SavedRowY = 1098,
        SavedRowHeight = 132,
        CanvasHeight = 1280,
    } or {
        RootHeight = 1370,
        WindowRowY = 62,
        WindowRowHeight = 154,
        InterfaceHeaderY = 232,
        InterfaceDescriptionY = 259,
        InterfaceRowY = 290,
        InterfaceRowHeight = 140,
        AccessibilityHeaderY = 456,
        AccessibilityDescriptionY = 483,
        AccessibilityRowY = 514,
        AccessibilityRowHeight = 140,
        GameHeaderY = 680,
        GameDescriptionY = 707,
        GameRowY = 738,
        GameRowHeight = 140,
        SizeHeaderY = 904,
        SizeDescriptionY = 931,
        SizeRowY = 962,
        SizeRowHeight = 154,
        SavedHeaderY = 1138,
        SavedDescriptionY = 1165,
        SavedRowY = 1206,
        SavedRowHeight = 140,
        CanvasHeight = 1410,
    }

    local root = Instance.new("Frame")
    root.Position = UDim2.fromOffset(padding, padding)
    root.Size = UDim2.new(1, -(padding * 2), 0, settingsLayout.RootHeight)
    root.BackgroundTransparency = 1
    root.BorderSizePixel = 0
    root.Parent = page

    self:CreateText(root, "WINDOW & DISPLAY", UDim2.new(1, 0, 0, 30), UDim2.fromOffset(0, 0), {
        Font = Enum.Font.GothamBlack,
        TextSize = self.DeviceClass == "Phone" and 17 or 20,
        Color = self:GetPageAccent("Settings"),
        ZIndex = 1012,
    })

    self:CreateText(root, "Application behavior, recovery, and saved profiles. Visual customization is under UI.", UDim2.new(1, 0, 0, 22), UDim2.fromOffset(0, 30), {
        Font = Enum.Font.GothamMedium,
        TextSize = self.DeviceClass == "Phone" and 10 or 11,
        Color = self.Colors.Muted,
        ZIndex = 1012,
    })

    local windowRow = self:CreateEqualThreeColumnRow(root, settingsLayout.WindowRowY, settingsLayout.WindowRowHeight, "WindowSettingsRow")

    local freeRoam = self:CreateWindowToggleCard(
        windowRow,
        "FREE ROAM WINDOW",
        "Move across the game screen. If the app leaves the usable area, it minimizes and restores at the last safe position.",
        self:GetPageAccent("Players"),
        1,
        function() return self.FreeRoamEnabled end,
        function(value) self:SetFreeRoamEnabled(value) end
    )

    local fullScreen = self:CreateWindowToggleCard(
        windowRow,
        "FULL SCREEN MODE",
        "Fill the complete usable viewport while preserving the internal three-column layout.",
        self:GetPageAccent("Detective"),
        2,
        function() return self.IsFullScreen end,
        function(value) self:SetFullScreen(value) end
    )

    local reset = self:CreateWindowActionCard(
        windowRow,
        "RESET WINDOW",
        "Return to a centered, safe, movable position and leave maximized or full-screen mode.",
        self:GetPageAccent("Settings"),
        3,
        "RESET POSITION",
        function() self:ResetWindowPosition() end
    )

    self:CreateText(root, "INTERFACE FEEDBACK", UDim2.new(1, 0, 0, 28), UDim2.fromOffset(0, settingsLayout.InterfaceHeaderY), {
        Font = Enum.Font.GothamBlack,
        TextSize = self.DeviceClass == "Phone" and 15 or 18,
        Color = self:GetPageAccent("Settings"),
        ZIndex = 1012,
    })

    self:CreateText(root, "General SquidNoMo interaction preferences.", UDim2.new(1, 0, 0, 20), UDim2.fromOffset(0, settingsLayout.InterfaceDescriptionY), {
        Font = Enum.Font.GothamMedium,
        TextSize = self.DeviceClass == "Phone" and 9 or 10,
        Color = self.Colors.Muted,
        ZIndex = 1012,
    })

    local interfaceRow = self:CreateEqualThreeColumnRow(root, settingsLayout.InterfaceRowY, settingsLayout.InterfaceRowHeight, "InterfaceSettingsRow")

    local buttonGlow = self:CreateWindowToggleCard(
        interfaceRow,
        "BUTTON CLICK GLOW",
        "Show the short themed glow pulse when application buttons are pressed.",
        self:GetPageAccent("UI"),
        1,
        function() return self.ButtonGlowEnabled end,
        function(value) self:SetButtonGlowEnabled(value) end
    )

    local navigationGlow = self:CreateWindowToggleCard(
        interfaceRow,
        "SELECTED PAGE GLOW",
        "Keep the active navigation tab highlighted with its page-specific accent.",
        self:GetPageAccent("Home"),
        2,
        function() return self.NavigationGlowEnabled end,
        function(value) self:SetNavigationGlowEnabled(value) end
    )

    local closeConfirmation = self:CreateWindowToggleCard(
        interfaceRow,
        "CONFIRM BEFORE CLOSE",
        "Require confirmation before closing the application to prevent accidental taps.",
        self.Colors.Close,
        3,
        function() return self.CloseConfirmationEnabled end,
        function(value) self:SetCloseConfirmationEnabled(value) end
    )

    self:CreateText(root, "ACCESSIBILITY & SESSION", UDim2.new(1, 0, 0, 28), UDim2.fromOffset(0, settingsLayout.AccessibilityHeaderY), {
        Font = Enum.Font.GothamBlack,
        TextSize = self.DeviceClass == "Phone" and 15 or 18,
        Color = self:GetPageAccent("Settings"),
        ZIndex = 1012,
    })

    self:CreateText(root, "Motion, page memory, and orientation behavior.", UDim2.new(1, 0, 0, 20), UDim2.fromOffset(0, settingsLayout.AccessibilityDescriptionY), {
        Font = Enum.Font.GothamMedium,
        TextSize = self.DeviceClass == "Phone" and 9 or 10,
        Color = self.Colors.Muted,
        ZIndex = 1012,
    })

    local accessibilityRow = self:CreateEqualThreeColumnRow(root, settingsLayout.AccessibilityRowY, settingsLayout.AccessibilityRowHeight, "AccessibilitySettingsRow")

    local reducedMotion = self:CreateWindowToggleCard(
        accessibilityRow,
        "REDUCED MOTION",
        "Use immediate state changes instead of application tween animations.",
        self:GetPageAccent("UI"),
        1,
        function() return self.ReducedMotionEnabled end,
        function(value) self:SetReducedMotionEnabled(value) end
    )

    local rememberLastPage = self:CreateWindowToggleCard(
        accessibilityRow,
        "REMEMBER LAST PAGE",
        "Reopen the page you used most recently during the current server session.",
        self:GetPageAccent("Players"),
        2,
        function() return self.RememberLastPageEnabled end,
        function(value) self:SetRememberLastPageEnabled(value) end
    )

    local autoCenter = self:CreateWindowToggleCard(
        accessibilityRow,
        "CENTER ON RESIZE",
        "Recenter the restored window after orientation or viewport-size changes.",
        self:GetPageAccent("Detective"),
        3,
        function() return self.AutoCenterOnResizeEnabled end,
        function(value) self:SetAutoCenterOnResizeEnabled(value) end
    )

    self:CreateText(root, "GAME AUTOMATION & PERFORMANCE", UDim2.new(1, 0, 0, 28), UDim2.fromOffset(0, settingsLayout.GameHeaderY), {
        Font = Enum.Font.GothamBlack,
        TextSize = self.DeviceClass == "Phone" and 15 or 18,
        Color = self:GetPageAccent("Games"),
        ZIndex = 1012,
    })

    self:CreateText(root, "Restore chosen features only when their matching game is detected, while keeping inactive modules asleep.", UDim2.new(1, 0, 0, 20), UDim2.fromOffset(0, settingsLayout.GameDescriptionY), {
        Font = Enum.Font.GothamMedium,
        TextSize = self.DeviceClass == "Phone" and 9 or 10,
        Color = self.Colors.Muted,
        Wrapped = true,
        ZIndex = 1012,
    })

    local gameAutomationRow = self:CreateEqualThreeColumnRow(root, settingsLayout.GameRowY, settingsLayout.GameRowHeight, "GameAutomationSettingsRow")

    local autoApplyPerGame = self:CreateWindowToggleCard(
        gameAutomationRow,
        "AUTO APPLY PER GAME",
        "Remember the game features you choose, enable them when that game is detected, and pause other game categories.",
        self:GetPageAccent("Games"),
        1,
        function() return self.AutoApplyPerGameEnabled end,
        function(value) self:SetAutoApplyPerGameEnabled(value) end
    )

    local lightweightMode = self:CreateWindowToggleCard(
        gameAutomationRow,
        "LIGHTWEIGHT RUNTIME",
        "Use shared scheduling, cached searches, idle backoff, and movement coordination to reduce frame spikes.",
        self.Colors.Success,
        2,
        function() return self.LightweightModeEnabled end,
        function(value) self:SetLightweightModeEnabled(value) end
    )

    local clearGameProfiles = self:CreateWindowActionCard(
        gameAutomationRow,
        "CLEAR GAME PROFILES",
        "Turn off and forget all remembered game-category feature choices without changing Player or UI features.",
        self.Colors.Error,
        3,
        "CLEAR PROFILES",
        function() self:ClearGameAutoApplyProfiles() end
    )

    self:CreateText(root, "SIZE & TRANSPARENCY", UDim2.new(1, 0, 0, 28), UDim2.fromOffset(0, settingsLayout.SizeHeaderY), {
        Font = Enum.Font.GothamBlack,
        TextSize = self.DeviceClass == "Phone" and 15 or 18,
        Color = self:GetPageAccent("Settings"),
        ZIndex = 1012,
    })

    self:CreateText(root, "Fine-tune the restored app, recovery bubble, and window background.", UDim2.new(1, 0, 0, 20), UDim2.fromOffset(0, settingsLayout.SizeDescriptionY), {
        Font = Enum.Font.GothamMedium,
        TextSize = self.DeviceClass == "Phone" and 9 or 10,
        Color = self.Colors.Muted,
        ZIndex = 1012,
    })

    local sizeRow = self:CreateEqualThreeColumnRow(root, settingsLayout.SizeRowY, settingsLayout.SizeRowHeight, "SizeSettingsRow")

    local userScale = self:CreateWindowSliderCard(
        sizeRow,
        "RESTORED APP SCALE",
        "Adjust restored-mode size without exceeding the usable viewport.",
        self:GetPageAccent("Settings"),
        1,
        0.75,
        1.15,
        function() return self.UserScale end,
        function(value) self:SetUserScale(value) end,
        function(value) return tostring(math.floor(value * 100 + 0.5)) .. "%" end
    )

    local bubbleSize = self:CreateWindowSliderCard(
        sizeRow,
        "FLOATING BUBBLE SIZE",
        "Adjust the minimized recovery bubble for touch comfort.",
        self:GetPageAccent("Home"),
        2,
        48,
        92,
        function() return self.BubbleSize or (self:IsMobile() and 66 or 60) end,
        function(value) self:SetBubbleSize(value) end,
        function(value) return tostring(math.floor(value + 0.5)) .. " px" end
    )

    local windowOpacity = self:CreateWindowSliderCard(
        sizeRow,
        "WINDOW TRANSPARENCY",
        "Adjust the main application background while keeping cards readable.",
        self:GetPageAccent("UI"),
        3,
        0,
        0.35,
        function() return self.WindowOpacity end,
        function(value) self:SetWindowOpacity(value) end,
        function(value) return tostring(math.floor(value * 100 + 0.5)) .. "%" end
    )

self:CreateText(
    root,
    "SAVED SETTINGS",
    UDim2.new(1, 0, 0, 28),
    UDim2.fromOffset(0, settingsLayout.SavedHeaderY),
    {
        Font = Enum.Font.GothamBlack,
        TextSize =
            self.DeviceClass == "Phone" and 15 or 18,
        Color = self:GetPageAccent("Settings"),
        ZIndex = 1012,
    }
)

local storageMode = self.SettingsStore
    and self.SettingsStore:GetStorageMode()
    or "SESSION"

self:CreateText(
    root,
    storageMode == "FILE"
        and "Preferences restore automatically "
            .. "across reruns and new servers."
        or "File storage is unavailable. "
            .. "Preferences remain in executor "
            .. "session memory.",
    UDim2.new(1, 0, 0, 34),
    UDim2.fromOffset(0, settingsLayout.SavedDescriptionY),
    {
        Font = Enum.Font.GothamMedium,
        TextSize =
            self.DeviceClass == "Phone" and 9 or 10,
        Color = self.Colors.Muted,
        Wrapped = true,
        ZIndex = 1012,
    }
)

local savedRow = self:CreateEqualThreeColumnRow(
    root,
    settingsLayout.SavedRowY,
    settingsLayout.SavedRowHeight,
    "SavedSettingsRow"
)

local saveNow = self:CreateWindowActionCard(
    savedRow,
    "AUTOMATIC MEMORY",
    "Feature states, supported values, colors, "
        .. "and app preferences save after changes.",
    self.Colors.Success,
    1,
    "SAVE NOW",
    function()
        self:SavePersistentSettingsNow(true)
    end
)

local restoreSaved = self:CreateWindowActionCard(
    savedRow,
    "RESTORE SAVED",
    "Reload the most recently saved profile "
        .. "without rerunning the application.",
    self:GetPageAccent("Players"),
    2,
    "RESTORE PROFILE",
    function()
        self:ReloadPersistentSettings()
    end
)

local resetAll = self:CreateWindowActionCard(
    savedRow,
    "RESET ALL SETTINGS",
    "Disable every feature, turn optional app "
        .. "settings off, and reset sliders.",
    self.Colors.Error,
    3,
    "RESET ALL TO OFF",
    function()
        self:ResetAllSettingsToOff()
    end
)

    self.WindowSettingsWidgets = {
        Root = root,
        FreeRoam = freeRoam,
        FullScreen = fullScreen,
        Reset = reset,
        ButtonGlow = buttonGlow,
        NavigationGlow = navigationGlow,
        CloseConfirmation = closeConfirmation,
        ReducedMotion = reducedMotion,
        RememberLastPage = rememberLastPage,
        AutoCenter = autoCenter,
        AutoApplyPerGame = autoApplyPerGame,
        LightweightMode = lightweightMode,
        ClearGameProfiles = clearGameProfiles,
        UserScale = userScale,
        BubbleSize = bubbleSize,
        WindowOpacity = windowOpacity,
        SaveNow = saveNow,
        RestoreSaved = restoreSaved,
        ResetAll = resetAll,
    }

    self:RefreshWindowSettings()

    page.AutomaticCanvasSize = Enum.AutomaticSize.None
    page.CanvasSize = UDim2.fromOffset(
        0,
        math.max(
            settingsLayout.CanvasHeight,
            (root and root.Size.Y.Offset or settingsLayout.RootHeight) + 36
        )
    )
end

function App:OpenPage(name)
    if not self.Pages[name] then
        return false
    end

    for pageName, page in pairs(self.Pages) do
        page.Visible = pageName == name
    end

    for pageName, navigationEntry in pairs(self.NavigationButtons) do
        if type(navigationEntry) == "table"
            and type(navigationEntry.SetSelected) == "function"
        then
            navigationEntry.SetSelected(pageName == name)
        end
    end

    self.CurrentPage = name

    if self.Session and self.RememberLastPageEnabled then
        self.Session.LastPage = name
    end

    if self.Session and name ~= "UI" then
        self.Session.UIEditTargetPage = name
    end

    if self.PageTitle then
        self.PageTitle.Text = string.upper(name)
    end

    self:QueueSettingsSave()
    return true
end

----------------------------------------------------------
-- Generic UI builders for the canonical dashboard
----------------------------------------------------------

function App:CreateCard(parent, size, options)
    options = options or {}

    local pageName, context = self:GetUIStyleContext(parent)
    local styleRadius = self:GetUIStyleValue(
        pageName,
        "CardRadius",
        context
    ) or 14
    local requestedRadius = options.Radius
    local radius = requestedRadius or styleRadius
    if requestedRadius and requestedRadius < 90 then
        radius = styleRadius
    end

    local borderThickness = options.BorderThickness
        or self:GetUIStyleValue(
            pageName,
            "BorderThickness",
            context
        )
        or 1

    local card = Instance.new("Frame")
    card.Size = size
    card.BackgroundColor3 = options.Color or self.Colors.Card
    card.BackgroundTransparency = options.Transparency or 0
    card.BorderSizePixel = 0
    card.ClipsDescendants = options.ClipsDescendants ~= false
    card.ZIndex = options.ZIndex or 1010
    card.Parent = parent
    makeCorner(card, radius)
    makeStroke(
        card,
        options.BorderColor or self.Colors.BorderSoft,
        borderThickness,
        options.BorderTransparency or 0.15
    )

    return card
end

function App:CreateText(parent, text, size, position, options)
    options = options or {}

    local label = Instance.new("TextLabel")
    label.BackgroundTransparency = 1
    label.Size = size
    label.Position = position or UDim2.fromOffset(0, 0)
    label.Font = options.Font or Enum.Font.Gotham
    label.Text = tostring(text or "")
    local requestedTextSize = options.TextSize or 13
    if self.Config.MobileTextBoost and self:IsMobile() then
        -- Phone displays shrink the app surface considerably. Keep labels
        -- readable even when the window is not expanded to fullscreen.
        if requestedTextSize <= 10 then
            requestedTextSize = 13
        elseif requestedTextSize <= 13 then
            requestedTextSize = requestedTextSize + 3
        else
            requestedTextSize = requestedTextSize + 2
        end
    end
    local textScale = tonumber(
        self:GetUIStyleForInstance(parent, "TextScale")
    ) or 1
    label.TextSize = math.clamp(
        math.floor((requestedTextSize * textScale) + 0.5),
        8,
        36
    )
    if self.Config.MobileTextBoost and self:IsMobile() then
        label:SetAttribute("SquidReadableText", true)
    end
    label.TextColor3 = options.Color or self.Colors.Text
    label.TextTransparency = options.Transparency or 0
    label.TextWrapped = options.Wrapped or false
    label.TextXAlignment = options.XAlignment or Enum.TextXAlignment.Left
    label.TextYAlignment = options.YAlignment or Enum.TextYAlignment.Center
    label.RichText = options.RichText or false
    label.ZIndex = options.ZIndex or 1012
    label.Parent = parent
    return label
end

function App:CreatePill(parent, text, color, position, width)
    local pill = Instance.new("Frame")
    pill.Position = position
    pill.Size = UDim2.fromOffset(width or 90, 24)
    pill.BackgroundColor3 = color
    pill.BackgroundTransparency = 0.82
    pill.BorderSizePixel = 0
    pill.ZIndex = 1013
    pill.Parent = parent
    makeCorner(pill, 99)
    makeStroke(pill, color, 1, 0.28)

    self:CreateText(
        pill,
        text,
        UDim2.fromScale(1, 1),
        UDim2.fromOffset(0, 0),
        {
            Font = Enum.Font.GothamBold,
            TextSize = 9,
            Color = color,
            XAlignment = Enum.TextXAlignment.Center,
            ZIndex = 1014,
        }
    )

    return pill
end

function App:CreateSectionTitle(parent, title, subtitle)
    self:CreateText(
        parent,
        title,
        UDim2.new(1, -28, 0, 24),
        UDim2.fromOffset(14, 12),
        {
            Font = Enum.Font.GothamBold,
            TextSize = 14,
            Color = self.Colors.Text,
        }
    )

    if subtitle then
        self:CreateText(
            parent,
            subtitle,
            UDim2.new(1, -28, 0, 18),
            UDim2.fromOffset(14, 35),
            {
                Font = Enum.Font.Gotham,
                TextSize = 9,
                Color = self.Colors.Muted,
            }
        )
    end
end

function App:GetFeatureOverview()
    local summary = nil

    if self.FeatureManager and type(self.FeatureManager.GetSnapshot) == "function" then
        local ok, result = pcall(function()
            return self.FeatureManager:GetSnapshot()
        end)
        if ok and type(result) == "table" then
            summary = result
        end
    end

    summary = summary or {
        FullyOn = 0,
        Partial = 0,
        Off = 0,
        Total = 0,
        Categories = {},
    }

    summary.FullyOn = tonumber(summary.FullyOn) or 0
    summary.Partial = tonumber(summary.Partial) or 0
    summary.Off = tonumber(summary.Off) or 0
    summary.Total = tonumber(summary.Total) or (summary.FullyOn + summary.Partial + summary.Off)

    if summary.Total > 0 then
        summary.FullyPercent = math.floor((summary.FullyOn / summary.Total) * 100 + 0.5)
        summary.PartialPercent = math.floor((summary.Partial / summary.Total) * 100 + 0.5)
        summary.OffPercent = math.max(0, 100 - summary.FullyPercent - summary.PartialPercent)
    else
        summary.FullyPercent = 0
        summary.PartialPercent = 0
        summary.OffPercent = 0
    end

    summary.Categories = summary.Categories or {}
    for _, category in ipairs({"Safe", "SemiSafe", "Experimental"}) do
        summary.Categories[category] = summary.Categories[category] or {
            Total = 0,
            On = 0,
            Partial = 0,
            Off = 0,
            State = "empty",
        }
    end

    return summary
end

function App:CreateStatLine(parent, y, leftText, rightText, rightColor)
    local line = Instance.new("Frame")
    line.Position = UDim2.fromOffset(20, y)
    line.Size = UDim2.new(1, -40, 0, 34)
    line.BackgroundTransparency = 1
    line.BorderSizePixel = 0
    line.ZIndex = 1012
    line.Parent = parent

    local divider = Instance.new("Frame")
    divider.AnchorPoint = Vector2.new(0, 1)
    divider.Position = UDim2.new(0, 0, 1, 0)
    divider.Size = UDim2.new(1, 0, 0, 1)
    divider.BackgroundColor3 = self.Colors.BorderSoft
    divider.BackgroundTransparency = 0.45
    divider.BorderSizePixel = 0
    divider.ZIndex = 1012
    divider.Parent = line

    local leftLabel = self:CreateText(line, leftText, UDim2.new(0.58, 0, 1, 0), UDim2.fromOffset(0, 0), {
        Font = Enum.Font.Gotham,
        TextSize = 12,
        Color = self.Colors.Text,
        ZIndex = 1013,
    })

    local rightLabel = self:CreateText(line, rightText, UDim2.new(0.42, 0, 1, 0), UDim2.new(0.58, 0, 0, 0), {
        Font = Enum.Font.GothamBold,
        TextSize = 12,
        Color = rightColor or self.Colors.Text,
        XAlignment = Enum.TextXAlignment.Right,
        ZIndex = 1013,
    })

    return line, leftLabel, rightLabel
end

function App:CreateEqualThreeColumnRow(parent, y, height, name)
    local phone = self.DeviceClass == "Phone"
    local sideInset = phone and 8 or 16

    local row = Instance.new("Frame")
    row.Name = name or "ThreeColumnRow"
    row.Position = UDim2.fromOffset(sideInset, y)
    row.Size = UDim2.new(1, -(sideInset * 2), 0, height)
    row.BackgroundTransparency = 1
    row.BorderSizePixel = 0
    row.ClipsDescendants = true
    row.ZIndex = 1010
    row.Parent = parent

    local layout = Instance.new("UIListLayout")
    layout.FillDirection = Enum.FillDirection.Horizontal
    layout.HorizontalAlignment = Enum.HorizontalAlignment.Left
    layout.VerticalAlignment = Enum.VerticalAlignment.Top
    layout.SortOrder = Enum.SortOrder.LayoutOrder
    layout.Padding = UDim.new(
        0,
        self:GetUIStyleForInstance(parent, "ColumnGap")
            or (phone and 10 or 12)
    )
    layout.Parent = row

    return row
end

function App:CreateFeatureStateCard(parent, position, widthScale, color, title, count, percent, description, height)
    local phone = self.DeviceClass == "Phone"
    height = height or (phone and 98 or 118)

    local card = self:CreateCard(parent, UDim2.new(0.333333, -8, 1, 0), {
        Color = Color3.fromRGB(17, 12, 24),
        BorderColor = color,
        BorderTransparency = 0.08,
        Radius = phone and 12 or 14,
        ZIndex = 1011,
    })
    card.LayoutOrder = widthScale or 1

    local iconSize = phone and 42 or 52
    local iconRing = Instance.new("Frame")
    iconRing.Position = UDim2.fromOffset(phone and 12 or 18, phone and 18 or 22)
    iconRing.Size = UDim2.fromOffset(iconSize, iconSize)
    iconRing.BackgroundTransparency = 1
    iconRing.BorderSizePixel = 0
    iconRing.ZIndex = 1012
    iconRing.Parent = card
    makeCorner(iconRing, 999)
    makeStroke(iconRing, color, 2, 0.04)

    local glyph = Instance.new("TextLabel")
    glyph.BackgroundTransparency = 1
    glyph.Size = UDim2.fromScale(1, 1)
    glyph.Font = Enum.Font.GothamBold
    glyph.Text = title == "FULLY ON" and "✓" or (title == "PARTIALLY ON" and "~" or "X")
    glyph.TextSize = phone and 20 or 24
    glyph.TextColor3 = color
    glyph.ZIndex = 1013
    glyph.Parent = iconRing

    local textX = phone and 64 or 84
    local titleLabel = self:CreateText(card, title, UDim2.new(1, -(textX + 10), 0, 18), UDim2.fromOffset(textX, phone and 12 or 16), {
        Font = Enum.Font.GothamBold,
        TextSize = phone and 9 or 10,
        Color = color,
        ZIndex = 1013,
    })
    local countLabel = self:CreateText(card, tostring(count), UDim2.fromOffset(72, 34), UDim2.fromOffset(textX, phone and 29 or 36), {
        Font = Enum.Font.GothamBlack,
        TextSize = phone and 24 or 28,
        Color = self.Colors.Text,
        ZIndex = 1013,
    })
    local featureLabel = self:CreateText(card, "Features", UDim2.fromOffset(100, 17), UDim2.fromOffset(textX, phone and 61 or 74), {
        Font = Enum.Font.GothamMedium,
        TextSize = phone and 10 or 12,
        Color = self.Colors.Text,
        ZIndex = 1013,
    })
    local descriptionLabel = self:CreateText(card, description, UDim2.new(1, -(textX + 8), 0, 16), UDim2.fromOffset(textX, height - (phone and 22 or 25)), {
        Font = Enum.Font.Gotham,
        TextSize = phone and 8 or 9,
        Color = self.Colors.Muted,
        ZIndex = 1013,
    })
    local percentLabel = self:CreateText(card, tostring(percent) .. "%", UDim2.fromOffset(48, 16), UDim2.new(1, -58, 1, -21), {
        Font = Enum.Font.GothamBold,
        TextSize = phone and 8 or 9,
        Color = color,
        XAlignment = Enum.TextXAlignment.Right,
        ZIndex = 1013,
    })

    return card, {
        Count = countLabel,
        Percent = percentLabel,
        Description = descriptionLabel,
        FeatureLabel = featureLabel,
        Title = titleLabel,
    }
end

function App:BuildHome(page)
    local content = Instance.new("Frame")
    content.Name = "HomeContent"
    content.Size = UDim2.new(1, 0, 0, 0)
    content.AutomaticSize = Enum.AutomaticSize.Y
    content.BackgroundTransparency = 1
    content.ZIndex = 1007
    content.Parent = page

    local padding = self.Profile.ContentPadding
    makePadding(content, padding, padding, padding, padding)

    local layout = Instance.new("UIListLayout")
    layout.Padding = UDim.new(0, self.Profile.HomeGap)
    layout.SortOrder = Enum.SortOrder.LayoutOrder
    layout.HorizontalAlignment = Enum.HorizontalAlignment.Center
    layout.Parent = content

    self:BuildHero(content)
    self:BuildFeatureStats(content)
    self:BuildBottomStatsRow(content)
end

function App:BuildHero(parent)
    local height = self.Profile.HeroHeight
    local phone = self.DeviceClass == "Phone"

    local hero = self:CreateCard(parent, UDim2.new(1, 0, 0, height), {
        Color = Color3.fromRGB(16, 11, 24),
        BorderColor = self.Colors.Border,
        BorderTransparency = 0.04,
        Radius = self.DeviceClass == "Phone" and 14 or 18,
    })
    hero.LayoutOrder = 1

    makeGradient(hero, ColorSequence.new({
        ColorSequenceKeypoint.new(0, Color3.fromRGB(18, 12, 28)),
        ColorSequenceKeypoint.new(0.55, Color3.fromRGB(23, 9, 19)),
        ColorSequenceKeypoint.new(1, Color3.fromRGB(12, 8, 16)),
    }), 0)

    local guardArtwork = Instance.new("ImageLabel")
    guardArtwork.Name = "BannerGuards"
    guardArtwork.AnchorPoint = Vector2.new(1, 0.5)
    guardArtwork.Position = UDim2.new(1, -6, 0.5, 0)
    guardArtwork.Size = UDim2.new(phone and 0.53 or 0.56, 0, 1, -6)
    guardArtwork.BackgroundTransparency = 1
    guardArtwork.Image = ""
    guardArtwork.ScaleType = Enum.ScaleType.Crop
    guardArtwork.ZIndex = 1011
    guardArtwork.Parent = hero
    self:SetImageFromAsset(guardArtwork, self.Config.Assets and self.Config.Assets.BannerGuards, nil)

    local logoSize = phone and 92 or 116
    local logoImage = Instance.new("ImageLabel")
    logoImage.Name = "HeroLogo"
    logoImage.Position = UDim2.fromOffset(phone and 22 or 24, math.floor((height - logoSize) / 2))
    logoImage.Size = UDim2.fromOffset(logoSize, logoSize)
    logoImage.BackgroundTransparency = 1
    logoImage.Image = ""
    logoImage.ScaleType = Enum.ScaleType.Fit
    logoImage.ZIndex = 1014
    logoImage.Parent = hero
    self:SetImageFromAsset(logoImage, self.Config.Assets and self.Config.Assets.Logo, "SN")

    local textX = phone and 132 or 166
    self:CreateText(hero, "WELCOME TO", UDim2.fromOffset(190, 24), UDim2.fromOffset(textX, phone and 24 or 36), {
        Font = Enum.Font.GothamMedium,
        TextSize = phone and 14 or 16,
        Color = self.Colors.Text,
        ZIndex = 1014,
    })
    self:CreateText(hero, "SQUIDNOMO", UDim2.fromOffset(420, 44), UDim2.fromOffset(textX, phone and 46 or 60), {
        Font = Enum.Font.GothamBlack,
        TextSize = phone and 29 or 34,
        Color = self.Colors.Text,
        ZIndex = 1014,
    })
    self:CreateText(hero, "THE ULTIMATE SQUID GAME EXPERIENCE", UDim2.fromOffset(480, 24), UDim2.fromOffset(textX, phone and 91 or 110), {
        Font = Enum.Font.GothamBold,
        TextSize = phone and 10 or 12,
        Color = self.Colors.Accent,
        ZIndex = 1014,
    })

    local version = Instance.new("TextLabel")
    version.AnchorPoint = Vector2.new(1, 1)
    version.Position = UDim2.new(1, -14, 1, -14)
    version.Size = UDim2.fromOffset(phone and 76 or 90, phone and 30 or 34)
    version.BackgroundColor3 = self.Colors.AccentDark
    version.BorderSizePixel = 0
    version.Font = Enum.Font.GothamBold
    version.Text = self.Version
    version.TextSize = phone and 12 or 15
    version.TextColor3 = self.Colors.Text
    version.ZIndex = 1014
    version.Parent = hero
    makeCorner(version, 9)
end

function App:CreateFeatureCategoryCard(parent, categoryKey, title, description, color, position, widthScale, height)
    local phone = self.DeviceClass == "Phone"
    local card = self:CreateCard(parent, UDim2.new(0.333333, -8, 1, 0), {
        Color = Color3.fromRGB(17, 12, 24),
        BorderColor = color,
        BorderTransparency = 0.10,
        Radius = phone and 12 or 14,
        ZIndex = 1011,
    })
    card.LayoutOrder = widthScale or 1

    local button = Instance.new("TextButton")
    button.Name = categoryKey .. "CategoryToggle"
    button.Size = UDim2.fromScale(1, 1)
    button.BackgroundTransparency = 1
    button.BorderSizePixel = 0
    button.AutoButtonColor = false
    button.Text = ""
    button.ZIndex = 1015
    button.Parent = card

    local glyph = self:CreateText(card, categoryKey == "Safe" and "✓" or (categoryKey == "SemiSafe" and "!" or "X"), UDim2.fromOffset(phone and 38 or 44, height - 16), UDim2.fromOffset(phone and 12 or 16, 8), {
        Font = Enum.Font.GothamBlack,
        TextSize = phone and 27 or 31,
        Color = color,
        XAlignment = Enum.TextXAlignment.Center,
        ZIndex = 1013,
    })

    local textX = phone and 56 or 66
    self:CreateText(card, string.upper(title), UDim2.new(1, -(textX + (phone and 76 or 70)), 0, 18), UDim2.fromOffset(textX, phone and 11 or 14), {
        Font = Enum.Font.GothamBold,
        TextSize = phone and 9 or 10,
        Color = color,
        ZIndex = 1013,
    })

    local available = self:CreateText(card, "0 Available", UDim2.new(1, -(textX + (phone and 76 or 70)), 0, 18), UDim2.fromOffset(textX, phone and 31 or 38), {
        Font = Enum.Font.GothamMedium,
        TextSize = phone and 9 or 10,
        Color = self.Colors.Text,
        ZIndex = 1013,
    })

    local descriptionLabel = self:CreateText(card, description, UDim2.new(1, -(textX + 16), 0, phone and 30 or 34), UDim2.fromOffset(textX, phone and 51 or 60), {
        Font = Enum.Font.Gotham,
        TextSize = phone and 8 or 9,
        Color = self.Colors.Muted,
        Wrapped = true,
        ZIndex = 1013,
    })

    local switch = Instance.new("Frame")
    switch.AnchorPoint = Vector2.new(1, 0)
    switch.Position = UDim2.new(1, phone and -12 or -16, 0, phone and 15 or 18)
    switch.Size = UDim2.fromOffset(phone and 46 or 50, phone and 24 or 26)
    switch.BackgroundColor3 = Color3.fromRGB(68, 64, 78)
    switch.BorderSizePixel = 0
    switch.ZIndex = 1013
    switch.Parent = card
    makeCorner(switch, 999)

    local knob = Instance.new("Frame")
    knob.Position = UDim2.fromOffset(3, 3)
    knob.Size = UDim2.fromOffset(phone and 18 or 20, phone and 18 or 20)
    knob.BackgroundColor3 = Color3.fromRGB(215, 211, 222)
    knob.BorderSizePixel = 0
    knob.ZIndex = 1014
    knob.Parent = switch
    makeCorner(knob, 999)

    button.Activated:Connect(function()
        self:PulseGlow(card, color)
        local summary = self:GetFeatureOverview()
        local category = summary.Categories[categoryKey]

        if not category or category.Total <= 0 then
            if self.Notifications and type(self.Notifications.Info) == "function" then
                self.Notifications:Info("Feature Categories", "No " .. title .. " are registered yet.", 3)
            end
            return
        end

        if self.FeatureManager and type(self.FeatureManager.SetCategoryEnabled) == "function" then
            local desired = category.State ~= "on"
            self.FeatureManager:SetCategoryEnabled(categoryKey, desired)
            task.defer(function()
                self:RefreshFeatureDashboard()
            end)
        end
    end)

    return {
        Card = card,
        Available = available,
        Description = descriptionLabel,
        Switch = switch,
        Knob = knob,
        Color = color,
        Glyph = glyph,
        Button = button,
    }
end

function App:RefreshFeatureDashboard()
    local widgets = self.FeatureWidgets
    if not widgets or not widgets.Root or not widgets.Root.Parent then
        return
    end

    local summary = self:GetFeatureOverview()

    if widgets.Total then
        widgets.Total.Text = "Total Features: " .. tostring(summary.Total)
    end

    local stateValues = {
        FullyOn = {Count = summary.FullyOn, Percent = summary.FullyPercent, Description = summary.Total == 0 and "No features registered" or "Enabled features"},
        Partial = {Count = summary.Partial, Percent = summary.PartialPercent, Description = summary.Total == 0 and "No features registered" or "Partially enabled features"},
        Off = {Count = summary.Off, Percent = summary.OffPercent, Description = summary.Total == 0 and "No features registered" or "Disabled features"},
    }

    for key, values in pairs(stateValues) do
        local refs = widgets.States and widgets.States[key]
        if refs then
            refs.Count.Text = tostring(values.Count)
            refs.Percent.Text = tostring(values.Percent) .. "%"
            refs.Description.Text = values.Description
        end
    end

    for categoryKey, refs in pairs(widgets.Categories or {}) do
        local category = summary.Categories[categoryKey] or {Total = 0, State = "empty"}
        refs.Available.Text = tostring(category.Total or 0) .. " Available"

        local state = category.State or "empty"
        local on = state == "on"
        local partial = state == "partial"
        local disabled = (category.Total or 0) == 0

        refs.Button.Active = not disabled
        refs.Card.BackgroundTransparency = disabled and 0.20 or 0
        refs.Switch.BackgroundColor3 = on and refs.Color or (partial and self.Colors.Warning or Color3.fromRGB(68, 64, 78))
        refs.Knob.BackgroundColor3 = disabled and self.Colors.Dim or Color3.fromRGB(245, 242, 248)

        local knobWidth = refs.Knob.Size.X.Offset
        local trackWidth = refs.Switch.Size.X.Offset
        local knobX = on and (trackWidth - knobWidth - 3) or (partial and math.floor((trackWidth - knobWidth) / 2) or 3)
        refs.Knob.Position = UDim2.fromOffset(knobX, 3)
    end

    if widgets.LoadedValue then
        widgets.LoadedValue.Text = tostring(summary.Total)
    end
end

function App:StartFeatureTracking()
    if self._featureTrackingStarted then
        return
    end
    self._featureTrackingStarted = true

    if self.FeatureManager and type(self.FeatureManager.Subscribe) == "function" then
        local ok, connection = pcall(function()
            return self.FeatureManager:Subscribe(function()
                task.defer(function()
                    self:RefreshFeatureDashboard()
                end)
            end)
        end)
        if ok and connection then
            self:Track(connection)
        end
    end

    task.spawn(function()
        while self.Gui and self.Gui.Parent do
            task.wait(2.0)
            self:RefreshFeatureDashboard()
        end
    end)
end

function App:BuildFeatureStats(parent)
    local summary = self:GetFeatureOverview()
    local phone = self.DeviceClass == "Phone"
    local cardHeight = self.Profile.FeatureHeight
    local stateHeight = phone and 104 or 118
    local stateY = phone and 46 or 52

    local card = self:CreateCard(parent, UDim2.new(1, 0, 0, cardHeight), {
        Color = Color3.fromRGB(13, 10, 18),
        BorderColor = self.Colors.Border,
        BorderTransparency = 0.08,
        Radius = phone and 14 or 18,
    })
    card.LayoutOrder = 2

    self:CreateText(card, "FEATURE STATS", UDim2.fromOffset(220, 26), UDim2.fromOffset(16, phone and 10 or 14), {
        Font = Enum.Font.GothamBlack,
        TextSize = phone and 16 or 18,
        Color = self.Colors.Accent,
        ZIndex = 1013,
    })

    local totalLabel = self:CreateText(card, "Total Features: " .. tostring(summary.Total), UDim2.fromOffset(200, 24), UDim2.new(1, -216, 0, phone and 11 or 16), {
        Font = Enum.Font.GothamBold,
        TextSize = phone and 11 or 12,
        Color = self.Colors.Text,
        XAlignment = Enum.TextXAlignment.Right,
        ZIndex = 1013,
    })

    local stateRow = self:CreateEqualThreeColumnRow(card, stateY, stateHeight, "FeatureStateRow")
    local _, fullyRefs = self:CreateFeatureStateCard(stateRow, nil, 1, self.Colors.Success, "FULLY ON", summary.FullyOn, summary.FullyPercent, "Enabled features", stateHeight)
    local _, partialRefs = self:CreateFeatureStateCard(stateRow, nil, 2, self.Colors.Warning, "PARTIALLY ON", summary.Partial, summary.PartialPercent, "Partially enabled", stateHeight)
    local _, offRefs = self:CreateFeatureStateCard(stateRow, nil, 3, self.Colors.Error, "NOT ON", summary.Off, summary.OffPercent, "Disabled features", stateHeight)

    local registryY = stateY + stateHeight + (phone and 7 or 9)
    local registry = Instance.new("Frame")
    registry.Position = UDim2.fromOffset(16, registryY)
    registry.Size = UDim2.new(1, -32, 0, phone and 25 or 28)
    registry.BackgroundColor3 = self.Colors.CardAlt
    registry.BackgroundTransparency = 0.28
    registry.BorderSizePixel = 0
    registry.ZIndex = 1012
    registry.Parent = card
    makeCorner(registry, 9)
    makeStroke(registry, self.Colors.BorderSoft, 1, 0.46)

    self:CreateText(registry, "LIVE REGISTRY", UDim2.fromOffset(110, 20), UDim2.fromOffset(10, 2), {
        Font = Enum.Font.GothamBlack,
        TextSize = phone and 9 or 10,
        Color = self.Colors.Success,
        ZIndex = 1013,
    })

    self:CreateText(registry, "Updates automatically as features change on their dedicated pages.", UDim2.new(1, -130, 1, 0), UDim2.fromOffset(120, 0), {
        Font = Enum.Font.GothamMedium,
        TextSize = phone and 9 or 10,
        Color = self.Colors.Text,
        XAlignment = Enum.TextXAlignment.Right,
        ZIndex = 1013,
    })

    self.FeatureWidgets = {
        Root = card,
        Total = totalLabel,
        States = {
            FullyOn = fullyRefs,
            Partial = partialRefs,
            Off = offRefs,
        },
        Categories = {},
    }

    self:StartFeatureTracking()
    self:RefreshFeatureDashboard()
end

function App:CreateEqualTwoColumnRow(parent, height, layoutOrder)
    local row = Instance.new("Frame")
    row.Name = "TwoColumnStatsRow"
    row.Size = UDim2.new(1, 0, 0, height or 170)
    row.BackgroundTransparency = 1
    row.BorderSizePixel = 0
    row.LayoutOrder = layoutOrder or 1
    row.Parent = parent

    local layout = Instance.new("UIListLayout")
    layout.FillDirection = Enum.FillDirection.Horizontal
    layout.HorizontalAlignment = Enum.HorizontalAlignment.Left
    layout.VerticalAlignment = Enum.VerticalAlignment.Center
    layout.SortOrder = Enum.SortOrder.LayoutOrder
    layout.Padding = UDim.new(0, 12)
    layout.Parent = row

    return row
end

function App:CreateThreeColumnRow(parent, height, layoutOrder)
    local row = Instance.new("Frame")
    row.Name = "StatsRow"
    row.Size = UDim2.new(1, 0, 0, height or 208)
    row.BackgroundTransparency = 1
    row.BorderSizePixel = 0
    row.LayoutOrder = layoutOrder or 1
    row.Parent = parent

    local layout = Instance.new("UIListLayout")
    layout.FillDirection = Enum.FillDirection.Horizontal
    layout.HorizontalAlignment = Enum.HorizontalAlignment.Left
    layout.VerticalAlignment = Enum.VerticalAlignment.Center
    layout.SortOrder = Enum.SortOrder.LayoutOrder
    layout.Padding = UDim.new(0, 12)
    layout.Parent = row

    return row
end

function App:CreateCompactMetric(
    parent,
    position,
    widthScale,
    labelText,
    valueText,
    valueColor,
    detailText,
    height
)
    local phone = self.DeviceClass == "Phone"
    local metricHeight = height or (phone and 76 or 90)

    local frame = Instance.new("Frame")
    frame.Position = position
    frame.Size = UDim2.new(widthScale, -18, 0, metricHeight)
    frame.BackgroundColor3 = self.Colors.CardAlt
    frame.BackgroundTransparency = 0.22
    frame.BorderSizePixel = 0
    frame.ZIndex = 1012
    frame.Parent = parent
    makeCorner(frame, 12)
    makeStroke(frame, self.Colors.BorderSoft, 1, 0.62)

    self:CreateText(
        frame,
        labelText,
        UDim2.new(1, -18, 0, 22),
        UDim2.fromOffset(9, 14),
        {
            Font = Enum.Font.GothamBold,
            TextSize = phone and 11 or 12,
            Color = self.Colors.Muted,
            XAlignment = Enum.TextXAlignment.Center,
            ZIndex = 1013,
        }
    )

    local value = self:CreateText(
        frame,
        valueText,
        UDim2.new(1, -18, 0, 42),
        UDim2.new(0, 9, 0.5, -20),
        {
            Font = Enum.Font.GothamBlack,
            TextSize = phone and 24 or 28,
            Color = valueColor or self.Colors.Text,
            XAlignment = Enum.TextXAlignment.Center,
            ZIndex = 1013,
        }
    )

    self:CreateText(
        frame,
        string.upper(detailText or "LIVE"),
        UDim2.new(1, -18, 0, 20),
        UDim2.new(0, 9, 1, -34),
        {
            Font = Enum.Font.GothamBold,
            TextSize = phone and 9 or 10,
            Color = self.Colors.Accent,
            XAlignment = Enum.TextXAlignment.Center,
            ZIndex = 1013,
        }
    )

    return value
end

function App:BuildBottomStatsRow(parent)
    local rowHeight = self.Profile.BottomStatsHeight
    local row = self:CreateEqualTwoColumnRow(parent, rowHeight, 3)
    local phone = self.DeviceClass == "Phone"

    local left = self:CreateCard(row, UDim2.new(0.5, -8, 1, 0), {
        Color = Color3.fromRGB(13, 10, 18),
        BorderColor = self.Colors.Border,
        BorderTransparency = 0.14,
        Radius = phone and 14 or 18,
    })
    left.LayoutOrder = 1

    local right = self:CreateCard(row, UDim2.new(0.5, -8, 1, 0), {
        Color = Color3.fromRGB(13, 10, 18),
        BorderColor = self.Colors.Border,
        BorderTransparency = 0.14,
        Radius = phone and 14 or 18,
    })
    right.LayoutOrder = 2

    self:CreateText(left, "SERVER STATS", UDim2.fromOffset(220, 24), UDim2.fromOffset(16, phone and 10 or 14), {
        Font = Enum.Font.GothamBlack,
        TextSize = phone and 13 or 16,
        Color = self.Colors.Accent,
        ZIndex = 1013,
    })
    self:CreateText(right, "NOMO STATS", UDim2.fromOffset(220, 24), UDim2.fromOffset(16, phone and 10 or 14), {
        Font = Enum.Font.GothamBlack,
        TextSize = phone and 13 or 16,
        Color = self.Colors.Accent,
        ZIndex = 1013,
    })

    local metricY = phone and 46 or 52
    local metricHeight = rowHeight - metricY - (phone and 12 or 14)

    local playersValue = self:CreateCompactMetric(
        left,
        UDim2.fromOffset(14, metricY),
        0.333,
        "Players",
        tostring(#Players:GetPlayers()),
        self.Colors.Text,
        "In Server",
        metricHeight
    )
    local pingValue = self:CreateCompactMetric(
        left,
        UDim2.new(0.333333, 7, 0, metricY),
        0.333333,
        "Ping",
        "-- ms",
        self.Colors.Text,
        "Network",
        metricHeight
    )
    local fpsValue = self:CreateCompactMetric(
        left,
        UDim2.new(0.666666, 0, 0, metricY),
        0.333334,
        "FPS",
        "--",
        self.Colors.Text,
        "Rendering",
        metricHeight
    )

    local uptimeValue = self:CreateCompactMetric(
        right,
        UDim2.fromOffset(14, metricY),
        0.333,
        "Uptime",
        "00:00",
        self.Colors.Text,
        "Session",
        metricHeight
    )
    local memoryValue = self:CreateCompactMetric(
        right,
        UDim2.new(0.333333, 7, 0, metricY),
        0.333333,
        "Memory",
        "-- MB",
        self.Colors.Text,
        "Client",
        metricHeight
    )
    local versionValue = self:CreateCompactMetric(
        right,
        UDim2.new(0.666666, 0, 0, metricY),
        0.333334,
        "Version",
        self.Version,
        self.Colors.Text,
        "Current Build",
        metricHeight
    )

    self.FeatureWidgets.LoadedValue = nil

    task.spawn(function()
        local startedAt = os.clock()
        while left.Parent and right.Parent and self.Gui do
            task.wait(1)
            local ping = "-- ms"
            local fps = "--"
            local memory = "-- MB"

            pcall(function()
                ping = tostring(math.floor(Stats.Network.ServerStatsItem["Data Ping"]:GetValue())) .. " ms"
            end)
            if self.Utilities and type(self.Utilities.GetFPS) == "function" then
                pcall(function()
                    fps = tostring(self.Utilities:GetFPS())
                end)
            end
            pcall(function()
                memory = string.format("%.0f MB", Stats:GetTotalMemoryUsageMb())
            end)

            local elapsed = math.floor(os.clock() - startedAt)
            local uptime = string.format("%02d:%02d", math.floor(elapsed / 60), elapsed % 60)

            playersValue.Text = tostring(#Players:GetPlayers())
            pingValue.Text = ping
            fpsValue.Text = fps
            uptimeValue.Text = uptime
            memoryValue.Text = memory
            versionValue.Text = self.Version
        end
    end)
end

function App:BuildPlaceholder(page, title, message)
    local content = Instance.new("Frame")
    content.Size = UDim2.new(1, 0, 0, 0)
    content.AutomaticSize = Enum.AutomaticSize.Y
    content.BackgroundTransparency = 1
    content.Parent = page
    makePadding(content, 16, 16, 16, 16)

    local card = self:CreateCard(content, UDim2.new(1, 0, 0, 190), {
        BorderColor = self.Colors.AccentDark,
    })

    self:CreateText(card, string.upper(title), UDim2.new(1, -40, 0, 35), UDim2.fromOffset(20, 20), {
        Font = Enum.Font.GothamBlack,
        TextSize = 22,
        Color = self.Colors.Text,
    })

    self:CreateText(card, message, UDim2.new(1, -40, 0, 70), UDim2.fromOffset(20, 67), {
        Font = Enum.Font.Gotham,
        TextSize = 12,
        Color = self.Colors.Muted,
        Wrapped = true,
        YAlignment = Enum.TextYAlignment.Top,
    })

    self:CreatePill(card, "APP SHELL READY", self.Colors.Accent, UDim2.fromOffset(20, 145), 120)
end

function App:BuildErrorPage(page, title, errorText)
    local content = Instance.new("Frame")
    content.Size = UDim2.new(1, 0, 0, 0)
    content.AutomaticSize = Enum.AutomaticSize.Y
    content.BackgroundTransparency = 1
    content.Parent = page
    makePadding(content, 16, 16, 16, 16)

    local card = self:CreateCard(content, UDim2.new(1, 0, 0, 260), {
        Color = Color3.fromRGB(35, 15, 15),
        BorderColor = self.Colors.Error,
        BorderTransparency = 0.05,
    })

    self:CreateText(card, "MODULE COULD NOT BUILD: " .. string.upper(title), UDim2.new(1, -40, 0, 30), UDim2.fromOffset(20, 18), {
        Font = Enum.Font.GothamBold,
        TextSize = 14,
        Color = self.Colors.Error,
    })

    self:CreateText(card, "The main app is still running. Copy the message below when asking for help.", UDim2.new(1, -40, 0, 38), UDim2.fromOffset(20, 52), {
        Font = Enum.Font.Gotham,
        TextSize = 11,
        Color = self.Colors.Muted,
        Wrapped = true,
    })

    local errorBox = Instance.new("TextBox")
    errorBox.Position = UDim2.fromOffset(20, 100)
    errorBox.Size = UDim2.new(1, -40, 0, 135)
    errorBox.BackgroundColor3 = Color3.fromRGB(15, 8, 8)
    errorBox.BorderSizePixel = 0
    errorBox.ClearTextOnFocus = false
    errorBox.MultiLine = true
    errorBox.TextEditable = false
    errorBox.TextWrapped = true
    errorBox.Font = Enum.Font.Code
    errorBox.Text = tostring(errorText or "Unknown module error")
    errorBox.TextSize = 10
    errorBox.TextColor3 = self.Colors.Text
    errorBox.TextXAlignment = Enum.TextXAlignment.Left
    errorBox.TextYAlignment = Enum.TextYAlignment.Top
    errorBox.ZIndex = 1013
    errorBox.Parent = card
    makeCorner(errorBox, 9)
    makePadding(errorBox, 10, 10, 8, 8)
end

function App:GetModuleErrorCount()
    local count = 0
    for _ in pairs(self.ModuleErrors) do
        count = count + 1
    end
    return count
end


function App:CreateTermsModal()
    local environment = self:GetSessionEnvironment()
    local acceptedByServer = environment.__SquidNoMoTermsAcceptedByServer
    if type(acceptedByServer) == "table" and acceptedByServer[game.JobId] == true then
        self.TermsAccepted = true
        if self.Session then self.Session.TermsAccepted = true end
    end
    if self.TermsAccepted or not self.Window then
        return
    end

    local mobile = self:IsMobile()

    local overlay = Instance.new("Frame")
    overlay.Name = "TermsOverlay"
    overlay.Size = UDim2.fromScale(1, 1)
    overlay.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
    overlay.BackgroundTransparency = 0.20
    overlay.BorderSizePixel = 0
    overlay.Active = true
    overlay.ZIndex = 3000
    overlay.Parent = self.Window

    local modalWidth = mobile and 820 or 760
    local headerHeight = 112
    local bodyHeight = mobile and 244 or 224
    local bodyY = headerHeight + 8
    local acceptY = bodyY + bodyHeight + 14
    local acceptHeight = 58
    local buttonsY = acceptY + acceptHeight + 16
    local buttonHeight = 60
    local footerY = buttonsY + buttonHeight + 10
    local modalHeight = footerY + 28

    local modal = Instance.new("Frame")
    modal.AnchorPoint = Vector2.new(0.5, 0.5)
    modal.Position = UDim2.fromScale(0.5, 0.5)
    modal.Size = UDim2.fromOffset(modalWidth, modalHeight)
    modal.BackgroundColor3 = Color3.fromRGB(15, 11, 23)
    modal.BorderSizePixel = 0
    modal.ClipsDescendants = true
    modal.ZIndex = 3001
    modal.Parent = overlay
    makeCorner(modal, 22)
    makeStroke(modal, self.Colors.Border, 2, 0.02)

    self:CreateText(modal, "!   BEFORE YOU CONTINUE   !", UDim2.new(1, -48, 0, 42), UDim2.fromOffset(24, 18), {
        Font = Enum.Font.GothamBlack,
        TextSize = mobile and 30 or 28,
        Color = self.Colors.Warning,
        XAlignment = Enum.TextXAlignment.Center,
        ZIndex = 3003,
    })

    self:CreateText(modal, "!   READ AND ACCEPT THESE RISKS BEFORE ACCESSING SQUIDNOMO   !", UDim2.new(1, -56, 0, 30), UDim2.fromOffset(28, 64), {
        Font = Enum.Font.GothamBold,
        TextSize = mobile and 15 or 14,
        Color = self.Colors.Accent,
        XAlignment = Enum.TextXAlignment.Center,
        ZIndex = 3003,
    })

    local headerDragHandle = Instance.new("TextButton")
    headerDragHandle.Name = "TermsDragHandle"
    headerDragHandle.Position = UDim2.fromOffset(0, 0)
    headerDragHandle.Size = UDim2.new(1, 0, 0, headerHeight)
    headerDragHandle.BackgroundTransparency = 1
    headerDragHandle.BorderSizePixel = 0
    headerDragHandle.AutoButtonColor = false
    headerDragHandle.Text = ""
    headerDragHandle.ZIndex = 3004
    headerDragHandle.Parent = modal
    self:EnableDragging(headerDragHandle)

    local divider = Instance.new("Frame")
    divider.Position = UDim2.fromOffset(28, headerHeight - 1)
    divider.Size = UDim2.new(1, -56, 0, 1)
    divider.BackgroundColor3 = self.Colors.BorderSoft
    divider.BorderSizePixel = 0
    divider.ZIndex = 3002
    divider.Parent = modal

    local bodyCard = Instance.new("Frame")
    bodyCard.Position = UDim2.fromOffset(32, bodyY)
    bodyCard.Size = UDim2.new(1, -64, 0, bodyHeight)
    bodyCard.BackgroundColor3 = self.Colors.Card
    bodyCard.BorderSizePixel = 0
    bodyCard.ZIndex = 3002
    bodyCard.Parent = modal
    makeCorner(bodyCard, 14)
    makeStroke(bodyCard, self.Colors.BorderSoft, 1, 0.14)

    local body = Instance.new("TextLabel")
    body.BackgroundTransparency = 1
    body.Position = UDim2.fromOffset(24, 18)
    body.Size = UDim2.new(1, -48, 1, -36)
    body.Font = Enum.Font.GothamMedium
    body.TextWrapped = true
    body.TextYAlignment = Enum.TextYAlignment.Center
    body.TextXAlignment = Enum.TextXAlignment.Center
    body.TextSize = mobile and 18 or 17
    body.TextColor3 = self.Colors.Text
    body.Text = [=[Using this software may violate the game's Terms of Service. Your account may be warned, restricted, suspended, or banned.

Use it entirely at your own risk. The developers are not responsible for account actions, lost progress or data, crashes, interrupted gameplay, device problems, or any other consequences resulting from its use.

Only continue if you fully understand and accept these risks.]=]
    body.ZIndex = 3003
    body.Parent = bodyCard
    pcall(function()
        body.LineHeight = 1.12
    end)

    local acceptRow = Instance.new("TextButton")
    acceptRow.Position = UDim2.fromOffset(32, acceptY)
    acceptRow.Size = UDim2.new(1, -64, 0, acceptHeight)
    acceptRow.BackgroundColor3 = self.Colors.CardAlt
    acceptRow.BorderSizePixel = 0
    acceptRow.AutoButtonColor = false
    acceptRow.Text = ""
    acceptRow.ZIndex = 3002
    acceptRow.Parent = modal
    makeCorner(acceptRow, 13)
    local acceptStroke = makeStroke(acceptRow, self.Colors.BorderSoft, 1.2, 0.12)

    local checkbox = Instance.new("Frame")
    checkbox.AnchorPoint = Vector2.new(0, 0.5)
    checkbox.Position = UDim2.new(0, 16, 0.5, 0)
    checkbox.Size = UDim2.fromOffset(34, 34)
    checkbox.BackgroundColor3 = Color3.fromRGB(10, 8, 15)
    checkbox.BorderSizePixel = 0
    checkbox.ZIndex = 3003
    checkbox.Parent = acceptRow
    makeCorner(checkbox, 9)
    local checkboxStroke = makeStroke(checkbox, self.Colors.Border, 1.5, 0.08)

    local check = Instance.new("TextLabel")
    check.BackgroundTransparency = 1
    check.Size = UDim2.fromScale(1, 1)
    check.Font = Enum.Font.GothamBlack
    check.Text = "✓"
    check.TextSize = 22
    check.TextColor3 = Color3.fromRGB(255, 255, 255)
    check.Visible = false
    check.ZIndex = 3004
    check.Parent = checkbox

    self:CreateText(acceptRow, "I UNDERSTAND AND ACCEPT THESE RISKS", UDim2.new(1, -78, 1, 0), UDim2.fromOffset(66, 0), {
        Font = Enum.Font.GothamBold,
        TextSize = mobile and 17 or 16,
        Color = self.Colors.Text,
        XAlignment = Enum.TextXAlignment.Center,
        ZIndex = 3003,
    })

    local buttonRow = Instance.new("Frame")
    buttonRow.Position = UDim2.fromOffset(32, buttonsY)
    buttonRow.Size = UDim2.new(1, -64, 0, buttonHeight)
    buttonRow.BackgroundTransparency = 1
    buttonRow.BorderSizePixel = 0
    buttonRow.ZIndex = 3002
    buttonRow.Parent = modal

    local buttonLayout = Instance.new("UIListLayout")
    buttonLayout.FillDirection = Enum.FillDirection.Horizontal
    buttonLayout.HorizontalAlignment = Enum.HorizontalAlignment.Left
    buttonLayout.VerticalAlignment = Enum.VerticalAlignment.Center
    buttonLayout.SortOrder = Enum.SortOrder.LayoutOrder
    buttonLayout.Padding = UDim.new(0, 16)
    buttonLayout.Parent = buttonRow

    local exitButton = Instance.new("TextButton")
    exitButton.Size = UDim2.new(0.34, -8, 1, 0)
    exitButton.BackgroundColor3 = self.Colors.CardAlt
    exitButton.BorderSizePixel = 0
    exitButton.AutoButtonColor = false
    exitButton.Font = Enum.Font.GothamBold
    exitButton.Text = "EXIT"
    exitButton.TextSize = mobile and 18 or 17
    exitButton.TextColor3 = self.Colors.Text
    exitButton.LayoutOrder = 1
    exitButton.ZIndex = 3002
    exitButton.Parent = buttonRow
    makeCorner(exitButton, 13)
    makeStroke(exitButton, self.Colors.Close, 1.5, 0.12)
    self:BindButtonFeedback(exitButton, self.Colors.Close)

    local continueButton = Instance.new("TextButton")
    continueButton.Size = UDim2.new(0.66, -8, 1, 0)
    continueButton.BackgroundColor3 = self.Colors.CardAlt
    continueButton.BorderSizePixel = 0
    continueButton.AutoButtonColor = false
    continueButton.Font = Enum.Font.GothamBold
    continueButton.Text = "I UNDERSTAND — CONTINUE"
    continueButton.TextSize = mobile and 18 or 17
    continueButton.TextColor3 = self.Colors.Text
    continueButton.LayoutOrder = 2
    continueButton.ZIndex = 3002
    continueButton.Parent = buttonRow
    makeCorner(continueButton, 13)
    local continueStroke = makeStroke(continueButton, self.Colors.BorderSoft, 1.5, 0.12)
    self:BindButtonFeedback(continueButton, self.Colors.Accent)
    self:BindButtonFeedback(acceptRow, self.Colors.Accent)

    self:CreateText(modal, self.Version .. "  •  TERMS VERSION 1.2  •  ACCEPTANCE REQUIRED", UDim2.new(1, -64, 0, 18), UDim2.fromOffset(32, footerY), {
        Font = Enum.Font.GothamMedium,
        TextSize = 10,
        Color = self.Colors.Muted,
        XAlignment = Enum.TextXAlignment.Center,
        ZIndex = 3002,
    })

    local accepted = false

    local function refresh()
        check.Visible = accepted
        checkbox.BackgroundColor3 = accepted and self.Colors.Accent or Color3.fromRGB(10, 8, 15)
        checkboxStroke.Color = accepted and self.Colors.Accent or self.Colors.Border
        acceptStroke.Color = accepted and self.Colors.Accent or self.Colors.BorderSoft
        continueButton.BackgroundColor3 = accepted and self.Colors.Accent or self.Colors.CardAlt
        continueButton.TextTransparency = accepted and 0 or 0.24
        continueStroke.Color = accepted and self.Colors.Accent or self.Colors.BorderSoft
    end

    acceptRow.MouseButton1Click:Connect(function()
        accepted = not accepted
        refresh()
    end)

    exitButton.MouseButton1Click:Connect(function()
        if self.Session then
            self.Session.UserClosed = true
        end
        self:Destroy(true)
    end)

    continueButton.MouseButton1Click:Connect(function()
        if not accepted then
            if self.Notifications and type(self.Notifications.Warning) == "function" then
                pcall(function()
                    self.Notifications:Warning("Terms", "Tap the acceptance box before continuing.", 3)
                end)
            end
            return
        end

        self.TermsAccepted = true
        local environment = self:GetSessionEnvironment()
        local acceptedByServer = environment.__SquidNoMoTermsAcceptedByServer
        if type(acceptedByServer) ~= "table" then
            acceptedByServer = {}
            environment.__SquidNoMoTermsAcceptedByServer = acceptedByServer
        end
        acceptedByServer[game.JobId] = true
        if self.Session then
            self.Session.TermsAccepted = true
        end
        overlay:Destroy()
        self.TermsModal = nil
    end)

    refresh()
    self.TermsModal = overlay
end

----------------------------------------------------------
-- Responsive event binding
----------------------------------------------------------

function App:StartResponsive()
    local cameraConnection = nil

    local function bindCamera()
        safeDisconnect(cameraConnection)
        cameraConnection = nil

        local camera = workspace.CurrentCamera
        if camera then
            cameraConnection = camera:GetPropertyChangedSignal("ViewportSize"):Connect(function()
                task.defer(function()
                    self:UpdateResponsive(self.AutoCenterOnResizeEnabled)
                end)
            end)
            table.insert(self.Connections, cameraConnection)
        end
    end

    bindCamera()

    self:Track(workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
        bindCamera()
        task.defer(function()
            self:UpdateResponsive(self.AutoCenterOnResizeEnabled)
        end)
    end))

    self:Track(UserInputService:GetPropertyChangedSignal("TouchEnabled"):Connect(function()
        task.defer(function()
            self:UpdateResponsive(self.AutoCenterOnResizeEnabled)
        end)
    end))
end

----------------------------------------------------------
-- Visible emergency launch screen
----------------------------------------------------------

function App:CreateEmergencyGui(errorText)
    pcall(function()
        self:DestroyOldCopies()

        local gui = Instance.new("ScreenGui")
        gui.Name = self.Name
        gui.ResetOnSpawn = false
        gui.IgnoreGuiInset = true
        gui.DisplayOrder = self.Config.DisplayOrder
        gui.ZIndexBehavior = Enum.ZIndexBehavior.Global
        gui.Parent = self:GetGuiParent() or self:GetPlayerGui()

        local box = Instance.new("Frame")
        box.AnchorPoint = Vector2.new(0.5, 0.5)
        box.Position = UDim2.fromScale(0.5, 0.5)
        box.Size = UDim2.fromOffset(520, 260)
        box.BackgroundColor3 = Color3.fromRGB(27, 12, 12)
        box.BorderSizePixel = 0
        box.ZIndex = 9000
        box.Parent = gui
        makeCorner(box, 16)
        makeStroke(box, self.Colors.Error, 2, 0)

        self:CreateText(box, "SQUIDNOMO APP LAUNCH ERROR", UDim2.new(1, -40, 0, 35), UDim2.fromOffset(20, 18), {
            Font = Enum.Font.GothamBlack,
            TextSize = 18,
            Color = self.Colors.Error,
            ZIndex = 9001,
        })

        self:CreateText(box, "Delta may hide console errors, so this message is shown inside the game.", UDim2.new(1, -40, 0, 40), UDim2.fromOffset(20, 55), {
            Font = Enum.Font.Gotham,
            TextSize = 11,
            Color = self.Colors.Muted,
            Wrapped = true,
            ZIndex = 9001,
        })

        local message = Instance.new("TextBox")
        message.Position = UDim2.fromOffset(20, 105)
        message.Size = UDim2.new(1, -40, 0, 130)
        message.BackgroundColor3 = Color3.fromRGB(12, 6, 6)
        message.BorderSizePixel = 0
        message.ClearTextOnFocus = false
        message.MultiLine = true
        message.TextEditable = false
        message.TextWrapped = true
        message.Font = Enum.Font.Code
        message.Text = tostring(errorText)
        message.TextSize = 10
        message.TextColor3 = self.Colors.Text
        message.TextXAlignment = Enum.TextXAlignment.Left
        message.TextYAlignment = Enum.TextYAlignment.Top
        message.ZIndex = 9001
        message.Parent = box
        makeCorner(message, 10)
        makePadding(message, 10, 10, 8, 8)

        self.Gui = gui
    end)
end

----------------------------------------------------------
-- Mobile readability
----------------------------------------------------------

function App:ApplyReadableText(root)
    if not root or not self:IsMobile() then
        return
    end

    local function boost(instance)
        if not (instance:IsA("TextLabel") or instance:IsA("TextButton") or instance:IsA("TextBox")) then
            return
        end
        if instance.TextScaled or instance:GetAttribute("SquidReadableText") then
            return
        end

        local current = tonumber(instance.TextSize) or 14
        local boosted
        if current <= 10 then
            boosted = 14
        elseif current <= 13 then
            boosted = current + 4
        elseif current <= 17 then
            boosted = current + 3
        else
            boosted = current + 2
        end
        instance.TextSize = math.clamp(boosted, 14, 38)
        instance:SetAttribute("SquidReadableText", true)
    end

    boost(root)
    for _, instance in ipairs(root:GetDescendants()) do
        boost(instance)
    end

    if self._readabilityConnection then
        safeDisconnect(self._readabilityConnection)
    end
    self._readabilityConnection = root.DescendantAdded:Connect(function(instance)
        task.defer(boost, instance)
    end)
    table.insert(self.Connections, self._readabilityConnection)
end

----------------------------------------------------------
-- Public lifecycle
----------------------------------------------------------

function App:Build(loader)
    if self._building then
        return self
    end

    self._building = true
    self:Destroy(true)
    self.ModuleErrors = {}

    local ok, err = xpcall(function()
        self:Init(loader or {})
        self:CreateGui()
        self:CreateWindow()
        self:CreateSidebar()
        self:CreateTopbar()
        self:CreateStatusbar()
        self:CreatePageContainer()
        self:CreateReopenButton()
        self:BuildPageDefinitions()
        self:BuildPages()
        self:ApplyReadableText(self.Gui)

        local initialPage = "Home"
        if self.RememberLastPageEnabled and self.Session and self.Session.LastPage and self.Pages[self.Session.LastPage] then
            initialPage = self.Session.LastPage
        end
        self:OpenPage(initialPage)
        self:UpdateResponsive(true)
        self:StartResponsive()
        self:StartDetectionMonitor()
        self:CreateTermsModal()
        self:SetAppStatus("READY")

        if self.Session then
            self.Session.Loader = self.Loader
            self.Session.App = self
            self.Session.UserClosed = false
        end

        if self.Notifications and type(self.Notifications.Success) == "function" then
            pcall(function()
                self.Notifications:Success("SquidNoMo", "Responsive app shell loaded")
            end)
        end
    end, function(message)
        return debug.traceback(tostring(message), 2)
    end)

    self._building = false

    if not ok then
        warn("[SquidNoMo] Launch failed: " .. tostring(err))
        self:SetAppStatus("ERROR")
        self:Destroy(true)
        self:CreateEmergencyGui(err)
    end

    return self
end

function App:Destroy(keepSession)
    for _, connection in ipairs(self.Connections) do
        safeDisconnect(connection)
    end

    self.Connections = {}

    if self.Gui then
        pcall(function()
            self.Gui:Destroy()
        end)
    end

    self.Gui = nil
    self.Host = nil
    self.Window = nil
    self.WindowScale = nil
    self.Sidebar = nil
    self.Topbar = nil
    self.Statusbar = nil
    self.PageContainer = nil
    self.ReopenButton = nil
    self.PageTitle = nil
    self.TermsModal = nil
    self.SupportModal = nil
    self.CloseModal = nil
    self.MaximizeButton = nil
    self.Pages = {}
    self.PageDefinitions = {}
    self.NavigationButtons = {}
    self.AssetCache = {}
    self.FeatureWidgets = {}
    self.FooterLabels = {}
    self.CurrentPage = nil
    self.HasBeenDragged = false
    self.IsMinimized = false
    self.MinimizedByFreeRoam = false
    self.WindowSettingsWidgets = {}
    self.ReopenButtonHasBeenDragged = false
    self._featureTrackingStarted = false

    if not keepSession then
        self.TermsAccepted = false
    elseif self.Session then
        self.TermsAccepted = self.Session.TermsAccepted == true
    end
end

function App:GetPage(name)
    return self.Pages[name]
end

function App:GetWindow()
    return self.Window
end

function App:GetTheme()
    return self.Theme or self.Colors
end

function App:IsVisible()
    return self.Gui ~= nil and self.Gui.Parent ~= nil
end

function App:RefreshPageModule(name)
    if type(name) ~= "string" then
        return false
    end

    local page = self.Pages and self.Pages[name]
    if not page or not page.Container then
        return false
    end

    local builder = self.Loader and self.Loader[name]
    if type(builder) == "table"
        and type(builder.Create) == "function"
    then
        local ok = pcall(function()
            builder:Create(page.Container, self)
        end)
        return ok
    end

    return false
end

function App:RefreshAllPageLayouts()
    local order = {
        "Home",
        "Games",
        "Players",
        "Guards",
        "Detective",
        "Farming",
        "UI",
        "Settings",
    }

    for _, name in ipairs(order) do
        pcall(function()
            self:RefreshPageModule(name)
        end)
    end

    return true
end

function App:ApplyVisualRefresh()
    self:RefreshWindowSettings()
    self:RefreshAllPageLayouts()
    if self.Session and self.Session.LastPage
        and self.Pages
        and self.Pages[self.Session.LastPage]
    then
        pcall(function()
            self:OpenPage(self.Session.LastPage)
        end)
    end
end

function App:GetPerformanceProfile()
    local device = self.DeviceClass or "Phone"
    local mobile = self:IsMobile()

    return {
        LazyBuildPages = true,
        ReduceOverlayEffects = mobile,
        ReducedAnimationDefault = mobile,
        SmallerCanvasPadding = mobile,
        TouchDragSensitivity = 0.25,
        SliderStepScale = mobile and 0.45 or 0.7,
        HoldRepeatRate = mobile and 0.07 or 0.05,
    }
end

function App:CreateQuickButton(parent, label, size, accent)
    local button = Instance.new("TextButton")
    button.AutoButtonColor = false
    button.Text = tostring(label or "")
    button.Size = size or UDim2.fromOffset(48, 34)
    button.BackgroundColor3 = self.Colors.Card
    button.BackgroundTransparency = 0.08
    button.BorderSizePixel = 0
    button.TextColor3 = accent or self.Colors.Text
    button.Font = Enum.Font.GothamBold
    button.TextSize = self:IsMobile() and 12 or 13
    button.Parent = parent

    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 10)
    corner.Parent = button

    local stroke = Instance.new("UIStroke")
    stroke.Color = accent or self.Colors.BorderSoft
    stroke.Transparency = 0.28
    stroke.Thickness = 1
    stroke.Parent = button

    if type(self.BindButtonFeedback) == "function" then
        self:BindButtonFeedback(button, accent or self.Colors.Success)
    end

    return button
end

function App:CreateSlider(parent, options)
    options = options or {}

    local holder = Instance.new("Frame")
    holder.Name = "SliderHolder"
    holder.Position =
        options.Position or UDim2.fromOffset(0, 0)
    holder.Size =
        options.Size or UDim2.new(1, 0, 0, 32)
    holder.BackgroundTransparency = 1
    holder.BorderSizePixel = 0
    holder.Parent = parent

    local minimum = tonumber(options.Min) or 0
    local maximum = tonumber(options.Max) or 100
    local value = math.clamp(
        tonumber(options.Value) or minimum,
        minimum,
        maximum
    )
    local accent =
        options.AccentColor or self.Colors.Success
    local trackHeight = math.clamp(
        tonumber(options.TrackHeight) or 12,
        8,
        18
    )
    local knobSize = math.clamp(
        tonumber(options.KnobSize) or 28,
        24,
        36
    )

    local touchTarget = Instance.new("TextButton")
    touchTarget.Name = "TouchTarget"
    touchTarget.Size = UDim2.fromScale(1, 1)
    touchTarget.BackgroundTransparency = 1
    touchTarget.BorderSizePixel = 0
    touchTarget.AutoButtonColor = false
    touchTarget.Text = ""
    touchTarget.Active = true
    touchTarget.ZIndex = 1014
    touchTarget.Parent = holder

    local track = Instance.new("Frame")
    track.Name = "Track"
    track.AnchorPoint = Vector2.new(0, 0.5)
    track.Position = UDim2.new(0, 0, 0.5, 0)
    track.Size = UDim2.new(1, 0, 0, trackHeight)
    track.BackgroundColor3 = Color3.fromRGB(70, 64, 82)
    track.BackgroundTransparency = 0.08
    track.BorderSizePixel = 0
    track.ZIndex = 1015
    track.Parent = holder

    local trackCorner = Instance.new("UICorner")
    trackCorner.CornerRadius = UDim.new(1, 0)
    trackCorner.Parent = track

    local fill = Instance.new("Frame")
    fill.Name = "Fill"
    fill.Size = UDim2.new(0, 0, 1, 0)
    fill.BackgroundColor3 = accent
    fill.BorderSizePixel = 0
    fill.ZIndex = 1016
    fill.Parent = track

    local fillCorner = Instance.new("UICorner")
    fillCorner.CornerRadius = UDim.new(1, 0)
    fillCorner.Parent = fill

    local knob = Instance.new("Frame")
    knob.Name = "Knob"
    knob.AnchorPoint = Vector2.new(0.5, 0.5)
    knob.Size = UDim2.fromOffset(knobSize, knobSize)
    knob.Position = UDim2.new(0, 0, 0.5, 0)
    knob.BackgroundColor3 =
        Color3.fromRGB(250, 248, 252)
    knob.BorderSizePixel = 0
    knob.ZIndex = 1017
    knob.Parent = holder

    local knobCorner = Instance.new("UICorner")
    knobCorner.CornerRadius = UDim.new(1, 0)
    knobCorner.Parent = knob

    local knobStroke = Instance.new("UIStroke")
    knobStroke.Color = accent
    knobStroke.Thickness = 2
    knobStroke.Parent = knob

    local UserInputService =
        game:GetService("UserInputService")
    local dragging = false
    local activeTouch = nil
    local touchStartPosition = nil
    local touchMode = nil -- nil/"horizontal"/"vertical"

    local function render(nextValue, emit)
        value = math.clamp(
            tonumber(nextValue) or minimum,
            minimum,
            maximum
        )

        local span = math.max(
            0.0001,
            maximum - minimum
        )
        local alpha = (value - minimum) / span

        fill.Size = UDim2.new(alpha, 0, 1, 0)
        knob.Position =
            UDim2.new(alpha, 0, 0.5, 0)

        if emit
            and type(options.OnChanged) == "function"
        then
            options.OnChanged(value)
        end
    end

    local function valueFromInput(input)
        local width = track.AbsoluteSize.X
        if width <= 0 then
            return value
        end

        local alpha = math.clamp(
            (
                input.Position.X
                - track.AbsolutePosition.X
            ) / width,
            0,
            1
        )

        return minimum
            + ((maximum - minimum) * alpha)
    end

    self:Track(
        touchTarget.InputBegan:Connect(function(input)
            if input.UserInputType == Enum.UserInputType.Touch then
                activeTouch = input
                touchStartPosition = input.Position
                touchMode = nil
                dragging = false
            elseif input.UserInputType == Enum.UserInputType.MouseButton1 then
                activeTouch = nil
                touchStartPosition = nil
                touchMode = "horizontal"
                dragging = true
                render(valueFromInput(input), true)
            end
        end)
    )

    self:Track(
        UserInputService.InputChanged:Connect(
            function(input)
                local validTouch = activeTouch and input == activeTouch
                local validMouse = activeTouch == nil
                    and dragging
                    and input.UserInputType == Enum.UserInputType.MouseMovement

                if validTouch then
                    local delta = input.Position - (touchStartPosition or input.Position)
                    if touchMode == nil then
                        if math.abs(delta.Y) > 8 and math.abs(delta.Y) > math.abs(delta.X) then
                            -- Vertical intent belongs to the containing ScrollingFrame.
                            touchMode = "vertical"
                            dragging = false
                        elseif math.abs(delta.X) > 8 and math.abs(delta.X) >= math.abs(delta.Y) then
                            touchMode = "horizontal"
                            dragging = true
                        end
                    end
                    if touchMode == "horizontal" and dragging then
                        render(valueFromInput(input), true)
                    end
                elseif validMouse then
                    render(valueFromInput(input), true)
                end
            end
        )
    )

    self:Track(
        UserInputService.InputEnded:Connect(
            function(input)
                if input.UserInputType == Enum.UserInputType.MouseButton1 then
                    dragging = false
                elseif activeTouch and input == activeTouch then
                    -- A short stationary tap still sets the slider; a vertical swipe
                    -- is left completely untouched so the page can scroll naturally.
                    if touchMode == nil then
                        render(valueFromInput(input), true)
                    end
                    dragging = false
                    activeTouch = nil
                    touchStartPosition = nil
                    touchMode = nil
                end
            end
        )
    )

    local controller = {
        Root = holder,
        Track = track,
        Fill = fill,
        Knob = knob,
    }

    function controller:SetValue(nextValue, emit)
        render(nextValue, emit == true)
    end

    function controller:GetValue()
        return value
    end

    function controller:SetAccent(nextAccent)
        if typeof(nextAccent) == "Color3" then
            accent = nextAccent
            fill.BackgroundColor3 = nextAccent
            knobStroke.Color = nextAccent
        end
    end

    controller:SetValue(value, false)
    return controller
end

return App

]====],
        [ [====[Core/Components.lua]====] ] = [====[--//========================================================--
--// SquidNoMo
--// 1.1 beta 1
--// Components.lua
--//========================================================--

local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")

local Components = {}

Components.Theme = nil

----------------------------------------------------------
-- Initialize
----------------------------------------------------------

function Components:Initialize(Theme)
	assert(Theme, "[Components] Theme is required")
	self.Theme = Theme
end

local function IsTheme(Value)
	return type(Value) == "table"
		and Value.Card ~= nil
		and Value.Text ~= nil
end

----------------------------------------------------------
-- Card
----------------------------------------------------------

function Components:CreateCard(Parent, ThemeOrSize, MaybeSize)

	local Theme = IsTheme(ThemeOrSize) and ThemeOrSize or self.Theme
	local Size = MaybeSize or ThemeOrSize

	assert(Theme, "[Components] Components:Initialize(theme) was not called")
	assert(Size, "[Components] CreateCard requires a size")

	local Card = Instance.new("Frame")
	Card.Size = Size
	Card.BackgroundColor3 = Theme.Card
	Card.BorderSizePixel = 0
	Card.Parent = Parent

	local Corner = Instance.new("UICorner")
	Corner.CornerRadius = UDim.new(0,16)
	Corner.Parent = Card

	local Stroke = Instance.new("UIStroke")
	Stroke.Color = Theme.BorderDark
	Stroke.Thickness = 1
	Stroke.Parent = Card

	return Card
end

----------------------------------------------------------
-- Section
----------------------------------------------------------

function Components:CreateSection(Parent, ThemeOrTitle, MaybeTitle)

	local Theme = IsTheme(ThemeOrTitle) and ThemeOrTitle or self.Theme
	local Title = MaybeTitle or ThemeOrTitle

	local Section = Instance.new("Frame")
	Section.BackgroundTransparency = 1
	Section.Size = UDim2.new(1,0,0,0)
	Section.AutomaticSize = Enum.AutomaticSize.Y
	Section.Parent = Parent

	local Layout = Instance.new("UIListLayout")
	Layout.Padding = UDim.new(0,10)
	Layout.SortOrder = Enum.SortOrder.LayoutOrder
	Layout.Parent = Section

	local Header = Instance.new("TextLabel")
	Header.BackgroundTransparency = 1
	Header.Size = UDim2.new(1,0,0,26)
	Header.Font = Theme.FontBlack
	Header.Text = Title
	Header.TextSize = 19
	Header.TextColor3 = Theme.Text
	Header.TextXAlignment = Enum.TextXAlignment.Left
	Header.Parent = Section

	local Divider = Instance.new("Frame")
	Divider.Size = UDim2.new(1,0,0,1)
	Divider.BackgroundColor3 = Theme.BorderDark
	Divider.BorderSizePixel = 0
	Divider.Parent = Section

	local Content = Instance.new("Frame")
	Content.BackgroundTransparency = 1
	Content.Size = UDim2.new(1,0,0,0)
	Content.AutomaticSize = Enum.AutomaticSize.Y
	Content.Parent = Section

	local ContentLayout = Instance.new("UIListLayout")
	ContentLayout.Padding = UDim.new(0,8)
	ContentLayout.SortOrder = Enum.SortOrder.LayoutOrder
	ContentLayout.Parent = Content

	return Content
end

----------------------------------------------------------
-- Sidebar Button
----------------------------------------------------------

function Components:SidebarButton(Parent, Name, Icon)

	local Theme = self.Theme

	local Button = Instance.new("TextButton")
	Button.Name = Name
	Button.Size = UDim2.new(1,0,0,42)
	Button.BackgroundColor3 = Theme.Card
	Button.BorderSizePixel = 0
	Button.AutoButtonColor = false
	Button.Text = ""
	Button.Parent = Parent

	local Corner = Instance.new("UICorner")
	Corner.CornerRadius = UDim.new(0,10)
	Corner.Parent = Button

	local IconLabel = Instance.new("TextLabel")
	IconLabel.BackgroundTransparency = 1
	IconLabel.Position = UDim2.fromOffset(14,0)
	IconLabel.Size = UDim2.fromOffset(24,42)
	IconLabel.Font = Theme.FontBold
	IconLabel.Text = Icon
	IconLabel.TextSize = 18
	IconLabel.TextColor3 = Theme.Text
	IconLabel.Parent = Button

	local Label = Instance.new("TextLabel")
	Label.BackgroundTransparency = 1
	Label.Position = UDim2.fromOffset(46,0)
	Label.Size = UDim2.new(1,-46,1,0)
	Label.Font = Theme.Font
	Label.Text = Name
	Label.TextSize = 15
	Label.TextColor3 = Theme.Text
	Label.TextXAlignment = Enum.TextXAlignment.Left
	Label.Parent = Button

	function Button:SetSelected(State)

		TweenService:Create(
			Button,
			TweenInfo.new(.15),
			{
				BackgroundColor3 =
					State and Theme.Accent or Theme.Card
			}
		):Play()

	end

	function Button:SetCompact(State)
		Label.Visible = not State
		if State then
			IconLabel.AnchorPoint = Vector2.new(.5,0)
			IconLabel.Position = UDim2.new(.5,0,0,0)
		else
			IconLabel.AnchorPoint = Vector2.new(0,0)
			IconLabel.Position = UDim2.fromOffset(14,0)
		end
	end

	return Button
end

----------------------------------------------------------
-- Title
----------------------------------------------------------

function Components:CreateTitle(Parent, ThemeOrText, MaybeText)

	local Theme = IsTheme(ThemeOrText) and ThemeOrText or self.Theme
	local Text = MaybeText or ThemeOrText

	local Title = Instance.new("TextLabel")
	Title.BackgroundTransparency = 1
	Title.Position = UDim2.fromOffset(20,14)
	Title.Size = UDim2.new(1,-40,0,28)
	Title.Font = Theme.FontBlack
	Title.Text = tostring(Text or "")
	Title.TextSize = 19
	Title.TextColor3 = Theme.Text
	Title.TextXAlignment = Enum.TextXAlignment.Left
	Title.Parent = Parent

	return Title
end

----------------------------------------------------------
-- Button
----------------------------------------------------------

function Components:CreateButton(Parent, ThemeOrText, MaybeText)

	local Theme = IsTheme(ThemeOrText) and ThemeOrText or self.Theme
	local Text = MaybeText or ThemeOrText

	local Button = Instance.new("TextButton")

	Button.Size = UDim2.new(1,0,0,40)
	Button.BackgroundColor3 = Theme.Accent
	Button.BorderSizePixel = 0
	Button.AutoButtonColor = false
	Button.Font = Theme.FontBold
	Button.Text = Text
	Button.TextSize = 15
	Button.TextColor3 = Color3.new(1,1,1)
	Button.Parent = Parent

	local Corner = Instance.new("UICorner")
	Corner.CornerRadius = UDim.new(0,10)
	Corner.Parent = Button

	Button.MouseEnter:Connect(function()

		TweenService:Create(
			Button,
			TweenInfo.new(.15),
			{
				BackgroundTransparency = .08
			}
		):Play()

	end)

	Button.MouseLeave:Connect(function()

		TweenService:Create(
			Button,
			TweenInfo.new(.15),
			{
				BackgroundTransparency = 0
			}
		):Play()

	end)

	return Button
end


----------------------------------------------------------
-- Toggle
----------------------------------------------------------

function Components:CreateToggle(Parent, ThemeOrText, MaybeText)

	local Theme = IsTheme(ThemeOrText) and ThemeOrText or self.Theme
	local Text = MaybeText or ThemeOrText

	local Toggle = {}
	Toggle.Enabled = false


	local Holder = Instance.new("Frame")

	Holder.Size = UDim2.new(1,0,0,42)
	Holder.BackgroundTransparency = 1
	Holder.Parent = Parent


	local Label = Instance.new("TextLabel")

	Label.BackgroundTransparency = 1
	Label.Size = UDim2.new(1,-70,1,0)
	Label.Font = Theme.Font
	Label.Text = Text
	Label.TextSize = 15
	Label.TextColor3 = Theme.Text
	Label.TextXAlignment = Enum.TextXAlignment.Left
	Label.Parent = Holder


	local Switch = Instance.new("Frame")

	Switch.Size = UDim2.fromOffset(52,28)
	Switch.AnchorPoint = Vector2.new(1,.5)
	Switch.Position = UDim2.new(1,0,.5,0)
	Switch.BackgroundColor3 = Theme.Card
	Switch.BorderSizePixel = 0
	Switch.Parent = Holder


	local SwitchCorner = Instance.new("UICorner")

	SwitchCorner.CornerRadius = UDim.new(1,0)
	SwitchCorner.Parent = Switch


	local Knob = Instance.new("Frame")

	Knob.Size = UDim2.fromOffset(22,22)
	Knob.Position = UDim2.fromOffset(3,3)
	Knob.BackgroundColor3 = Theme.Text
	Knob.BorderSizePixel = 0
	Knob.Parent = Switch


	local KnobCorner = Instance.new("UICorner")

	KnobCorner.CornerRadius = UDim.new(1,0)
	KnobCorner.Parent = Knob


	local function Refresh()

		TweenService:Create(
			Switch,
			TweenInfo.new(.15),
			{
				BackgroundColor3 =
					Toggle.Enabled
					and Theme.Accent
					or Theme.Card
			}
		):Play()


		TweenService:Create(
			Knob,
			TweenInfo.new(.15),
			{
				Position =
					Toggle.Enabled
					and UDim2.fromOffset(27,3)
					or UDim2.fromOffset(3,3)
			}
		):Play()

	end


	local Click = Instance.new("TextButton")

	Click.BackgroundTransparency = 1
	Click.Size = UDim2.fromScale(1,1)
	Click.Text = ""
	Click.Parent = Holder


	Click.MouseButton1Click:Connect(function()

		Toggle.Enabled = not Toggle.Enabled

		Refresh()

		if Toggle.Callback then
			Toggle.Callback(Toggle.Enabled)
		end

	end)


	function Toggle:Set(Value)

		Toggle.Enabled = Value
		Refresh()

	end


	function Toggle:Get()

		return Toggle.Enabled

	end


	function Toggle:OnChanged(Function)

		Toggle.Callback = Function

	end


	Refresh()

	return Holder, Toggle

		end

		----------------------------------------------------------
-- Slider
----------------------------------------------------------

function Components:CreateSlider(
	Parent,
	ThemeOrTitle,
	TitleOrMin,
	MinOrMax,
	MaxOrDefault,
	MaybeDefault
)

	local Theme
	local Title
	local Min
	local Max
	local Default

	if IsTheme(ThemeOrTitle) then
		Theme = ThemeOrTitle
		Title = TitleOrMin
		Min = MinOrMax
		Max = MaxOrDefault
		Default = MaybeDefault
	else
		Theme = self.Theme
		Title = ThemeOrTitle
		Min = TitleOrMin
		Max = MinOrMax
		Default = MaxOrDefault
	end

	Min = tonumber(Min) or 0
	Max = tonumber(Max) or 100
	Default = tonumber(Default) or Min

	local Slider = {}

	Slider.Value = Default or Min


	local Holder = Instance.new("Frame")

	Holder.Size = UDim2.new(1,0,0,62)
	Holder.BackgroundTransparency = 1
	Holder.Parent = Parent


	local Label = Instance.new("TextLabel")

	Label.BackgroundTransparency = 1
	Label.Size = UDim2.new(1,-60,0,20)
	Label.Font = Theme.Font
	Label.Text = Title
	Label.TextSize = 15
	Label.TextColor3 = Theme.Text
	Label.TextXAlignment = Enum.TextXAlignment.Left
	Label.Parent = Holder


	local Value = Instance.new("TextLabel")

	Value.AnchorPoint = Vector2.new(1,0)
	Value.Position = UDim2.new(1,0,0,0)
	Value.Size = UDim2.new(0,50,0,20)
	Value.BackgroundTransparency = 1
	Value.Font = Theme.FontBold
	Value.Text = tostring(Slider.Value)
	Value.TextSize = 15
	Value.TextColor3 = Theme.Accent
	Value.Parent = Holder


	local Track = Instance.new("Frame")

	Track.Position = UDim2.new(0,0,0,34)
	Track.Size = UDim2.new(1,0,0,6)
	Track.BackgroundColor3 = Theme.Card
	Track.BorderSizePixel = 0
	Track.Parent = Holder


	local TrackCorner = Instance.new("UICorner")

	TrackCorner.CornerRadius = UDim.new(1,0)
	TrackCorner.Parent = Track


	local Fill = Instance.new("Frame")

	Fill.BackgroundColor3 = Theme.Accent
	Fill.BorderSizePixel = 0
	Fill.Parent = Track


	local FillCorner = Instance.new("UICorner")

	FillCorner.CornerRadius = UDim.new(1,0)
	FillCorner.Parent = Fill


	local function Refresh()

		local Percent =
			(Slider.Value-Min)/(Max-Min)

		Fill.Size =
			UDim2.new(
				math.clamp(Percent,0,1),
				0,
				1,
				0
			)

		Value.Text =
			tostring(Slider.Value)

	end


	local Dragging = false


	local function Update(X)

		local Percent =
			math.clamp(
				(X - Track.AbsolutePosition.X)
				/
				Track.AbsoluteSize.X,
				0,
				1
			)

		Slider.Value =
			math.floor(
				Min + ((Max-Min)*Percent)
			)

		Refresh()

		if Slider.Callback then
			Slider.Callback(Slider.Value)
		end

	end


	Track.InputBegan:Connect(function(Input)

		if Input.UserInputType ==
			Enum.UserInputType.MouseButton1
			or
			Input.UserInputType ==
			Enum.UserInputType.Touch then

			Dragging = true
			Update(Input.Position.X)

		end

	end)


	UserInputService.InputChanged:Connect(function(Input)

		if Dragging then

			if Input.UserInputType ==
				Enum.UserInputType.MouseMovement
				or
				Input.UserInputType ==
				Enum.UserInputType.Touch then

				Update(Input.Position.X)

			end

		end

	end)


	UserInputService.InputEnded:Connect(function(Input)

		if Input.UserInputType ==
			Enum.UserInputType.MouseButton1
			or
			Input.UserInputType ==
			Enum.UserInputType.Touch then

			Dragging = false

		end

	end)


	function Slider:Get()

		return Slider.Value

	end


	function Slider:Set(Value)

		Slider.Value = Value
		Refresh()

	end


	function Slider:OnChanged(Function)

		Slider.Callback = Function

	end


	Refresh()

	return Holder, Slider

end


----------------------------------------------------------
-- Dropdown
----------------------------------------------------------

function Components:CreateDropdown(
	Parent,
	ThemeOrTitle,
	TitleOrOptions,
	MaybeOptions
)

	local Theme
	local Title
	local Options

	if IsTheme(ThemeOrTitle) then
		Theme = ThemeOrTitle
		Title = TitleOrOptions
		Options = MaybeOptions
	else
		Theme = self.Theme
		Title = ThemeOrTitle
		Options = TitleOrOptions
	end

	local Dropdown = {}

	Dropdown.Value = nil


	local Holder = Instance.new("Frame")

	Holder.Size = UDim2.new(1,0,0,42)
	Holder.BackgroundTransparency = 1
	Holder.Parent = Parent


	local Button = Instance.new("TextButton")

	Button.Size = UDim2.new(1,0,1,0)
	Button.BackgroundColor3 = Theme.Card
	Button.BorderSizePixel = 0
	Button.Font = Theme.Font
	Button.TextSize = 15
	Button.TextColor3 = Theme.Text
	Button.Text = Title
	Button.Parent = Holder


	local Corner = Instance.new("UICorner")

	Corner.CornerRadius = UDim.new(0,10)
	Corner.Parent = Button


	function Dropdown:Set(Value)

		Dropdown.Value = Value

		Button.Text =
			Title.." : "..tostring(Value)

		if Dropdown.Callback then
			Dropdown.Callback(Value)
		end

	end


	function Dropdown:Get()

		return Dropdown.Value

	end


	function Dropdown:OnChanged(Function)

		Dropdown.Callback = Function

	end


	Button.MouseButton1Click:Connect(function()

		if Options and #Options > 0 then

			local Index = 1

			if Dropdown.Value then

				for i,v in ipairs(Options) do

					if v == Dropdown.Value then

						Index = i + 1
						break

					end

				end

			end


			if Index > #Options then
				Index = 1
			end


			Dropdown:Set(
				Options[Index]
			)

		end

	end)


	return Holder, Dropdown

						end


						----------------------------------------------------------
-- Textbox
----------------------------------------------------------

function Components:CreateTextbox(
	Parent,
	ThemeOrPlaceholder,
	MaybePlaceholder
)

	local Theme = IsTheme(ThemeOrPlaceholder) and ThemeOrPlaceholder or self.Theme
	local Placeholder = MaybePlaceholder or ThemeOrPlaceholder

	local Box = {}


	local TextBox = Instance.new("TextBox")

	TextBox.Size = UDim2.new(1,0,0,40)
	TextBox.BackgroundColor3 = Theme.Card
	TextBox.BorderSizePixel = 0
	TextBox.ClearTextOnFocus = false
	TextBox.PlaceholderText = Placeholder
	TextBox.Text = ""
	TextBox.Font = Theme.Font
	TextBox.TextSize = 15
	TextBox.TextColor3 = Theme.Text
	TextBox.PlaceholderColor3 = Theme.SubText
	TextBox.Parent = Parent


	local Corner = Instance.new("UICorner")

	Corner.CornerRadius = UDim.new(0,10)
	Corner.Parent = TextBox


	TextBox.FocusLost:Connect(function()

		if Box.Callback then

			Box.Callback(
				TextBox.Text
			)

		end

	end)


	function Box:Get()

		return TextBox.Text

	end


	function Box:Set(Value)

		TextBox.Text =
			tostring(Value)

	end


	function Box:OnChanged(Function)

		Box.Callback = Function

	end


	return TextBox, Box

end


----------------------------------------------------------
-- Label
----------------------------------------------------------

function Components:CreateLabel(
	Parent,
	ThemeOrText,
	MaybeText
)

	local Theme = IsTheme(ThemeOrText) and ThemeOrText or self.Theme
	local Text = MaybeText or ThemeOrText

	local Label = Instance.new("TextLabel")

	Label.Size =
		UDim2.new(1,0,0,22)

	Label.BackgroundTransparency = 1

	Label.Font =
		Theme.Font

	Label.Text =
		Text

	Label.TextSize =
		15

	Label.TextColor3 =
		Theme.Text

	Label.TextXAlignment =
		Enum.TextXAlignment.Left

	Label.Parent =
		Parent

	return Label

end


----------------------------------------------------------
-- Spacer
----------------------------------------------------------

function Components:CreateSpacer(
	Parent,
	Height
)

	local Spacer = Instance.new("Frame")

	Spacer.BackgroundTransparency = 1

	Spacer.Size =
		UDim2.new(
			1,
			0,
			0,
			Height or 8
		)

	Spacer.Parent =
		Parent

	return Spacer

end


----------------------------------------------------------
-- Divider
----------------------------------------------------------

function Components:CreateDivider(
	Parent,
	MaybeTheme
)

	local Theme = IsTheme(MaybeTheme) and MaybeTheme or self.Theme

	local Divider = Instance.new("Frame")

	Divider.Size =
		UDim2.new(
			1,
			0,
			0,
			1
		)

	Divider.BackgroundColor3 =
		Theme.BorderDark

	Divider.BorderSizePixel =
		0

	Divider.Parent =
		Parent

	return Divider

end

----------------------------------------------------------
-- Horizontal Container
----------------------------------------------------------

function Components:CreateHorizontalContainer(Parent)

	local Container = Instance.new("Frame")
	Container.Size = UDim2.new(1,0,0,250)
	Container.BackgroundTransparency = 1
	Container.Parent = Parent

	local Layout = Instance.new("UIListLayout")
	Layout.FillDirection = Enum.FillDirection.Horizontal
	Layout.HorizontalAlignment = Enum.HorizontalAlignment.Center
	Layout.VerticalAlignment = Enum.VerticalAlignment.Top
	Layout.Padding = UDim.new(0,12)
	Layout.SortOrder = Enum.SortOrder.LayoutOrder
	Layout.Parent = Container

	local OriginalSizes = {}

	local function IsCard(Child)
		return Child:IsA("GuiObject")
	end

	local function Update()
		local Compact = Container.AbsoluteSize.X > 0
			and Container.AbsoluteSize.X < 720

		Layout.FillDirection = Compact
			and Enum.FillDirection.Vertical
			or Enum.FillDirection.Horizontal

		for _, Child in ipairs(Container:GetChildren()) do
			if IsCard(Child) then
				OriginalSizes[Child] = OriginalSizes[Child] or Child.Size
				local Base = OriginalSizes[Child]
				if Compact then
					local Height = Base.Y.Offset > 0 and Base.Y.Offset or math.max(Child.AbsoluteSize.Y, 180)
					Child.Size = UDim2.new(1,0,0,Height)
				else
					Child.Size = Base
				end
			end
		end

		task.defer(function()
			if Container.Parent then
				Container.Size = UDim2.new(1,0,0,math.max(Layout.AbsoluteContentSize.Y, 1))
			end
		end)
	end

	Container.ChildAdded:Connect(function(Child)
		if IsCard(Child) then
			OriginalSizes[Child] = Child.Size
		end
		task.defer(Update)
	end)

	Container.ChildRemoved:Connect(function(Child)
		OriginalSizes[Child] = nil
		task.defer(Update)
	end)

	Container:GetPropertyChangedSignal("AbsoluteSize"):Connect(Update)
	Layout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
		if Container.Parent then
			Container.Size = UDim2.new(1,0,0,math.max(Layout.AbsoluteContentSize.Y, 1))
		end
	end)

	task.defer(Update)

	return Container

end

----------------------------------------------------------
-- Return
----------------------------------------------------------

return Components
]====],
        [ [====[Core/FeatureRegistry.lua]====] ] = [====[--//========================================================--
--// SquidNoMo
--// 1.1 beta 1
--// Core/FeatureRegistry.lua
--// Read-only dashboard state for the existing feature objects.
--//========================================================--

local FeatureRegistry = {}
FeatureRegistry.__index = FeatureRegistry

FeatureRegistry.Definitions = {
    {
        Id = "WalkSpeed",
        Name = "Walk Speed",
        Category = "Players",
        Path = {"Player", "WalkSpeed"},
        Kind = "slider",
        Default = 16,
        Maximum = 100,
    },
    {
        Id = "JumpPower",
        Name = "Jump Power",
        Category = "Players",
        Path = {"Player", "JumpPower"},
        Kind = "slider",
        Default = 50,
        Maximum = 200,
    },
    {
        Id = "InfiniteJump",
        Name = "Infinite Jump",
        Category = "Players",
        Path = {"Player", "InfiniteJump"},
        Kind = "toggle",
    },
    {
        Id = "Noclip",
        Name = "Noclip",
        Category = "Players",
        Path = {"Player", "Noclip"},
        Kind = "toggle",
    },
    {
        Id = "PlayerESP",
        Name = "Player ESP",
        Category = "Players",
        Path = {"Player", "PlayerESP"},
        Kind = "toggle",
    },
    {
        Id = "GuardESP",
        Name = "Guard ESP",
        Category = "Players",
        Path = {"Player", "GuardESP"},
        Kind = "toggle",
    },
    {
        Id = "DetectiveESP",
        Name = "Detective ESP",
        Category = "Players",
        Path = {"Player", "DetectiveESP"},
        Kind = "toggle",
    },
    {
        Id = "FrontmanESP",
        Name = "Frontman ESP",
        Category = "Players",
        Path = {"Player", "FrontmanESP"},
        Kind = "toggle",
    },
    {
        Id = "AntiAFK",
        Name = "Anti AFK",
        Category = "Players",
        Path = {"Player", "AntiAFK"},
        Kind = "toggle",
    },
    {
        Id = "AntiLag",
        Name = "Anti Lag",
        Category = "Players",
        Path = {"Player", "AntiLag"},
        Kind = "toggle",
    },
}

local function resolvePath(root, path)
    local current = root

    for _, segment in ipairs(path) do
        if type(current) ~= "table" then
            return nil
        end

        current = current[segment]
    end

    return current
end

function FeatureRegistry.new(loader)
    local self = setmetatable({}, FeatureRegistry)
    self.Loader = loader or {}
    self.ReadErrors = {}
    return self
end

function FeatureRegistry:SetLoader(loader)
    self.Loader = loader or {}
end

function FeatureRegistry:GetDefinitions()
    return self.Definitions
end

function FeatureRegistry:GetFeatureObject(definition)
    local features = self.Loader and self.Loader.Features
    return resolvePath(features, definition.Path)
end

function FeatureRegistry:GetState(definition)
    local object = self:GetFeatureObject(definition)

    if type(object) ~= "table" then
        return "off", false
    end

    if definition.Kind == "slider" then
        if type(object.Get) ~= "function" then
            return "off", true
        end

        local ok, value = pcall(function()
            return tonumber(object:Get())
        end)

        if not ok or value == nil then
            self.ReadErrors[definition.Id] = true
            return "off", true
        end

        if value <= definition.Default then
            return "off", true
        end

        if value >= definition.Maximum then
            return "full", true
        end

        return "partial", true
    end

    if type(object.IsEnabled) ~= "function" then
        return "off", true
    end

    local ok, enabled = pcall(function()
        return object:IsEnabled()
    end)

    if not ok then
        self.ReadErrors[definition.Id] = true
        return "off", true
    end

    return enabled and "full" or "off", true
end

function FeatureRegistry:GetSummary()
    local manager = self.Loader and self.Loader.FeatureManager
    if manager and type(manager.GetSnapshot) == "function" then
        local ok, snapshot = pcall(manager.GetSnapshot, manager)
        if ok and type(snapshot) == "table" then
            local total = tonumber(snapshot.Total) or 0
            local full = tonumber(snapshot.FullyOn) or 0
            local partial = tonumber(snapshot.Partial) or 0
            local off = tonumber(snapshot.Off) or math.max(0, total - full - partial)
            local loaded = type(manager.GetLoadedCount) == "function"
                and manager:GetLoadedCount()
                or 0
            return {
                full = full,
                partial = partial,
                off = off,
                total = total,
                loaded = loaded,
                states = {},
                fullPercent = total > 0 and math.floor((full / total) * 100 + 0.5) or 0,
                partialPercent = total > 0 and math.floor((partial / total) * 100 + 0.5) or 0,
                offPercent = total > 0 and math.floor((off / total) * 100 + 0.5) or 0,
            }
        end
    end

    local summary = {
        full = 0,
        partial = 0,
        off = 0,
        total = #self.Definitions,
        loaded = 0,
        states = {},
    }

    for _, definition in ipairs(self.Definitions) do
        local state, loaded = self:GetState(definition)
        summary.states[definition.Id] = state

        if loaded then
            summary.loaded = summary.loaded + 1
        end

        summary[state] = summary[state] + 1
    end

    if summary.total > 0 then
        summary.fullPercent = math.floor((summary.full / summary.total) * 100 + 0.5)
        summary.partialPercent = math.floor((summary.partial / summary.total) * 100 + 0.5)
        summary.offPercent = math.max(0, 100 - summary.fullPercent - summary.partialPercent)
    else
        summary.fullPercent = 0
        summary.partialPercent = 0
        summary.offPercent = 0
    end

    return summary
end

function FeatureRegistry:GetLoadedCount()
    return self:GetSummary().loaded
end

function FeatureRegistry:GetTotalCount()
    return #self.Definitions
end

function FeatureRegistry:GetReadErrorCount()
    local count = 0

    for _ in pairs(self.ReadErrors) do
        count = count + 1
    end

    return count
end

return FeatureRegistry
]====],
        [ [====[Core/Icons.lua]====] ] = [====[--//========================================================--
--// SquidNoMo
--// 1.1 beta 1
--// Core/Icons.lua
--// Dependency-free vector-style GUI icons.
--//========================================================--

local Icons = {}

local function corner(parent, radius)
    local uiCorner = Instance.new("UICorner")
    uiCorner.CornerRadius = UDim.new(0, radius)
    uiCorner.Parent = parent
    return uiCorner
end

local function stroke(parent, color, thickness, transparency)
    local uiStroke = Instance.new("UIStroke")
    uiStroke.Color = color
    uiStroke.Thickness = thickness or 1
    uiStroke.Transparency = transparency or 0
    uiStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
    uiStroke.Parent = parent
    return uiStroke
end

local function frame(parent, size, position, color, zIndex)
    local item = Instance.new("Frame")
    item.Size = size
    item.Position = position or UDim2.fromOffset(0, 0)
    item.BackgroundColor3 = color
    item.BorderSizePixel = 0
    item.ZIndex = zIndex or 1
    item.Parent = parent
    return item
end

local function label(parent, text, size, position, color, font, textSize, zIndex)
    local item = Instance.new("TextLabel")
    item.Size = size
    item.Position = position or UDim2.fromOffset(0, 0)
    item.BackgroundTransparency = 1
    item.BorderSizePixel = 0
    item.Font = font or Enum.Font.GothamBold
    item.Text = text
    item.TextSize = textSize or 18
    item.TextColor3 = color
    item.TextXAlignment = Enum.TextXAlignment.Center
    item.TextYAlignment = Enum.TextYAlignment.Center
    item.ZIndex = zIndex or 1
    item.Parent = parent
    return item
end

local function roundedLine(parent, size, position, rotation, color, zIndex)
    local line = frame(parent, size, position, color, zIndex)
    line.AnchorPoint = Vector2.new(0.5, 0.5)
    line.Rotation = rotation or 0
    corner(line, 99)
    return line
end

local function createTriangle(parent, color, zIndex)
    local holder = frame(parent, UDim2.fromScale(1, 1), UDim2.fromOffset(0, 0), color, zIndex)
    holder.BackgroundTransparency = 1

    roundedLine(holder, UDim2.new(0.055, 0, 0.58, 0), UDim2.new(0.36, 0, 0.48, 0), -30, color, zIndex)
    roundedLine(holder, UDim2.new(0.055, 0, 0.58, 0), UDim2.new(0.64, 0, 0.48, 0), 30, color, zIndex)
    roundedLine(holder, UDim2.new(0.56, 0, 0.055, 0), UDim2.new(0.50, 0, 0.73, 0), 0, color, zIndex)

    return holder
end

function Icons:CreateLogo(parent, size, options)
    options = options or {}

    local accent = options.Color or Color3.fromRGB(0, 238, 112)
    local background = options.BackgroundColor or Color3.fromRGB(5, 15, 10)
    local zIndex = options.ZIndex or 1

    local holder = frame(parent, UDim2.fromOffset(size, size), options.Position or UDim2.fromOffset(0, 0), background, zIndex)
    holder.Name = options.Name or "SquidNoMoLogo"
    holder.BackgroundTransparency = options.BackgroundTransparency or 0.08
    corner(holder, math.floor(size / 2))
    stroke(holder, accent, math.max(1, size * 0.025), 0.05)

    if options.Glow ~= false then
        local glowOuter = frame(holder, UDim2.new(1, 12, 1, 12), UDim2.fromOffset(-6, -6), accent, zIndex - 1)
        glowOuter.BackgroundTransparency = 0.90
        corner(glowOuter, math.floor((size + 12) / 2))

        local glowInner = frame(holder, UDim2.new(1, -10, 1, -10), UDim2.fromOffset(5, 5), accent, zIndex)
        glowInner.BackgroundTransparency = 0.88
        corner(glowInner, math.floor((size - 10) / 2))
    end

    local inner = frame(holder, UDim2.new(1, -12, 1, -12), UDim2.fromOffset(6, 6), background, zIndex + 1)
    inner.BackgroundTransparency = 0.18
    corner(inner, math.floor((size - 12) / 2))
    stroke(inner, accent, math.max(1, size * 0.016), 0.32)

    local triangle = createTriangle(inner, accent, zIndex + 2)
    triangle.Size = UDim2.new(0.58, 0, 0.58, 0)
    triangle.Position = UDim2.new(0.21, 0, 0.20, 0)

    return holder
end

local glyphs = {
    Home = "⌂",
    Games = "▣",
    Players = "●",
    Guards = "⬟",
    Detective = "⌕",
    Farming = "⌁",
    UI = "▱",
    Settings = "⚙",
    Warning = "!",
    Support = "♥",
    Stats = "▥",
    Server = "▤",
    Touch = "✋",
    Error = "!",
    Calendar = "▪",
    Build = "◆",
    Check = "✓",
    Partial = "!",
    Off = "×",
}

function Icons:Create(parent, name, size, color, zIndex)
    if name == "Logo" then
        return self:CreateLogo(parent, size, {
            Color = color,
            ZIndex = zIndex,
            Glow = false,
        })
    end

    local holder = frame(parent, UDim2.fromOffset(size, size), UDim2.fromOffset(0, 0), color, zIndex)
    holder.BackgroundTransparency = 1

    local text = glyphs[name] or string.sub(tostring(name or "?"), 1, 1)
    local icon = label(holder, text, UDim2.fromScale(1, 1), UDim2.fromOffset(0, 0), color, Enum.Font.GothamBold, math.floor(size * 0.68), (zIndex or 1) + 1)

    if name == "Players" then
        icon.Text = "●"
        icon.TextSize = math.floor(size * 0.40)
        icon.Position = UDim2.new(0, 0, -0.18, 0)
        local shoulders = frame(holder, UDim2.new(0.74, 0, 0.36, 0), UDim2.new(0.13, 0, 0.56, 0), color, (zIndex or 1) + 1)
        corner(shoulders, math.floor(size * 0.18))
    elseif name == "UI" then
        local monitor = frame(holder, UDim2.new(0.78, 0, 0.56, 0), UDim2.new(0.11, 0, 0.12, 0), color, (zIndex or 1) + 1)
        monitor.BackgroundTransparency = 1
        corner(monitor, 3)
        stroke(monitor, color, math.max(1, size * 0.07), 0)
        roundedLine(holder, UDim2.new(0.08, 0, 0.24, 0), UDim2.new(0.50, 0, 0.77, 0), 0, color, (zIndex or 1) + 1)
        roundedLine(holder, UDim2.new(0.42, 0, 0.07, 0), UDim2.new(0.50, 0, 0.91, 0), 0, color, (zIndex or 1) + 1)
        icon.Visible = false
    elseif name == "Games" then
        local body = frame(holder, UDim2.new(0.86, 0, 0.58, 0), UDim2.new(0.07, 0, 0.23, 0), color, (zIndex or 1) + 1)
        body.BackgroundTransparency = 1
        corner(body, math.floor(size * 0.20))
        stroke(body, color, math.max(1, size * 0.08), 0)

        local dpadH = roundedLine(body, UDim2.new(0.25, 0, 0.08, 0), UDim2.new(0.28, 0, 0.48, 0), 0, color, (zIndex or 1) + 2)
        local dpadV = roundedLine(body, UDim2.new(0.08, 0, 0.25, 0), UDim2.new(0.28, 0, 0.48, 0), 0, color, (zIndex or 1) + 2)
        local b1 = frame(body, UDim2.new(0.10, 0, 0.16, 0), UDim2.new(0.67, 0, 0.35, 0), color, (zIndex or 1) + 2)
        local b2 = frame(body, UDim2.new(0.10, 0, 0.16, 0), UDim2.new(0.78, 0, 0.54, 0), color, (zIndex or 1) + 2)
        corner(b1, 99)
        corner(b2, 99)
        icon.Visible = false
    end

    return holder
end

function Icons:CreateStatus(parent, state, size, theme, zIndex)
    local color = theme.Accent
    local glyph = "✓"

    if state == "partial" then
        color = theme.Warning
        glyph = "!"
    elseif state == "off" then
        color = theme.Error
        glyph = "×"
    end

    local holder = frame(parent, UDim2.fromOffset(size, size), UDim2.fromOffset(0, 0), color, zIndex)
    holder.BackgroundTransparency = 0.88
    corner(holder, math.floor(size / 2))
    stroke(holder, color, math.max(1, size * 0.05), 0)

    label(holder, glyph, UDim2.fromScale(1, 1), UDim2.fromOffset(0, 0), color, Enum.Font.GothamBlack, math.floor(size * 0.55), (zIndex or 1) + 1)
    return holder
end

function Icons:CreateTriangleStatus(parent, size, color, zIndex)
    local holder = frame(parent, UDim2.fromOffset(size, size), UDim2.fromOffset(0, 0), color, zIndex)
    holder.BackgroundTransparency = 1
    createTriangle(holder, color, (zIndex or 1) + 1)
    return holder
end

return Icons
]====],
        [ [====[Core/Navigation.lua]====] ] = [====[--//========================================================--
--// SquidNoMo
--// 1.1 beta 1
--// Navigation.lua
--//========================================================--

local TweenService = game:GetService("TweenService")

local Navigation = {}

Navigation.Pages = {}

Navigation.CurrentPage = nil

Navigation.TweenInfo =
	TweenInfo.new(

		0.20,

		Enum.EasingStyle.Quad,

		Enum.EasingDirection.Out

	)

----------------------------------------------------------
-- Register Page
----------------------------------------------------------

function Navigation:Register(Name, Page)

	self.Pages[Name] = Page

	Page.Visible = false

	Page.BackgroundTransparency = 1

end

----------------------------------------------------------
-- Hide All Pages
----------------------------------------------------------

function Navigation:HideAll()

	for _,Page in pairs(self.Pages) do

		Page.Visible = false

	end

end

----------------------------------------------------------
-- Fade In
----------------------------------------------------------

function Navigation:FadeIn(Page)

	Page.BackgroundTransparency = 1

	local Tween = TweenService:Create(

		Page,

		self.TweenInfo,

		{

			BackgroundTransparency = 0

		}

	)

	Tween:Play()

end

----------------------------------------------------------
-- Open Page
----------------------------------------------------------

function Navigation:Open(Name, App)

	local Page = self.Pages[Name]

	if not Page then
		warn("[Navigation] Missing page:", Name)
		return
	end

	------------------------------------------------------
	-- Hide Previous Page
	------------------------------------------------------

	if self.CurrentPage then
		self.CurrentPage.Visible = false
	end

	------------------------------------------------------
	-- Show New Page
	------------------------------------------------------

	Page.Visible = true

	self:FadeIn(Page)

	self.CurrentPage = Page

	------------------------------------------------------
	-- Sidebar Highlight
	------------------------------------------------------

	if App and App.NavigationButtons then

		for ButtonName,Button in pairs(App.NavigationButtons) do

			if ButtonName == Name then

				Button.BackgroundColor3 =
					App.Theme.Accent

				Button.TextColor3 =
					Color3.new(1,1,1)

			else

				Button.BackgroundColor3 =
					App.Theme.Card

				Button.TextColor3 =
					App.Theme.Text

			end

		end

	end

end

----------------------------------------------------------
-- Refresh
----------------------------------------------------------

function Navigation:Refresh()

	if self.CurrentPage then

		self.CurrentPage.CanvasPosition =
			Vector2.new(0,0)

	end

end

----------------------------------------------------------
-- Get Current Page
----------------------------------------------------------

function Navigation:GetCurrentPage()

	return self.CurrentPage

end

----------------------------------------------------------

return Navigation
]====],
        [ [====[Core/Notifications.lua]====] ] = [====[--//========================================================--
--// SquidNoMo
--// 1.1 beta 1
--// Notifications.lua
--//========================================================--

local TweenService = game:GetService("TweenService")

local Notifications = {}

Notifications.Container = nil

----------------------------------------------------------
-- Initialize
----------------------------------------------------------

function Notifications:Init(ScreenGui, Theme)

	if self.Container then
		return
	end

	local Container = Instance.new("Frame")

	Container.Name = "Notifications"

	Container.AnchorPoint = Vector2.new(1,0)

	Container.Position = UDim2.new(1,-20,0,20)

	Container.Size = UDim2.fromOffset(320,500)

	Container.BackgroundTransparency = 1

	Container.Parent = ScreenGui

	local Layout = Instance.new("UIListLayout")

	Layout.Padding = UDim.new(0,10)

	Layout.HorizontalAlignment = Enum.HorizontalAlignment.Right

	Layout.VerticalAlignment = Enum.VerticalAlignment.Top

	Layout.Parent = Container

	self.Container = Container

	self.Theme = Theme

end

----------------------------------------------------------
-- Create Notification
----------------------------------------------------------

function Notifications:Notify(Title, Message, Type, Duration)

	if not self.Container then
		warn("Notifications not initialized.")
		return
	end

	Duration = Duration or 4

	local Theme = self.Theme

	local Colors = {

		Success = Theme.Success,

		Warning = Theme.Warning,

		Error = Theme.Error,

		Info = Theme.Info

	}

	local Color = Colors[Type] or Theme.Info

	local Card = Instance.new("Frame")

	Card.Size = UDim2.fromOffset(300,82)

	Card.BackgroundColor3 = Theme.Card

	Card.BorderSizePixel = 0

	Card.BackgroundTransparency = 1

	Card.Parent = self.Container

	local Corner = Instance.new("UICorner")

	Corner.CornerRadius = UDim.new(0,12)

	Corner.Parent = Card

	local Stroke = Instance.new("UIStroke")

	Stroke.Color = Color

	Stroke.Thickness = 1.2

	Stroke.Parent = Card

	local TitleLabel = Instance.new("TextLabel")

	TitleLabel.BackgroundTransparency = 1

	TitleLabel.Position = UDim2.fromOffset(14,10)

	TitleLabel.Size = UDim2.new(1,-28,0,20)

	TitleLabel.Font = Theme.FontBold

	TitleLabel.Text = Title

	TitleLabel.TextColor3 = Theme.Text

	TitleLabel.TextSize = 16

	TitleLabel.TextXAlignment = Enum.TextXAlignment.Left

	TitleLabel.Parent = Card

	local MessageLabel = Instance.new("TextLabel")

	MessageLabel.BackgroundTransparency = 1

	MessageLabel.Position = UDim2.fromOffset(14,34)

	MessageLabel.Size = UDim2.new(1,-28,0,36)

	MessageLabel.Font = Theme.Font

	MessageLabel.TextWrapped = true

	MessageLabel.Text = Message

	MessageLabel.TextColor3 = Theme.SubText

	MessageLabel.TextSize = 13

	MessageLabel.TextXAlignment = Enum.TextXAlignment.Left

	MessageLabel.TextYAlignment = Enum.TextYAlignment.Top

	MessageLabel.Parent = Card

	Card.Position = UDim2.new(1,40,0,0)

	TweenService:Create(
		Card,
		TweenInfo.new(.25, Enum.EasingStyle.Quint),
		{
			BackgroundTransparency = 0
		}
	):Play()

	task.delay(Duration,function()

		TweenService:Create(
			Card,
			TweenInfo.new(.25, Enum.EasingStyle.Quint),
			{
				BackgroundTransparency = 1
			}
		):Play()

		task.wait(.3)

		Card:Destroy()

	end)

end

----------------------------------------------------------
-- Helper Functions
----------------------------------------------------------

function Notifications:Success(Title, Message, Duration)

	self:Notify(Title, Message, "Success", Duration)

end

function Notifications:Warning(Title, Message, Duration)

	self:Notify(Title, Message, "Warning", Duration)

end

function Notifications:Error(Title, Message, Duration)

	self:Notify(Title, Message, "Error", Duration)

end

function Notifications:Info(Title, Message, Duration)

	self:Notify(Title, Message, "Info", Duration)

end

return Notifications
]====],
        [ [====[Core/RuntimeStats.lua]====] ] = [====[--//========================================================--
--// SquidNoMo
--// 1.1 beta 1
--// Core/RuntimeStats.lua
--// Lightweight client/session diagnostics for the dashboard.
--//========================================================--

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local Stats = game:GetService("Stats")
local UserInputService = game:GetService("UserInputService")

local RuntimeStats = {}
RuntimeStats.__index = RuntimeStats

local LocalPlayer = Players.LocalPlayer

local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end
local FrameSampler = Environment.__SquidNoMoFrameSampler
if type(FrameSampler) ~= "table" or FrameSampler.Revision ~= "1.1b1-frame-sampler-r1" then
    FrameSampler = {Revision = "1.1b1-frame-sampler-r1", FPS = 60, Frames = 0, LastUpdate = os.clock()}
    FrameSampler.Connection = RunService.RenderStepped:Connect(function()
        FrameSampler.Frames = FrameSampler.Frames + 1
        local now = os.clock()
        local elapsed = now - FrameSampler.LastUpdate
        if elapsed >= 0.75 then
            FrameSampler.FPS = math.max(1, math.floor(FrameSampler.Frames / elapsed + 0.5))
            FrameSampler.Frames = 0
            FrameSampler.LastUpdate = now
        end
    end)
    Environment.__SquidNoMoFrameSampler = FrameSampler
end

local function formatDuration(seconds)
    seconds = math.max(0, math.floor(tonumber(seconds) or 0))

    local hours = math.floor(seconds / 3600)
    local minutes = math.floor((seconds % 3600) / 60)
    local remaining = seconds % 60

    return string.format("%02d:%02d:%02d", hours, minutes, remaining)
end

function RuntimeStats.new()
    local self = setmetatable({}, RuntimeStats)

    self.StartedAt = os.clock()
    self.FPS = FrameSampler.FPS
    self.Connection = nil

    return self
end

function RuntimeStats:Start()
    self.FPS = FrameSampler.FPS
end

function RuntimeStats:Destroy()
    self.Connection = nil
end

function RuntimeStats:GetPing()
    local ping

    if LocalPlayer and type(LocalPlayer.GetNetworkPing) == "function" then
        local ok, value = pcall(function()
            return LocalPlayer:GetNetworkPing()
        end)

        if ok and type(value) == "number" then
            ping = math.floor((value * 1000) + 0.5)
        end
    end

    if ping == nil then
        pcall(function()
            ping = math.floor(Stats.Network.ServerStatsItem["Data Ping"]:GetValue() + 0.5)
        end)
    end

    return ping or 0
end

function RuntimeStats:GetClientName()
    if UserInputService.TouchEnabled then
        return "Mobile"
    end

    return "Desktop"
end

function RuntimeStats:GetSnapshot()
    local serverAge = 0

    pcall(function()
        serverAge = workspace.DistributedGameTime
    end)

    local connected = game:IsLoaded() and LocalPlayer and LocalPlayer.Parent ~= nil
    local playerCount = #Players:GetPlayers()
    local maxPlayers = Players.MaxPlayers or 0

    return {
        Client = self:GetClientName(),
        FPS = FrameSampler.FPS > 0 and tostring(FrameSampler.FPS) or "--",
        Ping = string.format("%d ms", self:GetPing()),
        ServerAge = formatDuration(serverAge),
        Uptime = formatDuration(os.clock() - self.StartedAt),
        Connected = connected and "Yes" or "No",
        Players = string.format("%d / %d", playerCount, maxPlayers),
    }
end

return RuntimeStats
]====],
        [ [====[Core/SettingsStore.lua]====] ] = [====[local SettingsStore = {}

local HttpService = game:GetService("HttpService")

SettingsStore.FileName = "SquidNoMo-settings-v1.json"
SettingsStore.MemoryKey = "__SquidNoMoSavedSettings"
SettingsStore.SchemaVersion = 1

local function environment()
    if type(getgenv) == "function" then
        local ok, value = pcall(getgenv)
        if ok and type(value) == "table" then
            return value
        end
    end
    return _G
end

function SettingsStore:GetStorageMode()
    if type(isfile) == "function"
        and type(readfile) == "function"
        and type(writefile) == "function"
    then
        return "FILE"
    end
    return "SESSION"
end

function SettingsStore:Load()
    local env = environment()

    if type(isfile) == "function"
        and type(readfile) == "function"
    then
        local exists = false
        pcall(function()
            exists = isfile(self.FileName)
        end)

        if exists then
            local ok, data = pcall(function()
                return HttpService:JSONDecode(readfile(self.FileName))
            end)
            if ok and type(data) == "table" then
                env[self.MemoryKey] = data
                return data
            end
        end
    end

    local cached = env[self.MemoryKey]
    return type(cached) == "table" and cached or nil
end

function SettingsStore:Save(data)
    if type(data) ~= "table" then
        return false, "INVALID"
    end

    data.SchemaVersion = self.SchemaVersion
    environment()[self.MemoryKey] = data

    if type(writefile) ~= "function" then
        return true, "SESSION"
    end

    local ok, message = pcall(function()
        writefile(self.FileName, HttpService:JSONEncode(data))
    end)

    if not ok then
        return false, tostring(message)
    end

    return true, "FILE"
end

function SettingsStore:Clear()
    environment()[self.MemoryKey] = nil

    if type(delfile) == "function"
        and type(isfile) == "function"
    then
        pcall(function()
            if isfile(self.FileName) then
                delfile(self.FileName)
            end
        end)
    end

    return true
end

return SettingsStore
]====],
        [ [====[Core/Theme.lua]====] ] = [====[--//========================================================--
--// SquidNoMo
--// 1.1 beta 1
--// Theme.lua
--//========================================================--

local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end
local BuildManifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}

local Theme = {}

----------------------------------------------------------
-- Application
----------------------------------------------------------

Theme.Name = "SquidNoMo"

Theme.Version = tostring(BuildManifest.DisplayVersion or BuildManifest.Version or "1.1 beta")

----------------------------------------------------------
-- Colors
----------------------------------------------------------

Theme.Background = Color3.fromRGB(8,6,12)

Theme.Sidebar = Color3.fromRGB(12,10,18)

Theme.Header = Color3.fromRGB(14,10,20)

Theme.Card = Color3.fromRGB(18,13,25)

Theme.CardHover = Color3.fromRGB(28,20,37)

Theme.CardPressed = Color3.fromRGB(34,24,44)

----------------------------------------------------------
-- Accent
----------------------------------------------------------

Theme.Accent = Color3.fromRGB(255,58,145)

Theme.AccentHover = Color3.fromRGB(255,95,169)

Theme.AccentDark = Color3.fromRGB(194,30,109)

----------------------------------------------------------
-- Text
----------------------------------------------------------

Theme.Text = Color3.fromRGB(255,255,255)

Theme.SubText = Color3.fromRGB(177,163,184)

Theme.DisabledText = Color3.fromRGB(116,102,126)

----------------------------------------------------------
-- Status Colors
----------------------------------------------------------

Theme.Success = Color3.fromRGB(45,232,98)

Theme.Warning = Color3.fromRGB(255,196,64)

Theme.Error = Color3.fromRGB(255,63,86)

Theme.Info = Color3.fromRGB(0,170,255)

----------------------------------------------------------
-- Borders
----------------------------------------------------------

Theme.Border = Color3.fromRGB(255,58,145)

Theme.BorderDark = Color3.fromRGB(92,47,77)

----------------------------------------------------------
-- Fonts
----------------------------------------------------------

Theme.Font = Enum.Font.Gotham

Theme.FontMedium = Enum.Font.GothamMedium

Theme.FontBold = Enum.Font.GothamBold

Theme.FontBlack = Enum.Font.GothamBlack

----------------------------------------------------------
-- Sizes
----------------------------------------------------------

Theme.WindowWidth = 1225

Theme.WindowHeight = 730

Theme.SidebarWidth = 248

Theme.HeaderHeight = 72

Theme.PagePadding = 18

Theme.CardRadius = 16

Theme.ButtonRadius = 10

----------------------------------------------------------
-- Animation
----------------------------------------------------------

Theme.FastTween = TweenInfo.new(
    0.15,
    Enum.EasingStyle.Quint,
    Enum.EasingDirection.Out
)

Theme.NormalTween = TweenInfo.new(
    0.25,
    Enum.EasingStyle.Quint,
    Enum.EasingDirection.Out
)

Theme.SlowTween = TweenInfo.new(
    0.4,
    Enum.EasingStyle.Quint,
    Enum.EasingDirection.Out
)

----------------------------------------------------------
-- Icons
----------------------------------------------------------

Theme.Icons = {

    Home = "",

    Players = "",

    Guards = "",

    Detective = "",

    Farming = "",

    VIP = "",

    Games = "",

    Settings = "",

    Support = "",

    Warning = "",

    AI = ""

}

----------------------------------------------------------
-- Assets
----------------------------------------------------------

Theme.Assets = {

    Logo = "Images/SquidNoMoLogo.png",

    HeroImage = "Images/BannerGuards.png",

    SquidGameArtwork = "Images/BannerGuards.png",

    TabIcons = {
        Home = "Images/TabIcons/Home.png",
        Games = "Images/TabIcons/Games.png",
        Players = "Images/TabIcons/Players.png",
        Guards = "Images/TabIcons/Guards.png",
        Detective = "Images/TabIcons/Detective.png",
        Farming = "Images/TabIcons/Farming.png",
        UI = "Images/TabIcons/UI.png",
        Settings = "Images/TabIcons/Settings.png",
    },

    CashAppQR = "Images/CashAppQR.png",

    PayPalQR = "Images/PayPalQR.png",

    Shadow = "rbxassetid://1316045217"

}

----------------------------------------------------------
-- Utility
----------------------------------------------------------

function Theme:GetColor(Name)

    return self[Name]

end

function Theme:GetFont(Name)

    return self[Name]

end

return Theme
]====],
        [ [====[Core/UIStyleManager.lua]====] ] = [====[local UIStyleManager = {}

UIStyleManager.PageNames = {
    'Home',
    'Games',
    'Players',
    'Guards',
    'Detective',
    'Farming',
    'UI',
    'Settings',
}

UIStyleManager.Scopes = {
    'Current Page',
    'Main Pages',
    'Subpages',
    'Entire App',
}

UIStyleManager.Defaults = {
    ThemePreset = 'SquidNoMo',
    WindowWidth = 1225,
    WindowHeight = 690,
    AppScale = 1.0,
    SidebarWidth = 232,
    TopbarHeight = 56,
    FooterHeight = 34,
    PagePadding = 8,
    ColumnGap = 12,
    SectionSpacing = 10,
    CategoryBubbleWidth = 190,
    CategoryBubbleHeight = 72,
    CategoryBarHeight = 116,
    CategoryGap = 10,
    TextScale = 1.08,
    CardRadius = 14,
    BorderThickness = 1,
    ScrollbarThickness = 5,
    ButtonHeight = 46,
    ButtonRadius = 10,
    ButtonStyle = 'Soft Glow',
    ToggleWidth = 54,
    ToggleHeight = 30,
    ToggleSpacing = 8,
    ToggleStyle = 'Switch',
    SliderTrack = 8,
    SliderKnob = 18,
    GlowIntensity = 70,
    AnimationSpeed = 100,
    PressScale = 97,
    QuickAdjust = true,
    AccentHue = 328,
    AccentSaturation = 77,
    AccentBrightness = 100,
    BackgroundBrightness = 6,
    CardBrightness = 10,
    TextBrightness = 96,
    UniformPageAccents = false,
}

UIStyleManager.Themes = {
    SquidNoMo = {
        AccentHue = 328,
        AccentSaturation = 77,
        AccentBrightness = 100,
        BackgroundBrightness = 6,
        CardBrightness = 10,
        TextBrightness = 96,
    },
    ['Neon Pink'] = {
        AccentHue = 328,
        AccentSaturation = 90,
        AccentBrightness = 100,
        BackgroundBrightness = 5,
        CardBrightness = 10,
        TextBrightness = 100,
    },
    ['Cyber Purple'] = {
        AccentHue = 275,
        AccentSaturation = 76,
        AccentBrightness = 100,
        BackgroundBrightness = 5,
        CardBrightness = 11,
        TextBrightness = 98,
    },
    ['Ocean Blue'] = {
        AccentHue = 195,
        AccentSaturation = 90,
        AccentBrightness = 100,
        BackgroundBrightness = 5,
        CardBrightness = 10,
        TextBrightness = 98,
    },
    Emerald = {
        AccentHue = 148,
        AccentSaturation = 82,
        AccentBrightness = 92,
        BackgroundBrightness = 5,
        CardBrightness = 10,
        TextBrightness = 98,
    },
    Crimson = {
        AccentHue = 350,
        AccentSaturation = 86,
        AccentBrightness = 100,
        BackgroundBrightness = 5,
        CardBrightness = 10,
        TextBrightness = 98,
    },
    Amber = {
        AccentHue = 42,
        AccentSaturation = 88,
        AccentBrightness = 100,
        BackgroundBrightness = 5,
        CardBrightness = 10,
        TextBrightness = 98,
    },
    Monochrome = {
        AccentHue = 0,
        AccentSaturation = 0,
        AccentBrightness = 92,
        BackgroundBrightness = 5,
        CardBrightness = 11,
        TextBrightness = 98,
    },
    ['High Contrast'] = {
        AccentHue = 55,
        AccentSaturation = 100,
        AccentBrightness = 100,
        BackgroundBrightness = 2,
        CardBrightness = 5,
        TextBrightness = 100,
    },
}

local limits = {
    WindowWidth = {900, 1600},
    WindowHeight = {540, 900},
    AppScale = {0.75, 1.15},
    SidebarWidth = {170, 340},
    TopbarHeight = {44, 92},
    FooterHeight = {24, 64},
    PagePadding = {6, 24},
    ColumnGap = {8, 22},
    SectionSpacing = {8, 24},
    CategoryBubbleWidth = {145, 300},
    CategoryBubbleHeight = {54, 76},
    CategoryBarHeight = {92, 126},
    CategoryGap = {2, 28},
    TextScale = {0.90, 1.18},
    CardRadius = {2, 32},
    BorderThickness = {0, 4},
    ScrollbarThickness = {2, 14},
    ButtonHeight = {34, 54},
    ButtonRadius = {2, 32},
    ToggleWidth = {46, 68},
    ToggleHeight = {24, 38},
    ToggleSpacing = {2, 24},
    SliderTrack = {4, 18},
    SliderKnob = {14, 34},
    GlowIntensity = {0, 100},
    AnimationSpeed = {50, 200},
    PressScale = {90, 100},
    AccentHue = {0, 360},
    AccentSaturation = {0, 100},
    AccentBrightness = {40, 100},
    BackgroundBrightness = {1, 20},
    CardBrightness = {4, 32},
    TextBrightness = {65, 100},
    PageAccentHue = {0, 360},
}

local function copyTable(source)
    local result = {}
    for key, value in pairs(source or {}) do
        if type(value) == 'table' then
            result[key] = copyTable(value)
        else
            result[key] = value
        end
    end
    return result
end

local function clampValue(key, value)
    local boundary = limits[key]
    if boundary and type(value) == 'number' then
        return math.clamp(value, boundary[1], boundary[2])
    end
    return value
end

function UIStyleManager:Clone(source)
    return copyTable(source)
end

function UIStyleManager:CreateColorPreservingProfile(source)
    local fresh = self:CreateDefaultProfile()
    local normalized = self:Normalize(
        self:Clone(source)
    )

    local keys = {
        "ThemePreset",
        "AccentHue",
        "AccentSaturation",
        "AccentBrightness",
        "BackgroundBrightness",
        "CardBrightness",
        "TextBrightness",
        "UniformPageAccents",
        "PageAccentHue",
    }

    for _, key in ipairs(keys) do
        if normalized.Global[key] ~= nil then
            fresh.Global[key] = normalized.Global[key]
        end
    end

    for pageName, values in pairs(
        normalized.Pages or {}
    ) do
        if type(values) == "table"
            and values.PageAccentHue ~= nil
        then
            fresh.Pages[pageName] = {
                PageAccentHue =
                    values.PageAccentHue,
            }
        end
    end

    return self:Normalize(fresh)
end

function UIStyleManager:CreateDefaultProfile()
    return {
        Global = copyTable(self.Defaults),
        MainPages = {},
        Subpages = {},
        Pages = {},
    }
end

function UIStyleManager:Normalize(profile)
    if type(profile) ~= 'table' then
        return self:CreateDefaultProfile()
    end

    profile.Global = type(profile.Global) == 'table'
        and profile.Global
        or {}
    profile.MainPages = type(profile.MainPages) == 'table'
        and profile.MainPages
        or {}
    profile.Subpages = type(profile.Subpages) == 'table'
        and profile.Subpages
        or {}
    profile.Pages = type(profile.Pages) == 'table'
        and profile.Pages
        or {}

    for key, defaultValue in pairs(self.Defaults) do
        if profile.Global[key] == nil then
            profile.Global[key] = defaultValue
        else
            profile.Global[key] = clampValue(
                key,
                profile.Global[key]
            )
        end
    end

    for _, scopeTable in ipairs({
        profile.MainPages,
        profile.Subpages,
    }) do
        for key, value in pairs(scopeTable) do
            scopeTable[key] = clampValue(key, value)
        end
    end

    for _, pageValues in pairs(profile.Pages) do
        if type(pageValues) == 'table' then
            for key, value in pairs(pageValues) do
                pageValues[key] = clampValue(key, value)
            end
        end
    end

    return profile
end

function UIStyleManager:GetValue(
    profile,
    pageName,
    key,
    context
)
    profile = self:Normalize(profile)

    local pageValues = pageName
        and profile.Pages[pageName]
        or nil
    if type(pageValues) == 'table'
        and pageValues[key] ~= nil
    then
        return pageValues[key]
    end

    if context == 'Subpage'
        and profile.Subpages[key] ~= nil
    then
        return profile.Subpages[key]
    end

    if context == 'MainPage'
        and profile.MainPages[key] ~= nil
    then
        return profile.MainPages[key]
    end

    if profile.Global[key] ~= nil then
        return profile.Global[key]
    end

    return self.Defaults[key]
end

function UIStyleManager:GetEditableValue(
    profile,
    scope,
    pageName,
    key
)
    if scope == 'Current Page' then
        return self:GetValue(
            profile,
            pageName,
            key,
            'MainPage'
        )
    elseif scope == 'Main Pages' then
        return self:GetValue(
            profile,
            nil,
            key,
            'MainPage'
        )
    elseif scope == 'Subpages' then
        return self:GetValue(
            profile,
            nil,
            key,
            'Subpage'
        )
    end

    return self:GetValue(profile, nil, key, 'Global')
end

function UIStyleManager:SetValue(
    profile,
    scope,
    pageName,
    key,
    value
)
    profile = self:Normalize(profile)
    value = clampValue(key, value)

    local destination = profile.Global
    if scope == 'Current Page' then
        pageName = pageName or 'Home'
        profile.Pages[pageName] =
            profile.Pages[pageName] or {}
        destination = profile.Pages[pageName]
    elseif scope == 'Main Pages' then
        destination = profile.MainPages
    elseif scope == 'Subpages' then
        destination = profile.Subpages
    end

    destination[key] = value
    return value
end

function UIStyleManager:ResetScope(
    profile,
    scope,
    pageName
)
    profile = self:Normalize(profile)

    if scope == 'Current Page' then
        profile.Pages[pageName or 'Home'] = nil
    elseif scope == 'Main Pages' then
        profile.MainPages = {}
    elseif scope == 'Subpages' then
        profile.Subpages = {}
    else
        profile.Global = copyTable(self.Defaults)
    end

    return profile
end

function UIStyleManager:ApplyTheme(profile, themeName)
    profile = self:Normalize(profile)
    local theme = self.Themes[themeName]
    if type(theme) ~= 'table' then
        return false
    end

    profile.Global.ThemePreset = themeName
    for key, value in pairs(theme) do
        profile.Global[key] = value
    end
    return true
end

function UIStyleManager:ApplyProfileMetrics(
    deviceProfile,
    profile
)
    local global = self:Normalize(profile).Global
    deviceProfile.DesignWidth = global.WindowWidth
    deviceProfile.DesignHeight = global.WindowHeight
    deviceProfile.SidebarWidth = global.SidebarWidth
    deviceProfile.TopbarHeight = global.TopbarHeight
    deviceProfile.StatusbarHeight = global.FooterHeight
    deviceProfile.WindowRadius = global.CardRadius
    deviceProfile.ContentPadding = global.PagePadding
    deviceProfile.NavigationButtonHeight = math.clamp(
        global.ButtonHeight,
        32,
        58
    )
    deviceProfile.NavigationPadding = math.clamp(
        math.floor(global.SectionSpacing * 0.45),
        2,
        12
    )
    return deviceProfile
end

local defaultPageHues = {
    Home = 328,
    Games = 190,
    Players = 270,
    Guards = 350,
    Detective = 215,
    Farming = 145,
    UI = 300,
    Settings = 45,
}

function UIStyleManager:BuildPalette(profile)
    profile = self:Normalize(profile)
    local global = profile.Global

    local hue = (tonumber(global.AccentHue) or 328) / 360
    local saturation =
        (tonumber(global.AccentSaturation) or 77) / 100
    local brightness =
        (tonumber(global.AccentBrightness) or 100) / 100
    local backgroundBrightness =
        (tonumber(global.BackgroundBrightness) or 6) / 100
    local cardBrightness =
        (tonumber(global.CardBrightness) or 10) / 100
    local textBrightness =
        (tonumber(global.TextBrightness) or 96) / 100

    local accent = Color3.fromHSV(
        hue,
        math.clamp(saturation, 0, 1),
        math.clamp(brightness, 0.4, 1)
    )
    local backdrop = Color3.fromHSV(
        hue,
        0.28,
        math.clamp(backgroundBrightness, 0.01, 0.20)
    )
    local card = Color3.fromHSV(
        hue,
        0.25,
        math.clamp(cardBrightness, 0.04, 0.32)
    )
    local text = Color3.new(
        textBrightness,
        textBrightness,
        textBrightness
    )

    local colors = {
        Backdrop = backdrop,
        Window = Color3.fromHSV(
            hue,
            0.25,
            math.clamp(backgroundBrightness + 0.025, 0.02, 0.25)
        ),
        Sidebar = Color3.fromHSV(
            hue,
            0.26,
            math.clamp(backgroundBrightness + 0.035, 0.02, 0.27)
        ),
        Topbar = Color3.fromHSV(
            hue,
            0.28,
            math.clamp(backgroundBrightness + 0.045, 0.03, 0.28)
        ),
        Card = card,
        CardAlt = Color3.fromHSV(
            hue,
            0.28,
            math.clamp(cardBrightness + 0.045, 0.06, 0.38)
        ),
        CardHover = Color3.fromHSV(
            hue,
            0.32,
            math.clamp(cardBrightness + 0.09, 0.08, 0.46)
        ),
        Border = accent,
        BorderSoft = accent:Lerp(backdrop, 0.68),
        Accent = accent,
        AccentDark = accent:Lerp(Color3.new(0, 0, 0), 0.30),
        AccentSoft = accent:Lerp(backdrop, 0.48),
        Pink = accent,
        PinkDark = accent:Lerp(Color3.new(0, 0, 0), 0.34),
        Warning = Color3.fromRGB(255, 196, 64),
        Error = Color3.fromRGB(255, 63, 86),
        Success = Color3.fromRGB(45, 232, 98),
        Info = Color3.fromRGB(0, 170, 255),
        Minimize = Color3.fromRGB(106, 78, 176),
        Maximize = Color3.fromRGB(0, 139, 214),
        Close = Color3.fromRGB(211, 42, 68),
        CashApp = Color3.fromRGB(0, 224, 106),
        PayPal = Color3.fromRGB(0, 99, 214),
        Text = text,
        Muted = text:Lerp(backdrop, 0.34),
        Dim = text:Lerp(backdrop, 0.58),
        Black = Color3.fromRGB(0, 0, 0),
    }

    local pageAccents = {}
    for pageName, defaultHue in pairs(defaultPageHues) do
        local customHue = self:GetValue(
            profile,
            pageName,
            'PageAccentHue',
            'MainPage'
        )
        local resolvedHue = tonumber(customHue) or defaultHue
        if global.UniformPageAccents then
            resolvedHue = tonumber(global.AccentHue) or 328
        end

        pageAccents[pageName] = Color3.fromHSV(
            (resolvedHue % 360) / 360,
            math.clamp(saturation, 0.55, 1),
            math.clamp(brightness, 0.72, 1)
        )
    end

    pageAccents.Home = global.UniformPageAccents
        and accent
        or pageAccents.Home

    return colors, pageAccents
end

return UIStyleManager
]====],
        [ [====[Core/Utilities.lua]====] ] = [====[--//========================================================--
--// SquidNoMo
--// 1.1 beta 1
--// Utilities.lua
--//========================================================--

local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")
local RunService = game:GetService("RunService")
local Stats = game:GetService("Stats")

local Utilities = {}

----------------------------------------------------------
-- Number Formatting
----------------------------------------------------------

function Utilities:FormatNumber(Number)

	Number = tonumber(Number) or 0

	if Number >= 1000000 then
		return string.format("%.1fM", Number / 1000000)
	elseif Number >= 1000 then
		return string.format("%.1fK", Number / 1000)
	end

	return tostring(math.floor(Number))

end

----------------------------------------------------------
-- Time Formatting
----------------------------------------------------------

function Utilities:FormatTime(Seconds)

	Seconds = math.floor(Seconds)

	local Hours = math.floor(Seconds / 3600)
	local Minutes = math.floor((Seconds % 3600) / 60)
	local Secs = Seconds % 60

	if Hours > 0 then
		return string.format("%02d:%02d:%02d", Hours, Minutes, Secs)
	end

	return string.format("%02d:%02d", Minutes, Secs)

end

----------------------------------------------------------
-- Ping
----------------------------------------------------------

function Utilities:GetPing()

	local Ping = 0

	pcall(function()

		Ping = math.floor(
			Stats.Network.ServerStatsItem["Data Ping"]:GetValue()
		)

	end)

	return Ping

end

----------------------------------------------------------
-- FPS
----------------------------------------------------------

local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local FrameSampler = Environment.__SquidNoMoFrameSampler
if type(FrameSampler) ~= "table" or FrameSampler.Revision ~= "1.1b1-frame-sampler-r1" then
    FrameSampler = {
        Revision = "1.1b1-frame-sampler-r1",
        FPS = 60,
        Frames = 0,
        LastUpdate = os.clock(),
    }
    FrameSampler.Connection = RunService.RenderStepped:Connect(function()
        FrameSampler.Frames = FrameSampler.Frames + 1
        local now = os.clock()
        local elapsed = now - FrameSampler.LastUpdate
        if elapsed >= 0.75 then
            FrameSampler.FPS = math.max(1, math.floor(FrameSampler.Frames / elapsed + 0.5))
            FrameSampler.Frames = 0
            FrameSampler.LastUpdate = now
        end
    end)
    Environment.__SquidNoMoFrameSampler = FrameSampler
end

function Utilities:GetFPS()

	return FrameSampler.FPS

end

----------------------------------------------------------
-- Player Count
----------------------------------------------------------

function Utilities:GetPlayerCount()

	return #Players:GetPlayers()

end

----------------------------------------------------------
-- Server Age
----------------------------------------------------------

local StartTick = tick()

function Utilities:GetServerAge()

	return self:FormatTime(tick() - StartTick)

end

----------------------------------------------------------
-- Drag Window
----------------------------------------------------------

function Utilities:EnableDragging(Window, DragBar)

	local Dragging = false
	local DragInput
	local Start
	local Position

	local function Update(Input)

		local Delta = Input.Position - Start

		Window.Position = UDim2.new(

			Position.X.Scale,
			Position.X.Offset + Delta.X,

			Position.Y.Scale,
			Position.Y.Offset + Delta.Y

		)

	end

	DragBar.InputBegan:Connect(function(Input)

		if Input.UserInputType == Enum.UserInputType.MouseButton1 then

			Dragging = true

			Start = Input.Position

			Position = Window.Position

			Input.Changed:Connect(function()

				if Input.UserInputState == Enum.UserInputState.End then

					Dragging = false

				end

			end)

		end

	end)

	DragBar.InputChanged:Connect(function(Input)

		if Input.UserInputType == Enum.UserInputType.MouseMovement then

			DragInput = Input

		end

	end)

	UserInputService.InputChanged:Connect(function(Input)

		if Dragging and Input == DragInput then

			Update(Input)

		end

	end)

end

----------------------------------------------------------
-- Find Player
----------------------------------------------------------

function Utilities:FindPlayer(Name)

	Name = string.lower(Name)

	for _, Player in ipairs(Players:GetPlayers()) do

		if string.find(
			string.lower(Player.Name),
			Name,
			1,
			true
		) then

			return Player

		end

	end

	return nil

end

----------------------------------------------------------
-- Character
----------------------------------------------------------

function Utilities:GetCharacter(Player)

	Player = Player or Players.LocalPlayer

	return Player.Character
		or Player.CharacterAdded:Wait()

end

----------------------------------------------------------
-- Humanoid
----------------------------------------------------------

function Utilities:GetHumanoid(Player)

	local Character = self:GetCharacter(Player)

	return Character:WaitForChild("Humanoid")

end

----------------------------------------------------------
-- Root Part
----------------------------------------------------------

function Utilities:GetRoot(Player)

	local Character = self:GetCharacter(Player)

	return Character:WaitForChild("HumanoidRootPart")

end

----------------------------------------------------------
-- Teleport
----------------------------------------------------------

function Utilities:Teleport(CFramePosition)

	local Root = self:GetRoot()

	if Root then

		Root.CFrame = CFramePosition

	end

end

----------------------------------------------------------
-- Distance
----------------------------------------------------------

function Utilities:GetDistance(A, B)

	return (A - B).Magnitude

end

----------------------------------------------------------
-- Tween Wrapper
----------------------------------------------------------

function Utilities:Tween(Object, TweenInfoValue, Properties)

	return game:GetService("TweenService")
		:Create(Object, TweenInfoValue, Properties)

end

return Utilities
]====],
        [ [====[Features/Detective/BoatDepositor.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    Id = "mapped.detective.boat_operations.boatdepositor",
    Name = "Boat Depositor",
    Description = "Walks evidence back to the boat and deposits supported evidence tools.",
    Kind = "TaskChain",
    RequireToolTokens = {"evidence", "clue", "file", "document", "keycard"},
    SourceTokens = {"evidence", "clue", "file", "document", "keycard"},
    DestinationTokens = {"boat", "deposit", "submit", "evidence box", "dock", "return evidence", "hand in evidence"},
    SourceLabel = "evidence",
    DestinationLabel = "boat evidence deposit",
    InteractDistance = 12,
    ActionCooldown = 0.9,
    MovementPriority = 90,
    ActionPriority = 85,
})
]====],
        [ [====[Features/Detective/DisguiseManager.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    Id = "mapped.detective.disguise.disguisemanager",
    Name = "Disguise Manager",
    Description = "Equips an available disguise when a nearby guard is detected.",
    Kind = "Disguise",
    PlayerTokens = {"guard", "staff", "soldier"},
    ToolTokens = {"disguise", "uniform", "mask", "guard outfit"},
    Range = 38,
    Interval = 0.5,
})
]====],
        [ [====[Features/Detective/EvidenceCollector.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    Id = "mapped.detective.evidence.evidencecollector",
    Name = "Evidence Collector",
    Description = "Walks to nearby evidence and activates supported collection prompts.",
    Kind = "Interact",
    TargetTokens = {"evidence", "clue", "file", "document", "keycard", "fingerprint", "collect evidence", "inspect clue", "investigate"},
    ExcludeTokens = {"submitted", "deposit"},
    TargetClasses = {"Tool", "Model", "BasePart", "ProximityPrompt", "ClickDetector"},
    MaxDistance = 80,
    Walk = true,
    InteractDistance = 12,
    ActionCooldown = 0.65,
    MovementPriority = 70,
    ActionPriority = 70,
    WaitingMessage = "Waiting for collectible evidence",
})
]====],
        [ [====[Features/Detective/EvidenceESP.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    Id = "mapped.detective.evidence.evidenceesp",
    Name = "Evidence ESP",
    Description = "Highlights evidence, clues, files, and keycards in the world.",
    Kind = "Highlight",
    TargetTokens = {"evidence", "clue", "file", "document", "keycard", "fingerprint", "collect evidence", "inspect clue"},
    ExcludeTokens = {"submitted", "deposit"},
    TargetClasses = {"Tool", "Model", "BasePart"},
    Color = Color3.fromRGB(60, 220, 255),
    WaitingMessage = "Waiting for evidence objects",
})
]====],
        [ [====[Features/Detective/IslandNavigator.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    Id = "mapped.detective.island_navigation.islandnavigator",
    Name = "Island Navigator",
    Description = "Auto-walks from the boat or starting area to the nearest evidence using pathfinding; it does not teleport.",
    Kind = "WalkTo",
    TargetTokens = {"evidence", "clue", "file", "document", "keycard", "fingerprint", "objective", "waypoint", "hint marker"},
    ExcludeTokens = {"boat deposit", "submitted"},
    TargetClasses = {"Model", "BasePart", "ProximityPrompt"},
    StopDistance = 8,
    MaxWaypoints = 5,
    MovementPriority = 55,
    WaypointTimeout = 1.2,
    WaitingMessage = "Waiting for evidence on the island",
})
]====],
        [ [====[Features/Farming/DetectiveMasterController.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end
local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest or {}
local FarmingRuntime = Environment.__SquidNoMoFarmingRuntime
if type(FarmingRuntime) ~= "table"
    or FarmingRuntime.Revision ~= tostring(Manifest.FarmingRuntimeRevision or "")
    or tonumber(FarmingRuntime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    local bundle = Environment.__SquidNoMoSourceBundle
    local source = type(bundle) == "table" and bundle["Features/Farming/FarmingRuntime.lua"] or nil
    if type(source) ~= "string" then
        error("SquidNoMo verified farming runtime is unavailable")
    end
    FarmingRuntime = loadstring(source)()
end

return FarmingRuntime:CreateController({
    Id = "mapped.farming.detective_master_controller",
    Name = "Detective Evidence Farming",
    Description = "Runs a stable evidence loop: walk to clues, collect them, and return them to the boat.",
    Interval = 0.85,
    IdleInterval = 1.6,
    Select = function(self, helper)
        local _, _, _, root = helper:GetCharacter()
        if not root then return {}, "Waiting for the local character" end

        if helper:FindTool({"evidence", "clue", "file", "document", "keycard", "fingerprint"}) then
            return {
                DISGUISE,
                "Features/Detective/BoatDepositor.lua",
            }, "Carrying evidence back to the boat"
        end

        local evidence, distance = helper:FindNearest({
            Scope = "Workspace",
            TargetTokens = {"evidence", "clue", "file", "document", "keycard", "fingerprint"},
            ExcludeTokens = {"submitted", "deposit"},
            TargetClasses = {"Tool", "Model", "BasePart", "ProximityPrompt", "ClickDetector"},
            MaxTargets = 160,
        }, root.Position)

        if evidence and distance <= 80 then
            return {
                DISGUISE,
                "Features/Detective/EvidenceCollector.lua",
            }, "Collecting the nearest evidence"
        end

        return {
            DISGUISE,
            "Features/Detective/IslandNavigator.lua",
        }, "Walking from the boat toward island evidence"
    end,
})
]====],
        [ [====[Features/Farming/FarmingRuntime.lua]====] ] = [====[-- SquidNoMo farming controller runtime
-- Coordinates existing feature modules without relying on Roblox Instance require paths.

local Players = game:GetService("Players")
local Workspace = game:GetService("Workspace")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)

local FarmingRuntime = {
    Revision = tostring(Manifest.FarmingRuntimeRevision or "farming-runtime-r1"),
    BuildNumber = BUILD_NUMBER,
    Repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/",
}

local FeatureRuntime = Environment.__SquidNoMoFeatureRuntime
local expectedFeatureRevision = tostring(Manifest.FeatureRuntimeRevision or "")
if type(FeatureRuntime) ~= "table"
    or FeatureRuntime.Revision ~= expectedFeatureRevision
    or tonumber(FeatureRuntime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo farming requires the verified feature runtime from the current build")
end

local ModuleCache = Environment.__SquidNoMoFarmingModuleCache
if type(ModuleCache) ~= "table" then
    ModuleCache = {}
    Environment.__SquidNoMoFarmingModuleCache = ModuleCache
end

local function getLoader()
    local session = Environment.__SquidNoMoSession
    if type(session) == "table" and type(session.Loader) == "table" then
        return session.Loader
    end
    return nil
end

local function loadFeature(path)
    if type(ModuleCache[path]) == "table" then
        return ModuleCache[path]
    end

    local loader = getLoader()
    local feature

    -- Reuse the same feature object used by the normal Games/Guards/Detective
    -- pages. This prevents a farming controller and a page toggle from creating
    -- two independent copies of the same worker.
    local manager = loader and loader.FeatureManager
    if manager and type(manager.Registry) == "table" then
        for id, entry in pairs(manager.Registry) do
            if entry.Path == path then
                if type(entry.Feature) == "table" then
                    feature = entry.Feature
                elseif type(manager.LoadCatalogFeature) == "function" then
                    local loaded, loadError = manager:LoadCatalogFeature(id)
                    if type(loaded) == "table" then
                        feature = loaded
                    elseif loadError then
                        error(tostring(loadError))
                    end
                end
                break
            end
        end
    end

    if not feature and loader and type(loader.LoadRemote) == "function" then
        feature = loader:LoadRemote(path)
    elseif not feature then
        local bundle = Environment.__SquidNoMoSourceBundle
        local source = type(bundle) == "table" and bundle[path] or nil
        if type(source) ~= "string" then
            error("verified bundled source is unavailable for " .. tostring(path))
        end
        local chunk, compileError = loadstring(source)
        if not chunk then
            error("compile failed for " .. tostring(path) .. ": " .. tostring(compileError))
        end
        feature = chunk()
    end

    if type(feature) ~= "table" then
        error("feature module did not return a table: " .. tostring(path))
    end
    if type(feature.Toggle) ~= "function"
        and not (type(feature.Enable) == "function" and type(feature.Disable) == "function")
    then
        error("feature module has no Toggle or Enable/Disable API: " .. tostring(path))
    end

    ModuleCache[path] = feature
    return feature
end

local function featureEnabled(feature)
    if type(feature) ~= "table" then return false end
    if type(feature.IsEnabled) == "function" then
        local ok, value = pcall(feature.IsEnabled, feature)
        if ok then return value == true end
    end
    if type(feature.GetState) == "function" then
        local ok, value = pcall(feature.GetState, feature)
        if ok then
            value = string.lower(tostring(value or ""))
            return value == "on" or value == "enabled" or value == "full"
        end
    end
    return feature.Enabled == true or feature.Active == true
end

local function setFeatureEnabled(feature, state)
    state = state == true
    if type(feature) ~= "table" then
        return false, "feature is unavailable"
    end
    if featureEnabled(feature) == state then
        return true
    end

    local method = state and feature.Enable or feature.Disable
    if type(method) == "function" then
        local ok, result, detail = pcall(method, feature)
        if not ok then return false, tostring(result) end
        if result == false then return false, tostring(detail or "feature rejected the requested state") end
        return true
    end

    if type(feature.Toggle) == "function" then
        local ok, result, detail = pcall(feature.Toggle, feature, state)
        if not ok then return false, tostring(result) end
        if result == false then return false, tostring(detail or "feature rejected the requested state") end
        return true
    end

    return false, "feature has no supported toggle API"
end

local function getFeatureStatus(feature)
    if type(feature) ~= "table" then return "Off", "Not loaded" end
    if type(feature.GetStatus) == "function" then
        local ok, state, detail = pcall(feature.GetStatus, feature)
        if ok then
            return tostring(state or "Off"), tostring(detail or "")
        end
    end
    return featureEnabled(feature) and "Active" or "Off", featureEnabled(feature) and "Enabled" or "Disabled"
end

local function getCharacter()
    local player = Players.LocalPlayer
    local character = player and player.Character
    local humanoid = character and character:FindFirstChildOfClass("Humanoid")
    local root = character and character:FindFirstChild("HumanoidRootPart")
    return player, character, humanoid, root
end


local function normalizeText(value)
    local text = string.lower(tostring(value or ""))
    text = string.gsub(text, "[_%-]", " ")
    text = string.gsub(text, "%s+", " ")
    return text
end

local function containsAnyText(text, tokens)
    text = normalizeText(text)
    for _, token in ipairs(tokens or {}) do
        if string.find(text, normalizeText(token), 1, true) then
            return true
        end
    end
    return false
end


local function containsModeValue(value, tokens)
    local text = normalizeText(value)
    local words = " " .. string.gsub(text, "[^%w]+", " ") .. " "
    local compact = string.gsub(text, "[^%w]", "")
    for _, token in ipairs(tokens or {}) do
        local normalized = normalizeText(token)
        local compactToken = string.gsub(normalized, "[^%w]", "")
        if string.find(words, " " .. normalized .. " ", 1, true)
            or compact == compactToken
            or compact == "frontman" .. compactToken
            or compact == compactToken .. "mode"
            or compact == "frontman" .. compactToken .. "mode"
        then
            return true
        end
    end
    return false
end

local function isSquidNoMoGui(instance)
    local current = instance
    while current do
        if current:IsA("ScreenGui") and string.lower(current.Name) == "squidnomo" then
            return true
        end
        current = current.Parent
    end
    return false
end

local FrontmanModeCache = nil

local function detectFrontmanMode()
    local now = os.clock()
    if FrontmanModeCache and now - FrontmanModeCache.Time < 0.75 then
        return FrontmanModeCache.Mode, FrontmanModeCache.Detail, FrontmanModeCache.Confidence
    end

    local scores = {Guard = 0, Player = 0}
    local strongest = {Guard = nil, Player = nil}
    local strongestWeight = {Guard = 0, Player = 0}

    local function record(mode, weight, source)
        if mode ~= "Guard" and mode ~= "Player" then return end
        weight = tonumber(weight) or 0
        scores[mode] = scores[mode] + weight
        if weight > strongestWeight[mode] then
            strongestWeight[mode] = weight
            strongest[mode] = tostring(source or "mode signal")
        end
    end

    local guardValues = {"guard", "staff", "soldier", "worker", "triangle", "square", "circle"}
    local playerValues = {"player", "contestant", "participant", "runner", "survivor"}
    local relevantKeys = {
        "frontman mode", "front man mode", "selected mode", "selected role",
        "current mode", "current role", "play as", "playing as", "active role",
        "mode", "role", "class", "job", "team", "side",
    }

    local function scoreExplicitValue(key, value, weight, source)
        local keyText = normalizeText(key)
        if not containsAnyText(keyText, relevantKeys) then return end
        local valueText = normalizeText(value)
        local hasGuard = containsModeValue(valueText, guardValues)
        local hasPlayer = containsModeValue(valueText, playerValues)
        if hasGuard and not hasPlayer then
            record("Guard", weight, source .. " = " .. tostring(value))
        elseif hasPlayer and not hasGuard then
            record("Player", weight, source .. " = " .. tostring(value))
        end
    end

    local function scanAttributes(instance, weight, source)
        if not instance then return end
        local ok, attributes = pcall(instance.GetAttributes, instance)
        if not ok or type(attributes) ~= "table" then return end
        for key, value in pairs(attributes) do
            scoreExplicitValue(key, value, weight, source .. " attribute " .. tostring(key))
        end
    end

    local function scoreStatusPhrase(value, weight, source)
        local text = normalizeText(value)
        local guardPhrase = containsAnyText(text, {
            "playing as guard", "currently guard", "current mode guard",
            "current role guard", "selected guard", "guard selected",
            "guard mode active", "guard duties active", "mode: guard", "role: guard",
        })
        local playerPhrase = containsAnyText(text, {
            "playing as player", "currently player", "current mode player",
            "current role player", "selected player", "player selected",
            "player mode active", "contestant mode active", "mode: player", "role: player",
        })
        if guardPhrase and not playerPhrase then
            record("Guard", weight, source)
        elseif playerPhrase and not guardPhrase then
            record("Player", weight, source)
        end
    end

    local player, character = getCharacter()
    if not player then
        FrontmanModeCache = {
            Time = now,
            Mode = nil,
            Detail = "Waiting for the local player",
            Confidence = 0,
        }
        return nil, FrontmanModeCache.Detail, 0
    end

    -- Explicit role/mode data is the strongest signal and is checked first.
    scanAttributes(player, 20, "Player")
    scanAttributes(character, 20, "Character")
    if player.Team then
        scoreExplicitValue("team", player.Team.Name, 16, "Team")
    end

    for _, child in ipairs(player:GetChildren()) do
        if child:IsA("ValueBase") then
            scoreExplicitValue(child.Name, child.Value, 18, "Player value " .. child.Name)
        elseif child:IsA("Folder") and containsAnyText(child.Name, {"role", "mode", "selection", "frontman"}) then
            scanAttributes(child, 16, "Player folder " .. child.Name)
            local scanned = 0
            for _, descendant in ipairs(child:GetDescendants()) do
                if descendant:IsA("ValueBase") then
                    scoreExplicitValue(descendant.Name, descendant.Value, 16, "Player folder value " .. descendant.Name)
                    scanned = scanned + 1
                    if scanned >= 40 then break end
                end
            end
        end
    end

    if character then
        local scanned = 0
        for _, descendant in ipairs(character:GetDescendants()) do
            if descendant:IsA("ValueBase") then
                scoreExplicitValue(descendant.Name, descendant.Value, 18, "Character value " .. descendant.Name)
            end

            local appearance = normalizeText(descendant.Name)
            if containsAnyText(appearance, {
                "guard uniform", "guard mask", "triangle mask", "square mask",
                "circle mask", "soldier uniform", "staff uniform",
            }) then
                record("Guard", 9, "Guard uniform or mask detected")
            elseif containsAnyText(appearance, {
                "player uniform", "contestant uniform", "tracksuit", "track suit",
                "contestant outfit", "player outfit",
            }) then
                record("Player", 8, "Player uniform detected")
            end

            scanned = scanned + 1
            if scanned >= 140 then break end
        end
    end

    -- Some experiences store the local selection in a player-named folder.
    for _, dataRoot in ipairs({Workspace, ReplicatedStorage}) do
        for _, child in ipairs(dataRoot:GetChildren()) do
            local childName = normalizeText(child.Name)
            if childName == normalizeText(player.Name)
                or childName == tostring(player.UserId)
                or containsAnyText(childName, {"local player", "frontman selection", "frontman mode"})
            then
                scanAttributes(child, 16, dataRoot.Name .. "/" .. child.Name)
                local scanned = 0
                for _, descendant in ipairs(child:GetDescendants()) do
                    if descendant:IsA("ValueBase") then
                        scoreExplicitValue(
                            descendant.Name,
                            descendant.Value,
                            15,
                            dataRoot.Name .. "/" .. child.Name .. "/" .. descendant.Name
                        )
                        scanned = scanned + 1
                        if scanned >= 50 then break end
                    end
                end
            end
        end
    end

    -- Visible selection/status text is useful, but choice buttons by themselves
    -- are ignored because both Player and Guard buttons may be visible together.
    if type(FeatureRuntime.FindTargets) == "function" then
        local guiObjects = FeatureRuntime:FindTargets({
            Scope = "Gui",
            TargetClasses = {"TextLabel", "TextButton", "TextBox"},
            TargetTokens = {"frontman", "playing as", "selected", "current mode", "current role", "mode:", "role:"},
            VisibleOnly = true,
            MaxTargets = 90,
            CacheTTL = 0.45,
        })
        for _, object in ipairs(guiObjects) do
            if not isSquidNoMoGui(object) then
                local text = tostring(object.Text or object.Name)
                scoreStatusPhrase(text, 17, "Visible mode status: " .. text)
                scanAttributes(object, 15, "Mode UI " .. object.Name)

                local selected = false
                for _, attributeName in ipairs({"Selected", "IsSelected", "Active", "Chosen", "Current"}) do
                    local ok, value = pcall(object.GetAttribute, object, attributeName)
                    if ok and (value == true or normalizeText(value) == "selected" or normalizeText(value) == "active") then
                        selected = true
                        break
                    end
                end
                if selected then
                    local selectedText = normalizeText(text)
                    local hasGuard = containsModeValue(selectedText, guardValues)
                    local hasPlayer = containsModeValue(selectedText, playerValues)
                    if hasGuard and not hasPlayer then
                        record("Guard", 18, "Selected Guard mode button")
                    elseif hasPlayer and not hasGuard then
                        record("Player", 18, "Selected Player mode button")
                    end
                end
            end
        end
    end

    -- Equipped duty tools are a dependable fallback after the selection UI closes.
    if FeatureRuntime:FindTool({"taser", "stun", "baton", "guard weapon", "coffin", "corpse", "body bag"}) then
        record("Guard", 13, "Guard duty tool equipped")
    elseif FeatureRuntime:FindTool({"cooked", "meal", "tray", "raw", "ingredient", "uncooked"}) then
        record("Guard", 11, "Guard staff tool equipped")
    end

    local backpack = player:FindFirstChildOfClass("Backpack")
    for _, container in ipairs({character, backpack}) do
        if container then
            for _, item in ipairs(container:GetChildren()) do
                if item:IsA("Tool") then
                    local toolName = normalizeText(item.Name)
                    local compactTool = string.gsub(toolName, "[^%w]", "")
                    if containsAnyText(toolName, {"marble", "dalgona", "lighter", "keycard"})
                        or compactTool == "key"
                    then
                        record("Player", 7, "Player minigame tool equipped")
                        break
                    end
                end
            end
        end
    end

    -- A detected minigame is only weak evidence. It cannot override an explicit
    -- Guard signal, but it helps Player mode settle after a player morph loads.
    local category = nil
    if type(FeatureRuntime.DetectGameCategory) == "function" then
        category = FeatureRuntime:DetectGameCategory()
    end
    if category then
        record("Player", 3, "Active minigame: " .. tostring(category))
    end

    local mode = nil
    local confidence = math.abs(scores.Guard - scores.Player)
    if scores.Guard >= 8 and scores.Guard >= scores.Player + 4 then
        mode = "Guard"
    elseif scores.Player >= 8 and scores.Player >= scores.Guard + 4 then
        mode = "Player"
    end

    local detail
    if mode then
        detail = string.format(
            "%s mode detected (%s)",
            mode,
            strongest[mode] or "combined role signals"
        )
    elseif scores.Guard > 0 or scores.Player > 0 then
        detail = string.format(
            "Mode is ambiguous (Guard %d / Player %d); waiting for the selected mode to settle",
            scores.Guard,
            scores.Player
        )
    else
        detail = "Waiting for Frontman Player or Guard mode selection"
    end

    FrontmanModeCache = {
        Time = now,
        Mode = mode,
        Detail = detail,
        Confidence = confidence,
    }
    return mode, detail, confidence
end

local function normalizePathList(paths)
    local result = {}
    local seen = {}
    for _, path in ipairs(paths or {}) do
        if type(path) == "string" and path ~= "" and not seen[path] then
            seen[path] = true
            table.insert(result, path)
        end
    end
    return result
end

local ControllerMethods = {}
ControllerMethods.__index = ControllerMethods

function ControllerMethods:_SetStatus(state, detail)
    state = tostring(state or "Off")
    detail = tostring(detail or "")
    if self.Status == state and self.StatusDetail == detail then return end
    self.Status = state
    self.StatusDetail = detail
    for _, callback in pairs(self.StatusListeners) do
        task.spawn(function()
            pcall(callback, state, detail)
        end)
    end
end

function ControllerMethods:GetStatus()
    return self.Status, self.StatusDetail
end

function ControllerMethods:SubscribeStatus(callback)
    if type(callback) ~= "function" then return nil end
    self.NextListenerId = self.NextListenerId + 1
    local id = self.NextListenerId
    self.StatusListeners[id] = callback
    local connection = {}
    function connection:Disconnect()
        self.Connected = false
        if self._owner then self._owner.StatusListeners[self._id] = nil end
    end
    connection.Connected = true
    connection._owner = self
    connection._id = id
    return connection
end

function ControllerMethods:_Load(path)
    if type(self.Children[path]) == "table" then
        return self.Children[path]
    end
    local ok, result = pcall(loadFeature, path)
    if not ok then
        return nil, tostring(result)
    end
    self.Children[path] = result
    return result
end

function ControllerMethods:_DisableAll()
    local firstError
    local loader = getLoader()
    local manager = loader and loader.FeatureManager
    for path, feature in pairs(self.Children) do
        if self.OwnedPaths[path] then
            local released = false
            if manager and type(manager.Registry) == "table" and type(manager.SetTransientFeature) == "function" then
                for id, entry in pairs(manager.Registry) do
                    if entry.Path == path then
                        local ok, err = manager:SetTransientFeature(id, self, false)
                        if not ok and not firstError then firstError = err end
                        released = true
                        break
                    end
                end
            end
            if not released then
                local ok, err = setFeatureEnabled(feature, false)
                if not ok and not firstError then firstError = err end
            end
        end
    end
    self.ActivePaths = {}
    self.OwnedPaths = {}
    return firstError == nil, firstError
end

function ControllerMethods:_SwitchTo(paths)
    paths = normalizePathList(paths)
    local desired = {}
    for _, path in ipairs(paths) do desired[path] = true end
    local loader = getLoader()
    local manager = loader and loader.FeatureManager

    for path, feature in pairs(self.Children) do
        if self.ActivePaths[path] and not desired[path] then
            local released = false
            if manager and type(manager.Registry) == "table" and type(manager.SetTransientFeature) == "function" then
                for id, entry in pairs(manager.Registry) do
                    if entry.Path == path then
                        manager:SetTransientFeature(id, self, false)
                        released = true
                        break
                    end
                end
            end
            if not released and self.OwnedPaths[path] then
                local ok, err = setFeatureEnabled(feature, false)
                if not ok then return false, "failed to stop " .. tostring(path) .. ": " .. tostring(err) end
            end
            self.ActivePaths[path] = nil
            self.OwnedPaths[path] = nil
        end
    end

    for _, path in ipairs(paths) do
        local feature, loadError = self:_Load(path)
        if not feature then return false, loadError end
        local managed = false
        if manager and type(manager.Registry) == "table" and type(manager.SetTransientFeature) == "function" then
            for id, entry in pairs(manager.Registry) do
                if entry.Path == path then
                    local ok, err = manager:SetTransientFeature(id, self, true)
                    if not ok then return false, "failed to start " .. tostring(path) .. ": " .. tostring(err) end
                    managed = true
                    break
                end
            end
        end
        if not managed then
            local alreadyEnabled = featureEnabled(feature)
            local ok, err = setFeatureEnabled(feature, true)
            if not ok then return false, "failed to start " .. tostring(path) .. ": " .. tostring(err) end
            if not alreadyEnabled then self.OwnedPaths[path] = true end
        else
            self.OwnedPaths[path] = true
        end
        self.ActivePaths[path] = true
    end
    return true
end

function ControllerMethods:_Summarize(paths, fallbackDetail)
    local activeCount = 0
    local waitingCount = 0
    local firstWaiting
    for _, path in ipairs(paths or {}) do
        local feature = self.Children[path]
        local state, detail = getFeatureStatus(feature)
        local normalized = string.lower(state)
        if normalized == "error" then
            return "Error", detail ~= "" and detail or ("Child failed: " .. tostring(path))
        elseif normalized == "active" or normalized == "complete" then
            activeCount = activeCount + 1
        elseif normalized == "waiting" or normalized == "starting" then
            waitingCount = waitingCount + 1
            firstWaiting = firstWaiting or detail
        end
    end

    if activeCount > 0 then
        return "Active", fallbackDetail
    elseif waitingCount > 0 then
        return "Waiting", firstWaiting or fallbackDetail
    end
    return "Waiting", fallbackDetail
end

function ControllerMethods:_RunStep()
    local ok, paths, detail = xpcall(function()
        return self.Config.Select(self, FarmingRuntime, FeatureRuntime)
    end, debug.traceback)
    if not ok then
        self.LastError = tostring(paths)
        self:_DisableAll()
        self:_SetStatus("Error", self.LastError)
        return false
    end

    paths = normalizePathList(paths)
    detail = tostring(detail or self.Config.WaitingMessage or "Waiting for a supported farming task")
    if #paths == 0 then
        self:_DisableAll()
        self:_SetStatus("Waiting", detail)
        return false
    end

    local switched, switchError = self:_SwitchTo(paths)
    if not switched then
        self.LastError = tostring(switchError)
        self:_SetStatus("Error", self.LastError)
        return false
    end

    local state, statusDetail = self:_Summarize(paths, detail)
    self:_SetStatus(state, statusDetail)
    return state == "Active"
end

function ControllerMethods:Toggle(state)
    state = state == true
    if self.Enabled == state then return true end

    self.Enabled = state
    self.LastError = nil
    local scheduler = FeatureRuntime.Scheduler
    if scheduler and type(scheduler.Remove) == "function" then
        scheduler:Remove(self)
    end

    if not state then
        local ok, err = self:_DisableAll()
        self:_SetStatus("Off", "Disabled")
        if not ok then return false, err end
        return true
    end

    self:_SetStatus("Starting", "Preparing " .. self.Name)
    if not scheduler or type(scheduler.Add) ~= "function" then
        self.Enabled = false
        self:_SetStatus("Error", "Shared scheduler is unavailable")
        return false, "shared scheduler is unavailable"
    end

    scheduler:Add(
        self,
        self.Config.Interval or 0.8,
        self.Config.IdleInterval or 1.5,
        function(owner)
            return owner:_RunStep()
        end
    )
    self:_RunStep()
    return true
end

function ControllerMethods:Enable()
    return self:Toggle(true)
end

function ControllerMethods:Disable()
    return self:Toggle(false)
end

function ControllerMethods:IsEnabled()
    return self.Enabled == true
end

function ControllerMethods:GetState()
    return self.Enabled and "on" or "off"
end

function FarmingRuntime:CreateController(config)
    assert(type(config) == "table", "farming controller config must be a table")
    assert(type(config.Select) == "function", "farming controller Select callback is required")
    return setmetatable({
        Id = tostring(config.Id or config.Name or "farming.controller"),
        Name = tostring(config.Name or "Farming Controller"),
        Description = tostring(config.Description or ""),
        Config = config,
        Enabled = false,
        Status = "Off",
        StatusDetail = "Disabled",
        LastError = nil,
        Children = {},
        ActivePaths = {},
        OwnedPaths = {},
        StatusListeners = {},
        NextListenerId = 0,
    }, ControllerMethods)
end

function FarmingRuntime:GetCharacter()
    return getCharacter()
end

function FarmingRuntime:FindTool(tokens)
    if type(FeatureRuntime.FindTool) == "function" then
        return FeatureRuntime:FindTool(tokens or {})
    end
    return nil
end

function FarmingRuntime:FindNearest(config, origin)
    if type(FeatureRuntime.FindNearest) ~= "function" then return nil, math.huge end
    return FeatureRuntime:FindNearest(config or {}, origin)
end

function FarmingRuntime:DetectFrontmanMode()
    return detectFrontmanMode()
end

Environment.__SquidNoMoFarmingRuntime = FarmingRuntime
return FarmingRuntime
]====],
        [ [====[Features/Farming/FrontmanAdaptiveController.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end
local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest or {}
local FarmingRuntime = Environment.__SquidNoMoFarmingRuntime
if type(FarmingRuntime) ~= "table"
    or FarmingRuntime.Revision ~= tostring(Manifest.FarmingRuntimeRevision or "")
    or tonumber(FarmingRuntime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    local bundle = Environment.__SquidNoMoSourceBundle
    local source = type(bundle) == "table" and bundle["Features/Farming/FarmingRuntime.lua"] or nil
    if type(source) ~= "string" then
        error("SquidNoMo verified farming runtime is unavailable")
    end
    FarmingRuntime = loadstring(source)()
end

local MODE_PATHS = {
    Player = "Features/Farming/PlayerMinigameBot.lua",
    Guard = "Features/Farming/GuardMasterController.lua",
}

local Controller = FarmingRuntime:CreateController({
    Id = "mapped.farming.frontman_adaptive_controller",
    Name = "Frontman Adaptive Farming",
    Description = "Detects whether Frontman selected Player or Guard mode, then runs the matching farming controller.",
    Interval = 0.85,
    IdleInterval = 1.45,
    Select = function(self, helper)
        local detectedMode, detectionDetail, confidence = helper:DetectFrontmanMode()
        local now = os.clock()

        if detectedMode then
            if detectedMode == self.ActiveMode then
                self.PendingMode = nil
                self.PendingCount = 0
                self.LastModeEvidence = now
            else
                if self.PendingMode == detectedMode then
                    self.PendingCount = (self.PendingCount or 0) + 1
                else
                    self.PendingMode = detectedMode
                    self.PendingCount = 1
                end

                -- Strong explicit attributes, a selected GUI state, or a guard
                -- duty tool can switch immediately. Weaker outfit/tool evidence
                -- must agree twice so the controller does not flap between modes.
                local confirmed = (tonumber(confidence) or 0) >= 14
                    or self.PendingCount >= 2
                if confirmed then
                    self.ActiveMode = detectedMode
                    Environment.__SquidNoMoFrontmanFarmingMode = detectedMode
                    self.PendingMode = nil
                    self.PendingCount = 0
                    self.LastModeEvidence = now
                elseif self.ActiveMode then
                    return {
                        MODE_PATHS[self.ActiveMode],
                    }, string.format(
                        "Frontman %s mode active; confirming switch to %s",
                        self.ActiveMode,
                        detectedMode
                    )
                else
                    return {}, "Confirming Frontman " .. detectedMode .. " mode"
                end
            end
        elseif self.ActiveMode then
            -- Mode labels often disappear immediately after the selection menu
            -- closes. Keep the last confirmed selection until clear evidence
            -- identifies the other mode.
            return {
                MODE_PATHS[self.ActiveMode],
            }, "Frontman " .. self.ActiveMode .. " mode active; using the last confirmed selection"
        else
            self.ActiveMode = nil
            self.PendingMode = nil
            self.PendingCount = 0
            return {}, detectionDetail or "Waiting for Frontman mode selection"
        end

        local mode = self.ActiveMode
        local path = mode and MODE_PATHS[mode]
        if not path then
            return {}, detectionDetail or "Waiting for Frontman mode selection"
        end

        return {
            path,
        }, string.format(
            "Frontman %s mode: %s",
            mode,
            detectionDetail or "running matching farming tasks"
        )
    end,
})


local savedMode = Environment.__SquidNoMoFrontmanFarmingMode
if savedMode == "Player" or savedMode == "Guard" then
    Controller.ActiveMode = savedMode
    Controller.LastModeEvidence = os.clock()
end

return Controller
]====],
        [ [====[Features/Farming/GuardMasterController.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end
local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest or {}
local FarmingRuntime = Environment.__SquidNoMoFarmingRuntime
if type(FarmingRuntime) ~= "table"
    or FarmingRuntime.Revision ~= tostring(Manifest.FarmingRuntimeRevision or "")
    or tonumber(FarmingRuntime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    local bundle = Environment.__SquidNoMoSourceBundle
    local source = type(bundle) == "table" and bundle["Features/Farming/FarmingRuntime.lua"] or nil
    if type(source) ~= "string" then
        error("SquidNoMo verified farming runtime is unavailable")
    end
    FarmingRuntime = loadstring(source)()
end

local function nearby(helper, root, tokens, maxDistance)
    if not root then return nil, math.huge end
    local target, distance = helper:FindNearest({
        Scope = "Workspace",
        TargetTokens = tokens,
        TargetClasses = {"Model", "BasePart", "Tool", "ProximityPrompt"},
        MaxTargets = 140,
    }, root.Position)
    if target and distance <= (maxDistance or 70) then
        return target, distance
    end
    return nil, math.huge
end

return FarmingRuntime:CreateController({
    Id = "mapped.farming.guard_master_controller",
    Name = "Guard Staff Farming",
    Description = "Selects one compatible guard duty at a time for kitchen, morgue, or moderation work.",
    Interval = 0.9,
    IdleInterval = 1.7,
    Select = function(self, helper)
        local _, _, _, root = helper:GetCharacter()
        if not root then return {}, "Waiting for the local character" end

        if helper:FindTool({"cooked", "meal", "tray"}) then
            return {
                "Features/Guard/Kitchen/AutoStorage.lua",
            }, "Kitchen Staff: delivering cooked food"
        end
        if helper:FindTool({"raw", "ingredient", "meat", "uncooked"}) then
            return {
                "Features/Guard/Kitchen/AutoCooker.lua",
            }, "Kitchen Staff: cooking collected supplies"
        end
        if helper:FindTool({"coffin", "body", "corpse"}) then
            return {
                "Features/Guard/Coffin/CoffinDisposal.lua",
            }, "Morgue Staff: carrying a coffin to disposal"
        end

        local kitchen, kitchenDistance = nearby(
            helper,
            root,
            {"kitchen", "cook", "stove", "oven", "ingredient", "supply", "food crate"},
            70
        )
        local morgue, morgueDistance = nearby(
            helper,
            root,
            {"morgue", "coffin", "corpse", "incinerator", "furnace", "disposal"},
            70
        )
        local cleanup, cleanupDistance = nearby(
            helper,
            root,
            {"eliminated", "dead body", "cleanup target"},
            55
        )

        if kitchen and kitchenDistance <= morgueDistance and kitchenDistance <= cleanupDistance then
            return {
                "Features/Guard/Kitchen/AutoSupply.lua",
            }, "Kitchen Staff: collecting supplies"
        end
        if morgue and morgueDistance <= cleanupDistance then
            return {
                "Features/Guard/Coffin/CoffinGrabber.lua",
            }, "Morgue Staff: collecting a coffin or body"
        end
        if cleanup then
            return {
                "Features/Guard/PlayerModeration/GuardLocalCleanup.lua",
            }, "Game Moderation: cleaning an eliminated target"
        end

        if helper:FindTool({"taser", "stun", "baton", "guard weapon"}) then
            return {
                "Features/Guard/PlayerModeration/GuardLocalModerator.lua",
            }, "Game Moderation: monitoring nearby player targets"
        end

        return {}, "Waiting to identify a nearby guard duty station"
    end,
})
]====],
        [ [====[Features/Farming/PlayerMinigameBot.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end
local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest or {}
local FarmingRuntime = Environment.__SquidNoMoFarmingRuntime
if type(FarmingRuntime) ~= "table"
    or FarmingRuntime.Revision ~= tostring(Manifest.FarmingRuntimeRevision or "")
    or tonumber(FarmingRuntime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    local bundle = Environment.__SquidNoMoSourceBundle
    local source = type(bundle) == "table" and bundle["Features/Farming/FarmingRuntime.lua"] or nil
    if type(source) ~= "string" then
        error("SquidNoMo verified farming runtime is unavailable")
    end
    FarmingRuntime = loadstring(source)()
end

local profiles = {
    ["Red Light, Green Light"] = {
        "Features/Games/RLGL/AutoMove.lua",
    },
    ["Dalgona"] = {
        "Features/Games/Dalgona/AutoCut.lua",
    },
    ["Pentathlon"] = {
        "Features/Games/Pentathlon/Biseokchigi.lua",
        "Features/Games/Pentathlon/Ddakji.lua",
        "Features/Games/Pentathlon/Gonggi.lua",
        "Features/Games/Pentathlon/Jegichagi.lua",
        "Features/Games/Pentathlon/Paengi.lua",
    },
    ["Jump Rope"] = {
        "Features/Games/JumpRope/AutoComplete.lua",
    },
    ["Marbles"] = {
        "Features/Games/Marbles/RingShooter.lua",
    },
    ["Mingle"] = {
        "Features/Games/Mingle/SmartRoom.lua",
    },
    ["Fight Nights"] = {
        "Features/Games/NightBrawls/CombatAura.lua",
    },
    ["Glass Bridge"] = {
        "Features/Games/GlassBridge/AutoComplete.lua",
    },
    ["Rebellion"] = {
        "Features/Games/Rebellion/GuardCombat.lua",
    },
    ["Rock, Paper, Scissors Minus One"] = {
        "Features/Games/RockPaperScissors/AutoPlay.lua",
    },
    ["Sky Squid"] = {
        "Features/Games/SkySquid/AutoPush.lua",
    },
    ["Squid Game"] = {
        "Features/Games/SquidGame/SquidGamePush.lua",
    },
    ["Tug of War"] = {
        "Features/Games/TugOfWar/PerfectTiming.lua",
    },
    ["Escape"] = {
        "Features/Games/Escape/IslandNav.lua",
    },
}

return FarmingRuntime:CreateController({
    Id = "mapped.farming.player_minigame_bot",
    Name = "Player Minigame Farming",
    Description = "Detects the active minigame and runs one conservative automation profile at a time.",
    Interval = 0.8,
    IdleInterval = 1.5,
    Select = function(self, helper, runtime)
        local category = Environment.__SquidNoMoDetectedGame
        if not category then category = runtime:DetectGameCategory() end
        if not category then
            self.ActiveCategory = nil
            return {}, "Waiting to identify the active minigame"
        end

        self.ActiveCategory = category
        if category == "Hide & Seek" then
            local hasKey = helper:FindTool({"key", "keycard"}) ~= nil
            if hasKey then
                return {
                    "Features/Games/HideSeek/AutoPathToExit.lua",
                }, "Hide & Seek: carrying a key, walking to the exit"
            end
            return {
                "Features/Games/HideSeek/AutoGrabKey.lua",
            }, "Hide & Seek: searching for a key"
        end

        local selected = profiles[category]
        if not selected then
            self.ActiveCategory = nil
            return {}, "No stable farming profile is available for " .. tostring(category)
        end

        self.ActiveCategory = category
        return selected, "Auto farming " .. tostring(category)
    end,
})
]====],
        [ [====[Features/FeatureManager.lua]====] ] = [====[--// SquidNoMo live feature registry and loader

local FeatureManager = {}

FeatureManager.Features = {}
FeatureManager.Registry = {}
FeatureManager.Listeners = {}
FeatureManager._nextListenerId = 0
FeatureManager.AutoApplyPerGameEnabled = false
FeatureManager.LightweightModeEnabled = true
FeatureManager.DetectedGameCategory = nil
FeatureManager._gameWatcherOwner = {Enabled = true, Name = "Game mode monitor"}

local validCategories = {
    Safe = true,
    SemiSafe = true,
    Experimental = true,
}

local function Load(Loader, Path)
    if type(Loader.LoadRemote) == "function" then
        return Loader:LoadRemote(Path)
    end
    return loadstring(game:HttpGet(Loader.Config.Repository .. Path))()
end

local function normalizeCategory(category)
    local value = tostring(category or "")
    value = string.gsub(value, "[%s_%-]", "")
    value = string.lower(value)

    if value == "safe" then
        return "Safe"
    elseif value == "semisafe" then
        return "SemiSafe"
    elseif value == "experimental" then
        return "Experimental"
    end

    return nil
end

local function safeFeatureState(entry)
    local feature = entry and entry.Feature
    local options = entry and entry.Options or {}

    local ok, state = pcall(function()
        if type(options.GetState) == "function" then
            return options.GetState(feature, entry)
        end
        if type(feature) == "table" and type(feature.GetState) == "function" then
            return feature:GetState()
        end
        if type(feature) == "table"
            and type(feature.IsPartiallyEnabled) == "function"
            and feature:IsPartiallyEnabled()
        then
            return "partial"
        end
        if type(feature) == "table" and type(feature.IsEnabled) == "function" then
            return feature:IsEnabled() and "on" or "off"
        end
        if type(feature) == "table" then
            if feature.Enabled == true or feature.Active == true then
                return "on"
            end
        end
        return entry and entry.State or "off"
    end)

    if not ok then
        return "off"
    end

    if state == true then
        return "on"
    elseif state == false then
        return "off"
    end

    state = string.lower(tostring(state or "off"))
    if state == "on" or state == "enabled" or state == "fully" or state == "full" then
        return "on"
    elseif state == "partial" or state == "mixed" or state == "partially" then
        return "partial"
    end

    return "off"
end

local function setFeatureEnabled(feature, enabled)
    if type(feature) ~= "table" then
        return false
    end

    local method = enabled and feature.Enable or feature.Disable
    if type(method) == "function" then
        local ok, result = pcall(method, feature)
        return ok and result ~= false
    end

    if type(feature.Toggle) == "function" then
        local ok, result = pcall(
            feature.Toggle,
            feature,
            enabled
        )
        return ok and result ~= false
    end

    return false
end

function FeatureManager:Initialize(Loader)
    self.Loader = Loader
    -- The module can be re-used after a character rebuild, so clear stale entries
    -- before registering the current build's live and catalog features.
    self.Registry = {}

    local Features = {}

    Features.Shared = {}
    Features.Shared.Runtime = Load(Loader, "Features/Shared/Runtime.lua")
    if type(Features.Shared.Runtime.SetLightweightMode) == "function" then
        Features.Shared.Runtime:SetLightweightMode(self.LightweightModeEnabled)
    end
    if type(Features.Shared.Runtime.WarmIndices) == "function" then
        Features.Shared.Runtime:WarmIndices()
    end
    Features.Shared.PlayerRuntime = Load(Loader, "Features/Shared/PlayerRuntime.lua")
    Features.Shared.RoleService = Load(Loader, "Features/Shared/RoleService.lua")
    Loader.Features = Features

    Features.Player = Load(Loader, "Features/Player/Init.lua")
    Features.Player:Initialize(Loader)

    Features.UI = Load(Loader, "Features/UI/Init.lua")
    Features.UI:Initialize(Loader)

    self.Features = Features
    Loader.Features = Features

    if Loader.FeatureCatalog then
        self:RegisterCatalog(Loader.FeatureCatalog)
    end

    self:_EnsureGameWatcher()
    self:Notify()
    return Features
end

function FeatureManager:Get()
    return self.Features
end

function FeatureManager:GetEntry(id)
    return self.Registry[id]
end

function FeatureManager:GetFeature(id)
    local entry = self.Registry[id]
    return entry and entry.Feature or nil
end


function FeatureManager:SetLightweightModeEnabled(state)
    self.LightweightModeEnabled = state ~= false
    local runtime = self.Features and self.Features.Shared and self.Features.Shared.Runtime
    if runtime and type(runtime.SetLightweightMode) == "function" then
        runtime:SetLightweightMode(self.LightweightModeEnabled)
    end
    self:Notify()
    return true
end

function FeatureManager:GetDetectedGameCategory()
    return self.DetectedGameCategory
end

function FeatureManager:_SetDetectedGame(category, score, source)
    if type(category) ~= "string" or category == "" then return false end
    local changed = category ~= self.DetectedGameCategory
    self.DetectedGameCategory = category
    self.DetectedGameScore = tonumber(score) or 0
    self.DetectedGameSource = tostring(source or "visual detector")
    self._lastDetectedAt = os.clock()

    local environment = _G
    if type(getgenv) == "function" then
        local ok, result = pcall(getgenv)
        if ok and type(result) == "table" then environment = result end
    end
    environment.__SquidNoMoDetectedGame = category
    environment.__SquidNoMoDetectedGameAt = os.clock()
    if changed then self:Notify(true) end
    return changed
end

local function hasTransientOwner(entry)
    return type(entry.TransientOwners) == "table" and next(entry.TransientOwners) ~= nil
end

function FeatureManager:SetTransientFeature(id, owner, enabled)
    local entry = self.Registry[id]
    if not entry or owner == nil then return false, "feature or owner is unavailable" end
    entry.TransientOwners = entry.TransientOwners or setmetatable({}, {__mode = "k"})
    if enabled then entry.TransientOwners[owner] = true else entry.TransientOwners[owner] = nil end

    local wanted = entry.DesiredEnabled == true or hasTransientOwner(entry)
    local environment = _G
    if type(getgenv) == "function" then
        local ok, result = pcall(getgenv)
        if ok and type(result) == "table" then environment = result end
    end
    local detectedGame = self.DetectedGameCategory or environment.__SquidNoMoDetectedGame
    local allowed = entry.PageName ~= "Games"
        or not self.AutoApplyPerGameEnabled
        or entry.CategoryName == detectedGame
    local shouldRun = wanted and allowed
    local feature = entry.Feature
    if shouldRun and type(feature) ~= "table" then
        feature = self:LoadCatalogFeature(id)
    end
    if type(feature) == "table" then
        local ok = setFeatureEnabled(feature, shouldRun)
        entry.State = ok and (shouldRun and "on" or "off") or safeFeatureState(entry)
        self:Notify()
        return ok
    end
    entry.State = "off"
    self:Notify()
    return not shouldRun, shouldRun and "feature could not be loaded" or nil
end

function FeatureManager:LoadCatalogFeature(id)
    local entry = self.Registry[id]
    if not entry then return nil, "feature is not registered" end
    if type(entry.Feature) == "table" then return entry.Feature end
    if not entry.Path or not self.Loader then return nil, "feature path is unavailable" end
    local ok, feature = pcall(Load, self.Loader, entry.Path)
    if not ok or type(feature) ~= "table" then
        return nil, tostring(feature or "module did not return a feature table")
    end
    self:AttachCatalogFeature(id, feature)
    return feature
end

function FeatureManager:_ApplyDetectedGame(force)
    if not self.AutoApplyPerGameEnabled then return 0 end
    local runtime = self.Features and self.Features.Shared and self.Features.Shared.Runtime
    if not runtime or type(runtime.DetectGameCategory) ~= "function" then return 0 end

    local detected, detectionScore = runtime:DetectGameCategory()
    local now = os.clock()
    if detected then
        self._lastDetectedAt = now
    elseif self.DetectedGameCategory and now - (self._lastDetectedAt or 0) < 4 then
        detected = self.DetectedGameCategory
    end

    if not detected then
        -- Detection is intentionally conservative. An uncertain/transition state must
        -- never turn off a feature the user enabled manually. Keep the last confirmed
        -- category and currently running features until a different game is positively
        -- identified.
        return 0
    end

    local categoryChanged = detected ~= self.DetectedGameCategory
    if not force and not categoryChanged then return 0 end
    self:_SetDetectedGame(detected, detectionScore, "runtime")

    self.SuppressPersistence = true
    local changed = 0
    for id, entry in pairs(self.Registry) do
        if entry.PageName == "Games" then
            local profileWanted = entry.DesiredEnabled == true or hasTransientOwner(entry)
            local shouldEnable = entry.CategoryName == detected and profileWanted
            local feature = entry.Feature
            if shouldEnable and type(feature) ~= "table" then
                feature = self:LoadCatalogFeature(id)
            end
            if type(feature) == "table" then
                local currentlyEnabled = safeFeatureState(entry) ~= "off"
                if currentlyEnabled ~= shouldEnable and setFeatureEnabled(feature, shouldEnable) then
                    changed = changed + 1
                end
                entry.State = shouldEnable and "on" or "off"
            else
                entry.State = "off"
            end
        end
    end
    self.SuppressPersistence = false
    if changed > 0 or categoryChanged then self:Notify(true) end
    return changed
end

function FeatureManager:_EnsureGameWatcher()
    self._gameWatcherGeneration = (self._gameWatcherGeneration or 0) + 1
    local generation = self._gameWatcherGeneration
    local runtime = self.Features and self.Features.Shared and self.Features.Shared.Runtime
    if not runtime or type(runtime.DetectGameCategory) ~= "function" then return false end

    task.spawn(function()
        while generation == self._gameWatcherGeneration do
            local detected, score = runtime:DetectGameCategory()
            if detected then
                local changed = self:_SetDetectedGame(detected, score, "continuous detector")
                if self.AutoApplyPerGameEnabled then
                    self:_ApplyDetectedGame(changed)
                end
            end
            task.wait(0.42)
        end
    end)
    return true
end

function FeatureManager:SetAutoApplyPerGameEnabled(state)
    self.AutoApplyPerGameEnabled = state == true
    self:_EnsureGameWatcher()
    if self.AutoApplyPerGameEnabled then
        self:_ApplyDetectedGame(true)
    end
    self:Notify()
    return true
end

function FeatureManager:ClearGameProfiles()
    self.SuppressPersistence = true
    local count = 0
    for _, entry in pairs(self.Registry) do
        if entry.PageName == "Games" then
            entry.DesiredEnabled = false
            entry.PendingEnabled = nil
            if type(entry.Feature) == "table" then setFeatureEnabled(entry.Feature, false) end
            entry.State = "off"
            count = count + 1
        end
    end
    self.SuppressPersistence = false
    self:Notify()
    return count
end

function FeatureManager:RegisterFeature(id, feature, options)
    assert(type(id) == "string" and id ~= "", "Feature id is required")
    assert(type(feature) == "table", "Feature table is required")

    options = options or {}
    local category = normalizeCategory(options.Category)
    assert(category and validCategories[category], "Category must be Safe, SemiSafe, or Experimental")

    local previous = self.Registry[id]
    self.Registry[id] = {
        Id = id,
        Name = tostring(options.Name or (previous and previous.Name) or id),
        Category = category,
        Feature = feature,
        Options = options,
        State = previous and previous.State or options.InitialState or "off",
        IsCatalog = previous and previous.IsCatalog or false,
        Path = previous and previous.Path or options.Path,
        Description = options.Description or (previous and previous.Description),
        PendingEnabled = previous and previous.PendingEnabled or nil,
        PageName = options.PageName or (previous and previous.PageName),
        CategoryName = options.CategoryName or (previous and previous.CategoryName),
        DesiredEnabled = previous and previous.DesiredEnabled or options.DesiredEnabled or false,
    }

    if self.Registry[id].PendingEnabled ~= nil then
        local enabled = self.Registry[id].PendingEnabled == true
        if setFeatureEnabled(feature, enabled) then
            self.Registry[id].State = enabled and "on" or "off"
            self.Registry[id].PendingEnabled = nil
        end
    end

    self:Notify()
    return self.Registry[id]
end

function FeatureManager:RegisterCatalogFeature(definition)
    if type(definition) ~= "table" then
        return nil
    end

    local id = tostring(definition.Id or "")
    if id == "" then
        return nil
    end

    local existing = self.Registry[id]
    if existing then
        existing.Name = tostring(definition.Name or existing.Name or id)
        existing.Path = definition.Path or existing.Path
        existing.Description = definition.Description or existing.Description
        existing.PageName = definition.PageName or existing.PageName
        existing.CategoryName = definition.CategoryName or existing.CategoryName
        existing.IsCatalog = true
        return existing
    end

    local category = normalizeCategory(definition.Category) or "Experimental"
    local entry = {
        Id = id,
        Name = tostring(definition.Name or id),
        Category = category,
        Feature = nil,
        Options = {
            Name = definition.Name,
            Category = category,
            Description = definition.Description,
            Path = definition.Path,
        },
        State = "off",
        IsCatalog = true,
        Path = definition.Path,
        Description = definition.Description,
        PageName = definition.PageName,
        CategoryName = definition.CategoryName,
        DesiredEnabled = false,
    }

    self.Registry[id] = entry
    return entry
end

function FeatureManager:RegisterCatalog(catalog)
    if type(catalog) ~= "table" or type(catalog.GetAllFeatures) ~= "function" then
        return 0
    end

    local ok, features = pcall(catalog.GetAllFeatures, catalog)
    if not ok or type(features) ~= "table" then
        return 0
    end

    local count = 0
    for _, definition in ipairs(features) do
        if self:RegisterCatalogFeature(definition) then
            count = count + 1
        end
    end

    return count
end

function FeatureManager:AttachCatalogFeature(id, feature)
    if type(id) ~= "string" or id == "" or type(feature) ~= "table" then
        return false
    end

    local entry = self.Registry[id]
    if not entry then
        entry = self:RegisterCatalogFeature({
            Id = id,
            Name = id,
            Category = "Experimental",
        })
    end

    entry.Feature = feature

    if entry.PendingEnabled ~= nil then
        entry.DesiredEnabled = entry.PendingEnabled == true
        local enabled = entry.DesiredEnabled or hasTransientOwner(entry)
        if self.AutoApplyPerGameEnabled and entry.PageName == "Games" then
            enabled = entry.CategoryName == self.DetectedGameCategory and enabled
        end
        if setFeatureEnabled(feature, enabled) then
            entry.State = enabled and "on" or "off"
            entry.PendingEnabled = nil
        end
    else
        entry.State = safeFeatureState(entry)
    end

    self:Notify()
    return true
end

function FeatureManager:UnregisterFeature(id)
    self.Registry[id] = nil
    self:Notify()
end

function FeatureManager:SetFeatureState(id, state, options)
    local entry = self.Registry[id]
    if not entry then return false end
    options = options or {}
    local enabled = tostring(state or "off"):lower() ~= "off"
    entry.State = enabled and "on" or "off"

    if entry.PageName == "Games" then
        entry.DesiredEnabled = enabled

        -- A direct tap is a manual command, even when Auto Apply per Game is on.
        -- The old behavior only armed the profile and did nothing unless automatic
        -- game detection happened to succeed, which made every toggle appear broken.
        if options.Manual == true then
            local feature = entry.Feature
            if type(feature) ~= "table" then
                feature = self:LoadCatalogFeature(id)
            end
            if type(feature) ~= "table" then
                entry.State = "off"
                self:Notify()
                return false
            end
            local applied = setFeatureEnabled(feature, enabled)
            entry.State = applied and (enabled and "on" or "off") or safeFeatureState(entry)
            if enabled then
                self.ManualGameCategory = entry.CategoryName
                self.ManualGameCategoryAt = os.clock()
            end
            self:Notify()
            return applied
        end

        if self.AutoApplyPerGameEnabled then
            local shouldRun = entry.CategoryName == self.DetectedGameCategory and enabled
            local feature = entry.Feature
            if shouldRun and type(feature) ~= "table" then
                feature = self:LoadCatalogFeature(id)
            end
            if type(feature) == "table" and safeFeatureState(entry) ~= (shouldRun and "on" or "off") then
                setFeatureEnabled(feature, shouldRun)
                entry.State = shouldRun and "on" or "off"
            elseif not shouldRun then
                entry.State = "off"
            end
        end
    end
    self:Notify()
    return true
end

function FeatureManager:SetCategoryEnabled(category, enabled)
    local normalized = normalizeCategory(category)
    if not normalized then
        return 0
    end

    local changed = 0
    for _, entry in pairs(self.Registry) do
        if entry.Category == normalized and type(entry.Feature) == "table" then
            if setFeatureEnabled(entry.Feature, enabled) then
                entry.State = enabled and "on" or "off"
                changed = changed + 1
            end
        end
    end

    self:Notify()
    return changed
end

function FeatureManager:GetLoadedCount()
    local count = 0
    for _, entry in pairs(self.Registry) do
        if type(entry.Feature) == "table" then
            count = count + 1
        end
    end
    return count
end

function FeatureManager:GetTotalCount()
    local count = 0
    for _ in pairs(self.Registry) do
        count = count + 1
    end
    return count
end

function FeatureManager:GetSnapshot()
    local snapshot = {
        FullyOn = 0,
        Partial = 0,
        Off = 0,
        Total = 0,
        Categories = {
            Safe = {Total = 0, On = 0, Partial = 0, Off = 0, State = "empty"},
            SemiSafe = {Total = 0, On = 0, Partial = 0, Off = 0, State = "empty"},
            Experimental = {Total = 0, On = 0, Partial = 0, Off = 0, State = "empty"},
        },
    }

    for _, entry in pairs(self.Registry) do
        local state = safeFeatureState(entry)
        local category = snapshot.Categories[entry.Category]
            or snapshot.Categories.Experimental

        snapshot.Total = snapshot.Total + 1
        category.Total = category.Total + 1

        if state == "on" then
            snapshot.FullyOn = snapshot.FullyOn + 1
            category.On = category.On + 1
        elseif state == "partial" then
            snapshot.Partial = snapshot.Partial + 1
            category.Partial = category.Partial + 1
        else
            snapshot.Off = snapshot.Off + 1
            category.Off = category.Off + 1
        end
    end

    for _, category in pairs(snapshot.Categories) do
        if category.Total == 0 then
            category.State = "empty"
        elseif category.On == category.Total then
            category.State = "on"
        elseif category.Off == category.Total then
            category.State = "off"
        else
            category.State = "partial"
        end
    end

    return snapshot
end

function FeatureManager:Subscribe(callback)
    assert(type(callback) == "function", "Feature listener must be a function")

    self._nextListenerId = self._nextListenerId + 1
    local id = self._nextListenerId
    self.Listeners[id] = callback

    local disconnected = false
    local connection = {}

    function connection:Disconnect()
        if disconnected then
            return
        end
        disconnected = true
        FeatureManager.Listeners[id] = nil
    end

    return connection
end

local function packColor(value)
    if typeof(value) ~= "Color3" then
        return nil
    end
    return {R = value.R, G = value.G, B = value.B}
end

local function unpackColor(value)
    if type(value) ~= "table" then
        return nil
    end

    local r = tonumber(value.R)
    local g = tonumber(value.G)
    local b = tonumber(value.B)
    if not r or not g or not b then
        return nil
    end

    return Color3.new(
        math.clamp(r, 0, 1),
        math.clamp(g, 0, 1),
        math.clamp(b, 0, 1)
    )
end

function FeatureManager:SetPersistenceCallback(callback)
    self.PersistenceCallback =
        type(callback) == "function" and callback or nil
end

function FeatureManager:ExportSettings()
    local result = {}

    for id, entry in pairs(self.Registry) do
        local feature = entry.Feature
        local data = {
            Enabled = safeFeatureState(entry) ~= "off",
            DesiredEnabled = entry.DesiredEnabled == true,
        }

        if type(feature) == "table" and type(feature.Get) == "function" then
            local ok, value = pcall(feature.Get, feature)
            if ok and (
                type(value) == "number"
                or type(value) == "string"
                or type(value) == "boolean"
            ) then
                data.Value = value
            end
        end

        if type(feature) == "table" and type(feature.GetColor) == "function" then
            local ok, color = pcall(feature.GetColor, feature)
            if ok then
                data.Color = packColor(color)
            end
        end

        result[id] = data
    end

    return result
end

function FeatureManager:ApplySettings(saved)
    if type(saved) ~= "table" then
        return 0
    end

    self.SuppressPersistence = true
    local count = 0

    for id, data in pairs(saved) do
        local entry = self.Registry[id]
        if entry and type(data) == "table" then
            local feature = entry.Feature
            local desired = data.DesiredEnabled
            if desired == nil then desired = data.Enabled end
            entry.DesiredEnabled = desired == true
            local enabled = data.Enabled == true
            if self.AutoApplyPerGameEnabled and entry.PageName == "Games" then
                enabled = entry.DesiredEnabled and entry.CategoryName == self.DetectedGameCategory
            end

            if type(feature) == "table" then
                if data.Value ~= nil and type(feature.Set) == "function" then
                    pcall(feature.Set, feature, data.Value)
                end

                local color = unpackColor(data.Color)
                if color and type(feature.SetColor) == "function" then
                    pcall(feature.SetColor, feature, color)
                end

                if setFeatureEnabled(feature, enabled) then
                    entry.State = enabled and "on" or "off"
                    count = count + 1
                end
            elseif entry.IsCatalog then
                -- Catalog features are loaded only when their page button is used.
                -- Preserve the requested state and apply it when the module attaches.
                entry.PendingEnabled = entry.PageName == "Games" and entry.DesiredEnabled or enabled
                entry.State = "off"
            end
        end
    end

    self.SuppressPersistence = false
    self:Notify()
    return count
end

function FeatureManager:ResetAll()
    self.SuppressPersistence = true
    local count = 0

    for _, entry in pairs(self.Registry) do
        local feature = entry.Feature
        local options = entry.Options or {}

        if type(feature) == "table" then
            setFeatureEnabled(feature, false)

            if options.DefaultValue ~= nil and type(feature.Set) == "function" then
                pcall(feature.Set, feature, options.DefaultValue)
            end

            if typeof(options.DefaultColor) == "Color3"
                and type(feature.SetColor) == "function"
            then
                pcall(feature.SetColor, feature, options.DefaultColor)
            end
        end

        entry.PendingEnabled = nil
        entry.DesiredEnabled = false
        entry.State = "off"
        count = count + 1
    end

    self.SuppressPersistence = false
    self:Notify()
    return count
end

function FeatureManager:Notify(skipPersistence)
    local snapshot = self:GetSnapshot()

    for id, callback in pairs(self.Listeners) do
        local ok = pcall(callback, snapshot)
        if not ok then
            self.Listeners[id] = nil
        end
    end

    if not skipPersistence
        and not self.SuppressPersistence
        and type(self.PersistenceCallback) == "function"
    then
        pcall(self.PersistenceCallback, snapshot)
    end
end

return FeatureManager
]====],
        [ [====[Features/Games/Dalgona/AutoCut.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Dalgona",
    Id = "mapped.games.dalgona.autocut",
    Name = "Auto Cut",
    Description = "Automates the cookie carving interaction to help complete the selected shape.",
    Kind = "GuiAction",
    ActionTokens = {"cut", "carve", "trace", "complete", "finish", "tap"},
    ActionCooldown = 0.12,
    ActionPriority = 55,
    Interval = 0.12,
    WaitingMessage = "Waiting for the Dalgona cutting controls",
})
]====],
        [ [====[Features/Games/Dalgona/AutoLighter.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Dalgona",
    Id = "mapped.games.dalgona.autolighter",
    Name = "Auto Lighter",
    Description = "Finds, equips, and repeatedly activates the lighter while enabled.",
    Kind = "ToolActivate",
    ToolTokens = {"lighter", "torch", "flame", "fire"},
    Interval = 0.3,
    ActionPriority = 45,
    WaitingMessage = "Waiting for a lighter tool",
})
]====],
        [ [====[Features/Games/Dalgona/HighlightESP.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Dalgona",
    Id = "mapped.games.dalgona.highlightesp",
    Name = "Shape Highlight",
    Description = "Outlines the cookie shape so the tracing boundary is easier to see.",
    Kind = "GuiHighlight",
    TargetTokens = {"cookie", "shape", "outline", "cut area", "dalgona"},
    Color = Color3.fromRGB(255, 210, 70),
    Thickness = 3,
    WaitingMessage = "Waiting for the Dalgona shape interface",
})
]====],
        [ [====[Features/Games/Dalgona/TraceHelper.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Dalgona",
    Id = "mapped.games.dalgona.tracehelper",
    Name = "Trace Helper",
    Description = "Adds a visual tracing guide that follows the cursor over the cookie shape.",
    Kind = "GuiHighlight",
    TargetTokens = {"trace", "path", "line", "cursor", "needle", "shape"},
    Color = Color3.fromRGB(60, 220, 255),
    Thickness = 4,
    WaitingMessage = "Waiting for a trace path or cursor",
})
]====],
        [ [====[Features/Games/Escape/IslandNav.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Escape",
    Id = "mapped.games.escape.islandnav",
    Name = "Island Extraction Route",
    Description = "Walks toward the detected extraction boat or finish point.",
    Kind = "WalkTo",
    TargetTokens = {"extraction", "escape boat", "boat", "dock", "finish", "exit"},
    ExcludeTokens = {"start boat"},
    TargetClasses = {"Model", "BasePart", "ProximityPrompt"},
    StopDistance = 9,
    MovementPriority = 70,
    Interact = true,
    InteractDistance = 12,
    WaitingMessage = "Waiting for an extraction boat or finish point",
})
]====],
        [ [====[Features/Games/GlassBridge/AntiFall.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Glass Bridge",
    Id = "mapped.games.glass_bridge.antifall",
    Name = "Anti Fall",
    Description = "Stores a recent safe bridge position and recovers after a fall.",
    Kind = "AntiFall",
    DropDistance = 14,
    FallVelocity = 65,
    RecoveryPriority = 85,
})
]====],
        [ [====[Features/Games/GlassBridge/AutoComplete.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Glass Bridge",
    Id = "mapped.games.glass_bridge.autocomplete",
    Name = "Auto Complete",
    Description = "Moves toward detected safe glass tiles in sequence.",
    Kind = "SafeTileWalk",
    MinimumDistance = 2,
    MaximumDistance = 55,
    Interval = 0.32,
    MovementPriority = 75,
    WaitingMessage = "Waiting for Glass Bridge panels",
})
]====],
        [ [====[Features/Games/GlassBridge/AutoReset.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Glass Bridge",
    Id = "mapped.games.glass_bridge.autoreset",
    Name = "Auto Reset",
    Description = "Returns the character to a recovery point after falling below the bridge.",
    Kind = "AntiFall",
    DropDistance = 8,
    FallVelocity = 45,
    RecoveryPriority = 60,
})
]====],
        [ [====[Features/Games/GlassBridge/GlassESP.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Glass Bridge",
    Id = "mapped.games.glass_bridge.glassesp",
    Name = "Glass ESP",
    Description = "Highlights detected safe and unsafe glass panels.",
    Kind = "GlassESP",
    SafeColor = Color3.fromRGB(60, 255, 126),
    UnsafeColor = Color3.fromRGB(255, 80, 90),
    UnknownColor = Color3.fromRGB(255, 210, 70),
    Interval = 0.75,
})
]====],
        [ [====[Features/Games/HideSeek/AutoGrabKey.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Hide & Seek",
    Id = "mapped.games.hide_seek.autograbkey",
    Name = "Auto Grab Key",
    Description = "Finds the nearest key and moves close enough to collect it.",
    Kind = "WalkTo",
    TargetTokens = {"key", "keycard"},
    ExcludeTokens = {"keyboard", "monkey"},
    TargetClasses = {"Tool", "Model", "BasePart", "ProximityPrompt"},
    Interact = true,
    StopDistance = 7,
    InteractDistance = 12,
    SkipIfToolTokens = {"key", "keycard"},
    ExcludeLocalRoleTokens = {"hunter", "seeker", "killer"},
    MovementPriority = 70,
    WaitingMessage = "Waiting for an available Hide & Seek key",
})
]====],
        [ [====[Features/Games/HideSeek/AutoGrabKnife.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Hide & Seek",
    Id = "mapped.games.hide_seek.autograbknife",
    Name = "Auto Grab Knife",
    Description = "Finds the nearest knife and moves close enough to collect it.",
    Kind = "WalkTo",
    TargetTokens = {"knife", "blade", "weapon"},
    TargetClasses = {"Tool", "Model", "BasePart", "ProximityPrompt"},
    Interact = true,
    StopDistance = 7,
    InteractDistance = 12,
    SkipIfToolTokens = {"knife", "blade", "weapon"},
    LocalRoleTokens = {"hunter", "seeker", "killer"},
    MovementPriority = 65,
    WaitingMessage = "Waiting for an available knife",
})
]====],
        [ [====[Features/Games/HideSeek/AutoPathToExit.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Hide & Seek",
    Id = "mapped.games.hide_seek.autopathtoexit",
    Name = "Auto Path to Exit",
    Description = "Uses pathfinding to walk toward the nearest detected exit.",
    Kind = "WalkTo",
    TargetTokens = {"exit", "escape", "gate", "finish door"},
    ExcludeTokens = {"emergency light"},
    TargetClasses = {"Model", "BasePart", "ProximityPrompt"},
    StopDistance = 7,
    Interact = true,
    InteractDistance = 12,
    RequireToolTokens = {"key", "keycard"},
    ExcludeLocalRoleTokens = {"hunter", "seeker", "killer"},
    MovementPriority = 85,
    WaitingMessage = "Waiting for a detected exit",
})
]====],
        [ [====[Features/Games/HideSeek/AutoSwing.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Hide & Seek",
    Id = "mapped.games.hide_seek.autoswing",
    Name = "Auto Swing",
    Description = "Automatically activates the equipped melee tool while enabled.",
    Kind = "ToolAura",
    ToolTokens = {"knife", "bat", "sword", "weapon", "blade"},
    Range = 10,
    FaceTarget = true,
    Interval = 0.24,
    LocalRoleTokens = {"hunter", "seeker", "killer"},
    ActionPriority = 70,
    WaitingMessage = "Waiting for a melee tool and a nearby opponent",
})
]====],
        [ [====[Features/Games/HideSeek/EnemyESP.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Hide & Seek",
    Id = "mapped.games.hide_seek.enemyesp",
    Name = "Enemy ESP",
    Description = "Highlights opposing players so nearby threats are easier to track.",
    Kind = "Highlight",
    PlayerMode = true,
    Color = Color3.fromRGB(255, 82, 100),
    WaitingMessage = "Waiting for opposing players",
})
]====],
        [ [====[Features/Games/HideSeek/ExitESP.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Hide & Seek",
    Id = "mapped.games.hide_seek.exitesp",
    Name = "Exit ESP",
    Description = "Marks detected exits and escape points in the map.",
    Kind = "Highlight",
    TargetTokens = {"exit", "escape", "gate", "finish door"},
    TargetClasses = {"Model", "BasePart"},
    Color = Color3.fromRGB(60, 255, 126),
    WaitingMessage = "Waiting for detected exits",
})
]====],
        [ [====[Features/Games/HideSeek/HunterTracker.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Hide & Seek",
    Id = "mapped.games.hide_seek.huntertracker",
    Name = "Hunter Tracker",
    Description = "Tracks hunters and keeps their location visible during the round.",
    Kind = "Highlight",
    PlayerMode = true,
    PlayerTokens = {"hunter", "seeker", "killer"},
    Color = Color3.fromRGB(255, 70, 70),
    WaitingMessage = "Waiting for a hunter or seeker role",
})
]====],
        [ [====[Features/Games/HideSeek/MapRadar.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Hide & Seek",
    Id = "mapped.games.hide_seek.mapradar",
    Name = "Map Radar",
    Description = "Shows nearby players and important map objects in a compact radar view.",
    Kind = "Radar",
    PlayerColor = Color3.fromRGB(255, 82, 100),
    TargetColor = Color3.fromRGB(60, 255, 126),
    TargetTokens = {"exit", "key", "knife", "door"},
    Range = 180,
    Title = "HIDE & SEEK RADAR",
})
]====],
        [ [====[Features/Games/JumpRope/AutoComplete.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Jump Rope",
    Id = "mapped.games.jump_rope.autocomplete",
    Name = "Auto Complete",
    Description = "Coordinates movement and jumps to progress across the rope course.",
    Kind = "CourseAssist",
    TargetTokens = {"finish", "end", "goal", "exit", "other side", "checkpoint"},
    ObstacleTokens = {"rope", "swing", "bar", "spinner", "sweep"},
    JumpDistance = 17,
    MovementPriority = 70,
    WaitingMessage = "Waiting for the Jump Rope course",
})
]====],
        [ [====[Features/Games/JumpRope/AutoJump.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Jump Rope",
    Id = "mapped.games.jump_rope.autojump",
    Name = "Auto Jump",
    Description = "Triggers jumps automatically as the rope approaches.",
    Kind = "AutoJump",
    TargetTokens = {"rope", "swing", "bar", "spinner", "sweep"},
    TriggerDistance = 17,
    Interval = 0.10,
})
]====],
        [ [====[Features/Games/JumpRope/AutoPosition.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Jump Rope",
    Id = "mapped.games.jump_rope.autoposition",
    Name = "Auto Position",
    Description = "Keeps the character aligned with the preferred jumping position.",
    Kind = "PositionKeeper",
    MaxDistance = 7,
    Interval = 0.22,
    MovementPriority = 25,
})
]====],
        [ [====[Features/Games/JumpRope/JumpBoost.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Jump Rope",
    Id = "mapped.games.jump_rope.jumpboost",
    Name = "Jump Boost",
    Description = "Temporarily increases jump strength for the rope sequence.",
    Kind = "JumpBoost",
    JumpPower = 78,
    JumpHeight = 13,
    Interval = 0.35,
})
]====],
        [ [====[Features/Games/Marbles/MarbleAimer.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Marbles",
    Id = "mapped.games.marbles.marbleaimer",
    Name = "Marble Aimer",
    Description = "Adds aiming assistance for more consistent marble throws.",
    Kind = "AimActivate",
    TargetTokens = {"ring", "target", "hole", "goal"},
    ToolTokens = {"marble", "ball"},
    Range = 140,
    Interval = 0.20,
    ActionPriority = 60,
    WaitingMessage = "Waiting for a marble and a target",
})
]====],
        [ [====[Features/Games/Marbles/MarblesESP.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Marbles",
    Id = "mapped.games.marbles.marblesesp",
    Name = "Marbles ESP",
    Description = "Highlights marbles, targets, and useful round objects.",
    Kind = "Highlight",
    TargetTokens = {"marble", "ring", "target", "hole"},
    TargetClasses = {"Tool", "Model", "BasePart"},
    Color = Color3.fromRGB(60, 220, 255),
    WaitingMessage = "Waiting for marble targets",
})
]====],
        [ [====[Features/Games/Marbles/RecoveryAssist.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Marbles",
    Id = "mapped.games.marbles.recoveryassist",
    Name = "Recovery Assist",
    Description = "Helps recover the aiming position after a missed marble throw.",
    Kind = "PositionKeeper",
    MaxDistance = 9,
    Interval = 0.25,
})
]====],
        [ [====[Features/Games/Marbles/RingShooter.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Marbles",
    Id = "mapped.games.marbles.ringshooter",
    Name = "Ring Shooter",
    Description = "Assists with lining up and firing marbles toward ring targets.",
    Kind = "AimActivate",
    TargetTokens = {"ring", "hoop", "hole", "target"},
    ToolTokens = {"marble", "ball"},
    Range = 160,
    Interval = 0.20,
    ActionPriority = 75,
    WaitingMessage = "Waiting for a ring target and marble tool",
})
]====],
        [ [====[Features/Games/Mingle/AutoRoom.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Mingle",
    Id = "mapped.games.mingle.autoroom",
    Name = "Auto Room",
    Description = "Automatically moves toward a room that matches the current player count.",
    Kind = "RoomAssist",
    Interact = true,
    Interval = 0.4,
    MovementPriority = 55,
})
]====],
        [ [====[Features/Games/Mingle/RoomESP.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Mingle",
    Id = "mapped.games.mingle.roomesp",
    Name = "Room ESP",
    Description = "Highlights available rooms and displays useful room information.",
    Kind = "Highlight",
    TargetTokens = {"room", "door", "mingle", "enter room", "join room"},
    TargetClasses = {"Model", "BasePart"},
    Color = Color3.fromRGB(60, 220, 255),
    WaitingMessage = "Waiting for Mingle rooms",
})
]====],
        [ [====[Features/Games/Mingle/SmartRoom.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Mingle",
    Id = "mapped.games.mingle.smartroom",
    Name = "Smart Room",
    Description = "Chooses a suitable room based on occupancy and nearby players.",
    Kind = "RoomAssist",
    Interact = true,
    Interval = 0.32,
    MovementPriority = 75,
})
]====],
        [ [====[Features/Games/NightBrawls/BrawlESP.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Fight Nights",
    Id = "mapped.games.fight_nights.brawlesp",
    Name = "Brawl ESP",
    Description = "Highlights nearby opponents during night-fight rounds.",
    Kind = "Highlight",
    PlayerMode = true,
    Color = Color3.fromRGB(255, 70, 92),
    WaitingMessage = "Waiting for night-brawl opponents",
})
]====],
        [ [====[Features/Games/NightBrawls/BrawlEvasion.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Fight Nights",
    Id = "mapped.games.fight_nights.brawlevasion",
    Name = "Brawl Evasion",
    Description = "Keeps distance from nearby attackers and dangerous positions.",
    Kind = "Evasion",
    Range = 24,
    EvadeDistance = 20,
    Interval = 0.24,
    MovementPriority = 75,
})
]====],
        [ [====[Features/Games/NightBrawls/CombatAura.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Fight Nights",
    Id = "mapped.games.fight_nights.combataura",
    Name = "Combat Aura",
    Description = "Automatically uses the equipped combat tool on nearby valid targets.",
    Kind = "ToolAura",
    ToolTokens = {"bat", "bottle", "knife", "weapon", "fist"},
    Range = 10,
    FaceTarget = true,
    Interval = 0.22,
    ActionPriority = 65,
})
]====],
        [ [====[Features/Games/Pentathlon/Biseokchigi.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Pentathlon",
    Id = "mapped.games.pentathlon.biseokchigi",
    Name = "Biseokchigi Assist",
    Description = "Automates the timing and interaction used for the Biseokchigi event.",
    Kind = "Timing",
    IndicatorTokens = {"indicator", "power", "cursor", "needle"},
    ZoneTokens = {"target", "sweet spot", "green", "hit zone"},
    ActionTokens = {"throw", "hit", "biseok", "play"},
    ClickActionWhenVisible = true,
    ActionCooldown = 0.25,
    ActionPriority = 85,
    WaitingMessage = "Waiting for the Biseokchigi timing interface",
})
]====],
        [ [====[Features/Games/Pentathlon/Ddakji.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Pentathlon",
    Id = "mapped.games.pentathlon.ddakji",
    Name = "Ddakji Assist",
    Description = "Helps perform the Ddakji action with consistent timing.",
    Kind = "Timing",
    IndicatorTokens = {"indicator", "power", "cursor", "needle"},
    ZoneTokens = {"target", "sweet spot", "green", "flip zone"},
    ActionTokens = {"throw", "flip", "ddakji", "play"},
    ClickActionWhenVisible = true,
    ActionCooldown = 0.25,
    ActionPriority = 85,
    WaitingMessage = "Waiting for the Ddakji timing interface",
})
]====],
        [ [====[Features/Games/Pentathlon/Gonggi.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Pentathlon",
    Id = "mapped.games.pentathlon.gonggi",
    Name = "Gonggi Assist",
    Description = "Automates the repeated inputs needed for the Gonggi event.",
    Kind = "GuiAction",
    ActionTokens = {"catch", "throw", "gonggi", "tap", "next"},
    ActionCooldown = 0.12,
    ActionPriority = 65,
    Interval = 0.12,
    WaitingMessage = "Waiting for the Gonggi action controls",
})
]====],
        [ [====[Features/Games/Pentathlon/Jegichagi.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Pentathlon",
    Id = "mapped.games.pentathlon.jegichagi",
    Name = "Jegichagi Assist",
    Description = "Keeps the Jegichagi sequence going with automatic timed inputs.",
    Kind = "Timing",
    IndicatorTokens = {"indicator", "timing", "cursor", "ball"},
    ZoneTokens = {"target", "sweet spot", "green", "kick zone"},
    ActionTokens = {"kick", "jegi", "tap"},
    ClickActionWhenVisible = true,
    ActionCooldown = 0.18,
    ActionPriority = 85,
    WaitingMessage = "Waiting for the Jegichagi timing interface",
})
]====],
        [ [====[Features/Games/Pentathlon/Paengi.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Pentathlon",
    Id = "mapped.games.pentathlon.paengi",
    Name = "Paengi Assist",
    Description = "Automates the spin interaction for the Paengi event.",
    Kind = "Timing",
    IndicatorTokens = {"indicator", "power", "cursor", "spin"},
    ZoneTokens = {"target", "sweet spot", "green", "spin zone"},
    ActionTokens = {"spin", "pull", "paengi", "play"},
    ClickActionWhenVisible = true,
    ActionCooldown = 0.22,
    ActionPriority = 85,
    WaitingMessage = "Waiting for the Paengi timing interface",
})
]====],
        [ [====[Features/Games/RLGL/AntiStuck.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Red Light, Green Light",
    Id = "mapped.games.red_light_green_light.antistuck",
    Name = "Anti Stuck",
    Description = "Detects stalled movement and helps the character recover during the round.",
    Kind = "AntiStuck",
    Interval = 0.35,
    StuckSeconds = 2.2,
    MinimumMovement = 0.3,
    RecoveryDistance = 5,
    IdleInterval = 0.8,
})
]====],
        [ [====[Features/Games/RLGL/AutoMove.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Red Light, Green Light",
    Id = "mapped.games.red_light_green_light.automove",
    Name = "Auto Move",
    Description = "Moves on green light and stops automatically when the doll changes to red.",
    Kind = "RLGLAutoMove",
    TargetTokens = {"finish", "safe zone", "end zone", "goal"},
    Interval = 0.10,
    MovementPriority = 95,
    IdleInterval = 0.65,
    WaitingMessage = "Waiting for the RLGL status and finish area",
})
]====],
        [ [====[Features/Games/RLGL/DollESP.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Red Light, Green Light",
    Id = "mapped.games.red_light_green_light.dollesp",
    Name = "Doll ESP",
    Description = "Highlights the doll so its position stays visible from anywhere on the field.",
    Kind = "Highlight",
    TargetTokens = {"doll", "younghee", "young hee", "mugunghwa", "robot"},
    TargetClasses = {"Model", "BasePart"},
    Color = Color3.fromRGB(255, 80, 110),
    WaitingMessage = "Waiting for the RLGL doll",
})
]====],
        [ [====[Features/Games/RLGL/SafeZoneESP.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Red Light, Green Light",
    Id = "mapped.games.red_light_green_light.safezoneesp",
    Name = "Safe Zone ESP",
    Description = "Marks safe areas and the finish zone to make the route easier to read.",
    Kind = "Highlight",
    TargetTokens = {"safe zone", "finish", "end zone", "goal"},
    ExcludeTokens = {"start", "spawn"},
    TargetClasses = {"Model", "BasePart"},
    Color = Color3.fromRGB(60, 255, 126),
    WaitingMessage = "Waiting for the finish or safe zone",
})
]====],
        [ [====[Features/Games/RLGL/StateESP.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Red Light, Green Light",
    Id = "mapped.games.red_light_green_light.stateesp",
    Name = "State ESP",
    Description = "Shows the current red-light or green-light state directly on screen.",
    Kind = "StateHUD",
    TargetTokens = {"status", "light", "red", "green", "stop", "go"},
    Interval = 0.12,
})
]====],
        [ [====[Features/Games/Rebellion/FrontmanNavigator.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Rebellion",
    Id = "mapped.games.rebellion.frontmannavigator",
    Name = "Frontman Navigator",
    Description = "Guides the character toward the detected Frontman objective.",
    Kind = "WalkTo",
    TargetTokens = {"frontman", "front man", "command", "control room", "host"},
    TargetClasses = {"Model", "BasePart", "ProximityPrompt"},
    StopDistance = 10,
    MovementPriority = 60,
    WaitingMessage = "Waiting for the Frontman objective",
})
]====],
        [ [====[Features/Games/Rebellion/GuardCombat.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Rebellion",
    Id = "mapped.games.rebellion.guardcombat",
    Name = "Guard Combat",
    Description = "Automatically engages nearby guard targets with the equipped tool.",
    Kind = "ToolAura",
    PlayerTokens = {"guard", "staff", "soldier"},
    TargetTokens = {"guard", "staff", "soldier"},
    IncludeNPCs = true,
    ToolTokens = {"gun", "rifle", "pistol", "bat", "weapon"},
    Range = 16,
    FaceTarget = true,
    Interval = 0.22,
    ActionPriority = 70,
})
]====],
        [ [====[Features/Games/RockPaperScissors/AutoPlay.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Rock, Paper, Scissors Minus One",
    Id = "mapped.games.rock_paper_scissors_minus_one.autoplay",
    Name = "Auto Play",
    Description = "Automatically selects and submits choices for each RPS Minus One round.",
    Kind = "RPSAutoPlay",
    Interval = 0.35,
})
]====],
        [ [====[Features/Games/SkySquid/AntiFall.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Sky Squid",
    Id = "mapped.games.sky_squid.antifall",
    Name = "Anti Fall",
    Description = "Attempts to recover the character before a fall eliminates them.",
    Kind = "AntiFall",
    DropDistance = 12,
    FallVelocity = 60,
    RecoveryPriority = 75,
})
]====],
        [ [====[Features/Games/SkySquid/AutoFight.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Sky Squid",
    Id = "mapped.games.sky_squid.autofight",
    Name = "Auto Fight",
    Description = "Automatically attacks nearby valid opponents with the equipped tool.",
    Kind = "ToolAura",
    ToolTokens = {"knife", "pole", "bat", "weapon", "push"},
    Range = 11,
    FaceTarget = true,
    Interval = 0.22,
    ActionPriority = 60,
})
]====],
        [ [====[Features/Games/SkySquid/AutoPush.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Sky Squid",
    Id = "mapped.games.sky_squid.autopush",
    Name = "Auto Push",
    Description = "Uses the push action when an opponent enters range.",
    Kind = "ToolAura",
    ToolTokens = {"push", "shove"},
    Range = 12,
    FaceTarget = true,
    Interval = 0.24,
    ActionPriority = 75,
})
]====],
        [ [====[Features/Games/SkySquid/InstantGrab.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Sky Squid",
    Id = "mapped.games.sky_squid.instantgrab",
    Name = "Instant Grab",
    Description = "Quickly collects nearby weapons, poles, and usable tools.",
    Kind = "Interact",
    TargetTokens = {"weapon", "pole", "knife", "tool", "bat"},
    ExcludeTokens = {"owned", "inventory"},
    TargetClasses = {"Tool", "Model", "BasePart", "ProximityPrompt"},
    MaxDistance = 45,
    Walk = true,
    InteractDistance = 11,
    ActionCooldown = 0.45,
    WaitingMessage = "Waiting for a nearby usable item",
})
]====],
        [ [====[Features/Games/SquidGame/CourtBoundaryKeeper.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Squid Game",
    Id = "mapped.games.squid_game.courtboundarykeeper",
    Name = "Court Boundary Keeper",
    Description = "Helps keep the character inside the active Squid Game court.",
    Kind = "Boundary",
    TargetTokens = {"court", "squid game", "arena", "play area", "field"},
    Radius = 58,
    Interval = 0.28,
    MovementPriority = 70,
    WaitingMessage = "Waiting for the Squid Game court",
})
]====],
        [ [====[Features/Games/SquidGame/SquidGamePush.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Squid Game",
    Id = "mapped.games.squid_game.squidgamepush",
    Name = "Squid Game Push",
    Description = "Automatically uses the push tool against nearby opponents.",
    Kind = "ToolAura",
    ToolTokens = {"push", "shove"},
    Range = 12,
    FaceTarget = true,
    Interval = 0.24,
    ActionPriority = 70,
})
]====],
        [ [====[Features/Games/TugOfWar/AutoPull.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Tug of War",
    Id = "mapped.games.tug_of_war.autopull",
    Name = "Auto Pull",
    Description = "Repeats the pull input automatically throughout Tug of War.",
    Kind = "GuiAction",
    ActionTokens = {"pull", "tug", "tap", "rope"},
    ActionCooldown = 0.08,
    ActionPriority = 40,
    Interval = 0.09,
    WaitingMessage = "Waiting for the Tug of War pull control",
})
]====],
        [ [====[Features/Games/TugOfWar/PerfectTiming.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    ExpectedGame = "Tug of War",
    Id = "mapped.games.tug_of_war.perfect_timing",
    Name = "Perfect Timing",
    Description = "Times pull inputs around the strongest part of the tug sequence.",
    Kind = "Timing",
    IndicatorTokens = {"indicator", "cursor", "needle", "power"},
    ZoneTokens = {"sweet spot", "green", "target", "perfect"},
    ActionTokens = {"pull", "tug", "tap"},
    ActionCooldown = 0.14,
    ActionPriority = 90,
    WaitingMessage = "Waiting for the Tug of War timing meter",
})
]====],
        [ [====[Features/Guard/Coffin/CoffinDisposal.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    Id = "mapped.guards.morgue_staff.coffindisposal",
    Name = "Coffin Disposal",
    Description = "Carries detected coffin or body tools toward the disposal area.",
    Kind = "TaskChain",
    RequireToolTokens = {"coffin", "body", "corpse"},
    SourceTokens = {"coffin", "body", "corpse"},
    DestinationTokens = {"dispose", "disposal", "incinerator", "furnace", "burn", "drop", "cremate", "place coffin"},
    SourceLabel = "coffin or body",
    DestinationLabel = "disposal area",
    InteractDistance = 12,
    ActionCooldown = 0.9,
    MovementPriority = 80,
    ActionPriority = 75,
})
]====],
        [ [====[Features/Guard/Coffin/CoffinGrabber.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    Id = "mapped.guards.morgue_staff.coffingrabber",
    Name = "Coffin Grabber",
    Description = "Finds and collects the nearest available coffin or body target.",
    Kind = "Interact",
    TargetTokens = {"coffin", "body", "corpse", "grab coffin", "pick up body", "collect body", "grab", "take", "carry", "pickup"},
    ExcludeTokens = {"disposal", "incinerator"},
    TargetClasses = {"Tool", "Model", "BasePart", "ProximityPrompt"},
    MaxDistance = 55,
    Walk = true,
    InteractDistance = 12,
    ActionCooldown = 0.7,
    MovementPriority = 55,
    ActionPriority = 55,
    WaitingMessage = "Waiting for an available coffin or body",
})
]====],
        [ [====[Features/Guard/Kitchen/AutoCooker.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    Id = "mapped.guards.kitchen_staff.autocooker",
    Name = "Auto Cooker",
    Description = "Finds raw supplies, equips them, and assists with nearby cooking stations.",
    Kind = "TaskChain",
    RequireToolTokens = {"raw", "ingredient", "food", "meat"},
    SourceTokens = {"raw", "ingredient", "supply", "food", "collect", "pick up"},
    DestinationTokens = {"cook", "stove", "oven", "grill", "pan", "place ingredient", "start cooking"},
    SourceLabel = "raw kitchen supply",
    DestinationLabel = "cooking station",
    InteractDistance = 11,
    ActionCooldown = 0.8,
    MovementPriority = 75,
    ActionPriority = 70,
})
]====],
        [ [====[Features/Guard/Kitchen/AutoStorage.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    Id = "mapped.guards.kitchen_staff.autostorage",
    Name = "Auto Storage",
    Description = "Moves cooked food into detected storage or delivery stations.",
    Kind = "TaskChain",
    RequireToolTokens = {"cooked", "meal", "food", "tray"},
    SourceTokens = {"cooked", "meal", "tray", "collect meal", "pick up tray"},
    DestinationTokens = {"storage", "shelf", "delivery", "counter", "serve", "place food", "deliver meal", "submit tray"},
    SourceLabel = "cooked food",
    DestinationLabel = "storage or delivery station",
    InteractDistance = 11,
    ActionCooldown = 0.8,
    MovementPriority = 85,
    ActionPriority = 80,
})
]====],
        [ [====[Features/Guard/Kitchen/AutoSupply.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    Id = "mapped.guards.kitchen_staff.autosupply",
    Name = "Auto Supply",
    Description = "Collects nearby kitchen supplies when inventory space is available.",
    Kind = "Interact",
    TargetTokens = {"supply", "ingredient", "raw", "food", "crate", "collect", "pick up", "take supply", "grab", "take", "pickup", "pick up ingredient"},
    ExcludeTokens = {"cooked", "empty"},
    TargetClasses = {"Tool", "Model", "BasePart", "ProximityPrompt"},
    MaxDistance = 50,
    Walk = true,
    InteractDistance = 11,
    ActionCooldown = 0.6,
    MovementPriority = 50,
    ActionPriority = 50,
    WaitingMessage = "Waiting for kitchen supplies",
})
]====],
        [ [====[Features/Guard/PlayerModeration/GuardLocalCleanup.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    Id = "mapped.guards.game_moderation.guardlocalcleanup",
    Name = "Guard Local Cleanup",
    Description = "Locally clears nearby eliminated bodies and cleanup targets during guard duty.",
    Kind = "Interact",
    TargetTokens = {"body", "dead", "eliminated", "cleanup", "coffin", "remove body", "dispose body", "collect body", "grab body"},
    ExcludeTokens = {"alive"},
    TargetClasses = {"Model", "BasePart", "ProximityPrompt"},
    MaxDistance = 55,
    Walk = true,
    InteractDistance = 12,
    ActionCooldown = 0.55,
    WaitingMessage = "Waiting for a nearby cleanup target",
})
]====],
        [ [====[Features/Guard/PlayerModeration/GuardLocalModerator.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local Runtime = Environment.__SquidNoMoFeatureRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= tostring(Manifest.FeatureRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo verified feature runtime is unavailable; execute the complete current build")
end

return Runtime:CreateFeature({
    Id = "mapped.guards.game_moderation.guardlocalmoderator",
    Name = "Guard Local Moderator",
    Description = "Assists with nearby guard moderation targets while avoiding unsupported rounds.",
    Kind = "ToolAura",
    PlayerTokens = {},
    ExcludePlayerTokens = {"guard", "staff", "detective", "frontman"},
    ToolTokens = {"taser", "stun", "baton", "guard", "weapon"},
    Range = 12,
    FaceTarget = true,
    Interval = 0.22,
})
]====],
        [ [====[Features/Player/AntiAFK.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.anti_afk",
    Name = "Anti AFK",
    Description = "Listens for Roblox idle events and sends a harmless local input to prevent an idle disconnect when supported.",
    Kind = "AntiAFK",
})
]====],
        [ [====[Features/Player/AntiLag.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.anti_lag",
    Name = "Anti Lag",
    Description = "Temporarily disables expensive particles, beams, trails, and post-processing effects, then restores them when disabled.",
    Kind = "AntiLag",
    Interval = 1.2,
})
]====],
        [ [====[Features/Player/AutoJump.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.auto_jump",
    Name = "Auto Jump",
    Description = "Automatically jumps whenever the local character is moving on the ground.",
    Kind = "AutoJump",
    Interval = 0.08,
})
]====],
        [ [====[Features/Player/AutoPickUpBaby.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.auto_pickup_baby",
    Name = "Auto Pick Up Baby",
    Description = "Automatically collects the nearby Baby objective when a supported pickup prompt, click target, tool, or touch pickup appears.",
    Kind = "PickupTarget",
    TargetTokens = {
        "baby", "newborn", "infant", "player 222", "222 baby",
        "pick up baby", "pickup baby", "grab baby", "carry baby",
        "take baby", "baby carrier"
    },
    HeldTokens = {
        "baby", "newborn", "infant", "player 222", "baby carrier"
    },
    ExcludeTokens = {
        "baby shop", "baby skin", "baby icon", "baby reward", "baby pass"
    },
    MaxDistance = 30,
    Interval = 0.35,
    IdleInterval = 1.1,
    ActionCooldown = 0.8,
    WaitingMessage = "Waiting for a nearby Baby pickup",
})
]====],
        [ [====[Features/Player/AutoStand.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.auto_stand",
    Name = "Auto Stand",
    Description = "Automatically clears sitting and platform-stand states so the local character can recover movement.",
    Kind = "AutoStand",
})
]====],
        [ [====[Features/Player/BoxESP.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.box_esp",
    Name = "Box ESP",
    Description = "Draws a clean always-visible outline around every other living player.",
    Kind = "PlayerHighlight",
    OutlineOnly = true,
    DefaultColor = Color3.fromRGB(255, 210, 60),
    OutlineColor = Color3.fromRGB(255, 210, 60),
})
]====],
        [ [====[Features/Player/DetectiveESP.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.detective_esp",
    Name = "Detective ESP",
    Description = "Highlights players whose team, role, attributes, or character identify them as detectives or investigators.",
    Kind = "PlayerHighlight",
    RoleTokens = {"detective", "investigator", "police"},
    DefaultColor = Color3.fromRGB(0, 230, 150),
    FillTransparency = 0.48,
})
]====],
        [ [====[Features/Player/DistanceESP.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.distance_esp",
    Name = "Distance ESP",
    Description = "Displays each other player’s live distance above their character.",
    Kind = "PlayerBillboard",
    Mode = "Distance",
    DefaultColor = Color3.fromRGB(0, 205, 255),
    Interval = 0.32,
})
]====],
        [ [====[Features/Player/ForceThirdPerson.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.force_third_person",
    Name = "Force Third Person",
    Description = "Keeps the local camera in a readable third-person range and restores the previous camera settings when disabled.",
    Kind = "ForceThirdPerson",
    MinZoom = 6,
    MaxZoom = 24,
})
]====],
        [ [====[Features/Player/FrontmanESP.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.frontman_esp",
    Name = "Frontman ESP",
    Description = "Highlights players whose role data identifies them as the Frontman, host, or game master.",
    Kind = "PlayerHighlight",
    RoleTokens = {"frontman", "front man", "host", "gamemaster", "game master"},
    DefaultColor = Color3.fromRGB(172, 76, 255),
    FillTransparency = 0.45,
})
]====],
        [ [====[Features/Player/Gravity.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.gravity",
    Name = "Gravity",
    Description = "Applies the selected local Workspace gravity value while enabled and restores the previous value when disabled.",
    Kind = "WorkspaceValue",
    Property = "Gravity",
    EnabledValue = 120,
    DefaultValue = 196.2,
    Min = 20,
    Max = 300,
    Interval = 0.2,
})
]====],
        [ [====[Features/Player/GuardESP.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.guard_esp",
    Name = "Guard ESP",
    Description = "Highlights players whose team, role, attributes, or character identify them as guards or staff.",
    Kind = "PlayerHighlight",
    RoleTokens = {"guard", "staff", "soldier", "worker"},
    DefaultColor = Color3.fromRGB(235, 55, 70),
    FillTransparency = 0.48,
})
]====],
        [ [====[Features/Player/HealthESP.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.health_esp",
    Name = "Health ESP",
    Description = "Displays each other player’s current and maximum health above their character.",
    Kind = "PlayerBillboard",
    Mode = "Health",
    DefaultColor = Color3.fromRGB(255, 82, 82),
    Interval = 0.32,
})
]====],
        [ [====[Features/Player/HideOthers.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.hide_others",
    Name = "Hide Other Players",
    Description = "Hides every other character locally without changing them for the server or other players.",
    Kind = "HideCharacters",
    Mode = "Others",
    Interval = 0.35,
})
]====],
        [ [====[Features/Player/HideSelf.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.hide_self",
    Name = "Hide Local Character",
    Description = "Hides the local character only on this client and restores every original transparency value when disabled.",
    Kind = "HideCharacters",
    Mode = "Self",
    Interval = 0.25,
})
]====],
        [ [====[Features/Player/InfiniteJump.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.infinite_jump",
    Name = "Infinite Jump",
    Description = "Allows another jump request while the character is airborne.",
    Kind = "InfiniteJump",
})
]====],
        [ [====[Features/Player/Init.lua]====] ] = [====[-- SquidNoMo player module registry
-- Every file under Features/Player is loaded and registered here.

local Player = {}

function Player:Initialize(Loader)
    local function LoadPath(path)
        if type(Loader.LoadRemote) == "function" then
            return Loader:LoadRemote(path)
        end
        return loadstring(game:HttpGet(Loader.Config.Repository .. path))()
    end

    local function Load(name)
        return LoadPath("Features/Player/" .. name .. ".lua")
    end

    -- Load shared implementations first so every player wrapper resolves the
    -- same runtime instance instead of creating duplicate event loops.
    self.Runtime = Loader.Features
        and Loader.Features.Shared
        and Loader.Features.Shared.PlayerRuntime
        or LoadPath("Features/Shared/PlayerRuntime.lua")

    self.WalkSpeed = Load("WalkSpeed")
    self.JumpPower = Load("JumpPower")
    self.Gravity = Load("Gravity")
    self.InfiniteJump = Load("InfiniteJump")
    self.AutoJump = Load("AutoJump")
    self.Noclip = Load("NoClip")
    self.ForceThirdPerson = Load("ForceThirdPerson")
    self.UnlockZoom = Load("UnlockZoom")
    self.AutoStand = Load("AutoStand")

    self.PlayerESP = Load("PlayerESP")
    self.GuardESP = Load("GuardESP")
    self.DetectiveESP = Load("DetectiveESP")
    self.FrontmanESP = Load("FrontmanESP")
    self.DistanceESP = Load("DistanceESP")
    self.HealthESP = Load("HealthESP")
    self.NameESP = Load("NameESP")
    self.BoxESP = Load("BoxESP")

    self.AntiAFK = Load("AntiAFK")
    self.AntiLag = Load("AntiLag")
    self.HideOthers = Load("HideOthers")
    self.HideSelf = Load("HideSelf")
    self.ToolESP = Load("ToolESP")
    self.AutoPickUpBaby = Load("AutoPickUpBaby")
    self.MuteCharacterSounds = Load("MuteCharacterSounds")
    self.Reset = Load("Reset")
    self.Rejoin = Load("Rejoin")

    for _, feature in pairs(self) do
        if type(feature) == "table" and type(feature.Initialize) == "function" then
            pcall(feature.Initialize, feature, Loader)
        end
    end

    local manager = Loader.FeatureManager
    if not manager or type(manager.RegisterFeature) ~= "function" then
        return self
    end

    local function Register(id, feature, options)
        options = options or {}
        options.Description = options.Description or feature.Description
        manager:RegisterFeature(id, feature, options)
    end

    Register("player.walk_speed", self.WalkSpeed, {
        Name = "Walk Speed", Category = "SemiSafe", DefaultValue = 16,
    })
    Register("player.jump_power", self.JumpPower, {
        Name = "Jump Power", Category = "SemiSafe", DefaultValue = 50,
    })
    Register("player.gravity", self.Gravity, {
        Name = "Gravity", Category = "SemiSafe", DefaultValue = 196.2,
    })
    Register("player.infinite_jump", self.InfiniteJump, {
        Name = "Infinite Jump", Category = "SemiSafe",
    })
    Register("player.auto_jump", self.AutoJump, {
        Name = "Auto Jump", Category = "SemiSafe",
    })
    Register("player.noclip", self.Noclip, {
        Name = "Noclip", Category = "Experimental",
    })
    Register("player.force_third_person", self.ForceThirdPerson, {
        Name = "Force Third Person", Category = "Safe",
    })
    Register("player.unlock_zoom", self.UnlockZoom, {
        Name = "Unlock Camera Zoom", Category = "Safe",
    })
    Register("player.auto_stand", self.AutoStand, {
        Name = "Auto Stand", Category = "Safe",
    })

    Register("player.player_esp", self.PlayerESP, {
        Name = "Player ESP", Category = "Safe", DefaultColor = Color3.fromRGB(0, 170, 255),
    })
    Register("player.guard_esp", self.GuardESP, {
        Name = "Guard ESP", Category = "Safe", DefaultColor = Color3.fromRGB(235, 55, 70),
    })
    Register("player.detective_esp", self.DetectiveESP, {
        Name = "Detective ESP", Category = "Safe", DefaultColor = Color3.fromRGB(0, 230, 150),
    })
    Register("player.frontman_esp", self.FrontmanESP, {
        Name = "Frontman ESP", Category = "Safe", DefaultColor = Color3.fromRGB(172, 76, 255),
    })
    Register("player.distance_esp", self.DistanceESP, {
        Name = "Distance ESP", Category = "Safe", DefaultColor = Color3.fromRGB(0, 205, 255),
    })
    Register("player.health_esp", self.HealthESP, {
        Name = "Health ESP", Category = "Safe", DefaultColor = Color3.fromRGB(255, 82, 82),
    })
    Register("player.name_esp", self.NameESP, {
        Name = "Name ESP", Category = "Safe", DefaultColor = Color3.fromRGB(245, 245, 255),
    })
    Register("player.box_esp", self.BoxESP, {
        Name = "Box ESP", Category = "Safe", DefaultColor = Color3.fromRGB(255, 210, 60),
    })

    Register("player.anti_afk", self.AntiAFK, {
        Name = "Anti AFK", Category = "Safe",
    })
    Register("player.anti_lag", self.AntiLag, {
        Name = "Anti Lag", Category = "Safe",
    })
    Register("player.hide_others", self.HideOthers, {
        Name = "Hide Other Players", Category = "Safe",
    })
    Register("player.hide_self", self.HideSelf, {
        Name = "Hide Local Character", Category = "Safe",
    })
    Register("player.tool_esp", self.ToolESP, {
        Name = "Tool ESP", Category = "Safe", DefaultColor = Color3.fromRGB(255, 210, 60),
    })
    Register("player.auto_pickup_baby", self.AutoPickUpBaby, {
        Name = "Auto Pick Up Baby", Category = "SemiSafe",
    })
    Register("player.mute_character_sounds", self.MuteCharacterSounds, {
        Name = "Mute Character Sounds", Category = "Safe",
    })
    Register("player.reset", self.Reset, {
        Name = "Reset Character", Category = "Safe",
    })
    Register("player.rejoin", self.Rejoin, {
        Name = "Rejoin Server", Category = "Safe",
    })

    return self
end

return Player
]====],
        [ [====[Features/Player/JumpPower.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.jump_power",
    Name = "Jump Power",
    Description = "Continuously applies the selected jump power and switches the humanoid to JumpPower mode when required.",
    Kind = "HumanoidValue",
    Property = "JumpPower",
    EnabledValue = 80,
    DefaultValue = 50,
    Min = 20,
    Max = 220,
    Interval = 0.1,
})
]====],
        [ [====[Features/Player/MuteCharacterSounds.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.mute_character_sounds",
    Name = "Mute Character Sounds",
    Description = "Mutes sounds inside the local character and restores their original volume values when disabled.",
    Kind = "MuteSounds",
    Interval = 0.45,
})
]====],
        [ [====[Features/Player/NameESP.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.name_esp",
    Name = "Name ESP",
    Description = "Displays each other player’s display name above their character with an always-visible label.",
    Kind = "PlayerBillboard",
    Mode = "Name",
    DefaultColor = Color3.fromRGB(245, 245, 255),
    Interval = 0.9,
})
]====],
        [ [====[Features/Player/NoClip.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.noclip",
    Name = "Noclip",
    Description = "Disables collision on local character parts while enabled and restores every original collision value afterward.",
    Kind = "NoClip",
})
]====],
        [ [====[Features/Player/PlayerESP.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.player_esp",
    Name = "Player ESP",
    Description = "Highlights every other living player with an always-visible outline.",
    Kind = "PlayerHighlight",
    DefaultColor = Color3.fromRGB(0, 170, 255),
    FillTransparency = 0.5,
})
]====],
        [ [====[Features/Player/Rejoin.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.rejoin",
    Name = "Rejoin Server",
    Description = "Requests a rejoin to the current Roblox server instance once, then returns to the off state.",
    Kind = "Action",
    Action = "Rejoin",
})
]====],
        [ [====[Features/Player/Reset.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.reset",
    Name = "Reset Character",
    Description = "Requests a local character reset once, then returns to the off state.",
    Kind = "Action",
    Action = "Reset",
})
]====],
        [ [====[Features/Player/ToolESP.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.tool_esp",
    Name = "Tool ESP",
    Description = "Highlights world tools and supported interactable prompts with labels, while ignoring items already owned by the local player.",
    Kind = "ToolESP",
    DefaultColor = Color3.fromRGB(255, 210, 60),
    Interval = 0.95,
})
]====],
        [ [====[Features/Player/UnlockZoom.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.unlock_zoom",
    Name = "Unlock Camera Zoom",
    Description = "Raises the local maximum camera zoom distance while preserving the original value for restoration.",
    Kind = "UnlockZoom",
    MaxZoom = 1000,
})
]====],
        [ [====[Features/Player/WalkSpeed.lua]====] ] = [====[local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local BUILD_TOKEN = tostring(Manifest.BuildToken or BUILD_NUMBER)
local expectedRevision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r3")

local Runtime = Environment.__SquidNoMoPlayerRuntime
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    local repository = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
    local source = game:HttpGet(
        repository .. "Features/Shared/PlayerRuntime.lua?squidnomo_build=" .. BUILD_TOKEN
    )
    Runtime = loadstring(source)()
end
if type(Runtime) ~= "table"
    or Runtime.Revision ~= expectedRevision
    or tonumber(Runtime.BuildNumber) ~= BUILD_NUMBER
then
    error("SquidNoMo player runtime build mismatch; deploy the complete build")
end

return Runtime:CreateFeature({
    Id = "player.walk_speed",
    Name = "Walk Speed",
    Description = "Continuously applies the selected walking speed to the local humanoid and reapplies it after respawn.",
    Kind = "HumanoidValue",
    Property = "WalkSpeed",
    EnabledValue = 32,
    DefaultValue = 16,
    Min = 8,
    Max = 120,
    Interval = 0.1,
})
]====],
        [ [====[Features/Shared/PlayerRuntime.lua]====] ] = [====[-- SquidNoMo player feature runtime
-- Shared implementation for every module under Features/Player.

local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")
local Lighting = game:GetService("Lighting")
local TeleportService = game:GetService("TeleportService")

local LocalPlayer = Players.LocalPlayer

local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end
local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local Runtime = {
    Revision = tostring(Manifest.PlayerRuntimeRevision or "player-runtime-r1"),
    BuildNumber = BUILD_NUMBER,
}
Environment.__SquidNoMoPlayerRuntime = Runtime


local Scheduler = Environment.__SquidNoMoScheduler
if type(Scheduler) ~= "table" or Scheduler.Revision ~= ("shared-scheduler-r2-build-" .. tostring(BUILD_NUMBER)) then
    -- Runtime.lua normally creates this first. The fallback is intentionally the
    -- same cooperative scheduler so PlayerRuntime remains safe when loaded alone.
    Scheduler = {
        Revision = "shared-scheduler-r2-build-" .. tostring(BUILD_NUMBER),
        Tasks = setmetatable({}, {__mode = "k"}),
        Running = false,
        Lightweight = true,
    }
    function Scheduler:SetLightweight(state) self.Lightweight = state ~= false end
    function Scheduler:Add(owner, interval, idleInterval, callback)
        interval = math.max(tonumber(interval) or 0.25, 0.03)
        self.Tasks[owner] = {
            Interval = interval,
            IdleInterval = math.max(tonumber(idleInterval) or math.max(interval * 4, 1), interval),
            Callback = callback,
            NextRun = os.clock(),
            Busy = false,
        }
        self:_Ensure()
    end
    function Scheduler:Remove(owner) self.Tasks[owner] = nil end
    function Scheduler:_Ensure()
        if self.Running then return end
        self.Running = true
        task.spawn(function()
            while next(self.Tasks) do
                local now, launched = os.clock(), 0
                local launchBudget = self.Lightweight and 3 or 8
                for owner, job in pairs(self.Tasks) do
                    if launched >= launchBudget then break end
                    if not owner or owner.Enabled ~= true then
                        self.Tasks[owner] = nil
                    elseif not job.Busy and now >= job.NextRun then
                        job.Busy = true
                        launched = launched + 1
                        task.spawn(function()
                            local ok, active = xpcall(function() return job.Callback(owner) end, debug.traceback)
                            if not ok and owner and owner.Enabled then
                                owner.LastError = tostring(active)
                                if type(owner._SetStatus) == "function" then owner:_SetStatus("Error", owner.LastError) end
                                active = false
                            end
                            job.Busy = false
                            job.NextRun = os.clock() + (active and job.Interval or job.IdleInterval)
                        end)
                    end
                end
                task.wait(self.Lightweight and 0.035 or 0.02)
            end
            self.Running = false
        end)
    end
    Environment.__SquidNoMoScheduler = Scheduler
end
Runtime.Scheduler = Scheduler

local function lower(value)
    return string.lower(tostring(value or ""))
end

local function containsAny(value, tokens)
    local text = lower(value)
    for _, token in ipairs(tokens or {}) do
        token = lower(token)
        if token ~= "" and string.find(text, token, 1, true) then
            return true
        end
    end
    return false
end

local function getCharacter(player)
    player = player or LocalPlayer
    local character = player and player.Character
    local humanoid = character and character:FindFirstChildOfClass("Humanoid")
    local root = character and character:FindFirstChild("HumanoidRootPart")
    return character, humanoid, root
end

local function roleText(player)
    local parts = {
        player and player.Name,
        player and player.DisplayName,
        player and player.Team and player.Team.Name,
    }
    if player then
        for _, attributeName in ipairs({"Role", "Class", "Team", "Job", "Rank"}) do
            local ok, value = pcall(player.GetAttribute, player, attributeName)
            if ok and value ~= nil then
                table.insert(parts, value)
            end
        end
        local character = player.Character
        if character then
            table.insert(parts, character.Name)
            for _, attributeName in ipairs({"Role", "Class", "Team", "Job", "Rank", "TeamRole", "PlayerRole"}) do
                local ok, value = pcall(character.GetAttribute, character, attributeName)
                if ok and value ~= nil then
                    table.insert(parts, value)
                end
            end
            local scanned = 0
            for _, descendant in ipairs(character:GetDescendants()) do
                if descendant:IsA("Tool") or descendant:IsA("Accessory")
                    or descendant:IsA("Shirt") or descendant:IsA("Pants")
                    or descendant:IsA("StringValue") or descendant:IsA("ObjectValue")
                then
                    table.insert(parts, descendant.Name)
                    if descendant:IsA("StringValue") then table.insert(parts, descendant.Value) end
                    scanned = scanned + 1
                    if scanned >= 36 then break end
                end
            end
        end
    end
    return lower(table.concat(parts, " "))
end

local function playerMatches(player, config)
    if not player or player == LocalPlayer then
        return false
    end
    local character, humanoid = getCharacter(player)
    if not character or not humanoid or humanoid.Health <= 0 then
        return false
    end
    local text = roleText(player)
    if config.RoleTokens and #config.RoleTokens > 0 and not containsAny(text, config.RoleTokens) then
        return false
    end
    if config.ExcludeRoleTokens and containsAny(text, config.ExcludeRoleTokens) then
        return false
    end
    return true
end

local FeatureMethods = {}
FeatureMethods.__index = FeatureMethods

function FeatureMethods:_SetStatus(state, detail)
    local nextStatus = tostring(state or "Unknown")
    local nextDetail = tostring(detail or "")
    if self.Status == nextStatus and self.StatusDetail == nextDetail then return end
    self.Status = nextStatus
    self.StatusDetail = nextDetail
    for id, callback in pairs(self.StatusListeners) do
        local ok = pcall(callback, self.Status, self.StatusDetail, self)
        if not ok then
            self.StatusListeners[id] = nil
        end
    end
end

function FeatureMethods:GetStatus()
    return self.Status, self.StatusDetail
end

function FeatureMethods:GetLastError()
    return self.LastError
end

function FeatureMethods:SubscribeStatus(callback)
    assert(type(callback) == "function", "status callback must be a function")
    self.NextListenerId = self.NextListenerId + 1
    local id = self.NextListenerId
    self.StatusListeners[id] = callback
    local disconnected = false
    return {
        Disconnect = function()
            if disconnected then return end
            disconnected = true
            self.StatusListeners[id] = nil
        end,
    }
end

function FeatureMethods:_TrackConnection(connection)
    if connection then
        table.insert(self.Connections, connection)
    end
    return connection
end

function FeatureMethods:_TrackInstance(instance)
    if instance then
        table.insert(self.Instances, instance)
    end
    return instance
end

function FeatureMethods:_Spawn(callback)
    local thread = task.spawn(function()
        local ok, err = xpcall(callback, debug.traceback)
        if not ok and self.Enabled then
            self.LastError = tostring(err)
            self:_SetStatus("Error", self.LastError)
            warn("[SquidNoMo][" .. self.Name .. "] " .. self.LastError)
        end
    end)
    table.insert(self.Threads, thread)
    return thread
end

function FeatureMethods:_Loop(interval, callback)
    interval = tonumber(interval) or tonumber(self.Config.Interval) or 0.2
    local idleInterval = tonumber(self.Config.IdleInterval) or math.max(interval * 4, 0.8)
    Scheduler:Add(self, interval, idleInterval, function(owner)
        local ok, active, detail = pcall(callback, owner)
        if not ok then error(active) end
        if active then
            owner:_SetStatus("Active", detail or "Working")
        else
            owner:_SetStatus("Waiting", detail or owner.Config.WaitingMessage or "Waiting for the local character")
        end
        return active == true
    end)
end

function FeatureMethods:_Clear()
    Scheduler:Remove(self)
    for _, connection in ipairs(self.Connections) do
        pcall(function() connection:Disconnect() end)
    end
    self.Connections = {}

    for _, thread in ipairs(self.Threads) do
        pcall(task.cancel, thread)
    end
    self.Threads = {}

    for _, instance in ipairs(self.Instances) do
        pcall(function() instance:Destroy() end)
    end
    self.Instances = {}

    if type(self.Restore) == "function" then
        pcall(self.Restore, self)
    end
    self.Restore = nil
end

function FeatureMethods:Set(value)
    local number = tonumber(value)
    if number == nil then
        return false
    end
    if self.Config.Min ~= nil then
        number = math.max(number, self.Config.Min)
    end
    if self.Config.Max ~= nil then
        number = math.min(number, self.Config.Max)
    end

    self.Value = number

    local isValueFeature =
        self.Config.Kind == "HumanoidValue"
        or self.Config.Kind == "WorkspaceValue"

    if isValueFeature then
        local defaultValue = tonumber(
            self.Config.DefaultValue
        ) or 0
        local changed =
            math.abs(number - defaultValue) > 0.001

        if changed then
            self.PreferredValue = number
            if not self.Enabled then
                return self:Toggle(true)
            end
        elseif self.Enabled then
            return self:Toggle(false)
        end
    end

    if self.Enabled
        and type(self.ApplyNow) == "function"
    then
        local ok, active, detail = pcall(
            self.ApplyNow,
            self
        )
        if not ok or active == false then
            return false, tostring(detail or active)
        end
    end
    return true
end

function FeatureMethods:Get()
    return self.Value
end

function FeatureMethods:SetColor(color)
    if typeof(color) ~= "Color3" then
        return false
    end
    self.Color = color
    if self.Enabled and type(self.RefreshNow) == "function" then
        pcall(self.RefreshNow, self)
    end
    return true
end

function FeatureMethods:GetColor()
    return self.Color
end

function FeatureMethods:IsEnabled()
    return self.Enabled == true
end

function FeatureMethods:GetState()
    return self.Enabled and "on" or "off"
end

local function startHumanoidValue(feature)
    feature.OriginalByHumanoid = {}
    feature.BoundHumanoid = nil

    local function apply(self)
        local _, humanoid = getCharacter()
        if not humanoid then return false, "Waiting for the local humanoid" end
        local property = self.Config.Property
        if self.OriginalByHumanoid[humanoid] == nil then
            local ok, original = pcall(function() return humanoid[property] end)
            if ok then self.OriginalByHumanoid[humanoid] = original end
        end
        if property == "JumpPower" and humanoid.UseJumpPower == false then
            if self.OriginalUseJumpPower == nil then self.OriginalUseJumpPower = humanoid.UseJumpPower end
            humanoid.UseJumpPower = true
        end
        local ok, current = pcall(function() return humanoid[property] end)
        if ok and math.abs((tonumber(current) or 0) - (tonumber(self.Value) or 0)) <= 0.01 then
            return true, property .. " already set to " .. tostring(self.Value)
        end
        local applied, err = pcall(function() humanoid[property] = self.Value end)
        return applied, applied and (property .. " set to " .. tostring(math.floor(self.Value * 10 + 0.5) / 10)) or tostring(err)
    end

    local function bind(self)
        local _, humanoid = getCharacter()
        if not humanoid or humanoid == self.BoundHumanoid then return end
        self.BoundHumanoid = humanoid
        apply(self)
        self:_TrackConnection(humanoid:GetPropertyChangedSignal(self.Config.Property):Connect(function()
            if self.Enabled then task.defer(function() if self.Enabled then apply(self) end end) end
        end))
    end

    feature.ApplyNow = apply
    feature.Restore = function(self)
        for humanoid, value in pairs(self.OriginalByHumanoid or {}) do
            if humanoid.Parent then
                pcall(function() humanoid[self.Config.Property] = value end)
                if self.Config.Property == "JumpPower" and self.OriginalUseJumpPower ~= nil then
                    pcall(function() humanoid.UseJumpPower = self.OriginalUseJumpPower end)
                end
            end
        end
        self.OriginalByHumanoid = {}
        self.BoundHumanoid = nil
    end
    if LocalPlayer then
        feature:_TrackConnection(LocalPlayer.CharacterAdded:Connect(function()
            task.defer(function() if feature.Enabled then bind(feature) end end)
        end))
    end
    bind(feature)
    feature:_Loop(feature.Config.Interval or 1.25, function(self)
        bind(self)
        return apply(self)
    end)
end

local function startWorkspaceValue(feature)
    local property = feature.Config.Property
    local ok, original = pcall(function() return Workspace[property] end)
    if ok then
        feature.OriginalValue = original
    end
    feature.ApplyNow = function(self)
        local applied, err = pcall(function() Workspace[property] = self.Value end)
        return applied, applied and (property .. " set to " .. tostring(self.Value)) or tostring(err)
    end
    feature.Restore = function(self)
        if self.OriginalValue ~= nil then
            pcall(function() Workspace[property] = self.OriginalValue end)
        end
    end
    feature:_Loop(feature.Config.Interval or 1.0, feature.ApplyNow)
end

local function startInfiniteJump(feature)
    feature:_TrackConnection(UserInputService.JumpRequest:Connect(function()
        if not feature.Enabled then return end
        local _, humanoid = getCharacter()
        if humanoid and humanoid.Health > 0 then
            humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
            feature:_SetStatus("Active", "Air jump triggered")
        else
            feature:_SetStatus("Waiting", "Waiting for the local humanoid")
        end
    end))
    feature:_SetStatus("Active", "Listening for jump input")
end

local function startAutoJump(feature)
    feature:_Loop(feature.Config.Interval or 0.12, function()
        local _, humanoid = getCharacter()
        if not humanoid then
            return false, "Waiting for the local humanoid"
        end
        if humanoid.MoveDirection.Magnitude > 0.05 and humanoid.FloorMaterial ~= Enum.Material.Air then
            humanoid.Jump = true
            return true, "Jumped while moving"
        end
        return true, "Monitoring movement"
    end)
end

local function startNoClip(feature)
    feature.OriginalCollision = {}
    feature.CollisionParts = setmetatable({}, {__mode = "k"})

    local function addPart(self, instance)
        if instance:IsA("BasePart") then
            if self.OriginalCollision[instance] == nil then self.OriginalCollision[instance] = instance.CanCollide end
            self.CollisionParts[instance] = true
        end
    end

    local function bindCharacter(self, character)
        if not character then return end
        for _, descendant in ipairs(character:GetDescendants()) do addPart(self, descendant) end
        self:_TrackConnection(character.DescendantAdded:Connect(function(instance) addPart(self, instance) end))
    end

    feature.Restore = function(self)
        for part, value in pairs(self.OriginalCollision or {}) do
            if part.Parent then pcall(function() part.CanCollide = value end) end
        end
        self.OriginalCollision = {}
        self.CollisionParts = setmetatable({}, {__mode = "k"})
    end
    local character = getCharacter()
    bindCharacter(feature, character)
    if LocalPlayer then
        feature:_TrackConnection(LocalPlayer.CharacterAdded:Connect(function(newCharacter)
            if feature.Enabled then bindCharacter(feature, newCharacter) end
        end))
    end
    feature:_Loop(feature.Config.Interval or 0.10, function(self)
        local count = 0
        for part in pairs(self.CollisionParts) do
            if part.Parent and part.CanCollide then part.CanCollide = false; count = count + 1 end
        end
        return next(self.CollisionParts) ~= nil, "Noclip active; corrected " .. tostring(count) .. " part(s)"
    end)
end

local function startForceThirdPerson(feature)
    feature.OriginalCameraMode = LocalPlayer and LocalPlayer.CameraMode
    feature.OriginalMinZoom = LocalPlayer and LocalPlayer.CameraMinZoomDistance
    feature.OriginalMaxZoom = LocalPlayer and LocalPlayer.CameraMaxZoomDistance
    feature.Restore = function(self)
        if LocalPlayer then
            if self.OriginalCameraMode then LocalPlayer.CameraMode = self.OriginalCameraMode end
            if self.OriginalMinZoom then LocalPlayer.CameraMinZoomDistance = self.OriginalMinZoom end
            if self.OriginalMaxZoom then LocalPlayer.CameraMaxZoomDistance = self.OriginalMaxZoom end
        end
    end
    feature:_Loop(0.85, function()
        if not LocalPlayer then return false, "Waiting for LocalPlayer" end
        LocalPlayer.CameraMode = Enum.CameraMode.Classic
        LocalPlayer.CameraMinZoomDistance = math.max(0.5, feature.Config.MinZoom or 6)
        LocalPlayer.CameraMaxZoomDistance = math.max(feature.Config.MaxZoom or 20, LocalPlayer.CameraMinZoomDistance)
        return true, "Third-person camera enforced"
    end)
end

local function startUnlockZoom(feature)
    feature.OriginalMaxZoom = LocalPlayer and LocalPlayer.CameraMaxZoomDistance
    feature.Restore = function(self)
        if LocalPlayer and self.OriginalMaxZoom then
            LocalPlayer.CameraMaxZoomDistance = self.OriginalMaxZoom
        end
    end
    feature:_Loop(1.0, function()
        if not LocalPlayer then return false, "Waiting for LocalPlayer" end
        LocalPlayer.CameraMaxZoomDistance = feature.Config.MaxZoom or 1000
        return true, "Camera zoom limit expanded"
    end)
end

local function startAutoStand(feature)
    feature:_Loop(0.18, function()
        local _, humanoid = getCharacter()
        if not humanoid then return false, "Waiting for the local humanoid" end
        if humanoid.Sit or humanoid.PlatformStand then
            humanoid.Sit = false
            humanoid.PlatformStand = false
            humanoid:ChangeState(Enum.HumanoidStateType.GettingUp)
            return true, "Recovered standing state"
        end
        return true, "Monitoring standing state"
    end)
end

local function createHighlight(feature, player, outlineOnly)
    local character = player.Character
    if not character then return nil end
    local existing = feature.Markers[character]
    if existing and existing.Parent then
        existing.FillColor = feature.Color
        existing.OutlineColor = feature.Config.OutlineColor or Color3.fromRGB(255, 255, 255)
        return existing
    end
    local highlight = Instance.new("Highlight")
    highlight.Name = "SquidNoMo_" .. feature.Id
    highlight.Adornee = character
    highlight.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
    highlight.FillColor = feature.Color
    highlight.OutlineColor = feature.Config.OutlineColor or Color3.fromRGB(255, 255, 255)
    highlight.FillTransparency = outlineOnly and 1 or (feature.Config.FillTransparency or 0.48)
    highlight.OutlineTransparency = feature.Config.OutlineTransparency or 0.02
    highlight.Parent = character
    feature.Markers[character] = highlight
    feature:_TrackInstance(highlight)
    return highlight
end

local function startPlayerHighlight(feature)
    feature.Markers = {}
    feature.RefreshNow = function(self)
        local valid = {}
        local count = 0
        for _, player in ipairs(Players:GetPlayers()) do
            if playerMatches(player, self.Config) then
                local character = player.Character
                valid[character] = true
                createHighlight(self, player, self.Config.OutlineOnly == true)
                count = count + 1
            end
        end
        for character, marker in pairs(self.Markers) do
            if not valid[character] or not character.Parent or not marker.Parent then
                if marker.Parent then marker:Destroy() end
                self.Markers[character] = nil
            end
        end
        return count
    end
    feature:_Loop(feature.Config.Interval or 0.65, function(self)
        local count = self:RefreshNow()
        return count > 0, count > 0 and ("Tracking " .. count .. " player(s)") or "Waiting for matching players"
    end)
end

local function createBillboard(feature, player)
    local character, humanoid, root = getCharacter(player)
    if not character or not humanoid or not root then return nil end
    local existing = feature.Markers[character]
    if existing and existing.Gui and existing.Gui.Parent then
        return existing
    end
    local gui = Instance.new("BillboardGui")
    gui.Name = "SquidNoMo_" .. feature.Id
    gui.Adornee = root
    gui.AlwaysOnTop = true
    gui.Size = UDim2.fromOffset(180, 34)
    local offsetY = feature.Config.Mode == "Health" and 4.5
        or (feature.Config.Mode == "Distance" and 3.8 or 3.1)
    gui.StudsOffset = Vector3.new(0, offsetY, 0)
    gui.Parent = root

    local label = Instance.new("TextLabel")
    label.Size = UDim2.fromScale(1, 1)
    label.BackgroundTransparency = 1
    label.Font = Enum.Font.GothamBold
    label.TextSize = 14
    label.TextColor3 = feature.Color
    label.TextStrokeTransparency = 0.25
    label.Text = player.DisplayName
    label.Parent = gui

    local marker = {Gui = gui, Label = label, Player = player, Humanoid = humanoid, Root = root}
    feature.Markers[character] = marker
    feature:_TrackInstance(gui)
    return marker
end

local function startPlayerBillboard(feature)
    feature.Markers = {}
    feature.RefreshNow = function(self)
        local valid = {}
        local count = 0
        local _, _, localRoot = getCharacter()
        for _, player in ipairs(Players:GetPlayers()) do
            if playerMatches(player, self.Config) then
                local character = player.Character
                local marker = createBillboard(self, player)
                if marker then
                    valid[character] = true
                    count = count + 1
                    marker.Label.TextColor3 = self.Color
                    if self.Config.Mode == "Distance" then
                        local distance = localRoot and math.floor((marker.Root.Position - localRoot.Position).Magnitude + 0.5) or 0
                        marker.Label.Text = player.DisplayName .. " • " .. tostring(distance) .. "m"
                    elseif self.Config.Mode == "Health" then
                        local health = math.max(0, math.floor(marker.Humanoid.Health + 0.5))
                        local maximum = math.max(1, math.floor(marker.Humanoid.MaxHealth + 0.5))
                        marker.Label.Text = player.DisplayName .. " • " .. health .. "/" .. maximum .. " HP"
                    else
                        marker.Label.Text = player.DisplayName
                    end
                end
            end
        end
        for character, marker in pairs(self.Markers) do
            if not valid[character] or not character.Parent or not marker.Gui.Parent then
                if marker.Gui.Parent then marker.Gui:Destroy() end
                self.Markers[character] = nil
            end
        end
        return count
    end
    local updateInterval = feature.Config.Interval
        or (feature.Config.Mode == "Name" and 0.9 or 0.32)
    feature:_Loop(updateInterval, function(self)
        local count = self:RefreshNow()
        return count > 0, count > 0 and ("Displaying " .. self.Config.Mode .. " for " .. count .. " player(s)") or "Waiting for players"
    end)
end

local function startHideCharacters(feature)
    feature.OriginalTransparency = {}
    feature.BoundCharacters = setmetatable({}, {__mode = "k"})

    local function appliesToPlayer(self, player)
        if self.Config.Mode == "Self" then
            return player == LocalPlayer
        end
        return player ~= LocalPlayer
    end

    local function applyInstance(self, descendant)
        if descendant:IsA("BasePart") then
            if self.OriginalTransparency[descendant] == nil then
                self.OriginalTransparency[descendant] = descendant.LocalTransparencyModifier
            end
            if descendant.LocalTransparencyModifier ~= 1 then
                descendant.LocalTransparencyModifier = 1
            end
        elseif descendant:IsA("Decal") or descendant:IsA("Texture") then
            if self.OriginalTransparency[descendant] == nil then
                self.OriginalTransparency[descendant] = descendant.Transparency
            end
            if descendant.Transparency ~= 1 then
                descendant.Transparency = 1
            end
        end
    end

    local function bindCharacter(self, player, character)
        if not character or self.BoundCharacters[character] or not appliesToPlayer(self, player) then
            return
        end
        self.BoundCharacters[character] = true
        for _, descendant in ipairs(character:GetDescendants()) do
            applyInstance(self, descendant)
        end
        self:_TrackConnection(character.DescendantAdded:Connect(function(instance)
            if self.Enabled then
                applyInstance(self, instance)
            end
        end))
    end

    local function bindPlayer(self, player)
        if not appliesToPlayer(self, player) then return end
        bindCharacter(self, player, player.Character)
        self:_TrackConnection(player.CharacterAdded:Connect(function(character)
            if self.Enabled then
                bindCharacter(self, player, character)
            end
        end))
    end

    feature.Restore = function(self)
        for instance, value in pairs(self.OriginalTransparency or {}) do
            if instance.Parent then
                if instance:IsA("BasePart") then
                    instance.LocalTransparencyModifier = value
                else
                    instance.Transparency = value
                end
            end
        end
        self.OriginalTransparency = {}
        self.BoundCharacters = setmetatable({}, {__mode = "k"})
    end

    for _, player in ipairs(Players:GetPlayers()) do
        bindPlayer(feature, player)
    end
    feature:_TrackConnection(Players.PlayerAdded:Connect(function(player)
        if feature.Enabled then
            bindPlayer(feature, player)
        end
    end))

    feature:_Loop(feature.Config.Interval or 1.25, function(self)
        local count = 0
        for character in pairs(self.BoundCharacters) do
            if character.Parent then count = count + 1 end
        end
        return count > 0, count > 0 and ("Hidden " .. count .. " character(s) locally") or "Waiting for character models"
    end)
end

local function targetAdornee(target)
    if not target then return nil end
    if target:IsA("BasePart") then return target end
    if target:IsA("Tool") or target:IsA("Model") then
        return target:FindFirstChild("Handle") or target.PrimaryPart or target:FindFirstChildWhichIsA("BasePart", true)
    end
    if target:IsA("ProximityPrompt") then
        local parent = target.Parent
        if parent and parent:IsA("Attachment") then parent = parent.Parent end
        return parent and (parent:IsA("BasePart") and parent or parent:FindFirstChildWhichIsA("BasePart", true))
    end
    return target:FindFirstAncestorWhichIsA("BasePart")
end

local function startToolESP(feature)
    feature.Markers = {}
    feature.Candidates = setmetatable({}, {__mode = "k"})

    local function resolve(instance)
        if instance:IsA("Tool") then return instance end
        local tool = instance:FindFirstAncestorWhichIsA("Tool")
        if tool then return tool end
        if instance:IsA("ProximityPrompt") then
            local context = lower(instance.Name .. " " .. instance.ActionText .. " " .. (instance.Parent and instance.Parent.Name or ""))
            if not containsAny(context, {"door", "seat", "sit", "talk", "dialog"}) then
                return instance
            end
        end
        return nil
    end

    local function addCandidate(self, instance)
        local target = resolve(instance)
        if target then self.Candidates[target] = true end
    end

    local function removeMarker(self, target)
        local marker = self.Markers[target]
        if not marker then return end
        if marker.Highlight and marker.Highlight.Parent then marker.Highlight:Destroy() end
        if marker.Billboard and marker.Billboard.Parent then marker.Billboard:Destroy() end
        self.Markers[target] = nil
    end

    local function ensureMarker(self, target, adornee)
        local marker = self.Markers[target]
        if marker and marker.Highlight and marker.Highlight.Parent and marker.Billboard and marker.Billboard.Parent then
            return marker
        end
        removeMarker(self, target)

        local highlight = Instance.new("Highlight")
        highlight.Name = "SquidNoMo_" .. self.Id
        highlight.Adornee = adornee
        highlight.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
        highlight.FillTransparency = 0.62
        highlight.OutlineTransparency = 0.05
        highlight.Parent = adornee

        local billboard = Instance.new("BillboardGui")
        billboard.Name = "SquidNoMo_" .. self.Id .. "_Label"
        billboard.Adornee = adornee
        billboard.AlwaysOnTop = true
        billboard.Size = UDim2.fromOffset(170, 32)
        billboard.StudsOffset = Vector3.new(0, 1.8, 0)
        billboard.Parent = adornee

        local label = Instance.new("TextLabel")
        label.Size = UDim2.fromScale(1, 1)
        label.BackgroundTransparency = 1
        label.Font = Enum.Font.GothamBold
        label.TextSize = 14
        label.TextStrokeTransparency = 0.25
        label.Text = target:IsA("ProximityPrompt") and (target.ActionText ~= "" and target.ActionText or (target.Parent and target.Parent.Name or target.Name)) or target.Name
        label.Parent = billboard

        marker = {Highlight = highlight, Billboard = billboard, Label = label, Adornee = adornee}
        self.Markers[target] = marker
        self:_TrackInstance(highlight)
        self:_TrackInstance(billboard)
        return marker
    end

    -- Reuse the shared object index when available so enabling Tool ESP never
    -- performs its own complete Workspace scan. The fallback walks in batches.
    local objectIndex = Environment.__SquidNoMoObjectIndex
    if type(objectIndex) == "table" and type(objectIndex.ForEach) == "function" then
        objectIndex:ForEach("workspace", {"Tool", "ProximityPrompt"}, function(instance)
            addCandidate(feature, instance)
            return true
        end)
    else
        feature:_Spawn(function()
            local queue = Workspace:GetChildren()
            local cursor = 1
            while feature.Enabled and cursor <= #queue do
                local instance = queue[cursor]
                cursor = cursor + 1
                addCandidate(feature, instance)
                for _, child in ipairs(instance:GetChildren()) do table.insert(queue, child) end
                if cursor % 220 == 0 then task.wait() end
            end
        end)
    end
    feature:_TrackConnection(Workspace.DescendantAdded:Connect(function(instance)
        if feature.Enabled then addCandidate(feature, instance) end
    end))
    feature:_TrackConnection(Workspace.DescendantRemoving:Connect(function(instance)
        if instance:IsA("Tool") or instance:IsA("ProximityPrompt") then
            feature.Candidates[instance] = nil
            removeMarker(feature, instance)
        end
    end))

    feature.RefreshNow = function(self)
        local valid = {}
        local count = 0
        local character = getCharacter()
        local backpack = LocalPlayer and LocalPlayer:FindFirstChildOfClass("Backpack")
        for target in pairs(self.Candidates) do
            if not target.Parent then
                self.Candidates[target] = nil
                removeMarker(self, target)
            elseif not (character and target:IsDescendantOf(character))
                and not (backpack and target:IsDescendantOf(backpack))
                and target:IsDescendantOf(Workspace)
            then
                local adornee = targetAdornee(target)
                if adornee and adornee.Parent then
                    valid[target] = true
                    local marker = ensureMarker(self, target, adornee)
                    if marker.Adornee ~= adornee then
                        marker.Adornee = adornee
                        marker.Highlight.Adornee = adornee
                        marker.Billboard.Adornee = adornee
                    end
                    marker.Highlight.FillColor = self.Color
                    marker.Highlight.OutlineColor = Color3.new(1, 1, 1)
                    marker.Label.TextColor3 = self.Color
                    count = count + 1
                end
            end
        end
        for target in pairs(self.Markers) do
            if not valid[target] then removeMarker(self, target) end
        end
        return count
    end

    feature:_Loop(feature.Config.Interval or 0.95, function(self)
        local count = self:RefreshNow()
        return count > 0, count > 0 and ("Tracking " .. count .. " tool/interactable target(s)") or "Waiting for tools or interactables"
    end)
end

local function playerHasHeldTarget(tokens)
    local character = LocalPlayer and LocalPlayer.Character
    local backpack = LocalPlayer and LocalPlayer:FindFirstChildOfClass("Backpack")
    for _, container in ipairs({character, backpack}) do
        if container then
            for _, child in ipairs(container:GetChildren()) do
                if containsAny(child.Name, tokens) then
                    return true, child
                end
            end
        end
    end
    if LocalPlayer then
        for _, attributeName in ipairs({"HasBaby", "CarryingBaby", "Baby", "HoldingBaby"}) do
            local ok, value = pcall(LocalPlayer.GetAttribute, LocalPlayer, attributeName)
            if ok and (value == true or containsAny(value, tokens)) then
                return true, attributeName
            end
        end
    end
    if character then
        for _, attributeName in ipairs({"HasBaby", "CarryingBaby", "Baby", "HoldingBaby"}) do
            local ok, value = pcall(character.GetAttribute, character, attributeName)
            if ok and (value == true or containsAny(value, tokens)) then
                return true, attributeName
            end
        end
    end
    return false
end

local function startPickupTarget(feature)
    local shared = Environment.__SquidNoMoFeatureRuntime
    if type(shared) ~= "table"
        or tonumber(shared.BuildNumber) ~= BUILD_NUMBER
        or type(shared.FindBestTarget) ~= "function"
        or type(shared.Interact) ~= "function"
    then
        feature:_SetStatus("Error", "Compatible shared interaction runtime is not loaded")
        error("compatible shared interaction runtime is not loaded")
    end

    feature:_Loop(feature.Config.Interval or 0.35, function(self)
        local character, _, root = getCharacter()
        if not character or not root then
            return false, "Waiting for the local character"
        end

        local held, heldObject = playerHasHeldTarget(self.Config.HeldTokens or self.Config.TargetTokens or {})
        if held then
            return true, "Baby is already being carried"
        end

        local target, distance = shared:FindBestTarget({
            Scope = "Workspace",
            TargetTokens = self.Config.TargetTokens,
            ExcludeTokens = self.Config.ExcludeTokens,
            TargetClasses = {"ProximityPrompt", "ClickDetector", "Tool", "Model", "BasePart"},
            MaxTargets = 160,
            MaxDistance = self.Config.MaxDistance or 30,
            PreferInteractive = true,
            CacheTTL = 0.22,
        }, root.Position)
        if not target then
            return false, self.Config.WaitingMessage or "Waiting for a nearby pickup"
        end
        if distance > (self.Config.MaxDistance or 30) then
            return false, "Baby pickup is " .. tostring(math.floor(distance + 0.5)) .. " studs away"
        end
        if os.clock() - (self.LastAction or 0) < (self.Config.ActionCooldown or 0.8) then
            return true, "Baby pickup detected — interaction cooling down"
        end

        local ok, detail = shared:Interact(target, self, {
            Resource = "PickupInteraction",
            Priority = 82,
            Duration = self.Config.ActionCooldown or 0.8,
        })
        if ok then
            self.LastAction = os.clock()
            return true, "Baby pickup interaction sent"
        end
        return false, detail or "The Baby target could not be picked up"
    end)
end

local function startAntiAFK(feature)
    local virtualUser
    pcall(function() virtualUser = game:GetService("VirtualUser") end)
    if LocalPlayer then
        feature:_TrackConnection(LocalPlayer.Idled:Connect(function()
            if not feature.Enabled then return end
            local ok = false
            if virtualUser then
                ok = pcall(function()
                    virtualUser:CaptureController()
                    virtualUser:ClickButton2(Vector2.new(0, 0), Workspace.CurrentCamera and Workspace.CurrentCamera.CFrame or CFrame.new())
                end)
            end
            feature:_SetStatus(ok and "Active" or "Waiting", ok and "Idle input prevented" or "Executor could not simulate anti-idle input")
        end))
        feature:_SetStatus("Active", "Anti-idle listener connected")
    else
        feature:_SetStatus("Waiting", "Waiting for LocalPlayer")
    end
end

local function startAntiLag(feature)
    feature.Originals = {}
    feature.OptimizedCount = 0
    local function optimize(self, instance)
        if instance:IsA("ParticleEmitter") or instance:IsA("Trail") or instance:IsA("Beam")
            or instance:IsA("Smoke") or instance:IsA("Fire") or instance:IsA("Sparkles")
            or instance:IsA("PostEffect")
        then
            if self.Originals[instance] == nil then
                self.Originals[instance] = instance.Enabled
                self.OptimizedCount = self.OptimizedCount + 1
            end
            instance.Enabled = false
            return true
        end
        return false
    end
    feature.Restore = function(self)
        for instance, value in pairs(self.Originals or {}) do
            if instance.Parent then pcall(function() instance.Enabled = value end) end
        end
        self.Originals = {}
        self.OptimizedCount = 0
    end
    feature.Scanning = true
    feature.PendingScans = 2
    for _, root in ipairs({Workspace, Lighting}) do
        feature:_TrackConnection(root.DescendantAdded:Connect(function(instance)
            if feature.Enabled then optimize(feature, instance) end
        end))
        feature:_Spawn(function()
            local queue = root:GetChildren()
            local cursor = 1
            while feature.Enabled and cursor <= #queue do
                local instance = queue[cursor]
                cursor = cursor + 1
                optimize(feature, instance)
                for _, child in ipairs(instance:GetChildren()) do table.insert(queue, child) end
                if cursor % 220 == 0 then task.wait() end
            end
            feature.PendingScans = math.max(0, (feature.PendingScans or 1) - 1)
            feature.Scanning = feature.PendingScans > 0
        end)
    end
    feature:_Loop(feature.Config.Interval or 2.0, function(self)
        if self.Scanning then
            return true, "Optimizing visual effects in small batches..."
        end
        return true, "Reduced " .. tostring(self.OptimizedCount) .. " expensive visual effect(s)"
    end)
end

local function startMuteSounds(feature)
    feature.OriginalVolumes = {}
    local function mute(self, sound)
        if not sound:IsA("Sound") then return end
        if self.OriginalVolumes[sound] == nil then self.OriginalVolumes[sound] = sound.Volume end
        sound.Volume = 0
    end
    local function bind(self, character)
        if not character then return end
        for _, descendant in ipairs(character:GetDescendants()) do mute(self, descendant) end
        self:_TrackConnection(character.DescendantAdded:Connect(function(instance)
            if self.Enabled then mute(self, instance) end
        end))
    end
    feature.Restore = function(self)
        for sound, volume in pairs(self.OriginalVolumes or {}) do
            if sound.Parent then sound.Volume = volume end
        end
        self.OriginalVolumes = {}
    end
    bind(feature, getCharacter())
    if LocalPlayer then
        feature:_TrackConnection(LocalPlayer.CharacterAdded:Connect(function(character)
            if feature.Enabled then bind(feature, character) end
        end))
    end
    feature:_Loop(feature.Config.Interval or 1.5, function(self)
        local count = 0
        for sound in pairs(self.OriginalVolumes) do if sound.Parent then count = count + 1 end end
        return true, "Muted " .. tostring(count) .. " character sound(s)"
    end)
end

local function executeAction(feature)
    local action = feature.Config.Action
    if action == "Reset" then
        local character = getCharacter()
        if not character then return false, "Local character is not ready" end
        local humanoid = character:FindFirstChildOfClass("Humanoid")
        if not humanoid then return false, "Local humanoid is not ready" end
        humanoid.Health = 0
        return true, "Character reset requested"
    elseif action == "Rejoin" then
        if not LocalPlayer then return false, "LocalPlayer is not ready" end
        local ok, err = pcall(function()
            TeleportService:TeleportToPlaceInstance(game.PlaceId, game.JobId, LocalPlayer)
        end)
        return ok, ok and "Rejoin requested" or tostring(err)
    end
    return false, "Unknown action: " .. tostring(action)
end

local starters = {
    HumanoidValue = startHumanoidValue,
    WorkspaceValue = startWorkspaceValue,
    InfiniteJump = startInfiniteJump,
    AutoJump = startAutoJump,
    NoClip = startNoClip,
    ForceThirdPerson = startForceThirdPerson,
    UnlockZoom = startUnlockZoom,
    AutoStand = startAutoStand,
    PlayerHighlight = startPlayerHighlight,
    PlayerBillboard = startPlayerBillboard,
    HideCharacters = startHideCharacters,
    ToolESP = startToolESP,
    PickupTarget = startPickupTarget,
    AntiAFK = startAntiAFK,
    AntiLag = startAntiLag,
    MuteSounds = startMuteSounds,
}

function FeatureMethods:Toggle(state)
    state = state == true

    if self.Config.Kind == "Action" then
        if not state then
            self.Enabled = false
            self:_SetStatus("Off", "Ready")
            return true
        end
        local ok, detail = executeAction(self)
        self.Enabled = false
        self:_SetStatus(ok and "Complete" or "Error", detail)
        if not ok then self.LastError = detail end
        return ok, detail
    end

    if self.Enabled == state then
        return true
    end

    self:_Clear()
    self.Enabled = state
    self.LastError = nil

    if not state then
        self:_SetStatus("Off", "Disabled")
        return true
    end

    self:_SetStatus("Starting", "Initializing " .. self.Name)
    local starter = starters[self.Config.Kind]
    if not starter then
        self.Enabled = false
        self.LastError = "Unsupported player feature kind: " .. tostring(self.Config.Kind)
        self:_SetStatus("Error", self.LastError)
        return false, self.LastError
    end

    local ok, err = xpcall(function() starter(self) end, debug.traceback)
    if not ok then
        self.Enabled = false
        self.LastError = tostring(err)
        self:_SetStatus("Error", self.LastError)
        return false, self.LastError
    end
    return true
end

function FeatureMethods:Enable()
    if self.Config.Kind == "HumanoidValue"
        or self.Config.Kind == "WorkspaceValue"
    then
        local defaultValue = tonumber(
            self.Config.DefaultValue
        ) or 0
        if math.abs(
            (tonumber(self.Value) or defaultValue)
            - defaultValue
        ) <= 0.001 then
            self.Value = tonumber(
                self.PreferredValue
                or self.Config.EnabledValue
            ) or defaultValue
        end
    end
    return self:Toggle(true)
end

function FeatureMethods:Disable()
    local result, detail = self:Toggle(false)
    if self.Config.Kind == "HumanoidValue"
        or self.Config.Kind == "WorkspaceValue"
    then
        self.Value = tonumber(
            self.Config.DefaultValue
        ) or self.Value
    end
    return result, detail
end

function FeatureMethods:Initialize(Loader)
    self.Loader = Loader
    return self
end

function Runtime:CreateFeature(config)
    assert(type(config) == "table", "player feature config must be a table")
    assert(type(config.Kind) == "string" and config.Kind ~= "", "player feature Kind is required")
    local defaultValue = tonumber(config.DefaultValue)
    local feature = setmetatable({
        Id = tostring(config.Id or config.Name or "player_feature"),
        Name = tostring(config.Name or config.Id or "Player Feature"),
        Description = tostring(config.Description or ""),
        Config = config,
        Enabled = false,
        Value = defaultValue,
        PreferredValue = tonumber(
            config.EnabledValue
        ) or defaultValue,
        Color = typeof(config.DefaultColor) == "Color3" and config.DefaultColor or Color3.fromRGB(0, 190, 255),
        Status = "Off",
        StatusDetail = "Disabled",
        LastError = nil,
        Connections = {},
        Threads = {},
        Instances = {},
        StatusListeners = {},
        NextListenerId = 0,
    }, FeatureMethods)
    return feature
end

return Runtime
]====],
        [ [====[Features/Shared/RoleService.lua]====] ] = [====[local RoleService = {}

RoleService.Roles = {
    Player = "Player",
    Guard = "Guard",
    Detective = "Detective",
    Frontman = "Frontman",
    Unknown = "Unknown",
}

local function normalize(value)
    local text = string.lower(tostring(value or ""))
    text = string.gsub(text, "[%s_%-]", "")

    if string.find(text, "frontman", 1, true) or string.find(text, "manager", 1, true) then
        return RoleService.Roles.Frontman
    elseif string.find(text, "detective", 1, true) or string.find(text, "police", 1, true) then
        return RoleService.Roles.Detective
    elseif string.find(text, "guard", 1, true) or string.find(text, "soldier", 1, true) or string.find(text, "staff", 1, true) then
        return RoleService.Roles.Guard
    elseif string.find(text, "player", 1, true) or string.find(text, "contestant", 1, true) then
        return RoleService.Roles.Player
    end

    return nil
end

function RoleService:GetRole(player)
    if not player then
        return self.Roles.Unknown
    end

    local candidates = {}
    for _, attributeName in ipairs({"Role", "role", "TeamRole", "PlayerRole", "Class"}) do
        local ok, value = pcall(function()
            return player:GetAttribute(attributeName)
        end)
        if ok and value ~= nil then
            table.insert(candidates, value)
        end
    end

    if player.Team then
        table.insert(candidates, player.Team.Name)
    end

    local character = player.Character
    if character then
        for _, attributeName in ipairs({"Role", "role", "TeamRole", "PlayerRole", "Class"}) do
            local ok, value = pcall(function()
                return character:GetAttribute(attributeName)
            end)
            if ok and value ~= nil then
                table.insert(candidates, value)
            end
        end

        for _, valueName in ipairs({"Role", "TeamRole", "PlayerRole", "Class"}) do
            local object = character:FindFirstChild(valueName)
            if object and object:IsA("ValueBase") then
                table.insert(candidates, object.Value)
            end
        end
    end

    for _, candidate in ipairs(candidates) do
        local role = normalize(candidate)
        if role then
            return role
        end
    end

    return self.Roles.Player
end

function RoleService:IsPlayer(player)
    return self:GetRole(player) == self.Roles.Player
end

function RoleService:IsGuard(player)
    return self:GetRole(player) == self.Roles.Guard
end

function RoleService:IsDetective(player)
    return self:GetRole(player) == self.Roles.Detective
end

function RoleService:IsFrontman(player)
    return self:GetRole(player) == self.Roles.Frontman
end

return RoleService
]====],
        [ [====[Features/Shared/Runtime.lua]====] ] = [====[-- SquidNoMo feature runtime
-- Runtime identity is supplied by BuildManifest.lua so feature fixes can advance builds automatically.

local Players = game:GetService("Players")
local PathfindingService = game:GetService("PathfindingService")
local Workspace = game:GetService("Workspace")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table"
    and Environment.__SquidNoMoBuildManifest
    or {}
local BUILD_NUMBER = tonumber(Manifest.BuildNumber) or 0
local Runtime = {
    Revision = tostring(Manifest.FeatureRuntimeRevision or "visual-gameplay-runtime-r2"),
    BuildNumber = BUILD_NUMBER,
}
Environment.__SquidNoMoFeatureRuntime = Runtime


-- One cooperative scheduler is shared by every game, guard, detective, and player
-- feature. It prevents dozens of independent while-loops from waking on the same
-- frame and automatically backs off features that are waiting for a round.
local Scheduler = Environment.__SquidNoMoScheduler
if type(Scheduler) ~= "table" or Scheduler.Revision ~= ("shared-scheduler-r2-build-" .. tostring(BUILD_NUMBER)) then
    Scheduler = {
        Revision = "shared-scheduler-r2-build-" .. tostring(BUILD_NUMBER),
        Tasks = setmetatable({}, {__mode = "k"}),
        Running = false,
        Lightweight = true,
    }

    function Scheduler:SetLightweight(state)
        self.Lightweight = state ~= false
    end

    function Scheduler:Add(owner, interval, idleInterval, callback)
        interval = math.max(tonumber(interval) or 0.25, 0.03)
        idleInterval = math.max(tonumber(idleInterval) or math.max(interval * 4, 1.0), interval)
        self.Tasks[owner] = {
            Interval = interval,
            IdleInterval = idleInterval,
            Callback = callback,
            NextRun = os.clock(),
            Busy = false,
        }
        self:_Ensure()
    end

    function Scheduler:Remove(owner)
        self.Tasks[owner] = nil
    end

    function Scheduler:_Ensure()
        if self.Running then return end
        self.Running = true
        task.spawn(function()
            while next(self.Tasks) do
                local now = os.clock()
                local launched = 0
                local launchBudget = self.Lightweight and 3 or 8
                for owner, job in pairs(self.Tasks) do
                    if launched >= launchBudget then break end
                    if not owner or owner.Enabled ~= true then
                        self.Tasks[owner] = nil
                    elseif not job.Busy and now >= job.NextRun then
                        job.Busy = true
                        launched = launched + 1
                        task.spawn(function()
                            local ok, active = xpcall(function()
                                return job.Callback(owner)
                            end, debug.traceback)
                            if not ok and owner and owner.Enabled then
                                owner.LastError = tostring(active)
                                if type(owner._SetStatus) == "function" then
                                    owner:_SetStatus("Error", owner.LastError)
                                end
                                warn("[SquidNoMo][Scheduler] " .. owner.LastError)
                                active = false
                            end
                            job.Busy = false
                            job.NextRun = os.clock() + (active and job.Interval or job.IdleInterval)
                        end)
                    end
                end
                task.wait(self.Lightweight and 0.035 or 0.02)
            end
            self.Running = false
        end)
    end

    Environment.__SquidNoMoScheduler = Scheduler
end
Runtime.Scheduler = Scheduler
Runtime.LightweightMode = true
Runtime.QueryCache = {}
Runtime.MovementLease = {Owner = nil, Priority = -math.huge, ExpiresAt = 0}
Runtime.ActionLeases = {}

local function lower(value)
    return string.lower(tostring(value or ""))
end

local function containsAny(value, tokens)
    local text = lower(value)
    for _, token in ipairs(tokens or {}) do
        token = lower(token)
        if token ~= "" and string.find(text, token, 1, true) then
            return true
        end
    end
    return false
end

local function containsAll(value, tokens)
    local text = lower(value)
    for _, token in ipairs(tokens or {}) do
        token = lower(token)
        if token ~= "" and not string.find(text, token, 1, true) then
            return false
        end
    end
    return true
end

local InstanceTextCache = setmetatable({}, {__mode = "k"})
local function instanceText(instance)
    if not instance then return "" end

    local dynamic = instance:IsA("TextLabel") or instance:IsA("TextButton") or instance:IsA("TextBox")
        or instance:IsA("ValueBase") or instance:IsA("ProximityPrompt")
    local parent = instance.Parent
    local parentName = parent and parent.Name or ""
    local grandparent = parent and parent.Parent
    local grandparentName = grandparent and grandparent.Name or ""
    local signature = instance.Name .. "|" .. parentName .. "|" .. grandparentName
    if not dynamic then
        local cached = InstanceTextCache[instance]
        if cached and cached.Signature == signature then return cached.Text end
    end

    local parts = {instance.Name, instance.ClassName, parentName, grandparentName}
    local current = grandparent and grandparent.Parent
    if current then table.insert(parts, current.Name) end
    if instance:IsA("TextLabel") or instance:IsA("TextButton") or instance:IsA("TextBox") then
        table.insert(parts, instance.Text)
    elseif instance:IsA("ValueBase") then
        table.insert(parts, tostring(instance.Value))
    end
    local ok, actionText, objectText = pcall(function()
        if instance:IsA("ProximityPrompt") then
            return instance.ActionText, instance.ObjectText
        end
        return nil, nil
    end)
    if ok then
        if actionText and actionText ~= "" then table.insert(parts, actionText) end
        if objectText and objectText ~= "" then table.insert(parts, objectText) end
    end
    local text = lower(table.concat(parts, " "))
    if not dynamic then InstanceTextCache[instance] = {Signature = signature, Text = text} end
    return text
end

local function classAllowed(instance, classes)
    if type(classes) ~= "table" or #classes == 0 then return true end
    for _, className in ipairs(classes) do
        if instance:IsA(className) then return true end
    end
    return false
end

local function getLocalPlayer()
    return Players.LocalPlayer
end

local function getCharacter()
    local player = getLocalPlayer()
    local character = player and player.Character
    local humanoid = character and character:FindFirstChildOfClass("Humanoid")
    local root = character and character:FindFirstChild("HumanoidRootPart")
    return player, character, humanoid, root
end

local function getGuiParent()
    if type(gethui) == "function" then
        local ok, result = pcall(gethui)
        if ok and result then return result end
    end
    local coreGui
    pcall(function() coreGui = game:GetService("CoreGui") end)
    if coreGui then return coreGui end
    local player = getLocalPlayer()
    return player and player:FindFirstChildOfClass("PlayerGui") or nil
end

local function getLocalContextText()
    local player, character = getCharacter()
    if not player then return "" end
    local parts = {player.Name, player.DisplayName, player.Team and player.Team.Name or ""}
    for _, attributeName in ipairs({"Role", "Class", "Team", "Job", "Rank", "GameRole"}) do
        local ok, value = pcall(player.GetAttribute, player, attributeName)
        if ok and value ~= nil then table.insert(parts, tostring(value)) end
        if character then
            local characterOk, characterValue = pcall(character.GetAttribute, character, attributeName)
            if characterOk and characterValue ~= nil then table.insert(parts, tostring(characterValue)) end
        end
    end
    if character then
        for _, child in ipairs(character:GetChildren()) do
            if child:IsA("Tool") then table.insert(parts, child.Name) end
        end
    end
    local backpack = player:FindFirstChildOfClass("Backpack")
    if backpack then
        for _, child in ipairs(backpack:GetChildren()) do
            if child:IsA("Tool") then table.insert(parts, child.Name) end
        end
    end
    return lower(table.concat(parts, " "))
end

function Runtime:ContextAllowed(config)
    config = config or {}
    local context = getLocalContextText()
    if config.ExcludeLocalRoleTokens and containsAny(context, config.ExcludeLocalRoleTokens) then
        return false, "This option does not match the current local role"
    end
    if config.LocalRoleTokens and #config.LocalRoleTokens > 0 and not containsAny(context, config.LocalRoleTokens) then
        local known = config.KnownLocalRoleTokens or {
            "hunter", "seeker", "killer", "hider", "runner", "guard", "staff", "detective", "player"
        }
        if config.StrictLocalRole or containsAny(context, known) then
            return false, "Waiting for the matching local role"
        end
    end
    return true
end

local function getPosition(instance)
    if not instance then return nil end
    if instance:IsA("BasePart") then return instance.Position end
    if instance:IsA("Attachment") then return instance.WorldPosition end
    if instance:IsA("Model") then
        local ok, pivot = pcall(instance.GetPivot, instance)
        if ok then return pivot.Position end
    end
    if instance:IsA("ProximityPrompt") or instance:IsA("ClickDetector") then
        return getPosition(instance.Parent)
    end
    return nil
end

local function getAdornee(instance)
    if not instance then return nil end
    if instance:IsA("Model") or instance:IsA("BasePart") then return instance end
    local model = instance:FindFirstAncestorOfClass("Model")
    if model then return model end
    return instance:FindFirstAncestorWhichIsA("BasePart")
end

-- A live, event-maintained index replaces repeated Workspace/GetDescendants scans.
-- Each data-model tree is enumerated once and then updated incrementally as objects
-- are created or removed. Feature queries usually inspect only the requested class
-- buckets (BasePart, Model, Tool, prompt, and so on).
local INDEX_REVISION = "object-index-r3-build-" .. tostring(BUILD_NUMBER)
local IndexManager = Environment.__SquidNoMoObjectIndex
if type(IndexManager) ~= "table" or IndexManager.Revision ~= INDEX_REVISION then
    if type(IndexManager) == "table" and type(IndexManager.Connections) == "table" then
        for _, connection in ipairs(IndexManager.Connections) do
            pcall(function() connection:Disconnect() end)
        end
    end

    IndexManager = {
        Revision = INDEX_REVISION,
        Indices = {},
        Connections = {},
        Generation = 0,
    }

    local broadClasses = {
        "BasePart", "Model", "Folder", "Tool", "ProximityPrompt", "ClickDetector",
        "ValueBase", "GuiObject", "GuiButton", "TextLabel", "TextButton", "TextBox",
        "RemoteEvent", "RemoteFunction", "BindableEvent", "BindableFunction",
    }

    local function weakSet()
        return setmetatable({}, {__mode = "k"})
    end

    function IndexManager:_Bucket(index, className)
        local bucket = index.Buckets[className]
        if not bucket then
            bucket = weakSet()
            index.Buckets[className] = bucket
        end
        return bucket
    end

    function IndexManager:_Add(index, instance)
        if not instance or index.All[instance] then return end
        index.All[instance] = true
        self:_Bucket(index, instance.ClassName)[instance] = true
        for _, className in ipairs(broadClasses) do
            if instance.ClassName ~= className and instance:IsA(className) then
                self:_Bucket(index, className)[instance] = true
            end
        end
        index.Generation = index.Generation + 1
        self.Generation = self.Generation + 1
    end

    function IndexManager:_Remove(index, instance)
        if not instance or not index.All[instance] then return end
        index.All[instance] = nil
        for _, bucket in pairs(index.Buckets) do
            bucket[instance] = nil
        end
        index.Generation = index.Generation + 1
        self.Generation = self.Generation + 1
    end

    function IndexManager:_Build(key, root)
        local previous = self.Indices[key]
        if previous and previous.Root == root and root and root.Parent then
            return previous
        end
        if previous then
            previous.Alive = false
            for _, connection in ipairs(previous.Connections or {}) do
                pcall(function() connection:Disconnect() end)
            end
        end
        if not root then
            self.Indices[key] = nil
            return nil
        end

        local index = {
            Root = root,
            All = weakSet(),
            Buckets = {},
            Connections = {},
            Generation = 0,
            Alive = true,
            Ready = false,
        }
        self.Indices[key] = index
        self:_Add(index, root)

        -- Subscribe first, then build the initial index cooperatively. Walking the
        -- tree in small batches avoids one large frame spike on map-heavy servers.
        local added = root.DescendantAdded:Connect(function(instance)
            if index.Alive then self:_Add(index, instance) end
        end)
        local removing = root.DescendantRemoving:Connect(function(instance)
            if index.Alive then self:_Remove(index, instance) end
        end)
        table.insert(index.Connections, added)
        table.insert(index.Connections, removing)
        table.insert(self.Connections, added)
        table.insert(self.Connections, removing)

        task.spawn(function()
            local queue = root:GetChildren()
            local cursor, processed = 1, 0
            while index.Alive and cursor <= #queue do
                local instance = queue[cursor]
                cursor = cursor + 1
                if instance and instance.Parent then
                    self:_Add(index, instance)
                    local children = instance:GetChildren()
                    for _, child in ipairs(children) do
                        table.insert(queue, child)
                    end
                end
                processed = processed + 1
                if processed % 240 == 0 then task.wait() end
            end
            if index.Alive then index.Ready = true end
        end)
        return index
    end

    function IndexManager:GetIndices(scope)
        scope = lower(scope)
        local indices = {}
        if scope == "gui" then
            local player = getLocalPlayer()
            local gui = player and player:FindFirstChildOfClass("PlayerGui")
            local index = self:_Build("PlayerGui", gui)
            if index then table.insert(indices, index) end
        elseif scope == "replicatedstorage" or scope == "remotes" then
            table.insert(indices, self:_Build("ReplicatedStorage", ReplicatedStorage))
        elseif scope == "both" then
            table.insert(indices, self:_Build("Workspace", Workspace))
            local player = getLocalPlayer()
            local gui = player and player:FindFirstChildOfClass("PlayerGui")
            local guiIndex = self:_Build("PlayerGui", gui)
            if guiIndex then table.insert(indices, guiIndex) end
        else
            table.insert(indices, self:_Build("Workspace", Workspace))
        end
        return indices
    end

    function IndexManager:ForEach(scope, classes, callback)
        local candidateSeen = weakSet()
        for _, index in ipairs(self:GetIndices(scope)) do
            local pools = {}
            if type(classes) == "table" and #classes > 0 then
                for _, className in ipairs(classes) do
                    local bucket = index.Buckets[className]
                    if bucket then table.insert(pools, bucket) end
                end
            else
                table.insert(pools, index.All)
            end
            for _, pool in ipairs(pools) do
                for instance in pairs(pool) do
                    if instance and instance.Parent and not candidateSeen[instance] then
                        candidateSeen[instance] = true
                        if callback(instance) == false then return false end
                    end
                end
            end
        end
        return true
    end

    Environment.__SquidNoMoObjectIndex = IndexManager
end
Runtime.IndexManager = IndexManager

function Runtime:WarmIndices()
    -- Starts the cooperative tree walk while the app is still on its loader.
    -- Calls are idempotent and return immediately with partially built indices.
    IndexManager:GetIndices("workspace")
    IndexManager:GetIndices("replicatedstorage")
    IndexManager:GetIndices("gui")
end

local function forEachIndexed(scope, classes, callback)
    return IndexManager:ForEach(scope, classes, callback)
end

local function isVisibleGui(instance)
    if not instance:IsA("GuiObject") or not instance.Visible then return false end
    local size = instance.AbsoluteSize
    if size.X < 2 or size.Y < 2 then return false end
    if (instance:IsA("TextLabel") or instance:IsA("TextButton") or instance:IsA("TextBox"))
        and instance.TextTransparency >= 0.96
    then
        return false
    end
    if instance:IsA("ImageLabel") or instance:IsA("ImageButton") then
        if instance.ImageTransparency >= 0.98 and instance.BackgroundTransparency >= 0.98 then
            return false
        end
    end
    local current = instance.Parent
    while current do
        if current:IsA("GuiObject") and not current.Visible then return false end
        if current:IsA("CanvasGroup") and current.GroupTransparency >= 0.96 then return false end
        if current:IsA("LayerCollector") and not current.Enabled then return false end
        current = current.Parent
    end
    return true
end


-- Visual-first gameplay context -------------------------------------------------
-- Squid Game X exposes many of its useful round and role cues through the same
-- HUD the player sees. The runtime keeps a small cached snapshot of that HUD so
-- features can use current objective text, counters, buttons, and meter geometry
-- without repeatedly walking the whole PlayerGui tree.
local function isSquidNoMoGui(instance)
    local current = instance
    while current do
        if current:IsA("ScreenGui") then
            local name = lower(current.Name)
            if string.find(name, "squidnomo", 1, true)
                or string.find(name, "squid no mo", 1, true)
            then
                return true
            end
        end
        current = current.Parent
    end
    return false
end

local function safeGuiNumber(instance, property, fallback)
    local ok, value = pcall(function() return instance[property] end)
    if ok and type(value) == "number" then return value end
    return fallback
end

local function safeGuiVector(instance, property)
    local ok, value = pcall(function() return instance[property] end)
    if ok and typeof(value) == "Vector2" then return value end
    return Vector2.zero
end

local function safeGuiColor(instance, property)
    local ok, value = pcall(function() return instance[property] end)
    if ok and typeof(value) == "Color3" then return value end
    return Color3.new(0, 0, 0)
end

function Runtime:GetVisualSnapshot(force)
    local now = os.clock()
    local cached = self._VisualSnapshot
    if not force and cached and now - cached.Time < 0.14 then
        return cached
    end

    local items, textParts = {}, {}
    local scanned = 0
    forEachIndexed("Gui", {"TextLabel", "TextButton", "TextBox", "ImageLabel", "ImageButton", "Frame"}, function(instance)
        if scanned >= 260 then return false end
        if isVisibleGui(instance) and not isSquidNoMoGui(instance) then
            local rawText = ""
            if instance:IsA("TextLabel") or instance:IsA("TextButton") or instance:IsA("TextBox") then
                rawText = tostring(instance.Text or "")
            end
            local context = instanceText(instance)
            if rawText ~= "" or instance:IsA("GuiButton") or containsAny(context, {
                "meter", "progress", "objective", "role", "round", "game", "evidence", "backpack"
            }) then
                local item = {
                    Instance = instance,
                    Text = lower(rawText),
                    RawText = rawText,
                    Context = context,
                    Name = lower(instance.Name),
                    ClassName = instance.ClassName,
                    Position = safeGuiVector(instance, "AbsolutePosition"),
                    Size = safeGuiVector(instance, "AbsoluteSize"),
                    TextSize = safeGuiNumber(instance, "TextSize", 0),
                    TextColor = safeGuiColor(instance, "TextColor3"),
                    BackgroundColor = safeGuiColor(instance, "BackgroundColor3"),
                }
                table.insert(items, item)
                if item.Text ~= "" then table.insert(textParts, item.Text) end
                scanned = scanned + 1
            end
        end
        return true
    end)

    cached = {
        Time = now,
        Items = items,
        Text = table.concat(textParts, " | "),
    }
    self._VisualSnapshot = cached
    return cached
end

function Runtime:GetVisibleText()
    return self:GetVisualSnapshot().Text
end

function Runtime:VisualContains(tokens, requireAll)
    local text = self:GetVisibleText()
    return requireAll and containsAll(text, tokens) or containsAny(text, tokens)
end

function Runtime:GetRoundTimerSeconds()
    local best
    for _, item in ipairs(self:GetVisualSnapshot().Items) do
        local minutes, seconds = string.match(item.RawText or "", "(%d+)%s*:%s*(%d%d)")
        minutes, seconds = tonumber(minutes), tonumber(seconds)
        if minutes and seconds and seconds <= 59 then
            local value = minutes * 60 + seconds
            if not best or value < best then best = value end
        end
    end
    return best
end

function Runtime:GetRoundPhase()
    local text = self:GetVisibleText()
    if containsAny(text, {
        "round complete", "game complete", "you survived", "survived the game",
        "you were eliminated", "victory", "game over", "round results", "match results"
    }) then
        return "Ended"
    end
    if containsAny(text, {
        "follow the beam to start", "waiting for players", "intermission",
        "game starting", "round starting", "starting in", "choose your role"
    }) then
        return "Lobby"
    end
    if self:DetectGameCategory() then
        return "Active"
    end
    return "Unknown"
end

function Runtime:GetGuardDuty()
    local text = self:GetVisibleText()
    local scores = {Kitchen = 0, Morgue = 0, Moderation = 0}
    local sources = {}
    local function add(duty, value, detail)
        scores[duty] = scores[duty] + value
        if detail then sources[duty] = sources[duty] or detail end
    end
    local function score(duty, tokens, weight, detail)
        for _, token in ipairs(tokens) do
            if string.find(text, token, 1, true) then
                add(duty, weight or 1, detail or "visible objective")
            end
        end
    end

    -- Objective text is the strongest signal because Guard maps may remain
    -- replicated while another duty is active.
    score("Kitchen", {
        "kitchen duty", "cook the food", "prepare food", "collect ingredients",
        "bring ingredients", "store cooked", "serve the food", "meal tray"
    }, 5, "guard objective")
    score("Kitchen", {
        "kitchen", "cook", "cooking", "ingredient", "raw food",
        "storage", "serve food", "supply crate"
    }, 2, "visible kitchen cue")
    score("Morgue", {
        "morgue duty", "collect the body", "collect bodies", "grab a coffin",
        "dispose the coffin", "dispose body", "take it to the incinerator"
    }, 5, "guard objective")
    score("Morgue", {
        "morgue", "coffin", "body bag", "incinerator", "cremation", "dead player"
    }, 2, "visible morgue cue")
    score("Moderation", {
        "moderation duty", "moderate the game", "eliminate rule breakers",
        "remove contestant", "guard orders", "discipline contestant"
    }, 5, "guard objective")
    score("Moderation", {
        "moderation", "moderate", "taser", "stun baton", "player cleanup"
    }, 2, "visible moderation cue")

    -- Held tools are useful secondary evidence after the duty selection HUD has
    -- closed. They never override a strong visible objective by themselves.
    local player, character = getCharacter()
    local containers = {}
    if character then table.insert(containers, character) end
    local backpack = player and player:FindFirstChildOfClass("Backpack")
    if backpack then table.insert(containers, backpack) end
    for _, container in ipairs(containers) do
        for _, item in ipairs(container:GetChildren()) do
            if item:IsA("Tool") then
                local name = lower(item.Name)
                if containsAny(name, {"ingredient", "food", "meal", "tray", "cook", "pan"}) then
                    add("Kitchen", 3, "held kitchen tool")
                elseif containsAny(name, {"coffin", "body", "corpse", "incinerator"}) then
                    add("Morgue", 3, "held morgue tool")
                elseif containsAny(name, {"taser", "stun", "baton", "rifle", "pistol"}) then
                    add("Moderation", 3, "held moderation tool")
                end
            end
        end
    end

    local bestDuty, bestScore, secondScore = nil, 0, 0
    for duty, value in pairs(scores) do
        if value > bestScore then
            secondScore = bestScore
            bestDuty, bestScore = duty, value
        elseif value > secondScore then
            secondScore = value
        end
    end
    if bestScore >= 4 and bestScore - secondScore >= 2 then
        return bestDuty, bestScore, sources[bestDuty]
    end
    return nil, bestScore, "guard duty is not yet unambiguous"
end

function Runtime:GetPentathlonStage()
    local text = self:GetVisibleText()
    local stages = {
        {Name = "Ddakji", Tokens = {"ddakji", "paper tile", "flip tile"}},
        {Name = "Gonggi", Tokens = {"gonggi", "stone toss", "pick up stones"}},
        {Name = "Jegichagi", Tokens = {"jegichagi", "jegi", "kick the shuttle"}},
        {Name = "Paengi", Tokens = {"paengi", "spinning top", "spin the top"}},
        {Name = "Biseokchigi", Tokens = {"biseokchigi", "biseok", "flying stone", "standing stone"}},
    }
    for _, stage in ipairs(stages) do
        if containsAny(text, stage.Tokens) then return stage.Name end
    end
    return nil
end

function Runtime:GetMingleRequiredCount()
    local snapshot = self:GetVisualSnapshot()
    local text = snapshot.Text
    local patterns = {
        "(%d+)%s*players", "players%s*[:%-]?%s*(%d+)",
        "group%s*of%s*(%d+)", "rooms?%s*for%s*(%d+)",
        "room%s*with%s*(%d+)", "enter%s+a%s+room%s+with%s+(%d+)",
        "number%s*[:%-]?%s*(%d+)", "mingle%s*[:%-]?%s*(%d+)",
    }
    for _, pattern in ipairs(patterns) do
        local number = tonumber(string.match(text, pattern))
        if number and number >= 1 and number <= 20 then return number end
    end

    -- During Mingle the required number is often displayed as one large central
    -- label. Only accept a standalone large number when the rest of the HUD
    -- confirms that Mingle is active.
    if containsAny(text, {"mingle", "find a room", "enter a room", "players per room"}) then
        local best, bestSize = nil, 0
        for _, item in ipairs(snapshot.Items) do
            local number = tonumber(string.match(item.RawText or "", "^%s*(%d+)%s*$"))
            if number and number >= 1 and number <= 20 and item.TextSize >= bestSize then
                best, bestSize = number, item.TextSize
            end
        end
        return best
    end
    return nil
end

function Runtime:GetMinglePhase()
    local text = self:GetVisibleText()
    if containsAny(text, {
        "room locked", "doors closed", "door closed", "stay in the room",
        "room accepted", "group complete"
    }) then
        return "Locked"
    end
    if containsAny(text, {
        "find a room", "enter a room", "get in a room", "players per room",
        "group of", "rooms open", "choose a room"
    }) or self:GetMingleRequiredCount() then
        return "ChooseRoom"
    end
    if containsAny(text, {
        "mingle", "carousel", "wait for the number", "music is playing",
        "keep moving"
    }) then
        return "Carousel"
    end
    return nil
end

function Runtime:GetHideSeekRole()
    local text = self:GetVisibleText()
    local scores = {Hider = 0, Seeker = 0}
    local function score(role, tokens, weight)
        for _, token in ipairs(tokens) do
            if string.find(text, token, 1, true) then
                scores[role] = scores[role] + weight
            end
        end
    end
    score("Hider", {
        "you are a hider", "playing as hider", "hider objective", "find a key",
        "collect a key", "unlock the exit", "escape before"
    }, 5)
    score("Seeker", {
        "you are a seeker", "playing as seeker", "seeker objective", "find the hiders",
        "eliminate the hiders", "grab a knife", "collect a knife"
    }, 5)

    if self:FindTool({"key", "door key", "exit key"}) then scores.Hider = scores.Hider + 6 end
    if self:FindTool({"knife", "blade"}) then scores.Seeker = scores.Seeker + 6 end

    if scores.Hider >= 5 and scores.Hider >= scores.Seeker + 2 then return "Hider", scores.Hider end
    if scores.Seeker >= 5 and scores.Seeker >= scores.Hider + 2 then return "Seeker", scores.Seeker end
    return nil, math.max(scores.Hider, scores.Seeker)
end

local function readProgressRatioNear(label)
    if not label or not label.Parent then return nil end
    local bestRatio, bestScore
    local root = label.Parent
    for depth = 1, 3 do
        local scanned = 0
        for _, object in ipairs(root:GetDescendants()) do
            if scanned >= 80 then break end
            if object:IsA("GuiObject") and object ~= label and object.Parent and isVisibleGui(object) then
                local context = instanceText(object)
                if containsAny(context, {"fill", "bar", "progress", "meter", "detection"}) then
                    local parentSize = object.Parent:IsA("GuiObject") and object.Parent.AbsoluteSize or Vector2.zero
                    local size = object.AbsoluteSize
                    if parentSize.X > 2 and parentSize.Y > 2 and size.X > 1 and size.Y > 1 then
                        local ratio
                        if parentSize.Y > parentSize.X * 1.25 then
                            ratio = math.clamp(size.Y / parentSize.Y, 0, 1)
                        else
                            ratio = math.clamp(size.X / parentSize.X, 0, 1)
                        end
                        local score = object.ZIndex + (containsAny(context, {"fill", "progress"}) and 10 or 0)
                        if ratio < 0.995 and (not bestScore or score > bestScore) then
                            bestRatio, bestScore = ratio, score
                        end
                    end
                end
                scanned = scanned + 1
            end
        end
        if bestRatio then break end
        root = root.Parent
        if not root then break end
    end
    return bestRatio
end

function Runtime:GetDetectiveState()
    local snapshot = self:GetVisualSnapshot()
    local state = {
        Stage = nil,
        Evidence = nil,
        Capacity = nil,
        Detection = nil,
        HasHint = false,
    }

    for _, item in ipairs(snapshot.Items) do
        local text = item.Text
        local current, maximum = string.match(text, "evidence%s*backpack%s*[:%-]?%s*(%d+)%s*/%s*(%d+)")
        if not current then current, maximum = string.match(text, "(%d+)%s*/%s*(%d+)%s*evidence") end
        if current and maximum then
            state.Evidence, state.Capacity = tonumber(current), tonumber(maximum)
        end
        if containsAny(text, {"detection meter", "detection"}) and not state.Detection then
            state.Detection = readProgressRatioNear(item.Instance)
        end
        if containsAny(text, {"hint", "next evidence", "evidence nearby", "clue nearby"}) then
            state.HasHint = true
        end
    end

    local text = snapshot.Text
    -- The objective list can show every step at once, so backpack state and live
    -- action prompts take priority over merely finding words in the list.
    if state.Evidence and state.Capacity and state.Evidence >= state.Capacity and state.Capacity > 0 then
        state.Stage = "Deposit Evidence"
    elseif containsAny(text, {"deposit evidence now", "return to the boat", "return to your boat", "deposit at the boat"}) then
        state.Stage = "Deposit Evidence"
    elseif containsAny(text, {"collect evidence", "gather the evidence", "search for evidence", "evidence nearby"}) then
        state.Stage = "Gather Evidence"
    elseif containsAny(text, {"find the island", "locate the island", "identify the island", "island picture"}) then
        state.Stage = "Find Island"
    elseif state.Evidence and state.Evidence > 0 then
        state.Stage = "Gather Evidence"
    end
    return state
end

function Runtime:GetVisualRole()
    local player, character = getCharacter()
    if not player then return nil, 0, "local player unavailable" end
    local scores = {Player = 0, Guard = 0, Detective = 0, Frontman = 0}
    local source = {}
    local function add(role, weight, detail)
        scores[role] = (scores[role] or 0) + weight
        source[role] = source[role] or detail
    end
    local function scoreValue(value, weight, detail)
        local valueText = lower(value)
        if containsAny(valueText, {"frontman", "front man", "manager"}) then add("Frontman", weight, detail)
        elseif containsAny(valueText, {"detective", "investigator"}) then add("Detective", weight, detail)
        elseif containsAny(valueText, {
            "guard", "soldier", "staff", "worker", "guard mask",
            "triangle guard", "square guard", "circle guard"
        }) then add("Guard", weight, detail)
        elseif containsAny(valueText, {"player", "contestant", "participant"}) then add("Player", weight, detail) end
    end

    if player.Team then scoreValue(player.Team.Name, 12, "team") end
    for _, object in ipairs({player, character}) do
        if object then
            for _, attributeName in ipairs({"Role", "TeamRole", "PlayerRole", "Class", "Job", "SelectedRole", "CurrentRole"}) do
                local ok, value = pcall(object.GetAttribute, object, attributeName)
                if ok and value ~= nil then scoreValue(value, 14, attributeName) end
            end
        end
    end
    if character then
        local scanned = 0
        for _, child in ipairs(character:GetDescendants()) do
            scoreValue(child.Name, 1, "character appearance")
            scanned = scanned + 1
            if scanned >= 100 then break end
        end
    end

    local visualText = self:GetVisibleText()
    local phrases = {
        Guard = {"playing as guard", "role: guard", "guard duties", "guard mode active"},
        Detective = {"playing as detective", "role: detective", "detective objectives", "evidence backpack"},
        Frontman = {"playing as frontman", "role: frontman", "frontman mode"},
        Player = {"playing as player", "role: player", "contestant mode active"},
    }
    for role, tokens in pairs(phrases) do
        if containsAny(visualText, tokens) then add(role, 10, "visible role HUD") end
    end

    local bestRole, bestScore, secondScore = nil, 0, 0
    for role, score in pairs(scores) do
        if score > bestScore then
            secondScore = bestScore
            bestRole, bestScore = role, score
        elseif score > secondScore then
            secondScore = score
        end
    end
    if bestScore >= 8 and bestScore - secondScore >= 3 then
        return bestRole, bestScore, source[bestRole] or "role signal"
    end
    return nil, bestScore, "role is not yet unambiguous"
end

function Runtime:Matches(instance, config)
    if not instance then return false end
    if not classAllowed(instance, config.TargetClasses) then return false end
    local text = instanceText(instance)
    if config.TargetNames and #config.TargetNames > 0 then
        local exact = false
        for _, name in ipairs(config.TargetNames) do
            if lower(instance.Name) == lower(name) then exact = true break end
        end
        if not exact and not containsAny(text, config.TargetTokens) then return false end
    elseif config.TargetTokens and #config.TargetTokens > 0 and not containsAny(text, config.TargetTokens) then
        return false
    end
    if config.RequiredTokens and #config.RequiredTokens > 0 and not containsAll(text, config.RequiredTokens) then
        return false
    end
    if config.ExcludeTokens and containsAny(text, config.ExcludeTokens) then return false end
    if config.VisibleOnly and instance:IsA("GuiObject") and not isVisibleGui(instance) then return false end
    if type(config.Predicate) == "function" then
        local ok, result = pcall(config.Predicate, instance)
        if not ok or not result then return false end
    end
    return true
end

local function stableList(values)
    local result = {}
    for _, value in ipairs(values or {}) do
        table.insert(result, lower(value))
    end
    table.sort(result)
    return table.concat(result, ",")
end

local function querySignature(config)
    if type(config.Predicate) == "function" or config.NoCache then return nil end
    return table.concat({
        lower(config.Scope or "workspace"),
        stableList(config.TargetNames),
        stableList(config.TargetTokens),
        stableList(config.RequiredTokens),
        stableList(config.ExcludeTokens),
        stableList(config.TargetClasses),
        tostring(config.ReturnAdornee == true),
        tostring(config.VisibleOnly == true),
        tostring(config.MaxTargets or 0),
    }, "|")
end

function Runtime:SetLightweightMode(state)
    self.LightweightMode = state ~= false
    Scheduler:SetLightweight(self.LightweightMode)
    self.QueryCache = {}
end

function Runtime:FindTargets(config)
    config = config or {}
    local signature = querySignature(config)
    local now = os.clock()
    local cache = signature and self.QueryCache[signature] or nil
    local defaultTTL = lower(config.Scope) == "gui" and 0.30 or (self.LightweightMode and 1.35 or 0.65)
    local ttl = tonumber(config.CacheTTL) or defaultTTL
    if cache and #cache.Results == 0 then
        ttl = math.min(ttl, 0.20)
    end

    if cache and cache.Generation == IndexManager.Generation and now - cache.Time <= ttl then
        local results = {}
        for _, target in ipairs(cache.Results) do
            if target and target.Parent then
                table.insert(results, target)
                if config.MaxTargets and #results >= config.MaxTargets then break end
            end
        end
        return results
    end

    local results = {}
    local seen = setmetatable({}, {__mode = "k"})
    forEachIndexed(config.Scope, config.TargetClasses, function(instance)
        if self:Matches(instance, config) then
            local target = config.ReturnAdornee and getAdornee(instance) or instance
            if target and not seen[target] then
                seen[target] = true
                table.insert(results, target)
                if config.MaxTargets and #results >= config.MaxTargets then
                    return false
                end
            end
        end
        return true
    end)

    if signature then
        self.QueryCache[signature] = {
            Time = now,
            Results = results,
            Generation = IndexManager.Generation,
        }
    end
    return results
end

function Runtime:FindNearest(config, origin)
    local nearest, nearestDistance = nil, math.huge
    for _, target in ipairs(self:FindTargets(config)) do
        local position = getPosition(target)
        if position then
            local distance = origin and (position - origin).Magnitude or 0
            if distance < nearestDistance then
                nearest, nearestDistance = target, distance
            end
        end
    end
    return nearest, nearestDistance
end

local function resolveInteractionObjects(target)
    if not target then return nil, nil, nil end
    local prompt = target:IsA("ProximityPrompt") and target
        or target:FindFirstChildWhichIsA("ProximityPrompt", true)
    local detector = target:IsA("ClickDetector") and target
        or target:FindFirstChildWhichIsA("ClickDetector", true)
    local touchPart
    if target:IsA("Tool") then
        touchPart = target:FindFirstChild("Handle") or target:FindFirstChildWhichIsA("BasePart", true)
    elseif target:IsA("BasePart") then
        touchPart = target
    else
        touchPart = target:FindFirstChildWhichIsA("BasePart", true)
    end
    return prompt, detector, touchPart
end

function Runtime:ScoreTarget(target, origin, config)
    config = config or {}
    local position = getPosition(target)
    if not position then return nil, math.huge end
    local distance = origin and (position - origin).Magnitude or 0
    if config.MaxDistance and distance > config.MaxDistance then
        return nil, distance
    end

    local score = -distance
    local text = instanceText(target)
    local name = lower(target.Name)
    for _, token in ipairs(config.TargetTokens or {}) do
        token = lower(token)
        if token ~= "" then
            if name == token then
                score = score + 90
            elseif string.find(name, token, 1, true) then
                score = score + 36
            elseif string.find(text, token, 1, true) then
                score = score + 14
            end
        end
    end
    for _, exactName in ipairs(config.TargetNames or {}) do
        if name == lower(exactName) then score = score + 120 end
    end

    local prompt, detector, touchPart = resolveInteractionObjects(target)
    if prompt and prompt.Enabled then
        score = score + 145
        local actionText = lower(prompt.ActionText)
        local objectText = lower(prompt.ObjectText)
        for _, token in ipairs(config.TargetTokens or {}) do
            token = lower(token)
            if token ~= "" and (string.find(actionText, token, 1, true) or string.find(objectText, token, 1, true)) then
                score = score + 48
            end
        end
        if distance <= math.max(4, tonumber(prompt.MaxActivationDistance) or 0) then
            score = score + 28
        end
    end
    if detector then score = score + 90 end
    if target:IsA("Tool") then score = score + 70 end
    if touchPart then
        score = score + 18
        local transmitter = touchPart:FindFirstChildOfClass("TouchTransmitter")
        if transmitter then score = score + 42 end
    end
    if config.PreferInteractive and not prompt and not detector and not touchPart then
        score = score - 150
    end
    return score, distance
end

function Runtime:FindBestTarget(config, origin)
    config = config or {}
    local best, bestDistance, bestScore = nil, math.huge, -math.huge
    for _, target in ipairs(self:FindTargets(config)) do
        local score, distance = self:ScoreTarget(target, origin, config)
        if score and score > bestScore then
            best, bestDistance, bestScore = target, distance, score
        end
    end
    return best, bestDistance, bestScore
end

function Runtime:FindTool(tokens)
    local player, character = getCharacter()
    local containers = {}
    if character then table.insert(containers, character) end
    local backpack = player and player:FindFirstChildOfClass("Backpack")
    if backpack then table.insert(containers, backpack) end
    for _, container in ipairs(containers) do
        for _, item in ipairs(container:GetChildren()) do
            if item:IsA("Tool") and (#(tokens or {}) == 0 or containsAny(item.Name, tokens)) then
                return item
            end
        end
    end
    return nil
end

function Runtime:EquipTool(tool)
    local _, character, humanoid = getCharacter()
    if not tool or not character or not humanoid then return false end
    if tool.Parent ~= character then
        local ok = pcall(humanoid.EquipTool, humanoid, tool)
        if not ok then return false end
    end
    return true
end

function Runtime:ActivateTool(tokens, feature, options)
    options = options or {}
    -- Do not reserve the shared tool channel until a usable tool actually exists.
    -- This prevents a waiting feature from starving another enabled tool feature.
    local tool = self:FindTool(tokens or {})
    if not tool then return false, "matching tool not found" end
    if not self:EquipTool(tool) then return false, "matching tool could not be equipped" end
    local claimed, ownerName = self:ClaimAction(
        feature,
        options.Resource or "ToolAction",
        options.Priority,
        options.Duration or options.Cooldown or 0.35
    )
    if not claimed then return false, "action is currently controlled by " .. tostring(ownerName) end
    local ok, err = pcall(tool.Activate, tool)
    return ok, ok and nil or tostring(err)
end

function Runtime:Interact(target, feature, options)
    if not target then return false, "target not found" end
    options = options or {}

    local prompt, detector, touchPart = resolveInteractionObjects(target)
    local _, _, _, root = getCharacter()
    local virtualInput
    pcall(function() virtualInput = game:GetService("VirtualInputManager") end)

    local promptSupported = prompt and prompt.Enabled
        and (type(fireproximityprompt) == "function" or virtualInput ~= nil)
    local detectorSupported = detector and type(fireclickdetector) == "function"
    local touchSupported = touchPart and root and type(firetouchinterest) == "function"
    if not promptSupported and not detectorSupported and not touchSupported then
        return false, "no supported prompt, click, or touch interaction is available"
    end

    local claimed, ownerName = self:ClaimAction(
        feature,
        options.Resource or "Interaction",
        options.Priority,
        options.Duration or 0.4
    )
    if not claimed then return false, "interaction is currently controlled by " .. tostring(ownerName) end

    local errors = {}
    if promptSupported then
        if type(fireproximityprompt) == "function" then
            local ok, err = pcall(function()
                -- Some executors accept the hold duration argument and others do not.
                local hold = math.max(0, tonumber(prompt.HoldDuration) or 0)
                local worked = pcall(fireproximityprompt, prompt, hold)
                if not worked then
                    fireproximityprompt(prompt)
                end
            end)
            if ok then return true end
            table.insert(errors, "prompt helper: " .. tostring(err))
        end
        if virtualInput then
            local key = prompt.KeyboardKeyCode
            if key == Enum.KeyCode.Unknown then key = Enum.KeyCode.E end
            local ok, err = pcall(function()
                virtualInput:SendKeyEvent(true, key, false, game)
                task.wait(math.max(0.06, math.min(tonumber(prompt.HoldDuration) or 0.08, 0.35)))
                virtualInput:SendKeyEvent(false, key, false, game)
            end)
            if ok then return true end
            table.insert(errors, "prompt key input: " .. tostring(err))
        end
    end

    if detectorSupported then
        local ok, err = pcall(fireclickdetector, detector)
        if ok then return true end
        table.insert(errors, "click detector: " .. tostring(err))
    end

    if touchSupported then
        local ok, err = pcall(function()
            firetouchinterest(root, touchPart, 0)
            task.wait()
            firetouchinterest(root, touchPart, 1)
        end)
        if ok then return true end
        table.insert(errors, "touch pickup: " .. tostring(err))
    end

    return false, #errors > 0 and table.concat(errors, " | ") or "interaction attempt failed"
end

function Runtime:ClaimAction(feature, resource, priority, duration)
    if not feature then return true end
    resource = tostring(resource or "General")
    local lease = self.ActionLeases[resource]
    if not lease then
        lease = {Owner = nil, Priority = -math.huge, ExpiresAt = 0}
        self.ActionLeases[resource] = lease
    end
    local now = os.clock()
    priority = tonumber(priority) or tonumber(feature.Config and feature.Config.ActionPriority) or 50
    duration = tonumber(duration) or 0.35
    local owner = lease.Owner
    if owner == feature or owner == nil or owner.Enabled ~= true or now >= lease.ExpiresAt or priority > lease.Priority then
        lease.Owner = feature
        lease.Priority = priority
        lease.ExpiresAt = now + duration
        return true
    end
    return false, owner and owner.Name or "another feature"
end

function Runtime:ReleaseActions(feature)
    for _, lease in pairs(self.ActionLeases) do
        if not feature or lease.Owner == feature then
            lease.Owner = nil
            lease.Priority = -math.huge
            lease.ExpiresAt = 0
        end
    end
end

function Runtime:CanUseMovement(feature, priority)
    local lease = self.MovementLease
    local now = os.clock()
    priority = tonumber(priority) or tonumber(feature and feature.Config and feature.Config.MovementPriority) or 50
    local owner = lease.Owner
    if owner == feature or owner == nil or owner.Enabled ~= true or now >= lease.ExpiresAt or priority > lease.Priority then
        return true
    end
    return false, owner and owner.Name or "another movement feature"
end

function Runtime:ClaimMovement(feature, priority, duration)
    if not feature then return true end
    local lease = self.MovementLease
    local now = os.clock()
    priority = tonumber(priority) or tonumber(feature.Config and feature.Config.MovementPriority) or 50
    duration = tonumber(duration) or 0.9
    local owner = lease.Owner
    if owner == feature or owner == nil or owner.Enabled ~= true or now >= lease.ExpiresAt or priority > lease.Priority then
        lease.Owner = feature
        lease.Priority = priority
        lease.ExpiresAt = now + duration
        return true
    end
    return false, owner and owner.Name or "another movement feature"
end

function Runtime:StopMovement(feature, force)
    local lease = self.MovementLease
    if not force and feature and lease.Owner and lease.Owner ~= feature then return false end
    local _, _, humanoid, root = getCharacter()
    if humanoid and root then
        pcall(humanoid.MoveTo, humanoid, root.Position)
        pcall(humanoid.Move, humanoid, Vector3.zero, false)
    end
    if force or lease.Owner == feature or not feature then
        if lease.Owner and type(lease.Owner) == "table" then lease.Owner._MoveState = nil end
        lease.Owner = nil
        lease.Priority = -math.huge
        lease.ExpiresAt = 0
    end
    if feature then feature._MoveState = nil end
    return true
end

function Runtime:MoveTo(position, feature, options)
    options = options or {}
    local _, _, humanoid, root = getCharacter()
    if not humanoid or not root then return false, "character is not ready" end
    if not position then return false, "target has no position" end

    local stopDistance = tonumber(options.StopDistance) or 5
    local distance = (root.Position - position).Magnitude
    if distance <= stopDistance then
        if feature then
            local claimed, ownerName = self:ClaimMovement(
                feature,
                options.MovementPriority,
                options.HoldLeaseAtTarget or 0.9
            )
            if not claimed then return false, "movement is currently controlled by " .. tostring(ownerName) end
            pcall(humanoid.MoveTo, humanoid, root.Position)
            pcall(humanoid.Move, humanoid, Vector3.zero, false)
            if feature._MoveState then feature._MoveState.ReachedAt = os.clock() end
        end
        return true, "target reached"
    end

    local claimed, ownerName = self:ClaimMovement(feature, options.MovementPriority, options.LeaseDuration)
    if not claimed then return false, "movement is currently controlled by " .. tostring(ownerName) end

    local state = feature and feature._MoveState or self._AnonymousMoveState
    if type(state) ~= "table" then state = {} end
    if feature then feature._MoveState = state else self._AnonymousMoveState = state end

    local now = os.clock()
    local targetChanged = not state.Target or (state.Target - position).Magnitude > (tonumber(options.TargetChangeDistance) or 7)
    local direct = options.Direct == true or options.UsePathfinding == false
    local repathInterval = tonumber(options.RepathInterval) or (self.LightweightMode and 1.65 or 1.0)

    if direct then
        state.Waypoints = nil
        state.Index = nil
    elseif targetChanged or not state.Waypoints or now - (state.ComputedAt or 0) >= repathInterval then
        state.Target = position
        state.ComputedAt = now
        state.Waypoints = nil
        state.Index = 2
        local path = PathfindingService:CreatePath({
            AgentRadius = tonumber(options.AgentRadius) or 2,
            AgentHeight = tonumber(options.AgentHeight) or 5,
            AgentCanJump = true,
            WaypointSpacing = tonumber(options.WaypointSpacing) or 6,
        })
        local ok = pcall(path.ComputeAsync, path, root.Position, position)
        if ok and path.Status == Enum.PathStatus.Success then
            state.Waypoints = path:GetWaypoints()
        end
    end

    local destination = position
    local waypoint
    if state.Waypoints and #state.Waypoints >= 2 then
        local index = math.clamp(state.Index or 2, 2, #state.Waypoints)
        waypoint = state.Waypoints[index]
        if (root.Position - waypoint.Position).Magnitude <= (tonumber(options.WaypointReachDistance) or 4) and index < #state.Waypoints then
            index = index + 1
            state.Index = index
            waypoint = state.Waypoints[index]
        end
        destination = waypoint.Position
        if waypoint.Action == Enum.PathWaypointAction.Jump then humanoid.Jump = true end
    end

    local commandInterval = tonumber(options.CommandInterval) or 0.45
    if targetChanged or now - (state.LastCommandAt or 0) >= commandInterval then
        state.Target = position
        state.LastCommandAt = now
        pcall(humanoid.MoveTo, humanoid, destination)
    end

    return true, waypoint and "following cached path" or "moving directly to target"
end

function Runtime:ClickGui(target, feature, options)
    if not target then return false, "GUI target not found" end
    options = options or {}
    local claimed, ownerName = self:ClaimAction(
        feature,
        options.Resource or "GuiAction",
        options.Priority,
        options.Duration or 0.25
    )
    if not claimed then return false, "GUI action is currently controlled by " .. tostring(ownerName) end

    local button = target:IsA("GuiButton") and target
        or target:FindFirstChildWhichIsA("GuiButton", true)
    if button and not button.Active then
        pcall(function() button.Active = true end)
    end

    -- Executors expose different signal helpers. Try all normal button signals,
    -- rather than only Activated, before falling back to simulated pointer input.
    if button and type(firesignal) == "function" then
        local fired = false
        for _, signalName in ipairs({"Activated", "MouseButton1Click", "MouseButton1Down", "MouseButton1Up"}) do
            local ok, signal = pcall(function() return button[signalName] end)
            if ok and signal then
                local signalOk = pcall(firesignal, signal)
                fired = fired or signalOk
            end
        end
        if fired then return true end
    end

    if button and type(getconnections) == "function" then
        local invoked = false
        for _, signalName in ipairs({"Activated", "MouseButton1Click"}) do
            local ok, signal = pcall(function() return button[signalName] end)
            if ok and signal then
                local connectionOk, connections = pcall(getconnections, signal)
                if connectionOk and type(connections) == "table" then
                    for _, connection in ipairs(connections) do
                        local callback = connection.Function or connection.Fire
                        if type(callback) == "function" then
                            invoked = pcall(callback) or invoked
                        elseif type(connection.Fire) == "function" then
                            invoked = pcall(connection.Fire, connection) or invoked
                        end
                    end
                end
            end
        end
        if invoked then return true end
    end

    local guiObject = button or (target:IsA("GuiObject") and target)
    if guiObject then
        local center = guiObject.AbsolutePosition + guiObject.AbsoluteSize / 2
        local virtualInput
        pcall(function() virtualInput = game:GetService("VirtualInputManager") end)
        if virtualInput then
            local ok, err = pcall(function()
                virtualInput:SendMouseMoveEvent(center.X, center.Y, game)
                virtualInput:SendMouseButtonEvent(center.X, center.Y, 0, true, game, 1)
                task.wait()
                virtualInput:SendMouseButtonEvent(center.X, center.Y, 0, false, game, 1)
            end)
            if ok then return true end
            if err then self.LastGuiInputError = tostring(err) end
        end

        local virtualUser
        pcall(function() virtualUser = game:GetService("VirtualUser") end)
        if virtualUser then
            local ok = pcall(function()
                virtualUser:CaptureController()
                virtualUser:Button1Down(Vector2.new(center.X, center.Y), workspace.CurrentCamera and workspace.CurrentCamera.CFrame or CFrame.new())
                task.wait()
                virtualUser:Button1Up(Vector2.new(center.X, center.Y), workspace.CurrentCamera and workspace.CurrentCamera.CFrame or CFrame.new())
            end)
            if ok then return true end
        end
    end
    return false, "executor cannot press the detected GUI control"
end

local FeatureMethods = {}
FeatureMethods.__index = FeatureMethods

function FeatureMethods:_SetStatus(state, detail)
    local nextStatus = tostring(state or "Unknown")
    local nextDetail = tostring(detail or "")
    if self.Status == nextStatus and self.StatusDetail == nextDetail then return end
    self.Status = nextStatus
    self.StatusDetail = nextDetail
    for id, callback in pairs(self.StatusListeners) do
        local ok = pcall(callback, self.Status, self.StatusDetail, self)
        if not ok then self.StatusListeners[id] = nil end
    end
end

function FeatureMethods:GetStatus()
    return self.Status, self.StatusDetail
end

function FeatureMethods:GetLastError()
    return self.LastError
end

function FeatureMethods:SubscribeStatus(callback)
    self.NextListenerId = self.NextListenerId + 1
    local id = self.NextListenerId
    self.StatusListeners[id] = callback
    local disconnected = false
    return {
        Disconnect = function()
            if disconnected then return end
            disconnected = true
            self.StatusListeners[id] = nil
        end,
    }
end

function FeatureMethods:_TrackConnection(connection)
    if connection then table.insert(self.Connections, connection) end
    return connection
end

function FeatureMethods:_TrackInstance(instance)
    if instance then table.insert(self.Instances, instance) end
    return instance
end

function FeatureMethods:_Spawn(callback)
    local thread = task.spawn(function()
        local ok, err = xpcall(callback, debug.traceback)
        if not ok and self.Enabled then
            self.LastError = tostring(err)
            self:_SetStatus("Error", self.LastError)
            warn("[SquidNoMo][" .. self.Name .. "] " .. self.LastError)
        end
    end)
    table.insert(self.Threads, thread)
    return thread
end

function FeatureMethods:_Loop(interval, callback)
    interval = tonumber(interval) or tonumber(self.Config.Interval) or 0.5
    local idleInterval = tonumber(self.Config.IdleInterval) or math.max(interval * 4, 1.0)
    Scheduler:Add(self, interval, idleInterval, function(owner)
        local contextAllowed, contextDetail = Runtime:FeatureContextAllowed(owner)
        if not contextAllowed then
            Runtime:StopMovement(owner)
            if type(owner.OnContextBlocked) == "function" then
                pcall(owner.OnContextBlocked, owner, contextDetail)
            end
            owner:_SetStatus("Waiting", contextDetail)
            return false
        end

        local ok, active, detail = pcall(callback, owner)
        if not ok then error(active) end
        local hint = Runtime:GetFeatureVisualHint(owner)
        if hint and hint ~= "" then
            detail = tostring(detail or (active and "Working" or owner.Config.WaitingMessage or "Waiting")) .. " • " .. hint
        end
        if active then
            owner:_SetStatus("Active", detail or "Working")
        else
            owner:_SetStatus("Waiting", detail or owner.Config.WaitingMessage or "Waiting for the matching game objects")
        end
        return active == true
    end)
end

function FeatureMethods:_Clear()
    Scheduler:Remove(self)
    Runtime:StopMovement(self)
    Runtime:ReleaseActions(self)
    for _, connection in ipairs(self.Connections) do
        pcall(function() connection:Disconnect() end)
    end
    self.Connections = {}
    for _, thread in ipairs(self.Threads) do
        pcall(task.cancel, thread)
    end
    self.Threads = {}
    for _, instance in ipairs(self.Instances) do
        pcall(function() instance:Destroy() end)
    end
    self.Instances = {}
    if type(self.Restore) == "function" then pcall(self.Restore, self) end
    self.Restore = nil
    self.OnContextBlocked = nil
end

local function addHighlight(feature, target, config)
    local adornee = getAdornee(target)
    if not adornee then return false end
    if feature.HighlightByTarget[adornee] and feature.HighlightByTarget[adornee].Parent then return false end
    local highlight = Instance.new("Highlight")
    highlight.Name = "SquidNoMo_" .. feature.Id
    highlight.Adornee = adornee
    highlight.FillColor = config.Color or Color3.fromRGB(42, 255, 126)
    highlight.OutlineColor = config.OutlineColor or Color3.fromRGB(255, 255, 255)
    highlight.FillTransparency = config.FillTransparency or 0.55
    highlight.OutlineTransparency = config.OutlineTransparency or 0.05
    highlight.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
    highlight.Parent = adornee
    feature.HighlightByTarget[adornee] = highlight
    feature:_TrackInstance(highlight)
    return true
end

local getOtherCharacterTargets

local function startHighlight(feature)
    feature.HighlightByTarget = {}
    feature:_Loop(feature.Config.Interval or 0.8, function(self)
        local targets
        if self.Config.PlayerMode then
            targets = getOtherCharacterTargets(self.Config)
        else
            targets = Runtime:FindTargets({
                Scope = self.Config.Scope or "Workspace",
                TargetNames = self.Config.TargetNames,
                TargetTokens = self.Config.TargetTokens,
                RequiredTokens = self.Config.RequiredTokens,
                ExcludeTokens = self.Config.ExcludeTokens,
                TargetClasses = self.Config.TargetClasses or {"Model", "BasePart"},
                ReturnAdornee = true,
                MaxTargets = self.Config.MaxTargets or 80,
                VisibleOnly = self.Config.VisibleOnly,
            })
        end
        local added = 0
        for _, target in ipairs(targets) do
            if addHighlight(self, target, self.Config) then added = added + 1 end
        end
        local alive = 0
        for target, highlight in pairs(self.HighlightByTarget) do
            if target.Parent and highlight.Parent then
                alive = alive + 1
            else
                self.HighlightByTarget[target] = nil
            end
        end
        return alive > 0, alive > 0 and ("Tracking " .. alive .. " target(s)") or self.Config.WaitingMessage
    end)
end

local function startWalkTo(feature)
    feature:_Loop(feature.Config.Interval or 0.7, function(self)
        local _, _, _, root = getCharacter()
        if not root then return false, "Waiting for the local character" end
        local contextAllowed, contextDetail = Runtime:ContextAllowed(self.Config)
        if not contextAllowed then return false, contextDetail end
        if self.Config.SkipIfToolTokens and Runtime:FindTool(self.Config.SkipIfToolTokens) then
            return false, self.Config.CompletedMessage or "Required item is already in the inventory"
        end
        if self.Config.RequireToolTokens and not Runtime:FindTool(self.Config.RequireToolTokens) then
            return false, "Waiting for " .. table.concat(self.Config.RequireToolTokens, "/") .. " tool"
        end
        local movementAvailable, movementOwner = Runtime:CanUseMovement(self, self.Config.MovementPriority)
        if not movementAvailable then return false, "Movement is currently controlled by " .. tostring(movementOwner) end

        local targetTokens = self.Config.TargetTokens
        local targetNames = self.Config.TargetNames
        local excludeTokens = self.Config.ExcludeTokens
        local waitingMessage = self.Config.WaitingMessage
        local id = lower(self.Id)

        -- Detective navigation follows the visible objective rather than assuming
        -- evidence is already spawned as soon as the role begins.
        if string.find(id, "mapped.detective.island_navigation.islandnavigator", 1, true) then
            local detective = Runtime:GetDetectiveState()
            if detective.Stage == "Deposit Evidence" then
                Runtime:StopMovement(self)
                return false, "Evidence is ready to deposit; use Boat Depositor"
            elseif detective.Stage == "Find Island" then
                targetTokens = {"objective", "island", "shore", "landing", "dock", "waypoint", "marker", "hint"}
                excludeTokens = {"wrong island", "decoy", "deposit", "submitted"}
                waitingMessage = "Waiting for the island objective marker or landing point"
            else
                targetTokens = {"evidence", "clue", "file", "document", "keycard", "fingerprint", "objective", "hint"}
                excludeTokens = {"boat deposit", "submitted", "evidence box"}
                waitingMessage = "Waiting for an evidence marker on the island"
            end
        end

        local targetQuery = {
            Scope = self.Config.Scope or "Workspace",
            TargetNames = targetNames,
            TargetTokens = targetTokens,
            RequiredTokens = self.Config.RequiredTokens,
            ExcludeTokens = excludeTokens,
            TargetClasses = self.Config.TargetClasses or {"Model", "BasePart", "ProximityPrompt", "ClickDetector", "Tool"},
            ReturnAdornee = self.Config.ReturnAdornee,
            MaxTargets = self.Config.MaxTargets or 120,
            PreferInteractive = self.Config.Interact == true,
        }
        local target, distance
        if self.Config.Interact then
            target, distance = Runtime:FindBestTarget(targetQuery, root.Position)
        else
            target, distance = Runtime:FindNearest(targetQuery, root.Position)
        end
        if not target then return false, waitingMessage end
        local position = getPosition(target)
        local moved, moveDetail = Runtime:MoveTo(position, self, self.Config)
        if self.Enabled and self.Config.Interact and position then
            local _, _, _, currentRoot = getCharacter()
            if currentRoot and (currentRoot.Position - position).Magnitude <= (self.Config.InteractDistance or 12) then
                local cooldown = self.Config.ActionCooldown or 0.8
                if os.clock() - (self.LastAction or 0) < cooldown then
                    return true, "Reached " .. target.Name .. " — interaction cooling down"
                end
                local interacted, interactDetail = Runtime:Interact(target, self, {Priority = self.Config.ActionPriority or 55, Duration = cooldown})
                if interacted then
                    self.LastAction = os.clock()
                    return true, "Reached and interacted with " .. target.Name
                end
                return moved, interactDetail or moveDetail
            end
        end
        return moved, moved and ("Walking to " .. target.Name .. " (" .. math.floor(distance) .. " studs)") or moveDetail
    end)
end

local function startInteract(feature)
    feature:_Loop(feature.Config.Interval or 0.55, function(self)
        local _, _, _, root = getCharacter()
        if not root then return false, "Waiting for the local character" end
        local contextAllowed, contextDetail = Runtime:ContextAllowed(self.Config)
        if not contextAllowed then return false, contextDetail end

        local id = lower(self.Id)
        if string.find(id, "mapped.detective.evidence.evidencecollector", 1, true) then
            local detective = Runtime:GetDetectiveState()
            if detective.Evidence and detective.Capacity and detective.Evidence >= detective.Capacity then
                return false, "Evidence backpack is full; return to the boat"
            elseif detective.Stage == "Deposit Evidence" then
                return false, "Current detective objective is to deposit evidence"
            end
        end

        if self.Config.SkipIfToolTokens and Runtime:FindTool(self.Config.SkipIfToolTokens) then
            return false, self.Config.CompletedMessage or "Required item is already in the inventory"
        end
        if self.Config.ToolTokens and not Runtime:FindTool(self.Config.ToolTokens) then
            return false, "Waiting for " .. table.concat(self.Config.ToolTokens, "/") .. " tool"
        end
        if self.Config.Walk then
            local movementAvailable, movementOwner = Runtime:CanUseMovement(self, self.Config.MovementPriority)
            if not movementAvailable then return false, "Movement is currently controlled by " .. tostring(movementOwner) end
        end

        local query = {
            Scope = self.Config.Scope or "Workspace",
            TargetNames = self.Config.TargetNames,
            TargetTokens = self.Config.TargetTokens,
            RequiredTokens = self.Config.RequiredTokens,
            ExcludeTokens = self.Config.ExcludeTokens,
            TargetClasses = self.Config.TargetClasses or {"Model", "BasePart", "ProximityPrompt", "ClickDetector"},
            MaxTargets = self.Config.MaxTargets or 140,
        }
        query.PreferInteractive = true
        query.MaxDistance = self.Config.Walk and nil or self.Config.MaxDistance
        local target, distance = Runtime:FindBestTarget(query, root.Position)

        if not target then return false, self.Config.WaitingMessage end
        if self.Config.MaxDistance and distance > self.Config.MaxDistance then
            if self.Config.Walk then
                local moved, detail = Runtime:MoveTo(getPosition(target), self, self.Config)
                return moved, moved and ("Walking to " .. target.Name) or detail
            end
            return false, "Nearest target is " .. math.floor(distance) .. " studs away"
        end
        if self.Config.ToolTokens then Runtime:EquipTool(Runtime:FindTool(self.Config.ToolTokens)) end
        local cooldown = self.Config.ActionCooldown or 0.45
        if os.clock() - (self.LastAction or 0) < cooldown then
            return true, "Target detected — interaction cooling down"
        end
        local ok, detail = Runtime:Interact(target, self, {Priority = self.Config.ActionPriority or 55, Duration = cooldown})
        if ok then self.LastAction = os.clock() end
        return ok, ok and ("Interacted with " .. target.Name) or detail
    end)
end

getOtherCharacterTargets = function(config)
    local targets = {}
    local localPlayer = getLocalPlayer()
    for _, player in ipairs(Players:GetPlayers()) do
        if player ~= localPlayer and player.Character then
            local humanoid = player.Character:FindFirstChildOfClass("Humanoid")
            local root = player.Character:FindFirstChild("HumanoidRootPart")
            local text = lower(player.Name .. " " .. player.DisplayName .. " " .. (player.Team and player.Team.Name or ""))
            if humanoid and root and humanoid.Health > 0
                and (not config.PlayerTokens or #config.PlayerTokens == 0 or containsAny(text, config.PlayerTokens))
                and not containsAny(text, config.ExcludePlayerTokens)
            then
                table.insert(targets, player.Character)
            end
        end
    end
    if config.IncludeNPCs then
        local now = os.clock()
        local cache = Runtime._NPCCharacterCache
        if not cache or now - cache.Time > 1.0 then
            local models = {}
            forEachIndexed("Workspace", {"Model"}, function(instance)
                if not Players:GetPlayerFromCharacter(instance) then
                    local humanoid = instance:FindFirstChildOfClass("Humanoid")
                    local root = instance:FindFirstChild("HumanoidRootPart")
                    if humanoid and root then table.insert(models, instance) end
                end
                return true
            end)
            cache = {Time = now, Models = models}
            Runtime._NPCCharacterCache = cache
        end
        for _, instance in ipairs(cache.Models) do
            if instance.Parent then
                local humanoid = instance:FindFirstChildOfClass("Humanoid")
                local root = instance:FindFirstChild("HumanoidRootPart")
                if humanoid and root and humanoid.Health > 0
                    and (not config.TargetTokens or containsAny(instanceText(instance), config.TargetTokens))
                then
                    table.insert(targets, instance)
                end
            end
        end
    end
    return targets
end

local function nearestCharacter(config, origin)
    local best, distance = nil, math.huge
    for _, character in ipairs(getOtherCharacterTargets(config)) do
        local root = character:FindFirstChild("HumanoidRootPart")
        if root then
            local d = (root.Position - origin).Magnitude
            if d < distance then best, distance = character, d end
        end
    end
    return best, distance
end

local function startToolAura(feature)
    feature:_Loop(feature.Config.Interval or 0.18, function(self)
        local contextAllowed, contextDetail = Runtime:ContextAllowed(self.Config)
        if not contextAllowed then return false, contextDetail end
        local _, character, _, root = getCharacter()
        if not character or not root then return false, "Waiting for the local character" end
        local target, distance = nearestCharacter(self.Config, root.Position)
        if not target or distance > (self.Config.Range or 10) then
            return false, "Waiting for a target within " .. tostring(self.Config.Range or 10) .. " studs"
        end
        local targetRoot = target:FindFirstChild("HumanoidRootPart")
        if self.Config.FaceTarget and targetRoot then
            pcall(function()
                root.CFrame = CFrame.lookAt(root.Position, Vector3.new(targetRoot.Position.X, root.Position.Y, targetRoot.Position.Z))
            end)
        end
        local ok, detail = Runtime:ActivateTool(self.Config.ToolTokens or {}, self, {
            Resource = "CombatAction",
            Priority = self.Config.ActionPriority or 60,
            Duration = math.max(self.Config.Interval or 0.18, 0.22),
        })
        return ok, ok and ("Activated tool near " .. target.Name) or detail
    end)
end

local function rectsOverlap(a, b)
    if not a or not b then return false end
    local aMin, aMax = a.AbsolutePosition, a.AbsolutePosition + a.AbsoluteSize
    local bMin, bMax = b.AbsolutePosition, b.AbsolutePosition + b.AbsoluteSize
    return aMin.X <= bMax.X and aMax.X >= bMin.X and aMin.Y <= bMax.Y and aMax.Y >= bMin.Y
end

local function directGuiText(instance)
    if not instance then return "" end
    local parts = {instance.Name}
    if instance:IsA("TextLabel") or instance:IsA("TextButton") or instance:IsA("TextBox") then
        table.insert(parts, instance.Text)
    elseif instance:IsA("ImageButton") or instance:IsA("ImageLabel") then
        local ok, image = pcall(function() return instance.Image end)
        if ok and image then table.insert(parts, image) end
    end
    return lower(table.concat(parts, " "))
end

local function scoreGuiCandidate(instance, tokens)
    local direct = directGuiText(instance)
    local context = instanceText(instance)
    local score, hits = 0, 0
    for _, rawToken in ipairs(tokens or {}) do
        local token = lower(rawToken)
        if token ~= "" then
            if direct == token then
                score = score + 80 + math.min(#token, 24)
                hits = hits + 1
            elseif string.find(direct, token, 1, true) then
                score = score + 36 + math.min(#token, 20)
                hits = hits + 1
            elseif string.find(context, token, 1, true) then
                score = score + 12 + math.min(#token, 12)
                hits = hits + 1
            end
        end
    end
    if hits == 0 then return nil end

    if instance:IsA("GuiButton") then
        score = score + 18
        local ok, active = pcall(function() return instance.Active end)
        if ok and active then score = score + 8 end
        local okSelectable, selectable = pcall(function() return instance.Selectable end)
        if okSelectable and selectable then score = score + 4 end
    end
    local size = safeGuiVector(instance, "AbsoluteSize")
    local area = math.max(0, size.X) * math.max(0, size.Y)
    if area >= 400 then score = score + math.min(12, math.log(area + 1)) end
    score = score + math.min(10, safeGuiNumber(instance, "ZIndex", 0))

    -- Generic menu controls are common in the experience and can contain words
    -- such as "play" or "button" in their ancestors. Penalize them unless the
    -- requested token explicitly names that control.
    local menuWords = {"shop", "daily reward", "settings", "inventory", "purchase", "buy", "donate", "close", "cancel"}
    for _, word in ipairs(menuWords) do
        if string.find(context, word, 1, true) and not containsAny(word, tokens or {}) then
            score = score - 55
        end
    end
    return score
end

local function findVisibleGui(tokens, classes)
    local player = getLocalPlayer()
    local gui = player and player:FindFirstChildOfClass("PlayerGui")
    if not gui then return nil end
    local key = stableList(tokens) .. "|" .. stableList(classes or {"GuiObject"})
    Runtime._GuiQueryCache = Runtime._GuiQueryCache or {}
    local cached = Runtime._GuiQueryCache[key]
    local now = os.clock()
    if cached and now - cached.Time < 0.18 then
        if cached.Instance and cached.Instance.Parent and isVisibleGui(cached.Instance) then
            return cached.Instance
        elseif cached.Instance == nil then
            return nil
        end
    end

    local found, bestScore = nil, -math.huge
    forEachIndexed("Gui", classes or {"GuiObject"}, function(instance)
        if classAllowed(instance, classes or {"GuiObject"}) and isVisibleGui(instance)
            and not isSquidNoMoGui(instance)
        then
            local score = scoreGuiCandidate(instance, tokens or {})
            if score and score > bestScore then
                found, bestScore = instance, score
            end
        end
        return true
    end)
    Runtime._GuiQueryCache[key] = {Time = now, Instance = found}
    return found
end

local function startTiming(feature)
    feature:_Loop(feature.Config.Interval or 0.03, function(self)
        local indicator = findVisibleGui(self.Config.IndicatorTokens or {"indicator", "pointer", "cursor", "needle"})
        local zone = findVisibleGui(self.Config.ZoneTokens or {"sweetspot", "sweet spot", "safezone", "safe zone", "bluezone", "greenzone", "target"})
        if indicator and zone then
            local claimed, ownerName = Runtime:ClaimAction(
                self,
                "GuiAction",
                self.Config.ActionPriority or 80,
                math.max(self.Config.Interval or 0.05, 0.22)
            )
            if not claimed then
                return false, "Timing input is currently controlled by " .. tostring(ownerName)
            end
            if rectsOverlap(indicator, zone) then
                if os.clock() - self.LastAction >= (self.Config.ActionCooldown or 0.35) then
                    local action = findVisibleGui(self.Config.ActionTokens or {"pull", "throw", "hit", "play", "tap", "button"}, {"GuiButton"})
                    local ok, detail = Runtime:ClickGui(action or indicator, self, {
                        Resource = "GuiAction",
                        Priority = self.Config.ActionPriority or 80,
                        Duration = self.Config.ActionCooldown or 0.35,
                    })
                    if ok then self.LastAction = os.clock() end
                    return ok, ok and "Pressed at the target timing zone" or detail
                end
                return true, "Timing zone detected"
            end
            return true, "Timing meter detected — waiting for the target zone"
        end
        local action = findVisibleGui(self.Config.ActionTokens or {}, {"GuiButton"})
        if self.Config.ClickActionWhenVisible and action and os.clock() - self.LastAction >= (self.Config.ActionCooldown or 0.5) then
            local ok, detail = Runtime:ClickGui(action, self, {
                Resource = "GuiAction",
                Priority = self.Config.ActionPriority or 80,
                Duration = self.Config.ActionCooldown or 0.5,
            })
            if ok then self.LastAction = os.clock() end
            return ok, ok and ("Pressed " .. action.Name) or detail
        end
        return false, self.Config.WaitingMessage or "Waiting for the minigame timing interface"
    end)
end

local function startGuiAction(feature)
    feature:_Loop(feature.Config.Interval or 0.2, function(self)
        local action = findVisibleGui(self.Config.ActionTokens or self.Config.TargetTokens or {}, {"GuiButton"})
        if not action then return false, self.Config.WaitingMessage or "Waiting for the matching game button" end
        if os.clock() - self.LastAction < (self.Config.ActionCooldown or 0.5) then return true, "Action control detected" end
        local ok, detail = Runtime:ClickGui(action, self, {
            Resource = "GuiAction",
            Priority = self.Config.ActionPriority or 50,
            Duration = self.Config.ActionCooldown or 0.5,
        })
        if ok then self.LastAction = os.clock() end
        return ok, ok and ("Pressed " .. action.Name) or detail
    end)
end

local SharedGroundSample = {Time = 0, Character = nil, Root = nil, Hit = nil, CFrame = nil}
local SharedGroundRayParams = RaycastParams.new()
SharedGroundRayParams.FilterType = Enum.RaycastFilterType.Exclude

local function sampleGround(character, humanoid, root)
    local now = os.clock()
    if SharedGroundSample.Character == character and SharedGroundSample.Root == root
        and now - SharedGroundSample.Time < 0.075
    then
        return SharedGroundSample.Hit, SharedGroundSample.CFrame
    end
    SharedGroundRayParams.FilterDescendantsInstances = character and {character} or {}
    local hit = Workspace:Raycast(root.Position, Vector3.new(0, -8, 0), SharedGroundRayParams)
    local safeCFrame = hit and humanoid.FloorMaterial ~= Enum.Material.Air and root.CFrame or nil
    SharedGroundSample = {
        Time = now,
        Character = character,
        Root = root,
        Hit = hit,
        CFrame = safeCFrame,
    }
    return hit, safeCFrame
end

local function startAntiFall(feature)
    feature.SafeCFrame = nil
    feature:_Loop(feature.Config.Interval or 0.12, function(self)
        local _, character, humanoid, root = getCharacter()
        if not humanoid or not root then return false, "Waiting for the local character" end
        local _, safeCFrame = sampleGround(character, humanoid, root)
        if safeCFrame then
            self.SafeCFrame = safeCFrame
            return true, "Safe position tracked"
        end
        if self.SafeCFrame and (root.Position.Y < self.SafeCFrame.Position.Y - (self.Config.DropDistance or 18)
            or root.AssemblyLinearVelocity.Y < -(self.Config.FallVelocity or 75))
        then
            local claimed, ownerName = Runtime:ClaimAction(
                self,
                "Recovery",
                self.Config.RecoveryPriority or 70,
                0.8
            )
            if not claimed then
                return true, "Fall recovery is currently controlled by " .. tostring(ownerName)
            end
            root.AssemblyLinearVelocity = Vector3.zero
            root.CFrame = self.SafeCFrame + Vector3.new(0, 2.5, 0)
            return true, "Recovered from a fall"
        end
        return true, "Monitoring fall state"
    end)
end

local function statusWord(value)
    local text = lower(value)
    if text == "red" or text == "redlight" or text == "red light" then return "Red" end
    if text == "green" or text == "greenlight" or text == "green light" then return "Green" end
    if string.find(text, "red light", 1, true) or string.find(text, "stop moving", 1, true)
        or string.find(text, "movement forbidden", 1, true)
    then
        return "Red"
    end
    if string.find(text, "green light", 1, true) or string.find(text, "you may move", 1, true)
        or string.find(text, "movement allowed", 1, true)
    then
        return "Green"
    end
    return nil
end

local function contextualStatusWord(value, context)
    local state = statusWord(value)
    if state then return state end
    if not containsAny(context, {"light", "rlgl", "doll", "younghee", "mugunghwa", "signal", "phase", "round state"}) then
        return nil
    end
    local text = lower(value)
    if text == "stop" or text == "freeze" or text == "false" or text == "0" then return "Red" end
    if text == "go" or text == "move" or text == "true" or text == "1" then return "Green" end
    return nil
end

local function rlglColorState(color)
    if typeof(color) ~= "Color3" then return nil end
    local r, g, b = color.R, color.G, color.B
    if g >= 0.42 and g > r * 1.28 and g > b * 1.12 then return "Green" end
    if r >= 0.48 and r > g * 1.30 and r > b * 1.12 then return "Red" end
    return nil
end

local function discoverRLGLSignals()
    local candidates = {}
    local likelyNames = {"light", "status", "state", "phase", "signal", "current", "red", "green"}
    for _, scope in ipairs({"Workspace", "ReplicatedStorage"}) do
        forEachIndexed(scope, {"ValueBase"}, function(instance)
            if containsAny(instance.Name, likelyNames) then
                table.insert(candidates, instance)
            end
            return true
        end)
    end
    local player = getLocalPlayer()
    local gui = player and player:FindFirstChildOfClass("PlayerGui")
    if gui then
        forEachIndexed("Gui", {"TextLabel", "TextButton"}, function(instance)
            local context = instanceText(instance)
            if not isSquidNoMoGui(instance) and (containsAny(context, likelyNames) or statusWord(instance.Text)) then
                table.insert(candidates, instance)
            end
            return true
        end)
    end
    Runtime._RLGLSignalCandidates = candidates
    Runtime._RLGLSignalsScannedAt = os.clock()
    return candidates
end

local function findStatusText(tokens)
    local now = os.clock()
    local cached = Runtime._StatusTextCache
    if cached and now - cached.Time < 0.08 then return cached.Value, cached.Instance end

    local candidates = Runtime._RLGLSignalCandidates
    if not candidates or now - (Runtime._RLGLSignalsScannedAt or 0) > 2.0 then
        candidates = discoverRLGLSignals()
    end

    -- Vote across every live signal instead of trusting whichever object happens
    -- to be returned first. When old red/green labels are both still present, a
    -- tie becomes Unknown, which is safer than moving or applying recovery input.
    local scores = {Red = 0, Green = 0}
    local bestInstance = {Red = nil, Green = nil}
    local bestWeight = {Red = 0, Green = 0}
    local liveCount = 0
    for _, instance in ipairs(candidates) do
        if instance and instance.Parent then
            liveCount = liveCount + 1
            local state, weight
            if instance:IsA("ValueBase") then
                local context = instanceText(instance)
                state = statusWord(instance.Value)
                weight = state and 7 or 0
                if not state then
                    state = contextualStatusWord(instance.Value, context)
                    weight = state and 4 or 0
                end
                if instance:IsA("BoolValue") then
                    local name = lower(instance.Name)
                    if string.find(name, "red", 1, true) then
                        state, weight = instance.Value and "Red" or "Green", 8
                    elseif string.find(name, "green", 1, true) then
                        state, weight = instance.Value and "Green" or "Red", 8
                    end
                end
            elseif isVisibleGui(instance) then
                state = statusWord(instance.Text)
                weight = state and 6 or 0
                if not state then
                    state = contextualStatusWord(instance.Text, instanceText(instance))
                    weight = state and 3 or 0
                end
                if not state then
                    local context = instanceText(instance)
                    if containsAny(context, {"light", "status", "signal", "stop", "go", "doll"}) then
                        local okText, textColor = pcall(function() return instance.TextColor3 end)
                        local okBackground, backgroundColor = pcall(function() return instance.BackgroundColor3 end)
                        state = (okText and rlglColorState(textColor))
                            or (okBackground and rlglColorState(backgroundColor))
                        weight = state and 4 or 0
                    end
                end
            end
            if state and weight and weight > 0 then
                scores[state] = scores[state] + weight
                if weight > bestWeight[state] then
                    bestWeight[state] = weight
                    bestInstance[state] = instance
                end
            end
        end
    end

    if liveCount == 0 or now - (Runtime._RLGLSignalsScannedAt or 0) > 0.75 then
        Runtime._RLGLSignalCandidates = nil
    end

    local value, instance
    local margin = math.abs(scores.Red - scores.Green)
    if scores.Red >= 4 and scores.Red > scores.Green and margin >= 2 then
        value, instance = "Red", bestInstance.Red
    elseif scores.Green >= 4 and scores.Green > scores.Red and margin >= 2 then
        value, instance = "Green", bestInstance.Green
    end
    Runtime._StatusTextCache = {Time = now, Value = value, Instance = instance}
    return value, instance
end

function Runtime:GetRLGLState()
    local candidate = findStatusText({"light", "status", "state"})
    local now = os.clock()
    if candidate ~= self._RLGLCandidate then
        self._RLGLCandidate = candidate
        self._RLGLCandidateAt = now
    end
    if candidate and now - (self._RLGLCandidateAt or now) >= 0.10 then
        self._RLGLStableState = candidate
    elseif not candidate and now - (self._RLGLCandidateAt or now) >= 0.35 then
        self._RLGLStableState = nil
    end
    return self._RLGLStableState
end

local function startRLGLAutoMove(feature)
    feature.Config.MovementPriority = feature.Config.MovementPriority or 95
    feature:_Loop(feature.Config.Interval or 0.10, function(self)
        local _, _, humanoid, root = getCharacter()
        if not humanoid or not root then return false, "Waiting for the local character" end
        local state = Runtime:GetRLGLState()
        if state ~= "Green" then
            Runtime:StopMovement(self, state == "Red")
            if state == "Red" then return false, "Red light detected — fully stopped" end
            return false, "Waiting for an unambiguous red/green signal"
        end

        local target = Runtime:FindNearest({
            Scope = "Workspace",
            TargetTokens = self.Config.TargetTokens or {"finish", "end zone", "safe zone", "goal"},
            ExcludeTokens = {"start", "spawn"},
            TargetClasses = {"BasePart", "Model"},
            ReturnAdornee = true,
            MaxTargets = 40,
            CacheTTL = 2.0,
        }, root.Position)
        if not target then
            target = Runtime:FindNearest({
                Scope = "Workspace",
                TargetTokens = {"doll", "younghee", "young hee", "mugunghwa"},
                TargetClasses = {"Model", "BasePart"},
                ReturnAdornee = true,
                MaxTargets = 20,
                CacheTTL = 2.0,
            }, root.Position)
        end
        local position = getPosition(target)
        if not position then
            Runtime:StopMovement(self)
            return false, "Green light detected; waiting for the finish area"
        end

        local moved, detail = Runtime:MoveTo(position, self, {
            StopDistance = 8,
            Direct = true,
            MovementPriority = 95,
            CommandInterval = 0.65,
            LeaseDuration = 0.9,
        })
        return moved, moved and "Green light detected — moving at normal character speed" or detail
    end)
end

local function closestPointOnPart(part, worldPosition)
    if not part or not part:IsA("BasePart") then return nil end
    local localPoint = part.CFrame:PointToObjectSpace(worldPosition)
    local half = part.Size * 0.5
    local clamped = Vector3.new(
        math.clamp(localPoint.X, -half.X, half.X),
        math.clamp(localPoint.Y, -half.Y, half.Y),
        math.clamp(localPoint.Z, -half.Z, half.Z)
    )
    return part.CFrame:PointToWorldSpace(clamped)
end

local RopeGeometryHistory = setmetatable({}, {__mode = "k"})

local function findGeometricRope(root)
    if not root then return nil end
    local now = os.clock()
    local cached = Runtime._RopeGeometryCache
    if cached and now - cached.Time < 0.12 and cached.Target and cached.Target.Parent then
        return cached.Target
    end

    local best, bestScore = nil, -math.huge
    local scanned = 0
    forEachIndexed("Workspace", {"BasePart"}, function(part)
        if scanned >= 520 then return false end
        scanned = scanned + 1
        if not part.Parent or part:IsDescendantOf(root.Parent) then return true end

        local offset = part.Position - root.Position
        local distance = offset.Magnitude
        if distance > 120 or math.abs(offset.Y) > 36 then return true end

        local size = part.Size
        local longest = math.max(size.X, size.Y, size.Z)
        local shortest = math.min(size.X, size.Y, size.Z)
        local middle = size.X + size.Y + size.Z - longest - shortest
        if longest < 8 or shortest > 5.5 or middle > math.max(8, longest * 0.55) then return true end

        local history = RopeGeometryHistory[part]
        local elapsed = history and math.max(now - history.Time, 0.001) or 0
        local positionalSpeed = 0
        local rotationalSpeed = 0
        if history and elapsed <= 2.0 then
            positionalSpeed = (part.Position - history.Position).Magnitude / elapsed
            local lookDelta = 1 - math.abs(math.clamp(part.CFrame.LookVector:Dot(history.LookVector), -1, 1))
            local upDelta = 1 - math.abs(math.clamp(part.CFrame.UpVector:Dot(history.UpVector), -1, 1))
            rotationalSpeed = math.max(lookDelta, upDelta) * longest / elapsed
        end
        RopeGeometryHistory[part] = {
            Time = now,
            Position = part.Position,
            LookVector = part.CFrame.LookVector,
            UpVector = part.CFrame.UpVector,
        }

        local physicsSpeed = part.AssemblyLinearVelocity.Magnitude
            + part.AssemblyAngularVelocity.Magnitude * math.min(longest, 40)
        local motion = math.max(physicsSpeed, positionalSpeed, rotationalSpeed)
        if motion < 0.35 then return true end

        local score = motion * 2.4 + math.min(longest, 45) - distance * 0.10 - math.abs(offset.Y) * 0.25
        if containsAny(instanceText(part), {"rope", "bar", "swing", "spinner"}) then score = score + 35 end
        if score > bestScore then
            best, bestScore = part, score
        end
        return true
    end)
    Runtime._RopeGeometryCache = {Time = now, Target = best}
    return best
end

function Runtime:ObserveRope(feature, root, tokens)
    if not root then return nil end
    local target = self:FindNearest({
        Scope = "Workspace",
        TargetTokens = tokens or {"rope", "bar", "swing", "spinner", "sweep"},
        TargetClasses = {"BasePart"},
        MaxTargets = 100,
        CacheTTL = 0.08,
    }, root.Position)
    if not target then
        -- Current Jump Rope builds can use generic part names. Fall back to the
        -- long, slender moving obstacle the player can actually see instead of
        -- depending only on a guessed internal object name.
        target = findGeometricRope(root)
    end
    if not target then return nil end

    local point = closestPointOnPart(target, root.Position) or target.Position
    local distance = (point - root.Position).Magnitude
    local now = os.clock()
    local previous = feature._RopeObservation
    local approaching, speed = false, 0
    if previous and previous.Target == target then
        local elapsed = math.max(now - previous.Time, 0.001)
        speed = (point - previous.Point).Magnitude / elapsed
        approaching = distance < previous.Distance - 0.06
    end
    local observation = {
        Target = target,
        Point = point,
        Distance = distance,
        Vertical = point.Y - root.Position.Y,
        Approaching = approaching,
        Speed = speed,
        Time = now,
    }
    feature._RopeObservation = observation
    return observation
end

local function startAutoJump(feature)
    feature.LastJumpAt = 0
    feature:_Loop(feature.Config.Interval or 0.045, function(self)
        local _, _, humanoid, root = getCharacter()
        if not humanoid or not root then return false, "Waiting for the local character" end
        local observation = Runtime:ObserveRope(self, root, self.Config.TargetTokens or {"rope", "bar", "swing", "spinner", "sweep"})
        if not observation then return false, "Waiting for the moving rope" end

        local grounded = humanoid.FloorMaterial ~= Enum.Material.Air
        local trigger = self.Config.TriggerDistance or 17
        local closeEnough = observation.Distance <= trigger and math.abs(observation.Vertical) <= 10
        local emergency = observation.Distance <= math.max(4.5, trigger * 0.32)
        local cooldownReady = os.clock() - (self.LastJumpAt or 0) >= (self.Config.JumpCooldown or 0.62)

        if grounded and cooldownReady and closeEnough and (observation.Approaching or emergency) then
            humanoid.Jump = true
            humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
            self.LastJumpAt = os.clock()
            return true, string.format("Jumped as rope approached (%.1f studs)", observation.Distance)
        end
        if closeEnough then
            return true, observation.Approaching and "Rope approaching — preparing jump" or "Rope nearby — waiting for its next approach"
        end
        return false, string.format("Tracking rope (%.1f studs away)", observation.Distance)
    end)
end

local function startEvasion(feature)
    feature:_Loop(feature.Config.Interval or 0.2, function(self)
        local _, _, humanoid, root = getCharacter()
        if not humanoid or not root then return false, "Waiting for the local character" end
        local movementAvailable, movementOwner = Runtime:CanUseMovement(self, self.Config.MovementPriority or 70)
        if not movementAvailable then return false, "Movement is currently controlled by " .. tostring(movementOwner) end
        local target, distance = nearestCharacter(self.Config, root.Position)
        if not target or distance > (self.Config.Range or 20) then return false, "No nearby threat detected" end
        local targetRoot = target:FindFirstChild("HumanoidRootPart")
        if not targetRoot then return false, "Threat has no root part" end
        local direction = root.Position - targetRoot.Position
        if direction.Magnitude < 0.1 then direction = root.CFrame.RightVector end
        local moved, detail = Runtime:MoveTo(
            root.Position + direction.Unit * (self.Config.EvadeDistance or 18),
            self,
            {Direct = true, StopDistance = 3, MovementPriority = self.Config.MovementPriority or 70, CommandInterval = 0.35}
        )
        return moved, moved and ("Moving away from " .. target.Name) or detail
    end)
end

local function startBoundary(feature)
    feature:_Loop(feature.Config.Interval or 0.35, function(self)
        local _, _, humanoid, root = getCharacter()
        if not humanoid or not root then return false, "Waiting for the local character" end
        local movementAvailable, movementOwner = Runtime:CanUseMovement(self, self.Config.MovementPriority or 65)
        if not movementAvailable then return false, "Movement is currently controlled by " .. tostring(movementOwner) end
        local zone = Runtime:FindNearest({
            Scope = "Workspace",
            TargetNames = self.Config.TargetNames,
            TargetTokens = self.Config.TargetTokens,
            TargetClasses = {"BasePart", "Model"},
            ReturnAdornee = true,
        }, root.Position)
        local position = getPosition(zone)
        if not zone or not position then return false, self.Config.WaitingMessage end
        local radius = self.Config.Radius or 60
        if zone:IsA("BasePart") then radius = math.max(zone.Size.X, zone.Size.Z) * 0.45 end
        if (root.Position - position).Magnitude > radius then
            local moved, detail = Runtime:MoveTo(position, self, {
                Direct = true,
                StopDistance = math.max(6, radius * 0.35),
                MovementPriority = self.Config.MovementPriority or 65,
                CommandInterval = 0.5,
            })
            return moved, moved and "Returning to the active play area" or detail
        end
        return true, "Inside the active play area"
    end)
end

local function parseRequiredCount()
    return Runtime:GetMingleRequiredCount()
end

local function treeContainsNumber(target, number)
    local wanted = tostring(number)
    if string.find(instanceText(target), wanted, 1, true) then return true end
    local scanned = 0
    for _, child in ipairs(target:GetDescendants()) do
        if child:IsA("TextLabel") or child:IsA("TextButton") or child:IsA("ValueBase") or child:IsA("ProximityPrompt") then
            if string.find(instanceText(child), wanted, 1, true) then return true end
            scanned = scanned + 1
            if scanned >= 50 then break end
        end
    end
    return false
end

local function roomOccupancy(target)
    for _, valueName in ipairs({"Occupants", "Occupancy", "PlayerCount", "PlayersInside", "Count"}) do
        local value = target:FindFirstChild(valueName, true)
        if value and value:IsA("ValueBase") then
            local number = tonumber(value.Value)
            if number then return number end
        end
    end

    local center, size
    if target:IsA("Model") then
        local ok, cframe, bounds = pcall(target.GetBoundingBox, target)
        if ok then center, size = cframe, bounds end
    elseif target:IsA("BasePart") then
        center, size = target.CFrame, target.Size
    else
        local adornee = getAdornee(target)
        if adornee and adornee:IsA("Model") then
            local ok, cframe, bounds = pcall(adornee.GetBoundingBox, adornee)
            if ok then center, size = cframe, bounds end
        elseif adornee and adornee:IsA("BasePart") then
            center, size = adornee.CFrame, adornee.Size
        end
    end
    if not center or not size then return nil end

    local count = 0
    for _, other in ipairs(Players:GetPlayers()) do
        local otherRoot = other.Character and other.Character:FindFirstChild("HumanoidRootPart")
        if otherRoot then
            local point = center:PointToObjectSpace(otherRoot.Position)
            if math.abs(point.X) <= size.X * 0.6
                and math.abs(point.Y) <= math.max(size.Y * 0.7, 8)
                and math.abs(point.Z) <= size.Z * 0.6
            then
                count = count + 1
            end
        end
    end
    return count
end

local function startRoomAssist(feature)
    feature:_Loop(feature.Config.Interval or 0.32, function(self)
        local phase = Runtime:GetMinglePhase()
        if phase == "Carousel" then return false, "Waiting for the Mingle room number" end
        if phase == "Locked" then
            Runtime:StopMovement(self)
            return true, "Room is locked — holding position"
        end
        local count = parseRequiredCount()
        if not count then return false, "Waiting for the visible Mingle room count" end
        local _, _, _, root = getCharacter()
        if not root then return false, "Waiting for the local character" end
        local movementAvailable, movementOwner = Runtime:CanUseMovement(self, self.Config.MovementPriority or 60)
        if not movementAvailable then return false, "Movement is currently controlled by " .. tostring(movementOwner) end

        local candidates = Runtime:FindTargets({
            Scope = "Workspace",
            TargetTokens = {"room", "door", "mingle", "capacity", "enter", "join", "open"},
            TargetClasses = {"Model", "BasePart", "ProximityPrompt"},
            MaxTargets = 220,
            CacheTTL = 0.28,
        })
        local best, bestScore, bestOccupancy = nil, -math.huge, nil
        for _, target in ipairs(candidates) do
            local capacity = target:FindFirstChild("Capacity", true)
            local capacityNumber = capacity and capacity:IsA("ValueBase") and tonumber(capacity.Value) or nil
            local capacityMatch = capacityNumber == count or treeContainsNumber(target, count)
            local position = getPosition(target)
            if capacityMatch and position then
                local occupancy = roomOccupancy(target)
                local hasSpace = occupancy == nil or occupancy < count
                if hasSpace then
                    local distance = (position - root.Position).Magnitude
                    -- Prefer a partly filled matching room, then the nearest one.
                    local fillBonus = occupancy and occupancy * 18 or 0
                    local score = fillBonus - distance
                    if score > bestScore then
                        best, bestScore, bestOccupancy = target, score, occupancy
                    end
                end
            end
        end
        if not best then return false, "No open room matching " .. count .. " players was detected" end

        local position = getPosition(best)
        local moved, detail = Runtime:MoveTo(position, self, {
            StopDistance = 6,
            MaxWaypoints = 4,
            MovementPriority = self.Config.MovementPriority or 60,
            HoldLeaseAtTarget = 0.75,
            RepathInterval = 0.65,
        })
        local _, _, _, currentRoot = getCharacter()
        if self.Config.Interact and currentRoot and (currentRoot.Position - position).Magnitude <= 10 then
            Runtime:Interact(best, self, {Priority = self.Config.ActionPriority or 60, Duration = self.Config.ActionCooldown or 0.6})
        end
        local occupancyText = bestOccupancy ~= nil and ("; " .. bestOccupancy .. "/" .. count .. " inside") or ""
        return moved, moved and ("Heading to a " .. count .. "-player room" .. occupancyText) or detail
    end)
end

local function startAimActivate(feature)
    feature:_Loop(feature.Config.Interval or 0.12, function(self)
        local _, _, _, root = getCharacter()
        if not root then return false, "Waiting for the local character" end
        local target, distance = Runtime:FindNearest({
            Scope = self.Config.Scope or "Workspace",
            TargetTokens = self.Config.TargetTokens,
            TargetNames = self.Config.TargetNames,
            ExcludeTokens = self.Config.ExcludeTokens,
            TargetClasses = {"Model", "BasePart"},
            ReturnAdornee = true,
        }, root.Position)
        local position = getPosition(target)
        if not position or distance > (self.Config.Range or 100) then return false, self.Config.WaitingMessage end
        local camera = Workspace.CurrentCamera
        if camera then camera.CFrame = CFrame.lookAt(camera.CFrame.Position, position) end
        local ok, detail = Runtime:ActivateTool(self.Config.ToolTokens or {}, self, {
            Resource = "AimAction",
            Priority = self.Config.ActionPriority or 65,
            Duration = math.max(self.Config.Interval or 0.12, 0.25),
        })
        return ok, ok and ("Aimed at " .. target.Name .. " and activated the tool") or detail
    end)
end

local function startDisguise(feature)
    feature:_Loop(feature.Config.Interval or 0.5, function(self)
        local player, character, _, root = getCharacter()
        if not player or not character or not root then return false, "Waiting for the local character" end

        local detective = Runtime:GetDetectiveState()
        local detectionHigh = detective.Detection and detective.Detection >= (self.Config.DetectionThreshold or 0.58)
        local guardNearby = false
        for _, other in ipairs(Players:GetPlayers()) do
            if other ~= player and other.Character then
                local otherRoot = other.Character:FindFirstChild("HumanoidRootPart")
                local roleText = lower((other.Team and other.Team.Name or "") .. " " .. other.Name .. " " .. other.DisplayName)
                if otherRoot and containsAny(roleText, self.Config.PlayerTokens or {"guard", "staff"})
                    and (otherRoot.Position - root.Position).Magnitude <= (self.Config.Range or 35)
                then
                    guardNearby = true
                    break
                end
            end
        end

        if not guardNearby and not detectionHigh then
            return false, detective.Detection
                and ("Detection meter is " .. math.floor(detective.Detection * 100 + 0.5) .. "%")
                or "No nearby guard or high detection warning"
        end

        local tool = Runtime:FindTool(self.Config.ToolTokens or {})
        if tool then
            local ok = Runtime:EquipTool(tool)
            if ok then
                pcall(tool.Activate, tool)
                return true, detectionHigh and "Changed disguise before detection became critical" or "Equipped disguise near a guard"
            end
        end

        local station, distance = Runtime:FindNearest({
            Scope = "Workspace",
            TargetTokens = self.Config.ToolTokens or {"disguise", "uniform", "mask", "guard outfit"},
            TargetClasses = {"ProximityPrompt", "ClickDetector", "Model", "BasePart", "Tool"},
            MaxTargets = 80,
        }, root.Position)
        if station then
            if distance > 11 then
                local moved, detail = Runtime:MoveTo(getPosition(station), self, {
                    StopDistance = 9,
                    MovementPriority = self.Config.MovementPriority or 82,
                    MaxWaypoints = 4,
                })
                return moved, moved and "Moving to a disguise station" or detail
            end
            local ok, detail = Runtime:Interact(station, self, {Priority = 82, Duration = 0.7})
            return ok, ok and "Activated a disguise station" or detail
        end
        return false, "Detection risk found, but no disguise tool or station is available"
    end)
end

local function startRadar(feature)
    local gui = Instance.new("ScreenGui")
    gui.Name = "SquidNoMo_Radar_" .. feature.Id
    gui.ResetOnSpawn = false
    gui.IgnoreGuiInset = true
    gui.DisplayOrder = 999985
    local guiParent = getGuiParent()
    if not guiParent then error("no compatible GUI parent is available") end
    gui.Parent = guiParent
    feature:_TrackInstance(gui)

    local frame = Instance.new("Frame")
    frame.AnchorPoint = Vector2.new(1, 0)
    frame.Position = UDim2.new(1, -18, 0, 84)
    frame.Size = UDim2.fromOffset(176, 176)
    frame.BackgroundColor3 = Color3.fromRGB(10, 15, 21)
    frame.BackgroundTransparency = 0.12
    frame.BorderSizePixel = 0
    frame.ClipsDescendants = true
    frame.Parent = gui

    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 16)
    corner.Parent = frame

    local stroke = Instance.new("UIStroke")
    stroke.Color = feature.Config.Color or Color3.fromRGB(42, 255, 126)
    stroke.Transparency = 0.2
    stroke.Thickness = 1.5
    stroke.Parent = frame

    local title = Instance.new("TextLabel")
    title.Size = UDim2.new(1, 0, 0, 28)
    title.BackgroundTransparency = 1
    title.Font = Enum.Font.GothamBold
    title.Text = feature.Config.Title or "MAP RADAR"
    title.TextColor3 = Color3.fromRGB(235, 240, 245)
    title.TextSize = 14
    title.Parent = frame

    local field = Instance.new("Frame")
    field.Position = UDim2.fromOffset(10, 32)
    field.Size = UDim2.new(1, -20, 1, -42)
    field.BackgroundColor3 = Color3.fromRGB(15, 23, 30)
    field.BackgroundTransparency = 0.18
    field.BorderSizePixel = 0
    field.ClipsDescendants = true
    field.Parent = frame
    local fieldCorner = Instance.new("UICorner")
    fieldCorner.CornerRadius = UDim.new(0, 12)
    fieldCorner.Parent = field

    local center = Instance.new("Frame")
    center.AnchorPoint = Vector2.new(0.5, 0.5)
    center.Position = UDim2.fromScale(0.5, 0.5)
    center.Size = UDim2.fromOffset(8, 8)
    center.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    center.BorderSizePixel = 0
    center.Parent = field
    local centerCorner = Instance.new("UICorner")
    centerCorner.CornerRadius = UDim.new(1, 0)
    centerCorner.Parent = center

    feature.RadarDots = {}

    local function getDot(self, target, color)
        local dot = self.RadarDots[target]
        if dot and dot.Parent then
            dot.BackgroundColor3 = color
            return dot
        end
        dot = Instance.new("Frame")
        dot.Name = "Dot"
        dot.AnchorPoint = Vector2.new(0.5, 0.5)
        dot.Size = UDim2.fromOffset(7, 7)
        dot.BackgroundColor3 = color
        dot.BorderSizePixel = 0
        dot.Parent = field
        local dotCorner = Instance.new("UICorner")
        dotCorner.CornerRadius = UDim.new(1, 0)
        dotCorner.Parent = dot
        self.RadarDots[target] = dot
        self:_TrackInstance(dot)
        return dot
    end

    feature:_Loop(feature.Config.Interval or 0.16, function(self)
        local _, _, _, root = getCharacter()
        if not root then return false, "Waiting for the local character" end

        local range = feature.Config.Range or 150
        local seen = {}
        local count = 0

        for _, character in ipairs(getOtherCharacterTargets({
            PlayerTokens = feature.Config.PlayerTokens,
            ExcludePlayerTokens = feature.Config.ExcludePlayerTokens,
        })) do
            local targetRoot = character:FindFirstChild("HumanoidRootPart")
            if targetRoot then
                local offset = targetRoot.Position - root.Position
                local x = math.clamp(offset.X / range, -1, 1)
                local y = math.clamp(offset.Z / range, -1, 1)
                local dot = getDot(feature, character, feature.Config.PlayerColor or Color3.fromRGB(255, 86, 110))
                dot.Position = UDim2.fromScale(0.5 + x * 0.46, 0.5 + y * 0.46)
                dot.Visible = math.abs(offset.X) <= range and math.abs(offset.Z) <= range
                seen[character] = true
                count = count + 1
            end
        end

        if feature.Config.TargetTokens then
            for _, target in ipairs(Runtime:FindTargets({
                Scope = "Workspace",
                TargetTokens = feature.Config.TargetTokens,
                TargetClasses = {"Model", "BasePart", "ProximityPrompt"},
                ReturnAdornee = true,
                MaxTargets = feature.Config.MaxTargets or 24,
            })) do
                local position = getPosition(target)
                if position then
                    local offset = position - root.Position
                    local x = math.clamp(offset.X / range, -1, 1)
                    local y = math.clamp(offset.Z / range, -1, 1)
                    local dot = getDot(feature, target, feature.Config.TargetColor or Color3.fromRGB(255, 220, 80))
                    dot.Position = UDim2.fromScale(0.5 + x * 0.46, 0.5 + y * 0.46)
                    dot.Visible = math.abs(offset.X) <= range and math.abs(offset.Z) <= range
                    seen[target] = true
                    count = count + 1
                end
            end
        end

        for target, dot in pairs(self.RadarDots) do
            local alive = false
            pcall(function() alive = target ~= nil and target.Parent ~= nil end)
            if not seen[target] or not alive then
                if dot and dot.Parent then dot.Visible = false end
                if not alive then self.RadarDots[target] = nil end
            end
        end
        return count > 0, count > 0 and ("Radar tracking " .. count .. " target(s)") or "Waiting for radar targets"
    end)
end

local function startCourseAssist(feature)
    feature.LastJumpAt = 0
    feature:_Loop(feature.Config.Interval or 0.10, function(self)
        local _, character, humanoid, root = getCharacter()
        if not humanoid or not root or not character then return false, "Waiting for the local character" end
        local movementAvailable, movementOwner = Runtime:CanUseMovement(self, self.Config.MovementPriority or 65)
        if not movementAvailable then return false, "Movement is currently controlled by " .. tostring(movementOwner) end

        local finish = Runtime:FindNearest({
            Scope = "Workspace",
            TargetTokens = self.Config.TargetTokens or {"finish", "end", "goal", "exit", "safe zone"},
            ExcludeTokens = {"start", "spawn"},
            TargetClasses = {"BasePart", "Model", "ProximityPrompt"},
            ReturnAdornee = true,
            MaxTargets = 120,
            CacheTTL = 0.65,
        }, root.Position)
        local finishPosition = getPosition(finish)
        if not finishPosition then return false, self.Config.WaitingMessage or "Waiting for the Jump Rope finish area" end

        local rope = Runtime:ObserveRope(self, root, self.Config.ObstacleTokens or {"rope", "swing", "bar", "spinner", "sweep"})
        local grounded = humanoid.FloorMaterial ~= Enum.Material.Air
        if rope then
            local dangerDistance = self.Config.JumpDistance or 17
            if grounded and os.clock() - (self.LastJumpAt or 0) >= 0.62
                and rope.Distance <= dangerDistance
                and math.abs(rope.Vertical) <= 10
                and (rope.Approaching or rope.Distance <= 5)
            then
                Runtime:StopMovement(self)
                humanoid.Jump = true
                humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
                self.LastJumpAt = os.clock()
                return true, string.format("Jumping the approaching rope (%.1f studs)", rope.Distance)
            elseif rope.Approaching and rope.Distance <= dangerDistance * 1.18 then
                Runtime:StopMovement(self)
                return true, "Holding position until the approaching rope can be jumped"
            end
        end

        -- The visual course has a gap in the bridge. Check a short distance ahead
        -- toward the finish and jump instead of walking into empty space.
        local flatDirection = Vector3.new(finishPosition.X - root.Position.X, 0, finishPosition.Z - root.Position.Z)
        if grounded and flatDirection.Magnitude > 0.1 and os.clock() - (self.LastJumpAt or 0) >= 0.62 then
            local ahead = root.Position + flatDirection.Unit * 5
            local params = RaycastParams.new()
            params.FilterType = Enum.RaycastFilterType.Exclude
            params.FilterDescendantsInstances = {character}
            local groundAhead = Workspace:Raycast(ahead + Vector3.new(0, 2, 0), Vector3.new(0, -9, 0), params)
            if not groundAhead then
                humanoid.Jump = true
                humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
                self.LastJumpAt = os.clock()
                return true, "Jumping the bridge gap"
            end
        end

        local moved, detail = Runtime:MoveTo(finishPosition, self, {
            Direct = true,
            StopDistance = self.Config.StopDistance or 7,
            MovementPriority = self.Config.MovementPriority or 65,
            CommandInterval = 0.38,
            LeaseDuration = 0.48,
            TargetChangeDistance = 4,
        })
        return moved, moved and "Advancing during a safe rope window" or detail
    end)
end

local function startPositionKeeper(feature)
    local _, _, _, initialRoot = getCharacter()
    feature.AnchorPosition = initialRoot and initialRoot.Position or nil
    feature:_Loop(feature.Config.Interval or 0.25, function(self)
        local _, _, _, root = getCharacter()
        if not root then return false, "Waiting for the local character" end
        if not self.AnchorPosition then
            self.AnchorPosition = root.Position
            return true, "Saved the preferred lane"
        end

        if string.find(lower(self.Id), "mapped.games.jump_rope.", 1, true) then
            local finish = Runtime:FindNearest({
                Scope = "Workspace",
                TargetTokens = {"finish", "end", "goal", "exit", "safe zone"},
                ExcludeTokens = {"start", "spawn"},
                TargetClasses = {"BasePart", "Model"},
                ReturnAdornee = true,
                MaxTargets = 100,
                CacheTTL = 1.0,
            }, root.Position)
            local finishPosition = getPosition(finish)
            if not finishPosition then return false, "Waiting for the Jump Rope finish direction" end
            local direction = Vector3.new(finishPosition.X - self.AnchorPosition.X, 0, finishPosition.Z - self.AnchorPosition.Z)
            if direction.Magnitude < 1 then return false, "Finish direction is not ready" end
            direction = direction.Unit
            local displacement = Vector3.new(root.Position.X - self.AnchorPosition.X, 0, root.Position.Z - self.AnchorPosition.Z)
            local forwardDistance = displacement:Dot(direction)
            local desired = self.AnchorPosition + direction * forwardDistance
            desired = Vector3.new(desired.X, root.Position.Y, desired.Z)
            local lateralError = (Vector3.new(root.Position.X, 0, root.Position.Z) - Vector3.new(desired.X, 0, desired.Z)).Magnitude
            if lateralError > (self.Config.MaxDistance or 7) then
                local moved, detail = Runtime:MoveTo(desired, self, {
                    Direct = true,
                    StopDistance = 1.5,
                    MovementPriority = self.Config.MovementPriority or 25,
                    CommandInterval = 0.45,
                    LeaseDuration = 0.5,
                })
                return moved, moved and "Recentering in the Jump Rope lane" or detail
            end
            return true, string.format("Centered in lane (%.1f studs lateral)", lateralError)
        end

        local distance = (root.Position - self.AnchorPosition).Magnitude
        if distance > (self.Config.MaxDistance or 8) then
            local moved, detail = Runtime:MoveTo(self.AnchorPosition, self, {
                Direct = true,
                StopDistance = self.Config.MaxDistance or 8,
                MovementPriority = 25,
                CommandInterval = 0.5,
            })
            return moved, moved and "Returning to the preferred position" or detail
        end
        return true, "Holding the preferred position"
    end)
end

local ObservedSafeGlass = setmetatable({}, {__mode = "k"})

local function updateObservedGlass()
    for _, player in ipairs(Players:GetPlayers()) do
        local character = player.Character
        local humanoid = character and character:FindFirstChildOfClass("Humanoid")
        local root = character and character:FindFirstChild("HumanoidRootPart")
        if humanoid and root and humanoid.Health > 0 and humanoid.FloorMaterial ~= Enum.Material.Air then
            local params = RaycastParams.new()
            params.FilterType = Enum.RaycastFilterType.Exclude
            params.FilterDescendantsInstances = {character}
            local hit = Workspace:Raycast(root.Position, Vector3.new(0, -8, 0), params)
            local part = hit and hit.Instance
            if part and part:IsA("BasePart") and containsAny(instanceText(part), {"glass", "panel", "tile", "bridge"}) then
                ObservedSafeGlass[part] = os.clock()
            end
        end
    end
end

local function glassSafety(part)
    for _, attributeName in ipairs({"Safe", "IsSafe", "Correct", "Real", "CanStand"}) do
        local ok, value = pcall(part.GetAttribute, part, attributeName)
        if ok and type(value) == "boolean" then return value end
    end
    local parent = part.Parent
    if parent then
        for _, valueName in ipairs({"Safe", "IsSafe", "Correct", "Real"}) do
            local value = parent:FindFirstChild(valueName)
            if value and value:IsA("BoolValue") then return value.Value end
        end
    end
    if ObservedSafeGlass[part] then return true end
    if part.CanCollide == false or part.Transparency > 0.85 then return false end
    return nil
end

local function glassParts()
    local now = os.clock()
    local cache = Runtime._GlassPartsCache
    if cache and now - cache.Time < 1.0 then
        local alive = {}
        for _, part in ipairs(cache.Results) do
            if part and part.Parent then table.insert(alive, part) end
        end
        return alive
    end
    local results = Runtime:FindTargets({
        Scope = "Workspace",
        TargetTokens = {"glass", "panel", "tile", "bridge"},
        TargetClasses = {"BasePart"},
        MaxTargets = 240,
        CacheTTL = 1.0,
    })
    Runtime._GlassPartsCache = {Time = now, Results = results}
    return results
end

local function startSafeTileWalk(feature)
    feature:_Loop(feature.Config.Interval or 0.35, function(self)
        local _, _, _, root = getCharacter()
        if not root then return false, "Waiting for the local character" end
        local movementAvailable, movementOwner = Runtime:CanUseMovement(self, self.Config.MovementPriority or 70)
        if not movementAvailable then return false, "Movement is currently controlled by " .. tostring(movementOwner) end
        updateObservedGlass()
        local best, bestDistance = nil, math.huge
        for _, part in ipairs(glassParts()) do
            local distance = (part.Position - root.Position).Magnitude
            if distance > (self.Config.MinimumDistance or 2) and distance < (self.Config.MaximumDistance or 55)
                and glassSafety(part) == true and distance < bestDistance
            then
                best, bestDistance = part, distance
            end
        end
        if not best then
            return false, "Waiting for a panel verified by attributes or another standing player"
        end
        local moved, detail = Runtime:MoveTo(best.Position + Vector3.new(0, 2.5, 0), self, {
            StopDistance = 4,
            MaxWaypoints = 2,
            WaypointTimeout = 0.75,
            MovementPriority = self.Config.MovementPriority or 70,
        })
        return moved, moved and "Walking to an observed-safe panel" or detail
    end)
end

local function startGlassESP(feature)
    feature.HighlightByTarget = {}
    feature:_Loop(feature.Config.Interval or 0.8, function(self)
        local count = 0
        for _, part in ipairs(glassParts()) do
            local safe = glassSafety(part)
            local color
            if safe == true then
                color = self.Config.SafeColor or Color3.fromRGB(60, 255, 126)
            elseif safe == false then
                color = self.Config.UnsafeColor or Color3.fromRGB(255, 80, 90)
            else
                color = self.Config.UnknownColor or Color3.fromRGB(255, 210, 70)
            end
            local highlight = self.HighlightByTarget[part]
            if not highlight or not highlight.Parent then
                highlight = Instance.new("Highlight")
                highlight.Name = "SquidNoMo_" .. self.Id
                highlight.Adornee = part
                highlight.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
                highlight.FillTransparency = 0.50
                highlight.OutlineTransparency = 0.02
                highlight.Parent = part
                self.HighlightByTarget[part] = highlight
                self:_TrackInstance(highlight)
            end
            highlight.FillColor = color
            highlight.OutlineColor = Color3.fromRGB(255, 255, 255)
            count = count + 1
        end
        return count > 0, count > 0 and ("Classified " .. count .. " bridge panel(s)") or "Waiting for bridge glass panels"
    end)
end

local function startTaskChain(feature)
    feature:_Loop(feature.Config.Interval or 0.55, function(self)
        local _, _, _, root = getCharacter()
        if not root then return false, "Waiting for the local character" end
        local movementAvailable, movementOwner = Runtime:CanUseMovement(self, self.Config.MovementPriority or 60)
        if not movementAvailable then return false, "Movement is currently controlled by " .. tostring(movementOwner) end

        local heldTool = Runtime:FindTool(self.Config.RequireToolTokens or {})
        local targetConfig
        local stageName
        local id = lower(self.Id)
        local forceDestination = false

        if string.find(id, "mapped.detective.boat_operations.boatdepositor", 1, true) then
            local detective = Runtime:GetDetectiveState()
            forceDestination = detective.Stage == "Deposit Evidence" or (detective.Evidence and detective.Evidence > 0)
            if not forceDestination and not heldTool then
                return false, "No carried evidence detected yet"
            end
        end

        if not forceDestination and self.Config.RequireToolTokens and #self.Config.RequireToolTokens > 0 and not heldTool then
            targetConfig = {
                TargetTokens = self.Config.SourceTokens,
                TargetNames = self.Config.SourceNames,
                ExcludeTokens = self.Config.SourceExcludeTokens,
            }
            stageName = self.Config.SourceLabel or "source item"
        else
            targetConfig = {
                TargetTokens = self.Config.DestinationTokens or self.Config.TargetTokens,
                TargetNames = self.Config.DestinationNames or self.Config.TargetNames,
                ExcludeTokens = self.Config.DestinationExcludeTokens,
            }
            stageName = self.Config.DestinationLabel or "destination"
            if heldTool then Runtime:EquipTool(heldTool) end
        end

        local target, distance = Runtime:FindBestTarget({
            Scope = self.Config.Scope or "Workspace",
            TargetTokens = targetConfig.TargetTokens,
            TargetNames = targetConfig.TargetNames,
            ExcludeTokens = targetConfig.ExcludeTokens,
            TargetClasses = {"Model", "BasePart", "ProximityPrompt", "ClickDetector", "Tool"},
            MaxTargets = 180,
            CacheTTL = 0.30,
            PreferInteractive = true,
        }, root.Position)

        if not target then return false, "Waiting for " .. stageName end
        if distance > (self.Config.InteractDistance or 12) then
            local moved, detail = Runtime:MoveTo(getPosition(target), self, {
                StopDistance = self.Config.InteractDistance or 10,
                MaxWaypoints = 4,
                WaypointTimeout = 1.0,
                MovementPriority = self.Config.MovementPriority or 60,
                RepathInterval = 0.75,
            })
            return moved, moved and ("Walking to " .. stageName) or detail
        end

        local cooldown = self.Config.ActionCooldown or 0.8
        if os.clock() - (self.LastAction or 0) < cooldown then
            return true, stageName .. " interaction cooling down"
        end
        local ok, detail = Runtime:Interact(target, self, {Priority = self.Config.ActionPriority or 55, Duration = cooldown})
        if heldTool and type(heldTool.Activate) == "function"
            and Runtime:ClaimAction(self, "Interaction", self.Config.ActionPriority or 55, cooldown)
        then
            pcall(heldTool.Activate, heldTool)
        end
        if ok then self.LastAction = os.clock() end
        return ok, ok and ("Completed " .. stageName .. " interaction") or detail
    end)
end

local function startRPSAutoPlay(feature)
    feature.ChoiceIndex = 0
    feature:_Loop(feature.Config.Interval or 0.35, function(self)
        local player = getLocalPlayer()
        local gui = player and player:FindFirstChildOfClass("PlayerGui")
        if not gui then return false, "Waiting for the RPS interface" end

        local visibleText = ""
        local buttons = {}
        forEachIndexed("Gui", {"GuiObject"}, function(instance)
            if isVisibleGui(instance) then
                if instance:IsA("TextLabel") or instance:IsA("TextButton") then
                    visibleText = visibleText .. " " .. lower(instance.Text)
                end
                if instance:IsA("GuiButton") and containsAny(instanceText(instance), {"rock", "paper", "scissors"}) then
                    table.insert(buttons, instance)
                end
            end
            return true
        end)
        if #buttons == 0 then return false, "Waiting for Rock/Paper/Scissors choice buttons" end

        local wanted
        if containsAny(visibleText, {"opponent: rock", "enemy rock", "picked rock"}) then
            wanted = "paper"
        elseif containsAny(visibleText, {"opponent: paper", "enemy paper", "picked paper"}) then
            wanted = "scissors"
        elseif containsAny(visibleText, {"opponent: scissors", "enemy scissors", "picked scissors"}) then
            wanted = "rock"
        else
            local choices = {"rock", "paper", "scissors"}
            self.ChoiceIndex = (self.ChoiceIndex % #choices) + 1
            wanted = choices[self.ChoiceIndex]
        end

        local selected
        for _, button in ipairs(buttons) do
            if containsAny(instanceText(button), {wanted}) then
                selected = button
                break
            end
        end
        selected = selected or buttons[1]
        local ok, detail = Runtime:ClickGui(selected, self, {
            Resource = "GuiAction",
            Priority = self.Config.ActionPriority or 75,
            Duration = 0.3,
        })
        if not ok then return false, detail end

        task.wait(0.08)
        local submit = findVisibleGui({"submit", "confirm", "play", "lock", "choose"}, {"GuiButton"})
        if submit then
            Runtime:ClickGui(submit, self, {
                Resource = "GuiAction",
                Priority = self.Config.ActionPriority or 75,
                Duration = 0.3,
            })
        end
        return true, "Selected " .. string.upper(wanted)
    end)
end

local GameProfiles = {
    {Name = "Red Light, Green Light", VisualTokens = {"red light", "green light", "younghee", "young hee", "mugunghwa"}, WorldTokens = {"rlgl", "younghee", "finish line"}},
    {Name = "Dalgona", VisualTokens = {"honeycomb", "dalgona", "cut the shape", "trace the shape", "carve"}, WorldTokens = {"dalgona", "honeycomb", "cookie"}},
    {Name = "Pentathlon", VisualTokens = {"pentathlon", "ddakji", "gonggi", "jegichagi", "paengi", "biseokchigi", "spinning top", "five legged"}, WorldTokens = {"pentathlon", "ddakji", "gonggi", "jegi", "biseok"}},
    {Name = "Hide & Seek", VisualTokens = {"hide & seek", "hide and seek", "hider", "seeker", "keys & knives", "find a key", "find the exit"}, WorldTokens = {"hide seek", "key room", "maze exit"}},
    {Name = "Jump Rope", VisualTokens = {"jump rope", "reach the other side", "make it to the other side", "cross the bridge", "swinging rope"}, WorldTokens = {"jump rope", "jumprope", "swinging bar"}},
    {Name = "Marbles", VisualTokens = {"marbles", "marble game", "throw the marble", "ring shooter"}, WorldTokens = {"marble", "marbles"}},
    {Name = "Mingle", VisualTokens = {"mingle", "find a room", "enter a room", "room with", "players per room", "group of"}, WorldTokens = {"mingle", "carousel room"}},
    {Name = "Fight Nights", VisualTokens = {"night brawl", "fight night", "lights out", "final dinner", "dinner fight"}, WorldTokens = {"night brawl", "lights out", "dinner arena"}},
    {Name = "Glass Bridge", VisualTokens = {"glass bridge", "choose a glass", "cross the glass", "glass stepping"}, WorldTokens = {"glass bridge", "glass panels", "bridge glass"}},
    {Name = "Rebellion", VisualTokens = {"rebellion", "uprising", "take the armory", "fight the guards"}, WorldTokens = {"rebellion", "armory", "uprising"}},
    {Name = "Rock, Paper, Scissors Minus One", VisualTokens = {"rock, paper, scissors", "rock paper scissors", "minus one", "remove one"}, WorldTokens = {"rps", "minus one"}},
    {Name = "Sky Squid", VisualTokens = {"sky squid", "push a player off", "floating platform", "platform round"}, WorldTokens = {"sky squid", "floating platform"}},
    {Name = "Squid Game", VisualTokens = {"attack the goal", "defend the goal", "squid court", "offense team", "defense team"}, WorldTokens = {"squid court", "squid game court"}},
    {Name = "Tug of War", VisualTokens = {"tug of war", "pull meter", "keep the marker", "team rope"}, WorldTokens = {"tugofwar", "tug of war", "rope team"}},
    {Name = "Escape", VisualTokens = {"island escape", "escape the island", "extraction boat", "escape route"}, WorldTokens = {"escape island", "extraction boat"}},
}

local ExpectedGameFragments = {
    {"mapped.games.red_light_green_light.", "Red Light, Green Light"},
    {"mapped.games.dalgona.", "Dalgona"},
    {"mapped.games.pentathlon.", "Pentathlon"},
    {"mapped.games.hide_seek.", "Hide & Seek"},
    {"mapped.games.jump_rope.", "Jump Rope"},
    {"mapped.games.marbles.", "Marbles"},
    {"mapped.games.mingle.", "Mingle"},
    {"mapped.games.fight_nights.", "Fight Nights"},
    {"mapped.games.glass_bridge.", "Glass Bridge"},
    {"mapped.games.rebellion.", "Rebellion"},
    {"mapped.games.rock_paper_scissors_minus_one.", "Rock, Paper, Scissors Minus One"},
    {"mapped.games.sky_squid.", "Sky Squid"},
    {"mapped.games.squid_game.", "Squid Game"},
    {"mapped.games.tug_of_war.", "Tug of War"},
    {"mapped.games.escape.", "Escape"},
}

local PentathlonStageFragments = {
    {".ddakji", "Ddakji"},
    {".gonggi", "Gonggi"},
    {".jegichagi", "Jegichagi"},
    {".paengi", "Paengi"},
    {".biseokchigi", "Biseokchigi"},
}

function Runtime:GetExpectedGame(feature)
    local config = feature and feature.Config or feature or {}
    if config.ExpectedGame then return config.ExpectedGame end
    local id = lower(feature and feature.Id or config.Id)
    for _, pair in ipairs(ExpectedGameFragments) do
        if string.find(id, pair[1], 1, true) then return pair[2] end
    end
    return nil
end

function Runtime:GetExpectedPentathlonStage(feature)
    local id = lower(feature and feature.Id or "")
    for _, pair in ipairs(PentathlonStageFragments) do
        if string.find(id, pair[1], 1, true) then return pair[2] end
    end
    return nil
end

function Runtime:DetectGameCategory()
    local now = os.clock()
    if self._GameDetectionCache and now - self._GameDetectionCache.Time < 0.22 then
        return self._GameDetectionCache.Name, self._GameDetectionCache.Score
    end

    local evidence = {}
    local function addEvidence(value, weight, source)
        local text = lower(value)
        if text ~= "" then
            table.insert(evidence, {Text = text, Weight = tonumber(weight) or 1, Source = source})
        end
    end

    local snapshot = self:GetVisualSnapshot(true)
    for _, item in ipairs(snapshot.Items) do
        if item.Text ~= "" then
            local weight = item.TextSize >= 30 and 15 or (item.TextSize >= 20 and 12 or 8)
            addEvidence(item.Text .. " " .. item.Context, weight, "HUD")
        end
    end

    local player, character = getCharacter()
    if player then
        if player.Team then addEvidence(player.Team.Name, 4, "team") end
        for _, object in ipairs({player, character}) do
            if object then
                for _, attributeName in ipairs({"CurrentGame", "Game", "Round", "RoundName", "Mode", "CurrentRound", "Minigame"}) do
                    local ok, value = pcall(object.GetAttribute, object, attributeName)
                    if ok and value ~= nil then addEvidence(attributeName .. " " .. tostring(value), 18, "player attribute") end
                end
            end
        end
    end

    for _, rootObject in ipairs({Workspace, ReplicatedStorage}) do
        for attributeName, attributeValue in pairs(rootObject:GetAttributes()) do
            if containsAny(attributeName, {"game", "round", "mode", "phase", "state", "current"}) then
                addEvidence(attributeName .. " " .. tostring(attributeValue), 16, "root attribute")
            end
        end
        local scanned = 0
        local scope = rootObject == Workspace and "Workspace" or "ReplicatedStorage"
        forEachIndexed(scope, {"ValueBase", "Folder", "Model"}, function(instance)
            if scanned >= 180 then return false end
            local context = instanceText(instance)
            if instance:IsA("ValueBase") then
                local strong = containsAny(context, {"current game", "current round", "game mode", "round name", "minigame"})
                addEvidence(context .. " " .. tostring(instance.Value), strong and 16 or 2, "value")
            elseif containsAny(context, {"active round", "current game", "current round", "minigame"}) then
                addEvidence(context, 5, "world")
            end
            scanned = scanned + 1
            return true
        end)
    end

    local ranked = {}
    for _, profile in ipairs(GameProfiles) do
        local score, strong, hits = 0, false, 0
        local function scoreTokens(tokens, visual)
            for _, token in ipairs(tokens) do
                local best = 0
                local phraseBonus = string.find(token, " ", 1, true) and 1.55 or 1.0
                for _, item in ipairs(evidence) do
                    if string.find(item.Text, token, 1, true) then
                        local sourceMultiplier = visual and item.Source == "HUD" and 1.45 or 1.0
                        best = math.max(best, item.Weight * phraseBonus * sourceMultiplier)
                    end
                end
                if best > 0 then
                    score = score + best
                    hits = hits + 1
                    if best >= 11 then strong = true end
                end
            end
        end
        scoreTokens(profile.VisualTokens, true)
        scoreTokens(profile.WorldTokens, false)
        table.insert(ranked, {Name = profile.Name, Score = score, Strong = strong, Hits = hits})
    end
    table.sort(ranked, function(a, b)
        if a.Score == b.Score then return a.Name < b.Name end
        return a.Score > b.Score
    end)

    local best, second = ranked[1], ranked[2]
    local candidate, candidateScore = nil, best and best.Score or 0
    if best and candidateScore >= 12 and best.Strong
        and (best.Hits >= 2 or candidateScore >= 24)
        and (not second or candidateScore - second.Score >= 4)
    then
        candidate = best.Name
    end

    local state = self._StableGameDetection or {Name = nil, Candidate = nil, Count = 0, ConfirmedAt = 0}
    if candidate and candidate == state.Candidate then
        state.Count = state.Count + 1
    elseif candidate then
        state.Candidate = candidate
        state.Count = 1
    else
        state.Candidate = nil
        state.Count = 0
    end

    if candidate and (state.Count >= 2 or candidateScore >= 30) then
        state.Name = candidate
        state.ConfirmedAt = now
    elseif not candidate and state.Name and now - (state.ConfirmedAt or 0) > 7 then
        state.Name = nil
    end
    self._StableGameDetection = state

    local confirmed = state.Name
    if confirmed then
        Environment.__SquidNoMoDetectedGame = confirmed
        Environment.__SquidNoMoDetectedGameAt = now
    end
    self._GameDetectionCache = {
        Time = now,
        Name = confirmed,
        Score = candidateScore,
        Candidate = candidate,
        RunnerUp = second and second.Name or nil,
    }
    return confirmed, candidateScore
end

function Runtime:FeatureContextAllowed(feature)
    if not feature or not feature.Config then return true end
    if feature.Config.IgnoreVisualContext == true then return true end

    local expectedGame = self:GetExpectedGame(feature)
    if expectedGame then
        local detectedGame = Environment.__SquidNoMoDetectedGame or self:DetectGameCategory()
        local phase = self:GetRoundPhase()
        if phase == "Lobby" then
            return false, "Paused: waiting for the round to begin"
        elseif phase == "Ended" then
            return false, "Paused: the current round has ended"
        elseif detectedGame and detectedGame ~= expectedGame then
            return false, "Paused: " .. tostring(detectedGame) .. " is active; this feature is for " .. tostring(expectedGame)
        end
        if expectedGame == "Pentathlon" then
            local expectedStage = self:GetExpectedPentathlonStage(feature)
            local currentStage = self:GetPentathlonStage()
            if expectedStage and currentStage and expectedStage ~= currentStage then
                return false, "Paused: Pentathlon is currently on " .. currentStage
            end
        elseif expectedGame == "Mingle" and feature.Config.Kind == "RoomAssist" then
            local minglePhase = self:GetMinglePhase()
            if minglePhase == "Carousel" then
                return false, "Paused: waiting for the room number"
            elseif minglePhase == "Locked" then
                return false, "Paused: the selected Mingle room is already locked"
            end
        end
    end

    local id = lower(feature.Id)
    if string.find(id, "mapped.games.hide_seek.", 1, true) then
        local hideSeekRole = self:GetHideSeekRole()
        local hiderOnly = string.find(id, ".autograbkey", 1, true)
            or string.find(id, ".autopathtoexit", 1, true)
            or string.find(id, ".exitesp", 1, true)
            or string.find(id, ".huntertracker", 1, true)
        local seekerOnly = string.find(id, ".autograbknife", 1, true)
            or string.find(id, ".autoswing", 1, true)
        if hideSeekRole == "Hider" and seekerOnly then
            return false, "Paused: this Hide & Seek feature is for Seekers"
        elseif hideSeekRole == "Seeker" and hiderOnly then
            return false, "Paused: this Hide & Seek feature is for Hiders"
        end
    end
    local expectedRole
    if string.find(id, "mapped.guards.", 1, true) then expectedRole = "Guard"
    elseif string.find(id, "mapped.detective.", 1, true) then expectedRole = "Detective" end
    if expectedRole then
        local role = self:GetVisualRole()
        if role then
            local allowed = role == expectedRole or (expectedRole == "Guard" and role == "Frontman")
            if not allowed then
                return false, "Paused: local role appears to be " .. role .. "; this feature is for " .. expectedRole
            end
        end
    end

    if string.find(id, "mapped.guards.", 1, true) then
        local expectedDuty
        if string.find(id, ".kitchen_staff.", 1, true) then expectedDuty = "Kitchen"
        elseif string.find(id, ".morgue_staff.", 1, true) then expectedDuty = "Morgue"
        elseif string.find(id, ".game_moderation.", 1, true) then expectedDuty = "Moderation" end
        local duty = self:GetGuardDuty()
        if expectedDuty and duty and duty ~= expectedDuty then
            return false, "Paused: current guard duty appears to be " .. duty
        end
    end

    return true
end

function Runtime:GetFeatureVisualHint(feature)
    if not feature then return nil end
    local id = lower(feature.Id)
    if string.find(id, "mapped.games.red_light_green_light.", 1, true) then
        local state = self:GetRLGLState()
        return state and (state .. " light") or "signal uncertain"
    elseif string.find(id, "mapped.games.mingle.", 1, true) then
        local count = self:GetMingleRequiredCount()
        local phase = self:GetMinglePhase()
        local parts = {}
        if phase then table.insert(parts, phase) end
        if count then table.insert(parts, "room count " .. count) end
        return #parts > 0 and table.concat(parts, ", ") or nil
    elseif string.find(id, "mapped.games.hide_seek.", 1, true) then
        local role = self:GetHideSeekRole()
        return role and ("role " .. role) or nil
    elseif string.find(id, "mapped.games.pentathlon.", 1, true) then
        local stage = self:GetPentathlonStage()
        return stage and ("stage " .. stage) or nil
    elseif string.find(id, "mapped.detective.", 1, true) then
        local state = self:GetDetectiveState()
        local parts = {}
        if state.Stage then table.insert(parts, state.Stage) end
        if state.Evidence and state.Capacity then table.insert(parts, state.Evidence .. "/" .. state.Capacity .. " evidence") end
        if state.Detection then table.insert(parts, math.floor(state.Detection * 100 + 0.5) .. "% detection") end
        return #parts > 0 and table.concat(parts, ", ") or nil
    elseif string.find(id, "mapped.guards.", 1, true) then
        local duty = self:GetGuardDuty()
        return duty and ("duty " .. duty) or nil
    end
    local expected = self:GetExpectedGame(feature)
    local detected = expected and self:DetectGameCategory()
    return detected and ("visual cue " .. detected) or nil
end

function Runtime:GetCompatibilitySummary()
    local virtualInput
    pcall(function() virtualInput = game:GetService("VirtualInputManager") end)
    return {
        Prompt = type(fireproximityprompt) == "function" or virtualInput ~= nil,
        Click = type(fireclickdetector) == "function",
        Touch = type(firetouchinterest) == "function",
        Gui = type(firesignal) == "function" or type(getconnections) == "function" or virtualInput ~= nil,
        Pathfinding = PathfindingService ~= nil,
    }
end

function Runtime:ValidateFeatureConfig(config)
    if type(config) ~= "table" then return false, "feature config is missing" end
    if type(config.Kind) ~= "string" or config.Kind == "" then return false, "feature Kind is missing" end
    local targetKinds = {
        Highlight = true, ToolActivate = true, GuiHighlight = true, WalkTo = true,
        Interact = true, ToolAura = true, Timing = true, GuiAction = true,
        AutoJump = true, Boundary = true, RoomAssist = true,
        AimActivate = true, Radar = true, CourseAssist = true, SafeTileWalk = true,
        GlassESP = true, TaskChain = true, StateHUD = true, AntiStuck = true,
        JumpBoost = true, AntiFall = true, RLGLAutoMove = true, Evasion = true,
        Disguise = true, PositionKeeper = true, RPSAutoPlay = true,
    }
    if targetKinds[config.Kind] then
        local hasSelector = (type(config.TargetTokens) == "table" and #config.TargetTokens > 0)
            or (type(config.TargetNames) == "table" and #config.TargetNames > 0)
            or (type(config.ActionTokens) == "table" and #config.ActionTokens > 0)
            or (type(config.ToolTokens) == "table" and #config.ToolTokens > 0)
            or config.Kind == "RoomAssist" or config.Kind == "SafeTileWalk"
            or config.Kind == "GlassESP" or config.Kind == "Radar"
            or config.Kind == "TaskChain" or config.Kind == "StateHUD"
            or config.Kind == "AntiStuck" or config.Kind == "JumpBoost"
            or config.Kind == "AntiFall" or config.Kind == "RLGLAutoMove"
            or config.Kind == "Evasion" or config.Kind == "Disguise"
            or config.Kind == "PositionKeeper" or config.Kind == "RPSAutoPlay"
            or config.PlayerMode == true
        if not hasSelector then
            return false, "feature has no target, action, or tool selector"
        end
    end
    return true
end

local function startToolActivate(feature)
    feature:_Loop(feature.Config.Interval or 0.3, function(self)
        local tool = Runtime:FindTool(self.Config.ToolTokens or self.Config.TargetTokens or {})
        if not tool then return false, self.Config.WaitingMessage or "Waiting for the required tool" end
        local cooldown = self.Config.ActionCooldown or math.max(self.Config.Interval or 0.3, 0.3)
        if os.clock() - (self.LastAction or 0) < cooldown then
            return true, "Tool equipped — action cooling down"
        end
        local ok, detail = Runtime:ActivateTool(self.Config.ToolTokens or self.Config.TargetTokens or {}, self, {
            Resource = "ToolAction",
            Priority = self.Config.ActionPriority or 45,
            Duration = cooldown,
        })
        if ok then self.LastAction = os.clock() end
        return ok, ok and ("Activated " .. tostring(tool.Name)) or detail
    end)
end

local function startGuiHighlight(feature)
    feature.GuiTarget = nil
    feature.GuiStroke = nil

    local function clear(self)
        if self.GuiStroke then pcall(function() self.GuiStroke:Destroy() end) end
        self.GuiStroke = nil
        self.GuiTarget = nil
    end
    feature.OnContextBlocked = clear
    feature.Restore = clear

    feature:_Loop(feature.Config.Interval or 0.2, function(self)
        local target = findVisibleGui(self.Config.TargetTokens or {}, {"GuiObject"})
        if not target then
            clear(self)
            return false, self.Config.WaitingMessage or "Waiting for the matching interface"
        end
        if self.GuiTarget ~= target or not self.GuiStroke or not self.GuiStroke.Parent then
            clear(self)
            local stroke = Instance.new("UIStroke")
            stroke.Name = "SquidNoMoGuiHighlight"
            stroke.Color = self.Config.Color or Color3.fromRGB(60, 220, 255)
            stroke.Thickness = self.Config.Thickness or 3
            stroke.Transparency = self.Config.Transparency or 0.02
            stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
            stroke.Parent = target
            self.GuiTarget = target
            self.GuiStroke = stroke
            self:_TrackInstance(stroke)
        end
        return true, "Highlighting " .. tostring(target.Name)
    end)
end

local function startStateHUD(feature)
    local parent = getGuiParent()
    if not parent then error("no compatible GUI parent is available") end
    local gui = Instance.new("ScreenGui")
    gui.Name = "SquidNoMo_StateHUD_" .. feature.Id
    gui.ResetOnSpawn = false
    gui.IgnoreGuiInset = true
    gui.DisplayOrder = 999986
    gui.Parent = parent
    feature:_TrackInstance(gui)

    local label = Instance.new("TextLabel")
    label.AnchorPoint = Vector2.new(0.5, 0)
    label.Position = UDim2.new(0.5, 0, 0, 76)
    label.Size = UDim2.fromOffset(220, 44)
    label.BackgroundColor3 = Color3.fromRGB(12, 14, 19)
    label.BackgroundTransparency = 0.08
    label.BorderSizePixel = 0
    label.Font = Enum.Font.GothamBlack
    label.Text = "RLGL: WAITING"
    label.TextSize = 18
    label.TextColor3 = Color3.fromRGB(255, 210, 80)
    label.Parent = gui
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 12)
    corner.Parent = label
    local stroke = Instance.new("UIStroke")
    stroke.Thickness = 1.5
    stroke.Transparency = 0.15
    stroke.Color = label.TextColor3
    stroke.Parent = label

    feature.OnContextBlocked = function(self, detail)
        label.Text = "RLGL: WAITING"
        label.TextColor3 = Color3.fromRGB(255, 210, 80)
        stroke.Color = label.TextColor3
    end
    feature:_Loop(feature.Config.Interval or 0.12, function(self)
        local state = Runtime:GetRLGLState()
        if state == "Green" then
            label.Text = "RLGL: GREEN — MOVE"
            label.TextColor3 = Color3.fromRGB(70, 255, 130)
            stroke.Color = label.TextColor3
            return true, "Green light visible"
        elseif state == "Red" then
            label.Text = "RLGL: RED — STOP"
            label.TextColor3 = Color3.fromRGB(255, 78, 92)
            stroke.Color = label.TextColor3
            return true, "Red light visible"
        end
        label.Text = "RLGL: SIGNAL UNCERTAIN"
        label.TextColor3 = Color3.fromRGB(255, 210, 80)
        stroke.Color = label.TextColor3
        return false, "Waiting for an unambiguous red/green signal"
    end)
end

local function startAntiStuck(feature)
    feature.LastPosition = nil
    feature.LastProgressAt = os.clock()
    feature.OnContextBlocked = function(self)
        self.LastPosition = nil
        self.LastProgressAt = os.clock()
    end
    feature:_Loop(feature.Config.Interval or 0.35, function(self)
        local _, _, humanoid, root = getCharacter()
        if not humanoid or not root then return false, "Waiting for the local character" end
        local state = Runtime:GetRLGLState()
        if state ~= "Green" then
            self.LastPosition = root.Position
            self.LastProgressAt = os.clock()
            return false, state == "Red" and "Red light — recovery paused" or "Waiting for a confirmed green light"
        end
        if humanoid.MoveDirection.Magnitude < 0.05 then
            self.LastPosition = root.Position
            self.LastProgressAt = os.clock()
            return true, "Green light — standing still by choice"
        end
        local current = root.Position
        if not self.LastPosition or (current - self.LastPosition).Magnitude >= (self.Config.MinimumMovement or 0.3) then
            self.LastPosition = current
            self.LastProgressAt = os.clock()
            return true, "Movement progress detected"
        end
        if os.clock() - (self.LastProgressAt or os.clock()) >= (self.Config.StuckSeconds or 2.2) then
            humanoid.Jump = true
            pcall(humanoid.ChangeState, humanoid, Enum.HumanoidStateType.Jumping)
            local direction = humanoid.MoveDirection.Magnitude > 0.05 and humanoid.MoveDirection.Unit or root.CFrame.LookVector
            local velocity = root.AssemblyLinearVelocity
            root.AssemblyLinearVelocity = Vector3.new(
                velocity.X + direction.X * (self.Config.RecoveryVelocity or 5),
                math.max(velocity.Y, 10),
                velocity.Z + direction.Z * (self.Config.RecoveryVelocity or 5)
            )
            self.LastPosition = current
            self.LastProgressAt = os.clock()
            return true, "Applied a one-time jump recovery"
        end
        return true, "Checking movement progress"
    end)
end

local function startJumpBoost(feature)
    feature.OriginalHumanoid = nil
    feature.OriginalUseJumpPower = nil
    feature.OriginalJumpPower = nil
    feature.OriginalJumpHeight = nil

    local function restore(self)
        local humanoid = self.OriginalHumanoid
        if humanoid and humanoid.Parent then
            pcall(function()
                if self.OriginalUseJumpPower ~= nil then humanoid.UseJumpPower = self.OriginalUseJumpPower end
                if self.OriginalJumpPower ~= nil then humanoid.JumpPower = self.OriginalJumpPower end
                if self.OriginalJumpHeight ~= nil then humanoid.JumpHeight = self.OriginalJumpHeight end
            end)
        end
        self.OriginalHumanoid = nil
        self.OriginalUseJumpPower = nil
        self.OriginalJumpPower = nil
        self.OriginalJumpHeight = nil
    end
    feature.Restore = restore
    feature.OnContextBlocked = restore

    feature:_Loop(feature.Config.Interval or 0.35, function(self)
        local _, _, humanoid = getCharacter()
        if not humanoid then return false, "Waiting for the local character" end
        if self.OriginalHumanoid ~= humanoid then
            restore(self)
            self.OriginalHumanoid = humanoid
            self.OriginalUseJumpPower = humanoid.UseJumpPower
            self.OriginalJumpPower = humanoid.JumpPower
            self.OriginalJumpHeight = humanoid.JumpHeight
        end
        if humanoid.UseJumpPower then
            humanoid.JumpPower = math.max(humanoid.JumpPower, self.Config.JumpPower or 78)
            return true, "Jump power boosted for Jump Rope"
        end
        humanoid.JumpHeight = math.max(humanoid.JumpHeight, self.Config.JumpHeight or 13)
        return true, "Jump height boosted for Jump Rope"
    end)
end

local starters = {
    Highlight = startHighlight,
    ToolActivate = startToolActivate,
    GuiHighlight = startGuiHighlight,
    StateHUD = startStateHUD,
    AntiStuck = startAntiStuck,
    JumpBoost = startJumpBoost,
    WalkTo = startWalkTo,
    Interact = startInteract,
    ToolAura = startToolAura,
    Timing = startTiming,
    GuiAction = startGuiAction,
    AntiFall = startAntiFall,
    RLGLAutoMove = startRLGLAutoMove,
    AutoJump = startAutoJump,
    Evasion = startEvasion,
    Boundary = startBoundary,
    RoomAssist = startRoomAssist,
    AimActivate = startAimActivate,
    Disguise = startDisguise,
    Radar = startRadar,
    CourseAssist = startCourseAssist,
    PositionKeeper = startPositionKeeper,
    SafeTileWalk = startSafeTileWalk,
    GlassESP = startGlassESP,
    TaskChain = startTaskChain,
    RPSAutoPlay = startRPSAutoPlay,
}

function FeatureMethods:Toggle(state)
    state = state == true
    if self.Enabled == state then return true end
    self:_Clear()
    self.Enabled = state
    self.LastError = nil
    if not state then
        self:_SetStatus("Off", "Disabled")
        return true
    end

    self:_SetStatus("Starting", "Initializing " .. self.Name)
    local configOk, configDetail = Runtime:ValidateFeatureConfig(self.Config)
    if not configOk then
        self.Enabled = false
        self.LastError = configDetail
        self:_SetStatus("Error", configDetail)
        return false, configDetail
    end
    local starter = starters[self.Config.Kind]
    if not starter then
        self.Enabled = false
        self.LastError = "unsupported feature kind: " .. tostring(self.Config.Kind)
        self:_SetStatus("Error", self.LastError)
        return false, self.LastError
    end
    local ok, err = xpcall(function() starter(self) end, debug.traceback)
    if not ok then
        self.Enabled = false
        self.LastError = tostring(err)
        self:_SetStatus("Error", self.LastError)
        return false, self.LastError
    end
    return true
end

function FeatureMethods:Enable()
    return self:Toggle(true)
end

function FeatureMethods:Disable()
    return self:Toggle(false)
end

function FeatureMethods:IsEnabled()
    return self.Enabled == true
end

function FeatureMethods:GetState()
    return self.Enabled and "on" or "off"
end

function Runtime:CreateFeature(config)
    assert(type(config) == "table", "feature config must be a table")
    assert(type(config.Kind) == "string" and config.Kind ~= "", "feature Kind is required")
    local feature = setmetatable({
        Id = tostring(config.Id or config.Name or "feature"),
        Name = tostring(config.Name or config.Id or "Feature"),
        Description = tostring(config.Description or ""),
        Config = config,
        Enabled = false,
        Status = "Off",
        StatusDetail = "Disabled",
        LastError = nil,
        LastAction = 0,
        Connections = {},
        Threads = {},
        Instances = {},
        StatusListeners = {},
        NextListenerId = 0,
    }, FeatureMethods)
    return feature
end

return Runtime
]====],
        [ [====[Features/UI/CameraFOV.lua]====] ] = [====[local CameraFOV = {}
local Workspace = game:GetService("Workspace")

local Current = 70
local Preferred = 90
local Enabled = false
local Defaults = {}
local CameraConnection = nil
local WorkspaceConnection = nil

local function disconnectCamera()
    if CameraConnection then
        CameraConnection:Disconnect()
        CameraConnection = nil
    end
end

local function getCamera()
    return Workspace.CurrentCamera
end

local function remember(camera)
    if camera and Defaults[camera] == nil then
        Defaults[camera] = camera.FieldOfView
        if not Enabled then
            Current = camera.FieldOfView
        end
    end
end

local function apply()
    local camera = getCamera()
    if camera then
        remember(camera)
        camera.FieldOfView = Current
    end
end

local function bindCamera()
    disconnectCamera()
    local camera = getCamera()
    if not camera then return end
    remember(camera)
    CameraConnection = camera:GetPropertyChangedSignal("FieldOfView"):Connect(function()
        if Enabled and math.abs(camera.FieldOfView - Current) > 0.1 then
            camera.FieldOfView = Current
        elseif not Enabled then
            Defaults[camera] = camera.FieldOfView
            Current = camera.FieldOfView
        end
    end)
    if Enabled then apply() end
end

bindCamera()
WorkspaceConnection = Workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(bindCamera)

function CameraFOV:Set(value)
    local camera = getCamera()
    local default = camera and (Defaults[camera] or camera.FieldOfView) or 70
    Current = math.clamp(tonumber(value) or default, 40, 120)
    if math.abs(Current - default) > 0.1 then
        Preferred = Current
        Enabled = true
    else
        Enabled = false
    end
    apply()
end

function CameraFOV:Get()
    return Current
end

function CameraFOV:Enable()
    Enabled = true
    Current = Preferred
    apply()
end

function CameraFOV:Disable()
    Enabled = false
    local camera = getCamera()
    if camera then
        remember(camera)
        Current = Defaults[camera] or 70
        camera.FieldOfView = Current
    end
end

function CameraFOV:IsEnabled()
    return Enabled
end

function CameraFOV:GetState()
    return Enabled and "on" or "off"
end

return CameraFOV
]====],
        [ [====[Features/UI/ClockHUD.lua]====] ] = [====[local ClockHUD = {}
local Players = game:GetService("Players")
local CoreGui = game:GetService("CoreGui")

local Enabled = false
local Gui = nil
local Thread = nil
local Generation = 0

local function getParent()
    if type(gethui) == "function" then
        local ok, result = pcall(gethui)
        if ok and result then return result end
    end
    local player = Players.LocalPlayer
    return (player and player:FindFirstChildOfClass("PlayerGui")) or CoreGui
end

local function build()
    if Gui and Gui.Parent then return Gui:FindFirstChild("Value", true) end
    Gui = Instance.new("ScreenGui")
    Gui.Name = "SquidNoMo_ClockHUD"
    Gui.IgnoreGuiInset = true
    Gui.ResetOnSpawn = false
    Gui.DisplayOrder = 999974
    Gui.Parent = getParent()

    local panel = Instance.new("Frame")
    panel.AnchorPoint = Vector2.new(1, 0)
    panel.Position = UDim2.new(1, -12, 0, 12)
    panel.Size = UDim2.fromOffset(150, 34)
    panel.BackgroundColor3 = Color3.fromRGB(12, 9, 18)
    panel.BackgroundTransparency = 0.12
    panel.BorderSizePixel = 0
    panel.Parent = Gui
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 10)
    corner.Parent = panel
    local outline = Instance.new("UIStroke")
    outline.Color = Color3.fromRGB(255, 58, 145)
    outline.Transparency = 0.18
    outline.Parent = panel

    local label = Instance.new("TextLabel")
    label.Name = "Value"
    label.Size = UDim2.new(1, -16, 1, 0)
    label.Position = UDim2.fromOffset(8, 0)
    label.BackgroundTransparency = 1
    label.Font = Enum.Font.GothamBold
    label.Text = "--:--:--"
    label.TextSize = 11
    label.TextColor3 = Color3.fromRGB(240, 245, 255)
    label.Parent = panel
    return label
end

function ClockHUD:Enable()
    if Enabled then return end
    Enabled = true
    Generation = Generation + 1
    local generation = Generation
    local label = build()
    Gui.Enabled = true
    Thread = task.spawn(function()
        while Enabled and generation == Generation and Gui and Gui.Parent do
            if label and label.Parent then
                label.Text = os.date("%I:%M:%S %p")
            end
            task.wait(1)
        end
    end)
end

function ClockHUD:Disable()
    Enabled = false
    Generation = Generation + 1
    Thread = nil
    if Gui then Gui.Enabled = false end
end

function ClockHUD:IsEnabled() return Enabled end
function ClockHUD:GetState() return Enabled and "on" or "off" end

return ClockHUD
]====],
        [ [====[Features/UI/CompassHUD.lua]====] ] = [====[local CompassHUD = {}
local Players = game:GetService("Players")
local CoreGui = game:GetService("CoreGui")
local RunService = game:GetService("RunService")

local Enabled = false
local Gui = nil
local Thread = nil
local Generation = 0

local function getParent()
    if type(gethui) == "function" then
        local ok, result = pcall(gethui)
        if ok and result then return result end
    end
    local player = Players.LocalPlayer
    return (player and player:FindFirstChildOfClass("PlayerGui")) or CoreGui
end

local function build()
    if Gui and Gui.Parent then return Gui:FindFirstChild("Value", true) end
    Gui = Instance.new("ScreenGui")
    Gui.Name = "SquidNoMo_CompassHUD"
    Gui.IgnoreGuiInset = true
    Gui.ResetOnSpawn = false
    Gui.DisplayOrder = 999976
    Gui.Parent = getParent()

    local panel = Instance.new("Frame")
    panel.AnchorPoint = Vector2.new(0.5, 0)
    panel.Position = UDim2.new(0.5, 0, 0, 12)
    panel.Size = UDim2.fromOffset(180, 34)
    panel.BackgroundColor3 = Color3.fromRGB(12, 9, 18)
    panel.BackgroundTransparency = 0.12
    panel.BorderSizePixel = 0
    panel.Parent = Gui
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 10)
    corner.Parent = panel
    local outline = Instance.new("UIStroke")
    outline.Color = Color3.fromRGB(232, 67, 255)
    outline.Transparency = 0.18
    outline.Parent = panel

    local label = Instance.new("TextLabel")
    label.Name = "Value"
    label.Size = UDim2.new(1, -16, 1, 0)
    label.Position = UDim2.fromOffset(8, 0)
    label.BackgroundTransparency = 1
    label.Font = Enum.Font.GothamBold
    label.Text = "N  000°"
    label.TextSize = 11
    label.TextColor3 = Color3.fromRGB(240, 245, 255)
    label.Parent = panel
    return label
end

local directions = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"}

function CompassHUD:Enable()
    if Enabled then return end
    Enabled = true
    Generation = Generation + 1
    local generation = Generation
    local label = build()
    Gui.Enabled = true
    Thread = task.spawn(function()
        while Enabled and generation == Generation and Gui and Gui.Parent do
            local camera = workspace.CurrentCamera
            if camera and label and label.Parent then
                local look = camera.CFrame.LookVector
                local heading = (math.deg(math.atan2(-look.X, -look.Z)) + 360) % 360
                local index = math.floor((heading + 22.5) / 45) % 8 + 1
                label.Text = string.format("%s  %03d°", directions[index], math.floor(heading + 0.5))
            end
            task.wait(0.15)
        end
    end)
end

function CompassHUD:Disable()
    Enabled = false
    Generation = Generation + 1
    Thread = nil
    if Gui then Gui.Enabled = false end
end

function CompassHUD:IsEnabled() return Enabled end
function CompassHUD:GetState() return Enabled and "on" or "off" end

return CompassHUD
]====],
        [ [====[Features/UI/CoordinatesHUD.lua]====] ] = [====[local CoordinatesHUD = {}
local Players = game:GetService("Players")
local CoreGui = game:GetService("CoreGui")
local RunService = game:GetService("RunService")

local LocalPlayer = Players.LocalPlayer
local Enabled = false
local Gui = nil
local Thread = nil
local Generation = 0

local function getParent()
    if type(gethui) == "function" then
        local ok, result = pcall(gethui)
        if ok and result then return result end
    end
    return (LocalPlayer and LocalPlayer:FindFirstChildOfClass("PlayerGui")) or CoreGui
end

local function build()
    if Gui and Gui.Parent then return Gui:FindFirstChild("Value", true) end
    Gui = Instance.new("ScreenGui")
    Gui.Name = "SquidNoMo_CoordinatesHUD"
    Gui.IgnoreGuiInset = true
    Gui.ResetOnSpawn = false
    Gui.DisplayOrder = 999978
    Gui.Parent = getParent()

    local panel = Instance.new("Frame")
    panel.AnchorPoint = Vector2.new(0, 1)
    panel.Position = UDim2.new(0, 12, 1, -12)
    panel.Size = UDim2.fromOffset(230, 34)
    panel.BackgroundColor3 = Color3.fromRGB(12, 9, 18)
    panel.BackgroundTransparency = 0.12
    panel.BorderSizePixel = 0
    panel.Parent = Gui
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 10)
    corner.Parent = panel
    local outline = Instance.new("UIStroke")
    outline.Color = Color3.fromRGB(45, 232, 98)
    outline.Transparency = 0.18
    outline.Parent = panel

    local label = Instance.new("TextLabel")
    label.Name = "Value"
    label.Size = UDim2.new(1, -16, 1, 0)
    label.Position = UDim2.fromOffset(8, 0)
    label.BackgroundTransparency = 1
    label.Font = Enum.Font.GothamBold
    label.Text = "X --  Y --  Z --"
    label.TextSize = 11
    label.TextColor3 = Color3.fromRGB(240, 245, 255)
    label.Parent = panel
    return label
end

function CoordinatesHUD:Enable()
    if Enabled then return end
    Enabled = true
    Generation = Generation + 1
    local generation = Generation
    local label = build()
    Gui.Enabled = true
    Thread = task.spawn(function()
        while Enabled and generation == Generation and Gui and Gui.Parent do
            local character = LocalPlayer and LocalPlayer.Character
            local root = character and character:FindFirstChild("HumanoidRootPart")
            if label and label.Parent then
                if root then
                    local position = root.Position
                    label.Text = string.format("X %.0f  Y %.0f  Z %.0f", position.X, position.Y, position.Z)
                else
                    label.Text = "X --  Y --  Z --"
                end
            end
            task.wait(0.18)
        end
    end)
end

function CoordinatesHUD:Disable()
    Enabled = false
    Generation = Generation + 1
    Thread = nil
    if Gui then Gui.Enabled = false end
end

function CoordinatesHUD:IsEnabled() return Enabled end
function CoordinatesHUD:GetState() return Enabled and "on" or "off" end

return CoordinatesHUD
]====],
        [ [====[Features/UI/CoreGuiToggle.lua]====] ] = [====[local StarterGui = game:GetService("StarterGui")

local CoreGuiToggle = {}
CoreGuiToggle.__index = CoreGuiToggle

function CoreGuiToggle.new(coreGuiType)
    return setmetatable({CoreGuiType = coreGuiType, Enabled = false}, CoreGuiToggle)
end

function CoreGuiToggle:Enable()
    if self.Enabled then return end
    local ok = pcall(function()
        StarterGui:SetCoreGuiEnabled(self.CoreGuiType, false)
    end)
    self.Enabled = ok
end

function CoreGuiToggle:Disable()
    if not self.Enabled then return end
    local ok = pcall(function()
        StarterGui:SetCoreGuiEnabled(self.CoreGuiType, true)
    end)
    if ok then
        self.Enabled = false
    end
end

function CoreGuiToggle:IsEnabled()
    return self.Enabled
end

function CoreGuiToggle:GetState()
    return self.Enabled and "on" or "off"
end

return CoreGuiToggle
]====],
        [ [====[Features/UI/Crosshair.lua]====] ] = [====[local Crosshair = {}

local Players = game:GetService("Players")
local CoreGui = game:GetService("CoreGui")
local Enabled = false
local Gui = nil
local Color = Color3.fromRGB(255, 58, 145)

local function getParent()
    if type(gethui) == "function" then
        local ok, result = pcall(gethui)
        if ok and result then return result end
    end
    local player = Players.LocalPlayer
    return (player and player:FindFirstChildOfClass("PlayerGui")) or CoreGui
end

local function createLine(parent, size, position)
    local line = Instance.new("Frame")
    line.AnchorPoint = Vector2.new(0.5, 0.5)
    line.Position = position
    line.Size = size
    line.BackgroundColor3 = Color
    line.BorderSizePixel = 0
    line.Parent = parent
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(1, 0)
    corner.Parent = line
    return line
end

local function build()
    if Gui and Gui.Parent then return end
    Gui = Instance.new("ScreenGui")
    Gui.Name = "SquidNoMo_Crosshair"
    Gui.IgnoreGuiInset = true
    Gui.ResetOnSpawn = false
    Gui.DisplayOrder = 999990
    Gui.Parent = getParent()

    local center = Instance.new("Frame")
    center.Name = "Center"
    center.AnchorPoint = Vector2.new(0.5, 0.5)
    center.Position = UDim2.fromScale(0.5, 0.5)
    center.Size = UDim2.fromOffset(42, 42)
    center.BackgroundTransparency = 1
    center.Parent = Gui

    createLine(center, UDim2.fromOffset(14, 3), UDim2.new(0.5, -13, 0.5, 0))
    createLine(center, UDim2.fromOffset(14, 3), UDim2.new(0.5, 13, 0.5, 0))
    createLine(center, UDim2.fromOffset(3, 14), UDim2.new(0.5, 0, 0.5, -13))
    createLine(center, UDim2.fromOffset(3, 14), UDim2.new(0.5, 0, 0.5, 13))
    createLine(center, UDim2.fromOffset(4, 4), UDim2.fromScale(0.5, 0.5))
end

local function recolor()
    if not Gui then return end
    for _, child in ipairs(Gui:GetDescendants()) do
        if child:IsA("Frame") and child.Name ~= "Center" then
            child.BackgroundColor3 = Color
        end
    end
end

function Crosshair:Enable()
    Enabled = true
    build()
    recolor()
    if Gui then Gui.Enabled = true end
end

function Crosshair:Disable()
    Enabled = false
    if Gui then Gui.Enabled = false end
end

function Crosshair:IsEnabled() return Enabled end
function Crosshair:GetState() return Enabled and "on" or "off" end
function Crosshair:SetColor(color)
    if typeof(color) == "Color3" then Color = color recolor() end
end
function Crosshair:GetColor() return Color end

return Crosshair
]====],
        [ [====[Features/UI/DisableParticles.lua]====] ] = [====[local DisableParticles = {}
local Workspace = game:GetService("Workspace")

local Enabled = false
local States = setmetatable({}, {__mode = "k"})
local Connection = nil
local Generation = 0

local function supported(object)
    return object:IsA("ParticleEmitter")
        or object:IsA("Trail")
        or object:IsA("Beam")
        or object:IsA("Fire")
        or object:IsA("Smoke")
        or object:IsA("Sparkles")
end

local function apply(object)
    if not object or not supported(object) then return end
    if States[object] == nil then States[object] = object.Enabled end
    if object.Enabled then object.Enabled = false end
end

function DisableParticles:Enable()
    if Enabled then return end
    Enabled = true
    Generation = Generation + 1
    local generation = Generation

    Connection = Workspace.DescendantAdded:Connect(function(object)
        if Enabled and generation == Generation then apply(object) end
    end)

    -- Cooperative initial pass: disabling effects must not freeze a map-heavy
    -- mobile client for a frame.
    task.spawn(function()
        local queue = Workspace:GetChildren()
        local cursor = 1
        while Enabled and generation == Generation and cursor <= #queue do
            local object = queue[cursor]
            cursor = cursor + 1
            if object and object.Parent then
                apply(object)
                for _, child in ipairs(object:GetChildren()) do table.insert(queue, child) end
            end
            if cursor % 240 == 0 then task.wait() end
        end
    end)
end

function DisableParticles:Disable()
    Enabled = false
    Generation = Generation + 1
    if Connection then Connection:Disconnect() Connection = nil end
    for object, state in pairs(States) do
        if object and object.Parent then pcall(function() object.Enabled = state end) end
    end
    table.clear(States)
end

function DisableParticles:IsEnabled() return Enabled end
function DisableParticles:GetState() return Enabled and "on" or "off" end

return DisableParticles
]====],
        [ [====[Features/UI/DisableShadows.lua]====] ] = [====[local DisableShadows = {}
local Lighting = game:GetService("Lighting")

local Enabled = false
local Default = nil
local Connection = nil

local function apply()
    if Enabled then
        Lighting.GlobalShadows = false
    end
end

function DisableShadows:Enable()
    if Enabled then return end
    Enabled = true
    Default = Lighting.GlobalShadows
    apply()
    Connection = Lighting:GetPropertyChangedSignal("GlobalShadows"):Connect(apply)
end

function DisableShadows:Disable()
    Enabled = false
    if Connection then Connection:Disconnect() Connection = nil end
    if Default ~= nil then Lighting.GlobalShadows = Default end
    Default = nil
end

function DisableShadows:IsEnabled() return Enabled end
function DisableShadows:GetState() return Enabled and "on" or "off" end

return DisableShadows
]====],
        [ [====[Features/UI/Fullbright.lua]====] ] = [====[local Fullbright = {}
local Lighting = game:GetService("Lighting")

local Enabled = false
local Defaults = nil
local Connections = {}

local function disconnectAll()
    for _, connection in ipairs(Connections) do
        pcall(function() connection:Disconnect() end)
    end
    table.clear(Connections)
end

local function apply()
    if not Enabled then return end
    Lighting.Brightness = 2
    Lighting.ClockTime = 14
    Lighting.Ambient = Color3.fromRGB(180, 180, 180)
    Lighting.OutdoorAmbient = Color3.fromRGB(180, 180, 180)
end

function Fullbright:Enable()
    if Enabled then return end
    Enabled = true
    Defaults = {
        Brightness = Lighting.Brightness,
        ClockTime = Lighting.ClockTime,
        Ambient = Lighting.Ambient,
        OutdoorAmbient = Lighting.OutdoorAmbient,
    }

    apply()
    for _, property in ipairs({"Brightness", "ClockTime", "Ambient", "OutdoorAmbient"}) do
        table.insert(Connections, Lighting:GetPropertyChangedSignal(property):Connect(apply))
    end
end

function Fullbright:Disable()
    Enabled = false
    disconnectAll()
    if Defaults then
        Lighting.Brightness = Defaults.Brightness
        Lighting.ClockTime = Defaults.ClockTime
        Lighting.Ambient = Defaults.Ambient
        Lighting.OutdoorAmbient = Defaults.OutdoorAmbient
    end
    Defaults = nil
end

function Fullbright:IsEnabled() return Enabled end
function Fullbright:GetState() return Enabled and "on" or "off" end

return Fullbright
]====],
        [ [====[Features/UI/HighContrast.lua]====] ] = [====[local HighContrast = {}
local Lighting = game:GetService("Lighting")

local Enabled = false
local Effect = nil

local function build()
    if Effect and Effect.Parent then return end
    Effect = Lighting:FindFirstChild("SquidNoMo_HighContrast")
    if not Effect then
        Effect = Instance.new("ColorCorrectionEffect")
        Effect.Name = "SquidNoMo_HighContrast"
        Effect.Brightness = 0.03
        Effect.Contrast = 0.28
        Effect.Saturation = 0.08
        Effect.TintColor = Color3.fromRGB(255, 250, 255)
        Effect.Parent = Lighting
    end
end

function HighContrast:Enable()
    if Enabled then return end
    Enabled = true
    build()
    Effect.Enabled = true
end

function HighContrast:Disable()
    Enabled = false
    if Effect then
        Effect:Destroy()
        Effect = nil
    end
end

function HighContrast:IsEnabled() return Enabled end
function HighContrast:GetState() return Enabled and "on" or "off" end

return HighContrast
]====],
        [ [====[Features/UI/Init.lua]====] ] = [====[local UI = {}

function UI:Initialize(Loader)
    local function Load(name)
        local path = "Features/UI/" .. name .. ".lua"
        if type(Loader.LoadRemote) == "function" then
            return Loader:LoadRemote(path)
        end
        return loadstring(game:HttpGet(
            Loader.Config.Repository .. path
        ))()
    end

    local CoreGuiToggle = Load("CoreGuiToggle")

    local function CreateCoreToggle(enumName)
        local ok, enumItem = pcall(function()
            return Enum.CoreGuiType[enumName]
        end)
        if ok and enumItem then
            return CoreGuiToggle.new(enumItem)
        end

        local unavailable = {Enabled = false}
        function unavailable:Enable() self.Enabled = false end
        function unavailable:Disable() self.Enabled = false end
        function unavailable:IsEnabled() return false end
        function unavailable:GetState() return "off" end
        return unavailable
    end

    self.Crosshair = Load("Crosshair")
    self.PerformanceHUD = Load("PerformanceHUD")
    self.RoleLegend = Load("RoleLegend")
    self.SessionHUD = Load("SessionHUD")
    self.CoordinatesHUD = Load("CoordinatesHUD")
    self.SpeedHUD = Load("SpeedHUD")
    self.CompassHUD = Load("CompassHUD")
    self.ServerHUD = Load("ServerHUD")
    self.ClockHUD = Load("ClockHUD")

    self.HideChat = CreateCoreToggle("Chat")
    self.HidePlayerList = CreateCoreToggle("PlayerList")
    self.HideBackpack = CreateCoreToggle("Backpack")
    self.HideHealth = CreateCoreToggle("Health")
    self.HideEmotes = CreateCoreToggle("EmotesMenu")

    self.RemoveBlur = Load("RemoveBlur")
    self.Fullbright = Load("Fullbright")
    self.ScreenEffects = Load("ScreenEffects")
    self.RemoveAtmosphere = Load("RemoveAtmosphere")
    self.RemoveFog = Load("RemoveFog")
    self.DisableShadows = Load("DisableShadows")
    self.DisableParticles = Load("DisableParticles")
    self.CameraFOV = Load("CameraFOV")
    self.HighContrast = Load("HighContrast")

    local manager = Loader.FeatureManager
    if manager and type(manager.RegisterFeature) == "function" then
        manager:RegisterFeature("ui.crosshair", self.Crosshair, {Name = "Crosshair", Category = "Safe", DefaultColor = Color3.fromRGB(255, 58, 145)})
        manager:RegisterFeature("ui.performance_hud", self.PerformanceHUD, {Name = "Performance HUD", Category = "Safe"})
        manager:RegisterFeature("ui.role_legend", self.RoleLegend, {Name = "Role Legend", Category = "Safe"})
        manager:RegisterFeature("ui.session_hud", self.SessionHUD, {Name = "Session Timer HUD", Category = "Safe"})
        manager:RegisterFeature("ui.coordinates_hud", self.CoordinatesHUD, {Name = "Coordinates HUD", Category = "Safe"})
        manager:RegisterFeature("ui.speed_hud", self.SpeedHUD, {Name = "Speed HUD", Category = "Safe"})
        manager:RegisterFeature("ui.compass_hud", self.CompassHUD, {Name = "Compass HUD", Category = "Safe"})
        manager:RegisterFeature("ui.server_hud", self.ServerHUD, {Name = "Server Info HUD", Category = "Safe"})
        manager:RegisterFeature("ui.clock_hud", self.ClockHUD, {Name = "Clock HUD", Category = "Safe"})

        manager:RegisterFeature("ui.hide_chat", self.HideChat, {Name = "Hide Chat", Category = "Safe"})
        manager:RegisterFeature("ui.hide_player_list", self.HidePlayerList, {Name = "Hide Player List", Category = "Safe"})
        manager:RegisterFeature("ui.hide_backpack", self.HideBackpack, {Name = "Hide Backpack", Category = "Safe"})
        manager:RegisterFeature("ui.hide_health", self.HideHealth, {Name = "Hide Health UI", Category = "Safe"})
        manager:RegisterFeature("ui.hide_emotes", self.HideEmotes, {Name = "Hide Emotes UI", Category = "Safe"})

        manager:RegisterFeature("ui.remove_blur", self.RemoveBlur, {Name = "Remove Blur", Category = "Safe"})
        manager:RegisterFeature("ui.fullbright", self.Fullbright, {Name = "Fullbright", Category = "SemiSafe"})
        manager:RegisterFeature("ui.screen_effects", self.ScreenEffects, {Name = "Disable Screen Effects", Category = "SemiSafe"})
        manager:RegisterFeature("ui.remove_atmosphere", self.RemoveAtmosphere, {Name = "Remove Atmosphere", Category = "Safe"})
        manager:RegisterFeature("ui.remove_fog", self.RemoveFog, {Name = "Remove Fog", Category = "Safe"})
        manager:RegisterFeature("ui.disable_shadows", self.DisableShadows, {Name = "Disable Shadows", Category = "Safe"})
        manager:RegisterFeature("ui.disable_particles", self.DisableParticles, {Name = "Disable Particles", Category = "Safe"})
        manager:RegisterFeature("ui.camera_fov", self.CameraFOV, {Name = "Camera FOV", Category = "Safe", DefaultValue = 70})
        manager:RegisterFeature("ui.high_contrast", self.HighContrast, {Name = "High Contrast", Category = "Safe"})
    end

    return self
end

return UI
]====],
        [ [====[Features/UI/PerformanceHUD.lua]====] ] = [====[local PerformanceHUD = {}

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local Stats = game:GetService("Stats")
local CoreGui = game:GetService("CoreGui")

local Enabled = false
local Gui = nil
local Thread = nil
local Generation = 0

local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end
local FrameSampler = Environment.__SquidNoMoFrameSampler
if type(FrameSampler) ~= "table" or FrameSampler.Revision ~= "1.1b1-frame-sampler-r1" then
    FrameSampler = {Revision = "1.1b1-frame-sampler-r1", FPS = 60, Frames = 0, LastUpdate = os.clock()}
    FrameSampler.Connection = RunService.RenderStepped:Connect(function()
        FrameSampler.Frames = FrameSampler.Frames + 1
        local now = os.clock()
        local elapsed = now - FrameSampler.LastUpdate
        if elapsed >= 0.75 then
            FrameSampler.FPS = math.max(1, math.floor(FrameSampler.Frames / elapsed + 0.5))
            FrameSampler.Frames = 0
            FrameSampler.LastUpdate = now
        end
    end)
    Environment.__SquidNoMoFrameSampler = FrameSampler
end

local function getParent()
    if type(gethui) == "function" then
        local ok, result = pcall(gethui)
        if ok and result then return result end
    end
    local player = Players.LocalPlayer
    return (player and player:FindFirstChildOfClass("PlayerGui")) or CoreGui
end

local function build()
    if Gui and Gui.Parent then return Gui:FindFirstChild("Value", true) end
    Gui = Instance.new("ScreenGui")
    Gui.Name = "SquidNoMo_PerformanceHUD"
    Gui.IgnoreGuiInset = true
    Gui.ResetOnSpawn = false
    Gui.DisplayOrder = 999980
    Gui.Parent = getParent()

    local panel = Instance.new("Frame")
    panel.Position = UDim2.fromOffset(12, 12)
    panel.Size = UDim2.fromOffset(220, 34)
    panel.BackgroundColor3 = Color3.fromRGB(12, 9, 18)
    panel.BackgroundTransparency = 0.12
    panel.BorderSizePixel = 0
    panel.Parent = Gui
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 10)
    corner.Parent = panel
    local outline = Instance.new("UIStroke")
    outline.Color = Color3.fromRGB(0, 205, 255)
    outline.Transparency = 0.18
    outline.Parent = panel

    local label = Instance.new("TextLabel")
    label.Name = "Value"
    label.Size = UDim2.new(1, -16, 1, 0)
    label.Position = UDim2.fromOffset(8, 0)
    label.BackgroundTransparency = 1
    label.Font = Enum.Font.GothamBold
    label.Text = "FPS --  |  PING --  |  PLAYERS --"
    label.TextSize = 11
    label.TextColor3 = Color3.fromRGB(240, 245, 255)
    label.TextXAlignment = Enum.TextXAlignment.Center
    label.Parent = panel
    return label
end

function PerformanceHUD:Enable()
    if Enabled then return end
    Enabled = true
    Generation = Generation + 1
    local generation = Generation
    local label = build()
    Gui.Enabled = true
    Thread = task.spawn(function()
        while Enabled and generation == Generation and Gui and Gui.Parent do
            local ping = "--"
            pcall(function()
                ping = tostring(math.floor(Stats.Network.ServerStatsItem["Data Ping"]:GetValue()))
            end)
            if label and label.Parent then
                label.Text = string.format(
                    "FPS %d  |  PING %s ms  |  PLAYERS %d",
                    FrameSampler.FPS,
                    ping,
                    #Players:GetPlayers()
                )
            end
            task.wait(1)
        end
    end)
end

function PerformanceHUD:Disable()
    Enabled = false
    Generation = Generation + 1
    Thread = nil
    if Gui then Gui.Enabled = false end
end

function PerformanceHUD:IsEnabled() return Enabled end
function PerformanceHUD:GetState() return Enabled and "on" or "off" end

return PerformanceHUD
]====],
        [ [====[Features/UI/RemoveAtmosphere.lua]====] ] = [====[local RemoveAtmosphere = {}
local Lighting = game:GetService("Lighting")

local Enabled = false
local States = {}
local Connection = nil

local function apply(object)
    if not object:IsA("Atmosphere") then return end
    if not States[object] then
        States[object] = {
            Density = object.Density,
            Haze = object.Haze,
            Glare = object.Glare,
        }
    end
    object.Density = 0
    object.Haze = 0
    object.Glare = 0
end

function RemoveAtmosphere:Enable()
    if Enabled then return end
    Enabled = true
    for _, child in ipairs(Lighting:GetChildren()) do
        apply(child)
    end
    Connection = Lighting.ChildAdded:Connect(function(child)
        if Enabled then apply(child) end
    end)
end

function RemoveAtmosphere:Disable()
    Enabled = false
    if Connection then Connection:Disconnect() Connection = nil end
    for object, state in pairs(States) do
        if object and object.Parent then
            object.Density = state.Density
            object.Haze = state.Haze
            object.Glare = state.Glare
        end
    end
    table.clear(States)
end

function RemoveAtmosphere:IsEnabled() return Enabled end
function RemoveAtmosphere:GetState() return Enabled and "on" or "off" end

return RemoveAtmosphere
]====],
        [ [====[Features/UI/RemoveBlur.lua]====] ] = [====[local RemoveBlur = {}
local Lighting = game:GetService("Lighting")
local Enabled = false
local States = {}
local Connection = nil

local function disable(effect)
    if effect:IsA("BlurEffect") then
        if States[effect] == nil then States[effect] = effect.Enabled end
        effect.Enabled = false
    end
end

function RemoveBlur:Enable()
    if Enabled then return end
    Enabled = true
    for _, child in ipairs(Lighting:GetChildren()) do disable(child) end
    Connection = Lighting.ChildAdded:Connect(function(child)
        if Enabled then disable(child) end
    end)
end

function RemoveBlur:Disable()
    Enabled = false
    if Connection then Connection:Disconnect() Connection = nil end
    for effect, state in pairs(States) do
        if effect and effect.Parent then effect.Enabled = state end
    end
    table.clear(States)
end

function RemoveBlur:IsEnabled() return Enabled end
function RemoveBlur:GetState() return Enabled and "on" or "off" end
return RemoveBlur
]====],
        [ [====[Features/UI/RemoveFog.lua]====] ] = [====[local RemoveFog = {}
local Lighting = game:GetService("Lighting")

local Enabled = false
local Defaults = nil

function RemoveFog:Enable()
    if Enabled then return end
    Enabled = true
    Defaults = {
        FogStart = Lighting.FogStart,
        FogEnd = Lighting.FogEnd,
        FogColor = Lighting.FogColor,
    }
    Lighting.FogStart = 100000
    Lighting.FogEnd = 1000000
end

function RemoveFog:Disable()
    if not Enabled then return end
    Enabled = false
    if Defaults then
        Lighting.FogStart = Defaults.FogStart
        Lighting.FogEnd = Defaults.FogEnd
        Lighting.FogColor = Defaults.FogColor
    end
    Defaults = nil
end

function RemoveFog:IsEnabled() return Enabled end
function RemoveFog:GetState() return Enabled and "on" or "off" end

return RemoveFog
]====],
        [ [====[Features/UI/RoleLegend.lua]====] ] = [====[local RoleLegend = {}

local Players = game:GetService("Players")
local CoreGui = game:GetService("CoreGui")
local Enabled = false
local Gui = nil

local function getParent()
    if type(gethui) == "function" then
        local ok, result = pcall(gethui)
        if ok and result then return result end
    end
    local player = Players.LocalPlayer
    return (player and player:FindFirstChildOfClass("PlayerGui")) or CoreGui
end

local function build()
    if Gui and Gui.Parent then return end
    Gui = Instance.new("ScreenGui")
    Gui.Name = "SquidNoMo_RoleLegend"
    Gui.IgnoreGuiInset = true
    Gui.ResetOnSpawn = false
    Gui.DisplayOrder = 999970
    Gui.Parent = getParent()

    local panel = Instance.new("Frame")
    panel.AnchorPoint = Vector2.new(1, 0)
    panel.Position = UDim2.new(1, -12, 0, 12)
    panel.Size = UDim2.fromOffset(160, 124)
    panel.BackgroundColor3 = Color3.fromRGB(12, 9, 18)
    panel.BackgroundTransparency = 0.12
    panel.BorderSizePixel = 0
    panel.Parent = Gui
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 10)
    corner.Parent = panel
    local outline = Instance.new("UIStroke")
    outline.Color = Color3.fromRGB(255, 196, 64)
    outline.Transparency = 0.18
    outline.Parent = panel

    local title = Instance.new("TextLabel")
    title.Position = UDim2.fromOffset(10, 5)
    title.Size = UDim2.new(1, -20, 0, 22)
    title.BackgroundTransparency = 1
    title.Font = Enum.Font.GothamBlack
    title.Text = "ROLE COLORS"
    title.TextSize = 11
    title.TextColor3 = Color3.fromRGB(255, 196, 64)
    title.TextXAlignment = Enum.TextXAlignment.Left
    title.Parent = panel

    local roles = {
        {"Player", Color3.fromRGB(0, 170, 255)},
        {"Guard", Color3.fromRGB(235, 55, 70)},
        {"Detective", Color3.fromRGB(0, 230, 150)},
        {"Frontman", Color3.fromRGB(172, 76, 255)},
    }
    for index, entry in ipairs(roles) do
        local dot = Instance.new("Frame")
        dot.Position = UDim2.fromOffset(12, 29 + ((index - 1) * 22))
        dot.Size = UDim2.fromOffset(12, 12)
        dot.BackgroundColor3 = entry[2]
        dot.BorderSizePixel = 0
        dot.Parent = panel
        local dotCorner = Instance.new("UICorner")
        dotCorner.CornerRadius = UDim.new(1, 0)
        dotCorner.Parent = dot

        local label = Instance.new("TextLabel")
        label.Position = UDim2.fromOffset(32, 25 + ((index - 1) * 22))
        label.Size = UDim2.new(1, -42, 0, 20)
        label.BackgroundTransparency = 1
        label.Font = Enum.Font.GothamMedium
        label.Text = entry[1]
        label.TextSize = 10
        label.TextColor3 = Color3.fromRGB(240, 236, 244)
        label.TextXAlignment = Enum.TextXAlignment.Left
        label.Parent = panel
    end
end

function RoleLegend:Enable()
    Enabled = true
    build()
    if Gui then Gui.Enabled = true end
end
function RoleLegend:Disable()
    Enabled = false
    if Gui then Gui.Enabled = false end
end
function RoleLegend:IsEnabled() return Enabled end
function RoleLegend:GetState() return Enabled and "on" or "off" end

return RoleLegend
]====],
        [ [====[Features/UI/ScreenEffects.lua]====] ] = [====[local ScreenEffects = {}
local Lighting = game:GetService("Lighting")
local Enabled = false
local States = {}
local Connection = nil

local function supported(effect)
    if effect.Name == "SquidNoMo_HighContrast" then
        return false
    end
    return effect:IsA("BloomEffect")
        or effect:IsA("SunRaysEffect")
        or effect:IsA("DepthOfFieldEffect")
        or effect:IsA("ColorCorrectionEffect")
end

local function disable(effect)
    if supported(effect) then
        if States[effect] == nil then States[effect] = effect.Enabled end
        effect.Enabled = false
    end
end

function ScreenEffects:Enable()
    if Enabled then return end
    Enabled = true
    for _, child in ipairs(Lighting:GetChildren()) do disable(child) end
    Connection = Lighting.ChildAdded:Connect(function(child)
        if Enabled then disable(child) end
    end)
end

function ScreenEffects:Disable()
    Enabled = false
    if Connection then Connection:Disconnect() Connection = nil end
    for effect, state in pairs(States) do
        if effect and effect.Parent then effect.Enabled = state end
    end
    table.clear(States)
end

function ScreenEffects:IsEnabled() return Enabled end
function ScreenEffects:GetState() return Enabled and "on" or "off" end
return ScreenEffects
]====],
        [ [====[Features/UI/ServerHUD.lua]====] ] = [====[local ServerHUD = {}
local Players = game:GetService("Players")
local CoreGui = game:GetService("CoreGui")

local Enabled = false
local Gui = nil
local Thread = nil
local Generation = 0

local function getParent()
    if type(gethui) == "function" then
        local ok, result = pcall(gethui)
        if ok and result then return result end
    end
    local player = Players.LocalPlayer
    return (player and player:FindFirstChildOfClass("PlayerGui")) or CoreGui
end

local function build()
    if Gui and Gui.Parent then return Gui:FindFirstChild("Value", true) end
    Gui = Instance.new("ScreenGui")
    Gui.Name = "SquidNoMo_ServerHUD"
    Gui.IgnoreGuiInset = true
    Gui.ResetOnSpawn = false
    Gui.DisplayOrder = 999975
    Gui.Parent = getParent()

    local panel = Instance.new("Frame")
    panel.AnchorPoint = Vector2.new(1, 1)
    panel.Position = UDim2.new(1, -12, 1, -12)
    panel.Size = UDim2.fromOffset(250, 34)
    panel.BackgroundColor3 = Color3.fromRGB(12, 9, 18)
    panel.BackgroundTransparency = 0.12
    panel.BorderSizePixel = 0
    panel.Parent = Gui
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 10)
    corner.Parent = panel
    local outline = Instance.new("UIStroke")
    outline.Color = Color3.fromRGB(0, 170, 255)
    outline.Transparency = 0.18
    outline.Parent = panel

    local label = Instance.new("TextLabel")
    label.Name = "Value"
    label.Size = UDim2.new(1, -16, 1, 0)
    label.Position = UDim2.fromOffset(8, 0)
    label.BackgroundTransparency = 1
    label.Font = Enum.Font.GothamBold
    label.Text = "SERVER --"
    label.TextSize = 10
    label.TextColor3 = Color3.fromRGB(240, 245, 255)
    label.Parent = panel
    return label
end

function ServerHUD:Enable()
    if Enabled then return end
    Enabled = true
    Generation = Generation + 1
    local generation = Generation
    local label = build()
    Gui.Enabled = true
    Thread = task.spawn(function()
        while Enabled and generation == Generation and Gui and Gui.Parent do
            local job = tostring(game.JobId or "")
            local shortJob = #job > 8 and string.sub(job, 1, 8) or job
            if shortJob == "" then shortJob = "STUDIO" end
            if label and label.Parent then
                label.Text = string.format("PLACE %s  |  %s  |  %d PLAYERS", tostring(game.PlaceId), shortJob, #Players:GetPlayers())
            end
            task.wait(1)
        end
    end)
end

function ServerHUD:Disable()
    Enabled = false
    Generation = Generation + 1
    Thread = nil
    if Gui then Gui.Enabled = false end
end

function ServerHUD:IsEnabled() return Enabled end
function ServerHUD:GetState() return Enabled and "on" or "off" end

return ServerHUD
]====],
        [ [====[Features/UI/SessionHUD.lua]====] ] = [====[local SessionHUD = {}
local Players = game:GetService("Players")
local CoreGui = game:GetService("CoreGui")

local Enabled = false
local Gui = nil
local Thread = nil
local Generation = 0
local StartedAt = 0

local function getParent()
    if type(gethui) == "function" then
        local ok, result = pcall(gethui)
        if ok and result then return result end
    end
    local player = Players.LocalPlayer
    return (player and player:FindFirstChildOfClass("PlayerGui")) or CoreGui
end

local function build()
    if Gui and Gui.Parent then return Gui:FindFirstChild("Value", true) end

    Gui = Instance.new("ScreenGui")
    Gui.Name = "SquidNoMo_SessionHUD"
    Gui.IgnoreGuiInset = true
    Gui.ResetOnSpawn = false
    Gui.DisplayOrder = 999979
    Gui.Parent = getParent()

    local panel = Instance.new("Frame")
    panel.Position = UDim2.fromOffset(12, 54)
    panel.Size = UDim2.fromOffset(180, 34)
    panel.BackgroundColor3 = Color3.fromRGB(12, 9, 18)
    panel.BackgroundTransparency = 0.12
    panel.BorderSizePixel = 0
    panel.Parent = Gui
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 10)
    corner.Parent = panel
    local outline = Instance.new("UIStroke")
    outline.Color = Color3.fromRGB(172, 76, 255)
    outline.Transparency = 0.18
    outline.Parent = panel

    local label = Instance.new("TextLabel")
    label.Name = "Value"
    label.Size = UDim2.new(1, -16, 1, 0)
    label.Position = UDim2.fromOffset(8, 0)
    label.BackgroundTransparency = 1
    label.Font = Enum.Font.GothamBold
    label.Text = "SESSION 00:00:00"
    label.TextSize = 11
    label.TextColor3 = Color3.fromRGB(240, 245, 255)
    label.Parent = panel
    return label
end

local function formatTime(seconds)
    seconds = math.max(0, math.floor(seconds))
    local hours = math.floor(seconds / 3600)
    local minutes = math.floor((seconds % 3600) / 60)
    local secs = seconds % 60
    return string.format("%02d:%02d:%02d", hours, minutes, secs)
end

function SessionHUD:Enable()
    if Enabled then return end
    Enabled = true
    StartedAt = os.clock()
    local label = build()
    Gui.Enabled = true
    Thread = task.spawn(function()
        while Enabled and generation == Generation and Gui and Gui.Parent do
            if label and label.Parent then
                label.Text = "SESSION " .. formatTime(os.clock() - StartedAt)
            end
            task.wait(1)
        end
    end)
end

function SessionHUD:Disable()
    Enabled = false
    Generation = Generation + 1
    Thread = nil
    if Gui then Gui.Enabled = false end
end

function SessionHUD:IsEnabled() return Enabled end
function SessionHUD:GetState() return Enabled and "on" or "off" end

return SessionHUD
]====],
        [ [====[Features/UI/SpeedHUD.lua]====] ] = [====[local SpeedHUD = {}
local Players = game:GetService("Players")
local CoreGui = game:GetService("CoreGui")
local RunService = game:GetService("RunService")

local LocalPlayer = Players.LocalPlayer
local Enabled = false
local Gui = nil
local Thread = nil
local Generation = 0

local function getParent()
    if type(gethui) == "function" then
        local ok, result = pcall(gethui)
        if ok and result then return result end
    end
    return (LocalPlayer and LocalPlayer:FindFirstChildOfClass("PlayerGui")) or CoreGui
end

local function build()
    if Gui and Gui.Parent then return Gui:FindFirstChild("Value", true) end
    Gui = Instance.new("ScreenGui")
    Gui.Name = "SquidNoMo_SpeedHUD"
    Gui.IgnoreGuiInset = true
    Gui.ResetOnSpawn = false
    Gui.DisplayOrder = 999977
    Gui.Parent = getParent()

    local panel = Instance.new("Frame")
    panel.AnchorPoint = Vector2.new(0.5, 1)
    panel.Position = UDim2.new(0.5, 0, 1, -12)
    panel.Size = UDim2.fromOffset(150, 34)
    panel.BackgroundColor3 = Color3.fromRGB(12, 9, 18)
    panel.BackgroundTransparency = 0.12
    panel.BorderSizePixel = 0
    panel.Parent = Gui
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 10)
    corner.Parent = panel
    local outline = Instance.new("UIStroke")
    outline.Color = Color3.fromRGB(255, 196, 64)
    outline.Transparency = 0.18
    outline.Parent = panel

    local label = Instance.new("TextLabel")
    label.Name = "Value"
    label.Size = UDim2.new(1, -16, 1, 0)
    label.Position = UDim2.fromOffset(8, 0)
    label.BackgroundTransparency = 1
    label.Font = Enum.Font.GothamBold
    label.Text = "SPEED --"
    label.TextSize = 11
    label.TextColor3 = Color3.fromRGB(240, 245, 255)
    label.Parent = panel
    return label
end

function SpeedHUD:Enable()
    if Enabled then return end
    Enabled = true
    Generation = Generation + 1
    local generation = Generation
    local label = build()
    Gui.Enabled = true
    Thread = task.spawn(function()
        while Enabled and generation == Generation and Gui and Gui.Parent do
            local character = LocalPlayer and LocalPlayer.Character
            local root = character and character:FindFirstChild("HumanoidRootPart")
            local speed = root and Vector3.new(root.AssemblyLinearVelocity.X, 0, root.AssemblyLinearVelocity.Z).Magnitude or 0
            if label and label.Parent then label.Text = string.format("SPEED %.0f", speed) end
            task.wait(0.15)
        end
    end)
end

function SpeedHUD:Disable()
    Enabled = false
    Generation = Generation + 1
    Thread = nil
    if Gui then Gui.Enabled = false end
end

function SpeedHUD:IsEnabled() return Enabled end
function SpeedHUD:GetState() return Enabled and "on" or "off" end

return SpeedHUD
]====],
        [ [====[Loader.lua]====] ] = [====[--// SquidNoMo loader
-- BUNDLE_COMPATIBLE_LOADER: bundled-startup-recovery-r5

local REPOSITORY = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"

local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

local function HttpGetWithTimeout(url, timeoutSeconds)
    local finished = false
    local success = false
    local result = nil
    task.spawn(function()
        success, result = pcall(function() return game:HttpGet(url) end)
        finished = true
    end)
    local started = os.clock()
    local timeout = tonumber(timeoutSeconds) or 20
    while not finished and os.clock() - started < timeout do
        task.wait(0.05)
    end
    if not finished then error("HTTP request timed out: " .. tostring(url)) end
    if not success then error("HTTP request failed: " .. tostring(result)) end
    if type(result) ~= "string" or #result == 0 then error("HTTP response was empty: " .. tostring(url)) end
    return result
end

local SourceBundle = Environment.__SquidNoMoSourceBundle

local function LoadBuildManifest()
    local cached = Environment.__SquidNoMoBuildManifest
    if type(cached) == "table" and cached.Version and cached.BuildNumber then
        return cached
    end

    local nonce = tostring(math.floor(os.clock() * 1000000))
    local source = HttpGetWithTimeout(
        REPOSITORY .. "BuildManifest.lua?squidnomo_manifest=" .. nonce,
        18
    )
    local chunk, compileError = loadstring(source)
    if not chunk then
        error("[Loader] Build manifest compile failed: " .. tostring(compileError))
    end
    local ok, manifest = pcall(chunk)
    if not ok or type(manifest) ~= "table" then
        error("[Loader] Build manifest load failed: " .. tostring(manifest))
    end
    Environment.__SquidNoMoBuildManifest = manifest
    return manifest
end

local BuildManifest = LoadBuildManifest()
local BUILD_VERSION = tostring(BuildManifest.Version or "SquidNoMo")
local BUILD_NUMBER = tonumber(BuildManifest.BuildNumber) or 0
local BUILD_REVISION = tostring(BuildManifest.Revision or "unknown")

local ExistingSession = Environment.__SquidNoMoSession

if type(ExistingSession) == "table" and ExistingSession.JobId == game.JobId then
    local existingApp = ExistingSession.App
    local sameVersion = ExistingSession.Version == BUILD_VERSION
        and ExistingSession.BuildNumber == BUILD_NUMBER
        and ExistingSession.Revision == BUILD_REVISION

    if sameVersion and existingApp and type(existingApp.BringToFront) == "function" then
        ExistingSession.UserClosed = false
        existingApp:BringToFront()
        return ExistingSession.Loader
    end

    -- Cleanly retire an older in-server build before loading the new version.
    local oldLoader = ExistingSession.Loader
    local oldManager = oldLoader and oldLoader.FeatureManager

    if oldManager and type(oldManager.SetCategoryEnabled) == "function" then
        for _, category in ipairs({"Safe", "SemiSafe", "Experimental"}) do
            pcall(function()
                oldManager:SetCategoryEnabled(category, false)
            end)
        end
    end

    if ExistingSession.CharacterConnection then
        pcall(function()
            ExistingSession.CharacterConnection:Disconnect()
        end)
        ExistingSession.CharacterConnection = nil
    end

    if existingApp and type(existingApp.Destroy) == "function" then
        pcall(function()
            existingApp:Destroy(true)
        end)
    end

    ExistingSession.Loader = nil
    ExistingSession.App = nil
    ExistingSession.UserClosed = false
    ExistingSession.FreeRoamEnabled = true
    ExistingSession.Version = BUILD_VERSION
    ExistingSession.BuildNumber = BUILD_NUMBER
    ExistingSession.Revision = BUILD_REVISION
end

local BUILD_TOKEN = tostring(BuildManifest.BuildToken or string.gsub(
    BUILD_VERSION .. "-" .. BUILD_REVISION,
    "[^%w_%-]",
    "_"
))

if type(SourceBundle) == "table" then
    local sourceToken = tostring(Environment.__SquidNoMoSourceBundleToken or "")
    if sourceToken ~= "" and sourceToken ~= BUILD_TOKEN then
        error("[Loader] Source bundle token mismatch. Upload the complete build together.")
    end
end

local function AddVersion(url)
    local separator = string.find(url, "?", 1, true) and "&" or "?"
    return url .. separator .. "squidnomo_build=" .. BUILD_TOKEN
end

local ConfigSource = type(SourceBundle) == "table" and SourceBundle["Config.lua"] or nil
if type(ConfigSource) ~= "string" then
    ConfigSource = HttpGetWithTimeout(AddVersion(REPOSITORY .. "Config.lua"), 18)
end
local ConfigChunk, ConfigCompileError = loadstring(ConfigSource)
if not ConfigChunk then
    error("[Loader] Config compile failed: " .. tostring(ConfigCompileError))
end
local Config = ConfigChunk()

local Loader = {}
Loader.Config = Config
Loader.ModuleCache = {}
Loader.ModuleNilSentinel = {}
Loader.BuildVersion = BUILD_VERSION
Loader.BuildNumber = BUILD_NUMBER
Loader.BuildRevision = BUILD_REVISION
Loader.Manifest = BuildManifest

local function ResolveQueueOnTeleport()
    if type(queue_on_teleport) == "function" then return queue_on_teleport end
    if type(queueonteleport) == "function" then return queueonteleport end
    if type(syn) == "table" and type(syn.queue_on_teleport) == "function" then
        return syn.queue_on_teleport
    end
    if type(fluxus) == "table" and type(fluxus.queue_on_teleport) == "function" then
        return fluxus.queue_on_teleport
    end
    return nil
end

function Loader:QueueReloadAfterTeleport()
    local queue = ResolveQueueOnTeleport()
    if type(queue) ~= "function" then
        self.TeleportPersistenceAvailable = false
        return false, "queue_on_teleport is unavailable in this executor"
    end

    local queueKey = "__SquidNoMoTeleportQueued_" .. tostring(game.JobId) .. "_" .. BUILD_TOKEN
    if Environment[queueKey] == true then
        self.TeleportPersistenceAvailable = true
        return true, "already queued"
    end

    local source = string.format([=[
repeat task.wait(0.1) until game:IsLoaded()
local ok, err = pcall(function()
    loadstring(game:HttpGet(%q .. "?squidnomo_teleport=" .. tostring(math.floor(os.clock() * 1000000))))()
end)
if not ok then warn("[SquidNoMo] Automatic reload failed: " .. tostring(err)) end
]=], REPOSITORY .. "Main.lua")

    local ok, err = pcall(queue, source)
    if not ok then
        self.TeleportPersistenceAvailable = false
        return false, tostring(err)
    end
    Environment[queueKey] = true
    self.TeleportPersistenceAvailable = true
    return true, "queued"
end

Loader:QueueReloadAfterTeleport()

local Bootstrap = Environment.__SquidNoMoBootstrap
local loadStep = 0
local estimatedSteps = 73

local function ReportLoading(message, progress)
    if type(Bootstrap) == "table" and type(Bootstrap.SetStatus) == "function" then
        Bootstrap:SetStatus(message, progress)
    end
end

ReportLoading("Configuration loaded...", 0.28)

local function EncodeRepositoryPath(path)
    path = tostring(path or "")
    -- Keep directory separators readable while encoding characters that can make
    -- raw GitHub URLs fail in some Roblox/executor HTTP implementations.
    path = string.gsub(path, "%%", "%%25")
    path = string.gsub(path, " ", "%%20")
    path = string.gsub(path, "#", "%%23")
    path = string.gsub(path, "?", "%%3F")
    return path
end

function Loader:GetRemoteUrl(path)
    return AddVersion(self.Config.Repository .. EncodeRepositoryPath(path))
end

function Loader:FetchSource(path)
    local bundled = Environment.__SquidNoMoSourceBundle
    if type(bundled) == "table" then
        local source = bundled[path]
        if type(source) == "string" then
            return source
        end
    end
    return HttpGetWithTimeout(self:GetRemoteUrl(path), 18)
end

function Loader:LoadRemote(path)
    local cached = self.ModuleCache[path]
    if cached ~= nil then
        if cached == self.ModuleNilSentinel then return nil end
        return cached
    end

    print("[Loader] " .. path)
    loadStep = loadStep + 1
    local readable = string.gsub(path, "%.lua$", "")
    readable = string.gsub(readable, "/", " › ")
    local progress = 0.28 + (math.min(loadStep, estimatedSteps) / estimatedSteps) * 0.58
    ReportLoading("Loading " .. readable .. "...", progress)

    local source = self:FetchSource(path)
    local chunk, compileError = loadstring(source)

    if not chunk then
        error(string.format(
            "[Loader] Compile failed for %s: %s",
            path,
            tostring(compileError)
        ))
    end

    local success, result = pcall(chunk)

    if not success then
        error(string.format(
            "[Loader] Execution failed for %s: %s",
            path,
            tostring(result)
        ))
    end

    self.ModuleCache[path] = result == nil and self.ModuleNilSentinel or result
    if loadStep % 8 == 0 then task.wait() end
    return result
end

local function Load(path)
    return Loader:LoadRemote(path)
end

if type(Loader.Manifest) ~= "table"
    or Loader.Manifest.Version ~= BUILD_VERSION
    or tonumber(Loader.Manifest.BuildNumber) ~= BUILD_NUMBER
    or Loader.Manifest.Revision ~= BUILD_REVISION
then
    error(
        "[Loader] Repository build mismatch. Upload the complete "
        .. BUILD_VERSION
        .. " build "
        .. tostring(BUILD_NUMBER)
        .. " / "
        .. BUILD_REVISION
        .. " project before executing it."
    )
end

Loader.Theme = Load("Core/Theme.lua")
Loader.Components = Load("Core/Components.lua")
Loader.Navigation = Load("Core/Navigation.lua")
Loader.Utilities = Load("Core/Utilities.lua")
Loader.Notifications = Load("Core/Notifications.lua")
Loader.SettingsStore = Load("Core/SettingsStore.lua")
Loader.UIStyleManager = Load("Core/UIStyleManager.lua")
Loader.SavedSettings = Loader.SettingsStore:Load()

if Loader.SavedSettings
    and Loader.SavedSettings.BuildVersion
        ~= BUILD_VERSION
    and Loader.SavedSettings.App
    and Loader.SavedSettings.App.UIStyles
    and type(
        Loader.UIStyleManager
            .CreateColorPreservingProfile
    ) == "function"
then
    Loader.SavedSettings.App.UIStyles =
        Loader.UIStyleManager
            :CreateColorPreservingProfile(
                Loader.SavedSettings.App.UIStyles
            )
end

Loader.FeatureCatalog = Load("Modules/FeatureCatalog.lua")
Loader.FeatureManager = Load("Features/FeatureManager.lua")
Loader.App = Load("Core/App.lua")

Loader.Home = Load("Modules/Home.lua")
Loader.CategoryStrip = Load("Modules/CategoryStrip.lua")
Loader.FeatureFolder = Load("Modules/FeatureFolder.lua")
Loader.Games = Load("Modules/Games.lua")
Loader.Players = Load("Modules/Players.lua")
Loader.Guards = Load("Modules/Guards.lua")
Loader.Detective = Load("Modules/Detective.lua")
Loader.Farming = Load("Modules/Farming.lua")
Loader.UI = Load("Modules/UI.lua")

Loader.HeroBanner = Load("Modules/Home/HeroBanner.lua")
Loader.FeatureGroups = Load("Modules/Home/FeatureGroups.lua")
Loader.ServerStatus = Load("Modules/Home/ServerStatus.lua")
Loader.NOMOAI = Load("Modules/Home/NOMOAI.lua")
Loader.SupportDevelopment = Load("Modules/Home/SupportDevelopment.lua")
Loader.DevelopmentGoal = Load("Modules/Home/DevelopmentGoal.lua")
Loader.Supporters = Load("Modules/Home/Supporters.lua")
Loader.ImportantNotice = Load("Modules/Home/ImportantNotice.lua")
Loader.Footer = Load("Modules/Home/Footer.lua")

local function GetOrCreateSession()
    local session = Environment.__SquidNoMoSession
    local acceptedByServer = Environment.__SquidNoMoTermsAcceptedByServer
    if type(acceptedByServer) ~= "table" then
        acceptedByServer = {}
        Environment.__SquidNoMoTermsAcceptedByServer = acceptedByServer
    end

    if type(session) ~= "table"
        or session.JobId ~= game.JobId
    then
        session = {
            JobId = game.JobId,
            TermsAccepted = acceptedByServer[game.JobId] == true,
            UserClosed = false,
            DetectionStatus = "UNKNOWN",
            DetectionDetail =
                "No status signal has been reported.",
            FreeRoamEnabled = true,
            FullScreenEnabled = false,
            ButtonGlowEnabled = true,
            NavigationGlowEnabled = true,
            CloseConfirmationEnabled = true,
            ReducedMotionEnabled = false,
            RememberLastPageEnabled = true,
            AutoCenterOnResizeEnabled = true,
            AutoApplyPerGameEnabled = true,
            LightweightModeEnabled = true,
            UserScale = 1.0,
            BubbleSize = nil,
            WindowOpacity = 0,
            LastPage = "Home",
            SelectedGameCategory =
                "Red Light, Green Light",
            SelectedGuardCategory = "Game Moderation",
            SelectedPlayerCategory =
                "Movement & Camera",
            SelectedFarmingCategory = "Player Farming",
            SelectedDetectiveCategory = "Island Navigation",
            SelectedUICategory = "Layout & Scale",
            UIEditScope = "Entire App",
            UIEditTargetPage = "Players",
            UIStyles = nil,
            LastSafePosition = nil,
        }
        Environment.__SquidNoMoSession = session
    end

    if acceptedByServer[game.JobId] == true then
        session.TermsAccepted = true
    end
    return session
end

local Session = GetOrCreateSession()
local savedApp = Loader.SavedSettings
    and Loader.SavedSettings.App

if type(savedApp) == "table" then
    local keys = {
        "FreeRoamEnabled",
        "FullScreenEnabled",
        "ButtonGlowEnabled",
        "NavigationGlowEnabled",
        "CloseConfirmationEnabled",
        "ReducedMotionEnabled",
        "RememberLastPageEnabled",
        "AutoCenterOnResizeEnabled",
        "AutoApplyPerGameEnabled",
        "LightweightModeEnabled",
        "UserScale",
        "BubbleSize",
        "WindowOpacity",
        "LastPage",
        "SelectedGameCategory",
        "SelectedGuardCategory",
        "SelectedPlayerCategory",
        "SelectedFarmingCategory",
        "SelectedDetectiveCategory",
        "SelectedUICategory",
        "UIEditScope",
        "UIEditTargetPage",
        "UIStyles",
    }

    for _, key in ipairs(keys) do
        if savedApp[key] ~= nil then
            Session[key] = savedApp[key]
        end
    end
end

ReportLoading("Initializing feature modules...", 0.88)

-- Features must exist before Players and UI pages capture their references.
local featuresLoaded, featuresOrError = pcall(function()
    return Loader.FeatureManager:Initialize(Loader)
end)

if featuresLoaded then
    Loader.Features = featuresOrError

    local shared = Loader.Features and Loader.Features.Shared
    local featureRuntime = shared and shared.Runtime
    local playerRuntime = shared and shared.PlayerRuntime
    if type(featureRuntime) ~= "table"
        or featureRuntime.Revision ~= Loader.Manifest.FeatureRuntimeRevision
        or tonumber(featureRuntime.BuildNumber) ~= BUILD_NUMBER
        or type(playerRuntime) ~= "table"
        or playerRuntime.Revision ~= Loader.Manifest.PlayerRuntimeRevision
        or tonumber(playerRuntime.BuildNumber) ~= BUILD_NUMBER
    then
        error(
            "[Loader] Shared runtime revision mismatch. Upload Runtime.lua, "
            .. "PlayerRuntime.lua, every feature wrapper, and BuildManifest.lua together."
        )
    end

    if Loader.SavedSettings
        and type(Loader.SavedSettings.Features) == "table"
        and type(Loader.FeatureManager.ApplySettings) == "function"
    then
        print(
            "[Loader] Restored feature settings:",
            Loader.FeatureManager:ApplySettings(
                Loader.SavedSettings.Features
            )
        )
    end

    local expectedTotal = Loader.Manifest
        and tonumber(
            Loader.Manifest.ExpectedRegistryTotal
        )
    local actualTotal = type(
        Loader.FeatureManager.GetTotalCount
    ) == "function"
        and Loader.FeatureManager:GetTotalCount()
        or 0

    if expectedTotal
        and actualTotal ~= expectedTotal
    then
        error(
            "[Loader] Feature registry mismatch. Expected "
            .. tostring(expectedTotal)
            .. " features but registered "
            .. tostring(actualTotal)
            .. ". Upload the complete repository build."
        )
    end

    print(
        "[Loader] Features initialized before page build:",
        actualTotal
    )
else
    error(
        "[Loader] Feature initialization failed: "
        .. tostring(featuresOrError)
    )
end

Loader.App.Features = Loader.Features
ReportLoading("Building the interface...", 0.94)
Loader.App:Build(Loader)
Loader.App:AttachFeatureManager(Loader.FeatureManager, Loader.Features)
if Environment.__SquidNoMoOpenMinimized == true and type(Loader.App.SetMinimized) == "function" then
    Loader.App:SetMinimized(true)
    Environment.__SquidNoMoOpenMinimized = nil
end
ReportLoading("Finalizing startup...", 0.98)

Session.Version = BUILD_VERSION
Session.BuildNumber = BUILD_NUMBER
Session.Revision = BUILD_REVISION
Session.Loader = Loader
Session.App = Loader.App
Session.UserClosed = false

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

if Session.CharacterConnection then
    pcall(function()
        Session.CharacterConnection:Disconnect()
    end)
end

if LocalPlayer then
    if Session.TeleportConnection then
        pcall(function() Session.TeleportConnection:Disconnect() end)
        Session.TeleportConnection = nil
    end
    Session.TeleportConnection = LocalPlayer.OnTeleport:Connect(function(state)
        if state == Enum.TeleportState.Started or state == Enum.TeleportState.InProgress then
            pcall(function()
                if Loader.App and type(Loader.App.SavePersistentSettingsNow) == "function" then
                    Loader.App:SavePersistentSettingsNow(false)
                end
            end)
            pcall(function() Loader:QueueReloadAfterTeleport() end)
        end
    end)

    Session.CharacterConnection = LocalPlayer.CharacterAdded:Connect(function()
        task.wait(1)

        if Session.JobId ~= game.JobId or Session.UserClosed then
            return
        end

        if not Loader.App:IsVisible() then
            Loader.App.Features = Loader.Features
            Loader.App:Build(Loader)
            Loader.App:AttachFeatureManager(
                Loader.FeatureManager,
                Loader.Features
            )
        end
    end)
end

return Loader
]====],
        [ [====[Main.lua]====] ] = [====[--// SquidNoMo entry point

local REPOSITORY = "https://raw.githubusercontent.com/JaysScriptz/SquidNoMo/main/"
local BANNER_PATH = "Images/BannerGuards.png"

local function HttpGetWithTimeout(url, timeoutSeconds)
    local finished = false
    local success = false
    local result = nil

    task.spawn(function()
        success, result = pcall(function()
            return game:HttpGet(url)
        end)
        finished = true
    end)

    local started = os.clock()
    local timeout = tonumber(timeoutSeconds) or 20
    while not finished and os.clock() - started < timeout do
        task.wait(0.05)
    end

    if not finished then
        error("HTTP request timed out after " .. tostring(timeout) .. " seconds: " .. tostring(url))
    end
    if not success then
        error("HTTP request failed: " .. tostring(result))
    end
    if type(result) ~= "string" or #result == 0 then
        error("HTTP request returned an empty response: " .. tostring(url))
    end
    return result
end

local function LoadBuildManifest()
    local nonce = tostring(math.floor(os.clock() * 1000000))
    local source = HttpGetWithTimeout(
        REPOSITORY .. "BuildManifest.lua?squidnomo_manifest=" .. nonce,
        18
    )
    local chunk, compileError = loadstring(source)
    if not chunk then
        error("Build manifest compile failed: " .. tostring(compileError))
    end
    local ok, manifest = pcall(chunk)
    if not ok or type(manifest) ~= "table" then
        error("Build manifest load failed: " .. tostring(manifest))
    end
    return manifest
end

local BuildManifest = LoadBuildManifest()
local BUILD_VERSION = tostring(BuildManifest.Version or "SquidNoMo")
local BUILD_NUMBER = tonumber(BuildManifest.BuildNumber) or 0
local BUILD_REVISION = tostring(BuildManifest.Revision or "unknown")
local BUILD_TOKEN = tostring(BuildManifest.BuildToken or string.gsub(
    BUILD_VERSION .. "-" .. BUILD_REVISION,
    "[^%w_%-]",
    "_"
))

local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then
        Environment = result
    end
end

Environment.__SquidNoMoBuildManifest = BuildManifest

local function resolveQueueOnTeleport()
    if type(queue_on_teleport) == "function" then return queue_on_teleport end
    if type(queueonteleport) == "function" then return queueonteleport end
    if type(syn) == "table" and type(syn.queue_on_teleport) == "function" then return syn.queue_on_teleport end
    if type(fluxus) == "table" and type(fluxus.queue_on_teleport) == "function" then return fluxus.queue_on_teleport end
    return nil
end

local function queueSelfForTeleport()
    local queue = resolveQueueOnTeleport()
    if type(queue) ~= "function" then return false end
    local key = "__SquidNoMoTeleportQueued_" .. tostring(game.JobId) .. "_" .. BUILD_TOKEN
    if Environment[key] == true then return true end
    local queuedSource = string.format([=[
repeat task.wait(0.1) until game:IsLoaded()
local ok, err = pcall(function()
    loadstring(game:HttpGet(%q .. "?squidnomo_teleport=" .. tostring(math.floor(os.clock() * 1000000))))()
end)
if not ok then warn("[SquidNoMo] Automatic reload failed: " .. tostring(err)) end
]=], REPOSITORY .. "Main.lua")
    local ok = pcall(queue, queuedSource)
    if ok then Environment[key] = true end
    return ok
end

queueSelfForTeleport()

local previous = Environment.__SquidNoMoBootstrap
if type(previous) == "table" and previous.Loading == true then
    local age = os.clock() - tonumber(previous.StartedAt or os.clock())
    local staleAfter = tonumber(BuildManifest.StartupTimeoutSeconds) or 30
    if age < staleAfter then
        if type(previous.SetStatus) == "function" then
            previous:SetStatus("Already loading — please do not execute again.", previous.Progress or 0.08)
        end
        if previous.Gui and previous.Gui.Parent then
            previous.Gui.Enabled = true
            previous.Gui.DisplayOrder = 1000000
        end
        warn("[SquidNoMo] A load is already in progress; duplicate execution ignored.")
        return previous.Loader
    end

    warn("[SquidNoMo] Replacing a stale loader session after " .. tostring(math.floor(age)) .. " seconds.")
    pcall(function()
        if previous.Gui then previous.Gui:Destroy() end
    end)
    Environment.__SquidNoMoBootstrap = nil
end

local bootstrap = {
    Loading = true,
    Version = BUILD_VERSION,
    Revision = BUILD_REVISION,
    BuildNumber = BUILD_NUMBER,
    StartedAt = os.clock(),
    Progress = 0.02,
}
Environment.__SquidNoMoBootstrap = bootstrap

local function getGuiParent()
    if type(gethui) == "function" then
        local ok, result = pcall(gethui)
        if ok and result then
            return result
        end
    end
    return game:GetService("CoreGui")
end

local function addCorner(parent, radius)
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, radius)
    corner.Parent = parent
    return corner
end

local function addStroke(parent, color, transparency, thickness)
    local stroke = Instance.new("UIStroke")
    stroke.Color = color
    stroke.Transparency = transparency or 0
    stroke.Thickness = thickness or 1
    stroke.Parent = parent
    return stroke
end

local gui = Instance.new("ScreenGui")
gui.Name = "SquidNoMoLoading"
gui.IgnoreGuiInset = true
gui.ResetOnSpawn = false
gui.DisplayOrder = 1000000
gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

if type(syn) == "table" and type(syn.protect_gui) == "function" then
    pcall(syn.protect_gui, gui)
end

gui.Parent = getGuiParent()
bootstrap.Gui = gui

local shade = Instance.new("Frame")
shade.Size = UDim2.fromScale(1, 1)
shade.BackgroundColor3 = Color3.fromRGB(5, 6, 10)
shade.BackgroundTransparency = 1
shade.BorderSizePixel = 0
shade.Parent = gui

local panel = Instance.new("ScrollingFrame")
panel.Name = "LoaderPanel"
panel.AnchorPoint = Vector2.new(0.5, 0.5)
panel.Position = UDim2.fromScale(0.5, 0.5)
panel.Size = UDim2.new(0.68, 0, 0.64, 0)
panel.BackgroundColor3 = Color3.fromRGB(9, 15, 19)
panel.BackgroundTransparency = 0.03
panel.BorderSizePixel = 0
panel.ScrollBarThickness = 4
panel.ScrollBarImageColor3 = Color3.fromRGB(52, 225, 104)
panel.CanvasSize = UDim2.fromOffset(0, 510)
panel.AutomaticCanvasSize = Enum.AutomaticSize.None
panel.ScrollingDirection = Enum.ScrollingDirection.Y
panel.Parent = shade
addCorner(panel, 18)
addStroke(panel, Color3.fromRGB(50, 223, 102), 0.12, 2)

local sizeConstraint = Instance.new("UISizeConstraint")
sizeConstraint.MinSize = Vector2.new(320, 360)
sizeConstraint.MaxSize = Vector2.new(590, 520)
sizeConstraint.Parent = panel

local minimizeLoader = Instance.new("TextButton")
minimizeLoader.Name = "MinimizeLoader"
minimizeLoader.AnchorPoint = Vector2.new(1, 0)
minimizeLoader.Position = UDim2.new(1, -10, 0, 10)
minimizeLoader.Size = UDim2.fromOffset(42, 34)
minimizeLoader.BackgroundColor3 = Color3.fromRGB(87, 67, 155)
minimizeLoader.BorderSizePixel = 0
minimizeLoader.Font = Enum.Font.GothamBlack
minimizeLoader.Text = "—"
minimizeLoader.TextColor3 = Color3.new(1, 1, 1)
minimizeLoader.TextSize = 22
minimizeLoader.ZIndex = 30
minimizeLoader.Parent = panel
addCorner(minimizeLoader, 10)

local loaderBubble = Instance.new("TextButton")
loaderBubble.Name = "LoaderBubble"
loaderBubble.AnchorPoint = Vector2.new(1, 0)
loaderBubble.Position = UDim2.new(1, -18, 0, 72)
loaderBubble.Size = UDim2.fromOffset(194, 54)
loaderBubble.BackgroundColor3 = Color3.fromRGB(9, 15, 19)
loaderBubble.BackgroundTransparency = 0.04
loaderBubble.BorderSizePixel = 0
loaderBubble.Font = Enum.Font.GothamBold
loaderBubble.Text = "SquidNoMo loading • 2%"
loaderBubble.TextColor3 = Color3.fromRGB(55, 235, 111)
loaderBubble.TextSize = 14
loaderBubble.Visible = false
loaderBubble.ZIndex = 40
loaderBubble.Parent = shade
addCorner(loaderBubble, 14)
addStroke(loaderBubble, Color3.fromRGB(50, 223, 102), 0.12, 2)

local function setLoaderMinimized(state)
    bootstrap.Minimized = state == true
    panel.Visible = not bootstrap.Minimized
    loaderBubble.Visible = bootstrap.Minimized
    Environment.__SquidNoMoOpenMinimized = bootstrap.Minimized
end
minimizeLoader.Activated:Connect(function() setLoaderMinimized(true) end)
loaderBubble.Activated:Connect(function() setLoaderMinimized(false) end)

local content = Instance.new("Frame")
content.Size = UDim2.new(1, -24, 0, 495)
content.Position = UDim2.fromOffset(12, 10)
content.BackgroundTransparency = 1
content.Parent = panel

local layout = Instance.new("UIListLayout")
layout.FillDirection = Enum.FillDirection.Vertical
layout.HorizontalAlignment = Enum.HorizontalAlignment.Center
layout.SortOrder = Enum.SortOrder.LayoutOrder
layout.Padding = UDim.new(0, 6)
layout.Parent = content

local version = Instance.new("TextLabel")
version.LayoutOrder = 1
version.Size = UDim2.new(1, -12, 0, 24)
version.BackgroundTransparency = 1
version.Font = Enum.Font.GothamSemibold
version.Text = BUILD_VERSION
version.TextColor3 = Color3.fromRGB(55, 235, 111)
version.TextSize = 15
version.TextXAlignment = Enum.TextXAlignment.Left
version.Parent = content

local bannerCard = Instance.new("Frame")
bannerCard.LayoutOrder = 2
bannerCard.Size = UDim2.new(1, -12, 0, 82)
bannerCard.BackgroundColor3 = Color3.fromRGB(5, 10, 14)
bannerCard.BorderSizePixel = 0
bannerCard.ClipsDescendants = true
bannerCard.Parent = content
addCorner(bannerCard, 14)
addStroke(bannerCard, Color3.fromRGB(41, 151, 75), 0.35, 1)

local bannerImage = Instance.new("ImageLabel")
bannerImage.Name = "AppBanner"
bannerImage.Size = UDim2.fromScale(1, 1)
bannerImage.BackgroundTransparency = 1
bannerImage.Image = ""
bannerImage.ScaleType = Enum.ScaleType.Crop
bannerImage.Visible = false
bannerImage.Parent = bannerCard

local bannerShade = Instance.new("Frame")
bannerShade.Size = UDim2.fromScale(1, 1)
bannerShade.BackgroundColor3 = Color3.fromRGB(2, 8, 10)
bannerShade.BackgroundTransparency = 0.48
bannerShade.BorderSizePixel = 0
bannerShade.ZIndex = 2
bannerShade.Parent = bannerCard

local bannerFallback = Instance.new("TextLabel")
bannerFallback.Size = UDim2.fromScale(1, 1)
bannerFallback.BackgroundTransparency = 1
bannerFallback.Font = Enum.Font.GothamBlack
bannerFallback.Text = "SQUID NO MO"
bannerFallback.TextColor3 = Color3.fromRGB(242, 246, 243)
bannerFallback.TextSize = 34
bannerFallback.TextScaled = true
bannerFallback.ZIndex = 3
bannerFallback.Parent = bannerCard
local fallbackConstraint = Instance.new("UITextSizeConstraint")
fallbackConstraint.MinTextSize = 24
fallbackConstraint.MaxTextSize = 48
fallbackConstraint.Parent = bannerFallback

local heading = Instance.new("TextLabel")
heading.LayoutOrder = 3
heading.Size = UDim2.new(1, -12, 0, 28)
heading.BackgroundTransparency = 1
heading.Font = Enum.Font.GothamBold
heading.Text = "LOADING SQUID NO MO..."
heading.TextColor3 = Color3.fromRGB(59, 236, 111)
heading.TextSize = 19
heading.TextXAlignment = Enum.TextXAlignment.Center
heading.Parent = content

local warningCard = Instance.new("Frame")
warningCard.LayoutOrder = 4
warningCard.Size = UDim2.new(1, -12, 0, 58)
warningCard.BackgroundColor3 = Color3.fromRGB(25, 26, 24)
warningCard.BorderSizePixel = 0
warningCard.Parent = content
addCorner(warningCard, 12)
addStroke(warningCard, Color3.fromRGB(235, 194, 61), 0.3, 1)

local warningIcon = Instance.new("TextLabel")
warningIcon.Size = UDim2.fromOffset(46, 58)
warningIcon.BackgroundTransparency = 1
warningIcon.Font = Enum.Font.GothamBold
warningIcon.Text = "!"
warningIcon.TextColor3 = Color3.fromRGB(255, 208, 45)
warningIcon.TextSize = 28
warningIcon.Parent = warningCard

local warning = Instance.new("TextLabel")
warning.Position = UDim2.fromOffset(46, 5)
warning.Size = UDim2.new(1, -54, 1, -10)
warning.BackgroundTransparency = 1
warning.Font = Enum.Font.GothamMedium
warning.Text = "DO NOT EXECUTE AGAIN\nThe loader is already working. Re-executing can cause errors."
warning.TextColor3 = Color3.fromRGB(238, 239, 235)
warning.TextSize = 13
warning.TextWrapped = true
warning.TextXAlignment = Enum.TextXAlignment.Left
warning.TextYAlignment = Enum.TextYAlignment.Center
warning.Parent = warningCard

local progressCard = Instance.new("Frame")
progressCard.LayoutOrder = 5
progressCard.Size = UDim2.new(1, -12, 0, 90)
progressCard.BackgroundColor3 = Color3.fromRGB(12, 22, 27)
progressCard.BorderSizePixel = 0
progressCard.Parent = content
addCorner(progressCard, 12)
addStroke(progressCard, Color3.fromRGB(48, 136, 77), 0.45, 1)

local progressTitle = Instance.new("TextLabel")
progressTitle.Position = UDim2.fromOffset(16, 10)
progressTitle.Size = UDim2.new(1, -110, 0, 25)
progressTitle.BackgroundTransparency = 1
progressTitle.Font = Enum.Font.GothamBold
progressTitle.Text = "OVERALL PROGRESS"
progressTitle.TextColor3 = Color3.fromRGB(57, 229, 106)
progressTitle.TextSize = 16
progressTitle.TextXAlignment = Enum.TextXAlignment.Left
progressTitle.Parent = progressCard

local percent = Instance.new("TextLabel")
percent.AnchorPoint = Vector2.new(1, 0)
percent.Position = UDim2.new(1, -16, 0, 8)
percent.Size = UDim2.fromOffset(86, 30)
percent.BackgroundTransparency = 1
percent.Font = Enum.Font.GothamBold
percent.Text = "2%"
percent.TextColor3 = Color3.fromRGB(57, 229, 106)
percent.TextSize = 23
percent.TextXAlignment = Enum.TextXAlignment.Right
percent.Parent = progressCard

local track = Instance.new("Frame")
track.Position = UDim2.fromOffset(16, 43)
track.Size = UDim2.new(1, -32, 0, 14)
track.BackgroundColor3 = Color3.fromRGB(41, 49, 53)
track.BorderSizePixel = 0
track.Parent = progressCard
addCorner(track, 20)

local fill = Instance.new("Frame")
fill.Size = UDim2.fromScale(0.02, 1)
fill.BackgroundColor3 = Color3.fromRGB(49, 222, 98)
fill.BorderSizePixel = 0
fill.Parent = track
addCorner(fill, 20)

local status = Instance.new("TextLabel")
status.Position = UDim2.fromOffset(16, 61)
status.Size = UDim2.new(1, -32, 0, 22)
status.BackgroundTransparency = 1
status.Font = Enum.Font.GothamSemibold
status.Text = "Preparing startup..."
status.TextColor3 = Color3.fromRGB(224, 232, 227)
status.TextSize = 13
status.TextWrapped = true
status.TextXAlignment = Enum.TextXAlignment.Left
status.Parent = progressCard

local stagesCard = Instance.new("Frame")
stagesCard.LayoutOrder = 6
stagesCard.Size = UDim2.new(1, -12, 0, 164)
stagesCard.BackgroundColor3 = Color3.fromRGB(10, 19, 23)
stagesCard.BorderSizePixel = 0
stagesCard.Parent = content
addCorner(stagesCard, 12)
addStroke(stagesCard, Color3.fromRGB(55, 94, 70), 0.52, 1)

local stagesLayout = Instance.new("UIListLayout")
stagesLayout.Padding = UDim.new(0, 2)
stagesLayout.SortOrder = Enum.SortOrder.LayoutOrder
stagesLayout.Parent = stagesCard

local stageDefinitions = {
    {"Connecting to repository", 0.08},
    {"Downloading core loader", 0.20},
    {"Loading core systems", 0.47},
    {"Loading feature modules", 0.86},
    {"Building interface", 0.96},
    {"Finalizing startup", 1.00},
}

local stageRows = {}
for index, definition in ipairs(stageDefinitions) do
    local row = Instance.new("Frame")
    row.LayoutOrder = index
    row.Size = UDim2.new(1, 0, 0, 26)
    row.BackgroundTransparency = 1
    row.Parent = stagesCard

    local dot = Instance.new("TextLabel")
    dot.Position = UDim2.fromOffset(12, 0)
    dot.Size = UDim2.fromOffset(28, 33)
    dot.BackgroundTransparency = 1
    dot.Font = Enum.Font.GothamBold
    dot.Text = "○"
    dot.TextColor3 = Color3.fromRGB(105, 113, 112)
    dot.TextSize = 16
    dot.Parent = row

    local label = Instance.new("TextLabel")
    label.Position = UDim2.fromOffset(43, 0)
    label.Size = UDim2.new(1, -128, 1, 0)
    label.BackgroundTransparency = 1
    label.Font = Enum.Font.GothamMedium
    label.Text = definition[1]
    label.TextColor3 = Color3.fromRGB(215, 222, 218)
    label.TextSize = 12
    label.TextXAlignment = Enum.TextXAlignment.Left
    label.Parent = row

    local state = Instance.new("TextLabel")
    state.AnchorPoint = Vector2.new(1, 0)
    state.Position = UDim2.new(1, -12, 0, 0)
    state.Size = UDim2.fromOffset(78, 33)
    state.BackgroundTransparency = 1
    state.Font = Enum.Font.GothamBold
    state.Text = "PENDING"
    state.TextColor3 = Color3.fromRGB(128, 136, 133)
    state.TextSize = 10
    state.TextXAlignment = Enum.TextXAlignment.Right
    state.Parent = row

    stageRows[index] = {Dot = dot, State = state, Threshold = definition[2]}
end

local tip = Instance.new("TextLabel")
tip.LayoutOrder = 7
tip.Size = UDim2.new(1, -12, 0, 42)
tip.BackgroundColor3 = Color3.fromRGB(12, 27, 23)
tip.BorderSizePixel = 0
tip.Font = Enum.Font.GothamMedium
tip.Text = "TIP  •  The interface opens automatically when loading reaches 100%."
tip.TextColor3 = Color3.fromRGB(190, 224, 202)
tip.TextSize = 12
tip.TextWrapped = true
tip.Parent = content
addCorner(tip, 11)

local function updateStageRows(progress)
    local activeAssigned = false
    for index, row in ipairs(stageRows) do
        local priorThreshold = index == 1 and 0 or stageRows[index - 1].Threshold
        if progress >= row.Threshold then
            row.Dot.Text = "✓"
            row.Dot.TextColor3 = Color3.fromRGB(53, 230, 105)
            row.State.Text = "COMPLETE"
            row.State.TextColor3 = Color3.fromRGB(53, 230, 105)
        elseif not activeAssigned and progress >= priorThreshold then
            activeAssigned = true
            row.Dot.Text = "◉"
            row.Dot.TextColor3 = Color3.fromRGB(53, 230, 105)
            row.State.Text = "LOADING"
            row.State.TextColor3 = Color3.fromRGB(53, 230, 105)
        else
            row.Dot.Text = "○"
            row.Dot.TextColor3 = Color3.fromRGB(105, 113, 112)
            row.State.Text = "PENDING"
            row.State.TextColor3 = Color3.fromRGB(128, 136, 133)
        end
    end
end

local function resolveBanner()
    local customAsset = nil
    if type(getcustomasset) == "function" then
        customAsset = getcustomasset
    elseif type(getsynasset) == "function" then
        customAsset = getsynasset
    end

    if not customAsset or type(writefile) ~= "function" then
        return
    end

    local folder = "SquidNoMo"
    local imageFolder = folder .. "/Images"
    local localPath = imageFolder .. "/" .. BUILD_TOKEN .. "_BannerGuards.png"

    pcall(function()
        if type(isfolder) == "function" and type(makefolder) == "function" then
            if not isfolder(folder) then makefolder(folder) end
            if not isfolder(imageFolder) then makefolder(imageFolder) end
        end
    end)

    local shouldDownload = true
    if type(isfile) == "function" then
        pcall(function()
            shouldDownload = not isfile(localPath)
        end)
    end

    if shouldDownload then
        local ok, data = pcall(function()
            return HttpGetWithTimeout(REPOSITORY .. BANNER_PATH .. "?squidnomo_build=" .. BUILD_TOKEN, 12)
        end)
        if not ok or type(data) ~= "string" or #data == 0 then
            return
        end
        local wrote = pcall(function()
            writefile(localPath, data)
        end)
        if not wrote then
            return
        end
    end

    local ok, asset = pcall(function()
        return customAsset(localPath)
    end)
    if ok and asset and bannerImage.Parent then
        bannerImage.Image = asset
        bannerImage.Visible = true
        bannerFallback.Visible = false
    end
end

task.spawn(resolveBanner)

function bootstrap:SetStatus(message, progress)
    if status and status.Parent then
        status.Text = tostring(message or "Loading...")
    end

    if progress ~= nil then
        local amount = math.clamp(tonumber(progress) or 0, 0.02, 1)
        self.Progress = math.max(self.Progress or 0.02, amount)
        amount = self.Progress

        if fill and fill.Parent then
            fill:TweenSize(
                UDim2.fromScale(amount, 1),
                Enum.EasingDirection.Out,
                Enum.EasingStyle.Quad,
                0.22,
                true
            )
        end
        local percentText = tostring(math.floor(amount * 100 + 0.5)) .. "%"
        if percent and percent.Parent then
            percent.Text = percentText
        end
        if loaderBubble and loaderBubble.Parent then
            loaderBubble.Text = "SquidNoMo loading • " .. percentText
        end
        updateStageRows(amount)
    end
end

function bootstrap:Finish(loader)
    self.Loader = loader
    self.Loading = false
    if self.Minimized == true then
        Environment.__SquidNoMoOpenMinimized = true
        if loader and loader.App and type(loader.App.SetMinimized) == "function" then
            pcall(loader.App.SetMinimized, loader.App, true)
        end
    end
    self:SetStatus("Ready — opening SquidNoMo...", 1)
    heading.Text = "SQUID NO MO IS READY"
    task.delay(0.55, function()
        if self.Gui then
            self.Gui:Destroy()
            self.Gui = nil
        end
    end)
end

function bootstrap:Fail(message)
    self.Loading = false
    heading.Text = "LOADING FAILED"
    heading.TextColor3 = Color3.fromRGB(255, 120, 120)
    self:SetStatus("Startup stopped. Check the message below.", self.Progress or 0.2)
    warning.Text = tostring(message or "An unknown startup error occurred.")
    warning.TextColor3 = Color3.fromRGB(255, 180, 180)
    warningIcon.Text = "×"
    warningIcon.TextColor3 = Color3.fromRGB(255, 115, 115)
    tip.Text = "You can close this screen, check the console, and execute again after fixing the error."

    local close = Instance.new("TextButton")
    close.LayoutOrder = 8
    close.Size = UDim2.new(1, -12, 0, 40)
    close.BackgroundColor3 = Color3.fromRGB(119, 45, 52)
    close.BorderSizePixel = 0
    close.Font = Enum.Font.GothamBold
    close.Text = "CLOSE LOADER"
    close.TextColor3 = Color3.new(1, 1, 1)
    close.TextSize = 15
    close.Parent = content
    addCorner(close, 10)
    close.Activated:Connect(function()
        gui:Destroy()
    end)
end

task.delay(tonumber(BuildManifest.StartupTimeoutSeconds) or 30, function()
    if bootstrap.Loading == true then
        bootstrap:Fail(
            "Startup timed out. The repository may be partially uploaded or the executor HTTP request stalled. "
            .. "Re-upload the complete build and execute once more."
        )
    end
end)

bootstrap:SetStatus("Connecting to the SquidNoMo repository...", 0.05)
print("[SquidNoMo] Starting " .. BUILD_VERSION .. " (build " .. BUILD_NUMBER .. ", " .. BUILD_REVISION .. ")")

local success, result = pcall(function()
    local bundlePath = tostring(BuildManifest.StartupBundle or "SourceBundle.lua")
    bootstrap:SetStatus("Downloading the verified startup bundle...", 0.14)
    local bundleSource = HttpGetWithTimeout(
        REPOSITORY .. bundlePath .. "?squidnomo_build=" .. BUILD_TOKEN,
        tonumber(BuildManifest.StartupTimeoutSeconds) or 30
    )

    bootstrap:SetStatus("Verifying the startup bundle...", 0.19)
    local bundleChunk, bundleCompileError = loadstring(bundleSource)
    if not bundleChunk then
        error("Startup bundle compile failed: " .. tostring(bundleCompileError))
    end
    local bundleOk, bundle = pcall(bundleChunk)
    if not bundleOk or type(bundle) ~= "table" then
        error("Startup bundle load failed: " .. tostring(bundle))
    end
    if tostring(bundle.BuildToken or "") ~= BUILD_TOKEN then
        error(
            "Repository build mismatch: BuildManifest is " .. BUILD_TOKEN
            .. " but SourceBundle is " .. tostring(bundle.BuildToken or "missing")
            .. ". Upload the complete project together."
        )
    end
    if type(bundle.Sources) ~= "table" then
        error("Startup bundle is missing its Sources table")
    end

    Environment.__SquidNoMoSourceBundle = bundle.Sources
    Environment.__SquidNoMoSourceBundleToken = bundle.BuildToken

    local LoaderSource = bundle.Sources["Loader.lua"]
    if type(LoaderSource) ~= "string" or #LoaderSource == 0 then
        error("Startup bundle does not contain Loader.lua")
    end

    bootstrap:SetStatus("Compiling the verified main loader...", 0.22)
    local chunk, compileError = loadstring(LoaderSource)
    if not chunk then
        error("Loader compile failed: " .. tostring(compileError))
    end

    bootstrap:SetStatus("Starting bundled core systems...", 0.24)
    return chunk()
end)

if not success then
    warn("[SquidNoMo] Startup failed: " .. tostring(result))
    bootstrap:Fail(tostring(result))
    return nil
end

bootstrap:Finish(result)
print("[SquidNoMo] Loader executed")
return result
]====],
        [ [====[Modules/CategoryStrip.lua]====] ] = [====[local CategoryStrip = {}

local function makeCorner(parent, radius)
    local corner = Instance.new('UICorner')
    corner.CornerRadius = UDim.new(0, radius or 13)
    corner.Parent = parent
    return corner
end

local function makeStroke(parent, color, thickness, transparency)
    local stroke = Instance.new('UIStroke')
    stroke.Color = color
    stroke.Thickness = thickness or 1
    stroke.Transparency = transparency or 0
    stroke.Parent = parent
    return stroke
end

function CategoryStrip:Create(Page, App, options)
    Page:ClearAllChildren()
    options = options or {}

    local items = options.Items or {}
    local pageName = options.PageName or 'Games'
    local sessionKey = options.SessionKey or 'SelectedCategory'
    local defaultName = options.DefaultName
        or (items[1] and items[1].Name)
    local accent = App:GetPageAccent(pageName)
    local pagePadding = App:GetUIStyleValue(
        pageName,
        'PagePadding',
        'MainPage'
    )
    local buttonWidth = App:GetUIStyleValue(
        pageName,
        'CategoryBubbleWidth',
        'Subpage'
    ) or options.ButtonWidth or 190
    if App:IsMobile() then
        buttonWidth = math.max(buttonWidth, 176)
    end
    local buttonHeight = App:GetUIStyleValue(
        pageName,
        'CategoryBubbleHeight',
        'Subpage'
    ) or 66
    local barHeight = App:GetUIStyleValue(
        pageName,
        'CategoryBarHeight',
        'Subpage'
    ) or 108
    local gap = App:GetUIStyleValue(
        pageName,
        'CategoryGap',
        'Subpage'
    ) or 10
    local scrollbar = App:GetUIStyleValue(
        pageName,
        'ScrollbarThickness',
        'Subpage'
    ) or 5

    local root = Instance.new('Frame')
    root.Name = pageName .. 'CategoryRoot'
    root:SetAttribute('SquidNoMoSubpage', true)
    root.Position = UDim2.fromOffset(pagePadding, pagePadding)
    root.Size = UDim2.new(
        1,
        -(pagePadding * 2),
        0,
        barHeight + 4
    )
    root.BackgroundTransparency = 1
    root.BorderSizePixel = 0
    root.Parent = Page

    local card = App:CreateCard(
        root,
        UDim2.new(1, 0, 0, barHeight),
        {
            Color = App.Colors.Card,
            BorderColor = accent,
            BorderTransparency = 0.08,
            Radius = App:GetUIStyleValue(
                pageName,
                'CardRadius',
                'Subpage'
            ),
        }
    )
    card.Position = UDim2.fromOffset(0, 0)
    card.ClipsDescendants = true

    local scroller = Instance.new('ScrollingFrame')
    scroller.Name = options.ScrollerName
        or (pageName .. 'CategoryScroller')
    scroller.Position = UDim2.fromOffset(12, 10)
    scroller.Size = UDim2.new(1, -24, 1, -20)
    scroller.BackgroundTransparency = 1
    scroller.BorderSizePixel = 0
    scroller.CanvasSize = UDim2.fromOffset(0, 0)
    scroller.AutomaticCanvasSize = Enum.AutomaticSize.X
    scroller.ScrollingDirection = Enum.ScrollingDirection.X
    scroller.ScrollBarThickness = scrollbar
    scroller.ScrollBarImageColor3 = accent
    scroller.ElasticBehavior = Enum.ElasticBehavior.WhenScrollable
    scroller.Active = true
    scroller.ZIndex = 1012
    scroller.Parent = card

    local paddingObject = Instance.new('UIPadding')
    paddingObject.PaddingLeft = UDim.new(0, 2)
    paddingObject.PaddingRight = UDim.new(0, 2)
    paddingObject.PaddingTop = UDim.new(0, 4)
    paddingObject.PaddingBottom = UDim.new(0, 8)
    paddingObject.Parent = scroller

    local layout = Instance.new('UIListLayout')
    layout.FillDirection = Enum.FillDirection.Horizontal
    layout.HorizontalAlignment = Enum.HorizontalAlignment.Left
    layout.VerticalAlignment = Enum.VerticalAlignment.Center
    layout.SortOrder = Enum.SortOrder.LayoutOrder
    layout.Padding = UDim.new(0, gap)
    layout.Parent = scroller

    local refs = {}
    local selectedIndex = 1

    local function renderSelection(index)
        selectedIndex = index
        local item = items[index]
        if not item then
            return
        end

        if App.Session then
            App.Session[sessionKey] = item.Name
        end

        if type(App.QueueSettingsSave) == 'function' then
            App:QueueSettingsSave()
        end

        for refIndex, ref in ipairs(refs) do
            local selected = refIndex == selectedIndex
            ref.Button.BackgroundColor3 = selected
                and accent
                or App.Colors.CardAlt
            ref.Button.BackgroundTransparency = selected
                and 0.08
                or 0.28
            ref.Stroke.Color = selected
                and accent
                or App.Colors.BorderSoft
            ref.Stroke.Transparency = selected
                and 0.02
                or 0.55
            ref.Stroke.Thickness = selected
                and 2
                or App:GetUIStyleValue(
                    pageName,
                    'BorderThickness',
                    'Subpage'
                )
            ref.Title.TextColor3 = selected
                and Color3.fromRGB(255, 255, 255)
                or App.Colors.Text
            ref.Code.TextColor3 = selected
                and Color3.fromRGB(255, 255, 255)
                or accent
        end

        if type(options.OnSelected) == 'function' then
            pcall(options.OnSelected, item, index)
        end
    end

    for index, item in ipairs(items) do
        local button = Instance.new('TextButton')
        button.Name = pageName
            .. 'Category_'
            .. tostring(index)
        button.Size = UDim2.fromOffset(
            options.ButtonWidth or buttonWidth,
            buttonHeight
        )
        button.BackgroundColor3 = App.Colors.CardAlt
        button.BackgroundTransparency = 0.28
        button.BorderSizePixel = 0
        button.AutoButtonColor = false
        button.Text = ''
        button.LayoutOrder = index
        button.ZIndex = 1013
        button.Parent = scroller
        makeCorner(
            button,
            App:GetUIStyleValue(
                pageName,
                'ButtonRadius',
                'Subpage'
            )
        )

        local outline = makeStroke(
            button,
            App.Colors.BorderSoft,
            App:GetUIStyleValue(
                pageName,
                'BorderThickness',
                'Subpage'
            ),
            0.55
        )

        local code = App:CreateText(
            button,
            item.Short or tostring(index),
            UDim2.fromOffset(90, 18),
            UDim2.fromOffset(12, 8),
            {
                Font = Enum.Font.GothamBlack,
                TextSize = App:IsMobile() and 12 or 11,
                Color = accent,
                ZIndex = 1014,
            }
        )

        local title = App:CreateText(
            button,
            item.Name,
            UDim2.new(1, -24, 0, buttonHeight - 28),
            UDim2.fromOffset(12, 25),
            {
                Font = Enum.Font.GothamBold,
                TextSize = App:IsMobile() and 14 or 13,
                Color = App.Colors.Text,
                Wrapped = true,
                YAlignment = Enum.TextYAlignment.Center,
                ZIndex = 1014,
            }
        )

        App:BindButtonFeedback(button, accent)
        button.Activated:Connect(function()
            if Page:GetAttribute("SquidNoMoTouchDragging") then return end
            renderSelection(index)
        end)

        refs[index] = {
            Button = button,
            Stroke = outline,
            Title = title,
            Code = code,
        }
    end

    local saved = App.Session and App.Session[sessionKey]
    local target = type(saved) == 'string'
        and saved
        or defaultName

    if type(target) == 'string' then
        for index, item in ipairs(items) do
            if item.Name == target then
                selectedIndex = index
                break
            end
        end
    end

    renderSelection(selectedIndex)

    return {
        Root = root,
        Card = card,
        Scroller = scroller,
        Select = renderSelection,
        SelectByName = function(name)
            for index, item in ipairs(items) do
                if item.Name == name then
                    if selectedIndex ~= index then renderSelection(index) end
                    return true
                end
            end
            return false
        end,
        SelectedName = function()
            local item = items[selectedIndex]
            return item and item.Name or nil
        end,
        SelectedIndex = function()
            return selectedIndex
        end,
    }
end

return CategoryStrip
]====],
        [ [====[Modules/Detective.lua]====] ] = [====[local DetectivePage = {}

function DetectivePage:Create(Page, App)
    local catalog = App.Loader.FeatureCatalog
    local categories = catalog and catalog:GetCategories("Detective") or {}

    App.Loader.CategoryStrip:Create(Page, App, {
        PageName = "Detective",
        SessionKey = "SelectedDetectiveCategory",
        DefaultName = categories[1] and categories[1].Name or "Island Navigation",
        ScrollerName = "DetectiveCategoryScroller",
        ButtonWidth = 240,
        Items = categories,
        OnSelected = function(item)
            App.Loader.FeatureFolder:Render(Page, App, {
                PageName = "Detective",
                Features = item.Features or {},
            })
        end,
    })
end

return DetectivePage
]====],
        [ [====[Modules/Farming.lua]====] ] = [====[local FarmingPage = {}

function FarmingPage:Create(Page, App)
    local catalog = App.Loader and App.Loader.FeatureCatalog
    local categories = catalog and catalog:GetCategories("Farming") or {}
    local features = {}

    for _, category in ipairs(categories) do
        for _, feature in ipairs(category.Features or {}) do
            table.insert(features, feature)
        end
    end

    -- Farming intentionally uses one continuous toggle page. There is no
    -- category strip because each controller already selects its own task.
    App.Loader.FeatureFolder:Render(Page, App, {
        PageName = "Farming",
        TopY = App:IsMobile() and 18 or 22,
        Features = features,
    })
end

return FarmingPage
]====],
        [ [====[Modules/FeatureCatalog.lua]====] ] = [====[local FeatureCatalog = {}

local function slug(value)
    value = tostring(value or ""):lower()
    value = value:gsub("[^%w]+", "_")
    return value:gsub("^_+", ""):gsub("_+$", "")
end

local function humanize(value)
    value = tostring(value or "Feature")
    value = value:gsub("(%l)(%u)", "%1 %2")
    value = value:gsub("_", " ")
    return value
end

local function fallbackDescription(name)
    local readable = humanize(name)
    local lower = readable:lower()
    if lower:find("esp", 1, true) then
        return "Highlights the relevant targets so they are easier to locate during play."
    elseif lower:find("auto", 1, true) then
        return "Automates the related game action while this feature is enabled."
    elseif lower:find("navigator", 1, true) or lower:find("path", 1, true) then
        return "Guides the character toward the related objective using movement assistance."
    elseif lower:find("anti", 1, true) then
        return "Helps prevent the related failure condition during the current round."
    end
    return "Provides focused assistance for " .. readable .. "."
end

FeatureCatalog.Pages = {
    Games = {
        {
            Name = "Red Light, Green Light",
            Short = "RLGL",
            Folder = "RLGL",
            Features = {
                {
                    Id = "mapped.games.red_light_green_light.antistuck",
                    Name = "Anti Stuck",
                    Description = "Detects stalled movement and helps the character recover during the round.",
                    Path = "Features/Games/RLGL/AntiStuck.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.red_light_green_light.automove",
                    Name = "Auto Move",
                    Description = "Moves on green light and stops automatically when the doll changes to red.",
                    Path = "Features/Games/RLGL/AutoMove.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.red_light_green_light.dollesp",
                    Name = "Doll ESP",
                    Description = "Highlights the doll so its position stays visible from anywhere on the field.",
                    Path = "Features/Games/RLGL/DollESP.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.red_light_green_light.safezoneesp",
                    Name = "Safe Zone ESP",
                    Description = "Marks safe areas and the finish zone to make the route easier to read.",
                    Path = "Features/Games/RLGL/SafeZoneESP.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.red_light_green_light.stateesp",
                    Name = "State ESP",
                    Description = "Shows the current red-light or green-light state directly on screen.",
                    Path = "Features/Games/RLGL/StateESP.lua",
                    Category = "Experimental",
                },
            },
        },
        {
            Name = "Dalgona",
            Short = "DALGONA",
            Folder = "Dalgona",
            Features = {
                {
                    Id = "mapped.games.dalgona.autocut",
                    Name = "Auto Cut",
                    Description = "Automates the cookie carving interaction to help complete the selected shape.",
                    Path = "Features/Games/Dalgona/AutoCut.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.dalgona.autolighter",
                    Name = "Auto Lighter",
                    Description = "Finds, equips, and repeatedly activates the lighter while enabled.",
                    Path = "Features/Games/Dalgona/AutoLighter.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.dalgona.highlightesp",
                    Name = "Shape Highlight",
                    Description = "Outlines the cookie shape so the tracing boundary is easier to see.",
                    Path = "Features/Games/Dalgona/HighlightESP.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.dalgona.tracehelper",
                    Name = "Trace Helper",
                    Description = "Adds a visual tracing guide that follows the cursor over the cookie shape.",
                    Path = "Features/Games/Dalgona/TraceHelper.lua",
                    Category = "Experimental",
                },
            },
        },
        {
            Name = "Pentathlon",
            Short = "PENTA",
            Folder = "Pentathlon",
            Features = {
                {
                    Id = "mapped.games.pentathlon.biseokchigi",
                    Name = "Biseokchigi Assist",
                    Description = "Automates the timing and interaction used for the Biseokchigi event.",
                    Path = "Features/Games/Pentathlon/Biseokchigi.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.pentathlon.ddakji",
                    Name = "Ddakji Assist",
                    Description = "Helps perform the Ddakji action with consistent timing.",
                    Path = "Features/Games/Pentathlon/Ddakji.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.pentathlon.gonggi",
                    Name = "Gonggi Assist",
                    Description = "Automates the repeated inputs needed for the Gonggi event.",
                    Path = "Features/Games/Pentathlon/Gonggi.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.pentathlon.jegichagi",
                    Name = "Jegichagi Assist",
                    Description = "Keeps the Jegichagi sequence going with automatic timed inputs.",
                    Path = "Features/Games/Pentathlon/Jegichagi.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.pentathlon.paengi",
                    Name = "Paengi Assist",
                    Description = "Automates the spin interaction for the Paengi event.",
                    Path = "Features/Games/Pentathlon/Paengi.lua",
                    Category = "Experimental",
                },
            },
        },
        {
            Name = "Hide & Seek",
            Short = "H&S",
            Folder = "HideSeek",
            Features = {
                {
                    Id = "mapped.games.hide_seek.autograbkey",
                    Name = "Auto Grab Key",
                    Description = "Finds the nearest key and moves close enough to collect it.",
                    Path = "Features/Games/HideSeek/AutoGrabKey.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.hide_seek.autograbknife",
                    Name = "Auto Grab Knife",
                    Description = "Finds the nearest knife and moves close enough to collect it.",
                    Path = "Features/Games/HideSeek/AutoGrabKnife.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.hide_seek.autopathtoexit",
                    Name = "Auto Path to Exit",
                    Description = "Uses pathfinding to walk toward the nearest detected exit.",
                    Path = "Features/Games/HideSeek/AutoPathToExit.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.hide_seek.autoswing",
                    Name = "Auto Swing",
                    Description = "Automatically activates the equipped melee tool while enabled.",
                    Path = "Features/Games/HideSeek/AutoSwing.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.hide_seek.enemyesp",
                    Name = "Enemy ESP",
                    Description = "Highlights opposing players so nearby threats are easier to track.",
                    Path = "Features/Games/HideSeek/EnemyESP.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.hide_seek.exitesp",
                    Name = "Exit ESP",
                    Description = "Marks detected exits and escape points in the map.",
                    Path = "Features/Games/HideSeek/ExitESP.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.hide_seek.huntertracker",
                    Name = "Hunter Tracker",
                    Description = "Tracks hunters and keeps their location visible during the round.",
                    Path = "Features/Games/HideSeek/HunterTracker.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.hide_seek.mapradar",
                    Name = "Map Radar",
                    Description = "Shows nearby players and important map objects in a compact radar view.",
                    Path = "Features/Games/HideSeek/MapRadar.lua",
                    Category = "Experimental",
                },
            },
        },
        {
            Name = "Jump Rope",
            Short = "ROPE",
            Folder = "JumpRope",
            Features = {
                {
                    Id = "mapped.games.jump_rope.autocomplete",
                    Name = "Auto Complete",
                    Description = "Coordinates movement and jumps to progress across the rope course.",
                    Path = "Features/Games/JumpRope/AutoComplete.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.jump_rope.autojump",
                    Name = "Auto Jump",
                    Description = "Triggers jumps automatically as the rope approaches.",
                    Path = "Features/Games/JumpRope/AutoJump.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.jump_rope.autoposition",
                    Name = "Auto Position",
                    Description = "Keeps the character aligned with the preferred jumping position.",
                    Path = "Features/Games/JumpRope/AutoPosition.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.jump_rope.jumpboost",
                    Name = "Jump Boost",
                    Description = "Temporarily increases jump strength for the rope sequence.",
                    Path = "Features/Games/JumpRope/JumpBoost.lua",
                    Category = "Experimental",
                },
            },
        },
        {
            Name = "Mingle",
            Short = "MINGLE",
            Folder = "Mingle",
            Features = {
                {
                    Id = "mapped.games.mingle.autoroom",
                    Name = "Auto Room",
                    Description = "Automatically moves toward a room that matches the current player count.",
                    Path = "Features/Games/Mingle/AutoRoom.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.mingle.roomesp",
                    Name = "Room ESP",
                    Description = "Highlights available rooms and displays useful room information.",
                    Path = "Features/Games/Mingle/RoomESP.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.mingle.smartroom",
                    Name = "Smart Room",
                    Description = "Chooses a suitable room based on occupancy and nearby players.",
                    Path = "Features/Games/Mingle/SmartRoom.lua",
                    Category = "Experimental",
                },
            },
        },
        {
            Name = "Tug of War",
            Short = "TUG",
            Folder = "TugOfWar",
            Features = {
                {
                    Id = "mapped.games.tug_of_war.autopull",
                    Name = "Auto Pull",
                    Description = "Repeats the pull input automatically throughout Tug of War.",
                    Path = "Features/Games/TugOfWar/AutoPull.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.tug_of_war.perfect_timing",
                    Name = "Perfect Timing",
                    Description = "Times pull inputs around the strongest part of the tug sequence.",
                    Path = "Features/Games/TugOfWar/PerfectTiming.lua",
                    Category = "Experimental",
                },
            },
        },
        {
            Name = "Marbles",
            Short = "MARBLES",
            Folder = "Marbles",
            Features = {
                {
                    Id = "mapped.games.marbles.marbleaimer",
                    Name = "Marble Aimer",
                    Description = "Adds aiming assistance for more consistent marble throws.",
                    Path = "Features/Games/Marbles/MarbleAimer.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.marbles.marblesesp",
                    Name = "Marbles ESP",
                    Description = "Highlights marbles, targets, and useful round objects.",
                    Path = "Features/Games/Marbles/MarblesESP.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.marbles.recoveryassist",
                    Name = "Recovery Assist",
                    Description = "Helps recover the aiming position after a missed marble throw.",
                    Path = "Features/Games/Marbles/RecoveryAssist.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.marbles.ringshooter",
                    Name = "Ring Shooter",
                    Description = "Assists with lining up and firing marbles toward ring targets.",
                    Path = "Features/Games/Marbles/RingShooter.lua",
                    Category = "Experimental",
                },
            },
        },
        {
            Name = "Glass Bridge",
            Short = "GLASS",
            Folder = "GlassBridge",
            Features = {
                {
                    Id = "mapped.games.glass_bridge.antifall",
                    Name = "Anti Fall",
                    Description = "Stores a recent safe bridge position and recovers after a fall.",
                    Path = "Features/Games/GlassBridge/AntiFall.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.glass_bridge.autocomplete",
                    Name = "Auto Complete",
                    Description = "Moves toward detected safe glass tiles in sequence.",
                    Path = "Features/Games/GlassBridge/AutoComplete.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.glass_bridge.autoreset",
                    Name = "Auto Reset",
                    Description = "Returns the character to a recovery point after falling below the bridge.",
                    Path = "Features/Games/GlassBridge/AutoReset.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.glass_bridge.glassesp",
                    Name = "Glass ESP",
                    Description = "Highlights detected safe and unsafe glass panels.",
                    Path = "Features/Games/GlassBridge/GlassESP.lua",
                    Category = "Experimental",
                },
            },
        },
        {
            Name = "Rock, Paper, Scissors Minus One",
            Short = "RPS-1",
            Folder = "RockPaperScissors",
            Features = {
                {
                    Id = "mapped.games.rock_paper_scissors_minus_one.autoplay",
                    Name = "Auto Play",
                    Description = "Automatically selects and submits choices for each RPS Minus One round.",
                    Path = "Features/Games/RockPaperScissors/AutoPlay.lua",
                    Category = "Experimental",
                },
            },
        },
        {
            Name = "Fight Nights",
            Short = "FIGHT",
            Folder = "NightBrawls",
            Features = {
                {
                    Id = "mapped.games.fight_nights.brawlesp",
                    Name = "Brawl ESP",
                    Description = "Highlights nearby opponents during night-fight rounds.",
                    Path = "Features/Games/NightBrawls/BrawlESP.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.fight_nights.brawlevasion",
                    Name = "Brawl Evasion",
                    Description = "Keeps distance from nearby attackers and dangerous positions.",
                    Path = "Features/Games/NightBrawls/BrawlEvasion.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.fight_nights.combataura",
                    Name = "Combat Aura",
                    Description = "Automatically uses the equipped combat tool on nearby valid targets.",
                    Path = "Features/Games/NightBrawls/CombatAura.lua",
                    Category = "Experimental",
                },
            },
        },
        {
            Name = "Rebellion",
            Short = "REBELLION",
            Folder = "Rebellion",
            Features = {
                {
                    Id = "mapped.games.rebellion.frontmannavigator",
                    Name = "Frontman Navigator",
                    Description = "Guides the character toward the detected Frontman objective.",
                    Path = "Features/Games/Rebellion/FrontmanNavigator.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.rebellion.guardcombat",
                    Name = "Guard Combat",
                    Description = "Automatically engages nearby guard targets with the equipped tool.",
                    Path = "Features/Games/Rebellion/GuardCombat.lua",
                    Category = "Experimental",
                },
            },
        },
        {
            Name = "Sky Squid",
            Short = "SKY",
            Folder = "SkySquid",
            Features = {
                {
                    Id = "mapped.games.sky_squid.antifall",
                    Name = "Anti Fall",
                    Description = "Attempts to recover the character before a fall eliminates them.",
                    Path = "Features/Games/SkySquid/AntiFall.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.sky_squid.autofight",
                    Name = "Auto Fight",
                    Description = "Automatically attacks nearby valid opponents with the equipped tool.",
                    Path = "Features/Games/SkySquid/AutoFight.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.sky_squid.autopush",
                    Name = "Auto Push",
                    Description = "Uses the push action when an opponent enters range.",
                    Path = "Features/Games/SkySquid/AutoPush.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.sky_squid.instantgrab",
                    Name = "Instant Grab",
                    Description = "Quickly collects nearby weapons, poles, and usable tools.",
                    Path = "Features/Games/SkySquid/InstantGrab.lua",
                    Category = "Experimental",
                },
            },
        },
        {
            Name = "Squid Game",
            Short = "SQUID",
            Folder = "Squid game",
            Features = {
                {
                    Id = "mapped.games.squid_game.courtboundarykeeper",
                    Name = "Court Boundary Keeper",
                    Description = "Helps keep the character inside the active Squid Game court.",
                    Path = "Features/Games/SquidGame/CourtBoundaryKeeper.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.games.squid_game.squidgamepush",
                    Name = "Squid Game Push",
                    Description = "Automatically uses the push tool against nearby opponents.",
                    Path = "Features/Games/SquidGame/SquidGamePush.lua",
                    Category = "Experimental",
                },
            },
        },
        {
            Name = "Escape",
            Short = "ESCAPE",
            Folder = "Escape",
            Features = {
                {
                    Id = "mapped.games.escape.islandnav",
                    Name = "Island Extraction Route",
                    Description = "Walks toward the detected extraction boat or finish point.",
                    Path = "Features/Games/Escape/IslandNav.lua",
                    Category = "Experimental",
                },
            },
        },
    },
    Guards = {
        {
            Name = "Game Moderation",
            Short = "MOD",
            Folder = "Player Moderation",
            Features = {
                {
                    Id = "mapped.guards.game_moderation.guardlocalcleanup",
                    Name = "Guard Local Cleanup",
                    Description = "Locally clears nearby eliminated bodies and cleanup targets during guard duty.",
                    Path = "Features/Guard/PlayerModeration/GuardLocalCleanup.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.guards.game_moderation.guardlocalmoderator",
                    Name = "Guard Local Moderator",
                    Description = "Assists with nearby guard moderation targets while avoiding unsupported rounds.",
                    Path = "Features/Guard/PlayerModeration/GuardLocalModerator.lua",
                    Category = "Experimental",
                },
            },
        },
        {
            Name = "Kitchen Staff",
            Short = "KITCHEN",
            Folder = "Kitchen",
            Features = {
                {
                    Id = "mapped.guards.kitchen_staff.autocooker",
                    Name = "Auto Cooker",
                    Description = "Finds raw supplies, equips them, and assists with nearby cooking stations.",
                    Path = "Features/Guard/Kitchen/AutoCooker.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.guards.kitchen_staff.autostorage",
                    Name = "Auto Storage",
                    Description = "Moves cooked food into detected storage or delivery stations.",
                    Path = "Features/Guard/Kitchen/AutoStorage.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.guards.kitchen_staff.autosupply",
                    Name = "Auto Supply",
                    Description = "Collects nearby kitchen supplies when inventory space is available.",
                    Path = "Features/Guard/Kitchen/AutoSupply.lua",
                    Category = "Experimental",
                },
            },
        },
        {
            Name = "Morgue Staff",
            Short = "MORGUE",
            Folder = "Coffin",
            Features = {
                {
                    Id = "mapped.guards.morgue_staff.coffindisposal",
                    Name = "Coffin Disposal",
                    Description = "Carries detected coffin or body tools toward the disposal area.",
                    Path = "Features/Guard/Coffin/CoffinDisposal.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.guards.morgue_staff.coffingrabber",
                    Name = "Coffin Grabber",
                    Description = "Finds and collects the nearest available coffin or body target.",
                    Path = "Features/Guard/Coffin/CoffinGrabber.lua",
                    Category = "Experimental",
                },
            },
        },
    },
    Detective = {
        {
            Name = "Island Navigation",
            Short = "WALK",
            Features = {
                {
                    Id = "mapped.detective.island_navigation.islandnavigator",
                    Name = "Island Navigator",
                    Description = "Auto-walks from the boat or starting area to the nearest evidence using pathfinding; it does not teleport.",
                    Path = "Features/Detective/IslandNavigator.lua",
                    Category = "Experimental",
                },
            },
        },
        {
            Name = "Evidence",
            Short = "EVIDENCE",
            Features = {
                {
                    Id = "mapped.detective.evidence.evidencecollector",
                    Name = "Evidence Collector",
                    Description = "Walks to nearby evidence and activates supported collection prompts.",
                    Path = "Features/Detective/EvidenceCollector.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.detective.evidence.evidenceesp",
                    Name = "Evidence ESP",
                    Description = "Highlights evidence, clues, files, and keycards in the world.",
                    Path = "Features/Detective/EvidenceESP.lua",
                    Category = "Experimental",
                },
            },
        },
        {
            Name = "Boat Operations",
            Short = "BOAT",
            Features = {
                {
                    Id = "mapped.detective.boat_operations.boatdepositor",
                    Name = "Boat Depositor",
                    Description = "Walks evidence back to the boat and deposits supported evidence tools.",
                    Path = "Features/Detective/BoatDepositor.lua",
                    Category = "Experimental",
                },
            },
        },
        {
            Name = "Disguise",
            Short = "DISGUISE",
            Features = {
                {
                    Id = "mapped.detective.disguise.disguisemanager",
                    Name = "Disguise Manager",
                    Description = "Equips an available disguise when a nearby guard is detected.",
                    Path = "Features/Detective/DisguiseManager.lua",
                    Category = "Experimental",
                },
            },
        },
    },
    Farming = {
        {
            Name = "Automation Controllers",
            Short = "AUTO",
            Features = {
                {
                    Id = "mapped.farming.player_minigame_bot",
                    Name = "Player Minigame Farming",
                    Description = "Detects the active minigame and runs one conservative automation profile at a time.",
                    Path = "Features/Farming/PlayerMinigameBot.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.farming.guard_master_controller",
                    Name = "Guard Staff Farming",
                    Description = "Selects one compatible guard duty at a time for kitchen, morgue, or moderation work.",
                    Path = "Features/Farming/GuardMasterController.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.farming.frontman_adaptive_controller",
                    Name = "Frontman Adaptive Farming",
                    Description = "Detects whether Frontman selected Player or Guard mode, then runs the matching farming controller.",
                    Path = "Features/Farming/FrontmanAdaptiveController.lua",
                    Category = "Experimental",
                },
                {
                    Id = "mapped.farming.detective_master_controller",
                    Name = "Detective Evidence Farming",
                    Description = "Runs a stable evidence loop: walk to clues, collect them, and return them to the boat.",
                    Path = "Features/Farming/DetectiveMasterController.lua",
                    Category = "Experimental",
                },
            },
        },
    },
}

local function finalize()
    for pageName, categories in pairs(FeatureCatalog.Pages) do
        for _, category in ipairs(categories) do
            for _, feature in ipairs(category.Features or {}) do
                feature.PageName = pageName
                feature.CategoryName = category.Name
                feature.Name = feature.Name or humanize(feature.Path:match("([^/]+)%.lua$") or "Feature")
                feature.Description = feature.Description or fallbackDescription(feature.Name)
                feature.Id = feature.Id or ("mapped." .. slug(pageName) .. "." .. slug(category.Name) .. "." .. slug(feature.Name))
                feature.Category = feature.Category or "Experimental"
            end
        end
    end
end

finalize()

function FeatureCatalog:GetCategories(pageName)
    return self.Pages[pageName] or {}
end

function FeatureCatalog:GetAllFeatures()
    local result = {}
    for _, categories in pairs(self.Pages) do
        for _, category in ipairs(categories) do
            for _, feature in ipairs(category.Features or {}) do
                table.insert(result, feature)
            end
        end
    end
    return result
end

function FeatureCatalog:GetTotalCount()
    return #self:GetAllFeatures()
end

function FeatureCatalog:Describe(feature)
    if type(feature) == "table" then
        return feature.Description or fallbackDescription(feature.Name)
    end
    return fallbackDescription(feature)
end

return FeatureCatalog
]====],
        [ [====[Modules/FeatureFolder.lua]====] ] = [====[local FeatureFolder = {}

local cache = {}

local function makeCorner(parent, radius)
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, radius or 12)
    corner.Parent = parent
end

local function loadFeature(App, info)
    local path = info.Path
    if cache[path] then
        return cache[path]
    end

    local loader = App.Loader
    local feature
    if loader and type(loader.LoadRemote) == "function" then
        feature = loader:LoadRemote(path)
    else
        feature = loadstring(game:HttpGet(App.Config.Repository .. path))()
    end

    if type(feature) ~= "table" then
        error(
            "module did not return a feature table: "
            .. tostring(path)
        )
    end
    if type(feature.Toggle) ~= "function"
        and not (
            type(feature.Enable) == "function"
            and type(feature.Disable) == "function"
        )
    then
        error(
            "module has no Toggle or Enable/Disable API: "
            .. tostring(path)
        )
    end

    cache[path] = feature

    local manager = App.FeatureManager
    if manager and type(manager.AttachCatalogFeature) == "function" and info.Id then
        manager:AttachCatalogFeature(info.Id, feature)
    end

    return feature
end

local function enabledState(feature)
    if type(feature) ~= "table" then
        return false
    end
    if type(feature.IsEnabled) == "function" then
        local ok, value = pcall(feature.IsEnabled, feature)
        if ok then return value == true end
    end
    if type(feature.GetState) == "function" then
        local ok, value = pcall(feature.GetState, feature)
        if ok then
            value = tostring(value or ""):lower()
            return value == "on" or value == "enabled" or value == "full"
        end
    end
    return feature.Enabled == true or feature.Active == true
end

local function desiredState(manager, info, feature)
    if manager and manager.AutoApplyPerGameEnabled
        and type(manager.GetEntry) == "function"
        and info and info.Id
    then
        local entry = manager:GetEntry(info.Id)
        if entry and entry.PageName == "Games" then
            return entry.DesiredEnabled == true
        end
    end
    return enabledState(feature)
end

local function isAutoManagedGame(manager, info)
    if not manager or not manager.AutoApplyPerGameEnabled or not info or not info.Id then return false end
    local entry = type(manager.GetEntry) == "function" and manager:GetEntry(info.Id) or nil
    return entry and entry.PageName == "Games"
end

local function setEnabled(feature, state)
    if type(feature) ~= "table" then
        return false, "module did not return a feature table"
    end

    local function invoke(method)
        local ok, result, detail = pcall(
            method,
            feature,
            state
        )
        if not ok then
            return false, tostring(result)
        end
        if result == false then
            return false, tostring(
                detail
                or "feature rejected the requested state"
            )
        end
        return true, result
    end

    if type(feature.Toggle) == "function" then
        return invoke(feature.Toggle)
    end

    local method = state
        and feature.Enable
        or feature.Disable
    if type(method) == "function" then
        local ok, result, detail = pcall(
            method,
            feature
        )
        if not ok then
            return false, tostring(result)
        end
        if result == false then
            return false, tostring(
                detail
                or "feature rejected the requested state"
            )
        end
        return true, result
    end

    return false, "module does not expose Toggle(state) or Enable/Disable"
end

local function descriptionFor(App, info)
    if type(info.Description) == "string" and info.Description ~= "" then
        return info.Description
    end

    local catalog = App.Loader and App.Loader.FeatureCatalog
    if catalog and type(catalog.Describe) == "function" then
        return catalog:Describe(info)
    end

    return "Provides focused assistance for " .. tostring(info.Name or "this feature") .. "."
end

function FeatureFolder:Render(Page, App, options)
    options = options or {}
    local pageName = options.PageName or "Games"
    local topY = options.TopY or 128
    local accent = App:GetPageAccent(pageName)
    local padding = App:GetUIStyleValue(pageName, "PagePadding", "MainPage") or 18

    local old = Page:FindFirstChild(pageName .. "FeatureContent")
    if old then old:Destroy() end

    local content = Instance.new("Frame")
    content.Name = pageName .. "FeatureContent"
    content:SetAttribute("SquidNoMoSubpage", true)
    content.Position = UDim2.fromOffset(padding, topY)
    content.Size = UDim2.new(1, -(padding * 2), 0, 10)
    content.AutomaticSize = Enum.AutomaticSize.Y
    content.BackgroundTransparency = 1
    content.BorderSizePixel = 0
    content.Parent = Page

    local grid = Instance.new("UIGridLayout")
    grid.SortOrder = Enum.SortOrder.LayoutOrder
    local cellGap = App:IsMobile() and 8 or 12
    local cardHeight = App:IsMobile() and 184 or 166
    grid.CellPadding = UDim2.fromOffset(cellGap, cellGap)
    grid.CellSize = UDim2.new(0.5, -(cellGap / 2), 0, cardHeight)
    grid.Parent = content

    local features = options.Features or {}
    for index, info in ipairs(features) do
        local card = App:CreateCard(content, UDim2.new(1, 0, 0, cardHeight), {
            Color = App.Colors.CardAlt,
            BorderColor = accent,
            BorderTransparency = 0.18,
            Radius = 14,
        })
        card.LayoutOrder = index

        App:CreateText(card, info.Name, UDim2.new(1, -28, 0, 44), UDim2.fromOffset(14, 12), {
            Font = Enum.Font.GothamBold,
            TextSize = App:IsMobile() and 14 or 15,
            Wrapped = true,
            YAlignment = Enum.TextYAlignment.Top,
            Color = App.Colors.Text,
            ZIndex = 1014,
        })

        App:CreateText(card, descriptionFor(App, info), UDim2.new(1, -28, 0, App:IsMobile() and 66 or 56), UDim2.fromOffset(14, 56), {
            Font = Enum.Font.GothamMedium,
            TextSize = App:IsMobile() and 13 or 12,
            Color = App.Colors.Muted,
            Wrapped = true,
            YAlignment = Enum.TextYAlignment.Top,
            ZIndex = 1014,
        })

        local statusLabel = App:CreateText(
            card,
            "READY • Tap to load",
            UDim2.new(1, -104, 0, 28),
            UDim2.new(0, 14, 1, -42),
            {
                Font = Enum.Font.GothamBold,
                TextSize = App:IsMobile() and 12 or 11,
                Color = App.Colors.Muted,
                Wrapped = false,
                XAlignment = Enum.TextXAlignment.Left,
                ZIndex = 1014,
            }
        )
        statusLabel.TextTruncate = Enum.TextTruncate.AtEnd

        local button = Instance.new("TextButton")
        button.AnchorPoint = Vector2.new(1, 1)
        button.Position = UDim2.new(1, -14, 1, -12)
        local toggleWidth = App:IsMobile() and 68 or 62
        local toggleHeight = App:IsMobile() and 38 or 34
        button.Size = UDim2.fromOffset(toggleWidth, toggleHeight)
        button.BackgroundColor3 = Color3.fromRGB(70, 66, 80)
        button.BorderSizePixel = 0
        button.AutoButtonColor = false
        button.Text = ""
        button.ZIndex = 1015
        button.Parent = card
        makeCorner(button, 999)

        local knob = Instance.new("Frame")
        local knobSize = toggleHeight - 6
        knob.Size = UDim2.fromOffset(knobSize, knobSize)
        knob.Position = UDim2.fromOffset(3, 3)
        knob.BackgroundColor3 = Color3.fromRGB(242, 239, 247)
        knob.BorderSizePixel = 0
        knob.ZIndex = 1016
        knob.Parent = button
        makeCorner(knob, 999)

        local manager = App.FeatureManager
        local feature = manager
            and type(manager.GetFeature) == "function"
            and manager:GetFeature(info.Id)
            or cache[info.Path]
        local busy = false
        local statusConnection = nil

        local function renderStatus()
            local armed = desiredState(manager, info, feature)
            local running = enabledState(feature)
            if isAutoManagedGame(manager, info) and armed and not running and type(feature) ~= "table" then
                local entry = manager:GetEntry(info.Id)
                statusLabel.Text = "ARMED • Waiting for " .. tostring(entry and entry.CategoryName or "matching game")
                statusLabel.TextColor3 = Color3.fromRGB(255, 210, 80)
                return
            end
            if type(feature) ~= "table" then
                statusLabel.Text = armed and "ARMED • Loads when detected" or "READY • Tap to load"
                statusLabel.TextColor3 = armed and Color3.fromRGB(255, 210, 80) or App.Colors.Muted
                return
            end

            local state = running and "ACTIVE" or "OFF"
            local detail = enabledState(feature) and "Enabled" or "Disabled"
            if type(feature.GetStatus) == "function" then
                local ok, nextState, nextDetail = pcall(
                    feature.GetStatus,
                    feature
                )
                if ok then
                    state = string.upper(tostring(nextState or state))
                    detail = tostring(nextDetail or detail)
                end
            end

            statusLabel.Text = state .. " • " .. detail
            if state == "ERROR" then
                statusLabel.TextColor3 = Color3.fromRGB(255, 105, 115)
            elseif state == "WAITING" or state == "STARTING" then
                statusLabel.TextColor3 = Color3.fromRGB(255, 210, 80)
            elseif state == "ACTIVE" or state == "COMPLETE" then
                statusLabel.TextColor3 = Color3.fromRGB(80, 255, 145)
            else
                statusLabel.TextColor3 = App.Colors.Muted
            end
        end

        local function subscribeStatus()
            if statusConnection then
                pcall(function() statusConnection:Disconnect() end)
                statusConnection = nil
            end
            if type(feature) == "table"
                and type(feature.SubscribeStatus) == "function"
            then
                local ok, connection = pcall(
                    feature.SubscribeStatus,
                    feature,
                    function()
                        renderStatus()
                    end
                )
                if ok then statusConnection = connection end
            end
            renderStatus()
        end

        local function render()
            local on = desiredState(manager, info, feature)
            button.BackgroundColor3 = on and accent or Color3.fromRGB(70, 66, 80)
            local travel = toggleWidth - knobSize - 3
            knob.Position = UDim2.fromOffset(on and travel or 3, 3)
            renderStatus()
        end

        button.Activated:Connect(function()
            if Page:GetAttribute("SquidNoMoTouchDragging") then return end
            if busy then return end
            busy = true

            -- Capture the user's intended state before a lazy module is loaded.
            -- This prevents a restored pending state from flipping the first click.
            local nextState = not desiredState(manager, info, feature)

            if not feature then
                local ok, result = pcall(loadFeature, App, info)
                if not ok then
                    local message = tostring(result)
                    warn("[SquidNoMo] Failed to load " .. tostring(info.Name) .. ": " .. message)
                    statusLabel.Text = "ERROR • " .. message
                    statusLabel.TextColor3 = Color3.fromRGB(255, 105, 115)
                    if App.Notifications
                        and type(App.Notifications.Error) == "function"
                    then
                        App.Notifications:Error(
                            tostring(info.Name),
                            message,
                            5
                        )
                    end
                    busy = false
                    return
                end
                feature = result
                subscribeStatus()
            end

            local ok, err = setEnabled(feature, nextState)
            if ok and manager then
                if type(manager.SetFeatureState) == "function" and info.Id then
                    -- Manual means the tap must take effect now. Auto Apply still
                    -- remembers the selection and handles later game transitions.
                    ok = manager:SetFeatureState(
                        info.Id,
                        nextState and "on" or "off",
                        {Manual = true}
                    )
                    if not ok then err = "feature state could not be saved" end
                elseif type(manager.Notify) == "function" then
                    manager:Notify()
                end
            end
            if not ok then
                local message = tostring(err)
                warn("[SquidNoMo] Toggle failed for " .. tostring(info.Name) .. ": " .. message)
                if App.Notifications and type(App.Notifications.Error) == "function" then
                    App.Notifications:Error(tostring(info.Name), message, 5)
                end
            end

            render()
            if type(App.QueueSettingsSave) == "function" then App:QueueSettingsSave() end
            busy = false
        end)

        card.Destroying:Connect(function()
            if statusConnection then
                pcall(function()
                    statusConnection:Disconnect()
                end)
                statusConnection = nil
            end
        end)

        App:BindButtonFeedback(button, accent)
        subscribeStatus()
        render()
    end

    local function updateCanvas()
        local height = math.max(cardHeight, grid.AbsoluteContentSize.Y)
        content.AutomaticSize = Enum.AutomaticSize.None
        content.Size = UDim2.new(1, -(padding * 2), 0, height)
        Page.AutomaticCanvasSize = Enum.AutomaticSize.None
        Page.ScrollingDirection = Enum.ScrollingDirection.Y
        Page.ScrollingEnabled = true
        local viewport = math.max(Page.AbsoluteWindowSize.Y, Page.AbsoluteSize.Y)
        Page.CanvasSize = UDim2.fromOffset(
            0,
            math.max(topY + height + (App:IsMobile() and 92 or 44), viewport + 2)
        )
    end
    local gridConnection = grid:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(updateCanvas)
    local pageConnection = Page:GetPropertyChangedSignal("AbsoluteSize"):Connect(updateCanvas)
    content.Destroying:Connect(function()
        pcall(function() gridConnection:Disconnect() end)
        pcall(function() pageConnection:Disconnect() end)
    end)
    task.defer(updateCanvas)
    task.delay(0.12, updateCanvas)
    task.delay(0.45, updateCanvas)

    return content
end

return FeatureFolder
]====],
        [ [====[Modules/Games.lua]====] ] = [====[local GamesPage = {}

function GamesPage:Create(Page, App)
    local catalog = App.Loader.FeatureCatalog
    local categories = catalog and catalog:GetCategories("Games") or {}
    local manager = App.FeatureManager
    local alive = true
    local lastDetected = nil

    local selector = App.Loader.CategoryStrip:Create(Page, App, {
        PageName = "Games",
        SessionKey = "SelectedGameCategory",
        DefaultName = categories[1] and categories[1].Name or "Red Light, Green Light",
        ScrollerName = "GameCategoryScroller",
        ButtonWidth = 190,
        Items = categories,
        OnSelected = function(item)
            App.Loader.FeatureFolder:Render(Page, App, {
                PageName = "Games",
                Features = item.Features or {},
            })
        end,
    })

    local function followDetectedGame()
        if not manager or type(manager.GetDetectedGameCategory) ~= "function" then return end
        local detected = manager:GetDetectedGameCategory()
        if detected and detected ~= lastDetected then
            lastDetected = detected
            selector.SelectByName(detected)
            if App.Session then App.Session.SelectedGameCategory = detected end
        end
    end

    followDetectedGame()
    local connection
    if manager and type(manager.Subscribe) == "function" then
        connection = manager:Subscribe(followDetectedGame)
    end

    -- Do not depend solely on registry notifications. The mode detector runs while
    -- the page is open and immediately changes the visible subpage after a round
    -- transition, even when no feature state changed.
    task.spawn(function()
        while alive and Page.Parent do
            followDetectedGame()
            task.wait(Page.Visible and 0.35 or 0.9)
        end
    end)

    Page.Destroying:Connect(function()
        alive = false
        if connection then pcall(function() connection:Disconnect() end) end
    end)
end

return GamesPage
]====],
        [ [====[Modules/Guards.lua]====] ] = [====[local GuardsPage = {}

function GuardsPage:Create(Page, App)
    local catalog = App.Loader.FeatureCatalog
    local categories = catalog and catalog:GetCategories("Guards") or {}

    App.Loader.CategoryStrip:Create(Page, App, {
        PageName = "Guards",
        SessionKey = "SelectedGuardCategory",
        DefaultName = categories[1] and categories[1].Name or "Game Moderation",
        ScrollerName = "GuardCategoryScroller",
        ButtonWidth = 220,
        Items = categories,
        OnSelected = function(item)
            App.Loader.FeatureFolder:Render(Page, App, {
                PageName = "Guards",
                Features = item.Features or {},
            })
        end,
    })
end

return GuardsPage
]====],
        [ [====[Modules/Home.lua]====] ] = [====[local Home = {}

function Home:Create(Page, App)

	local Components = App.Components

	local HeroBanner = App.Loader.HeroBanner
	local FeatureGroups = App.Loader.FeatureGroups
	local ServerStatus = App.Loader.ServerStatus
	local NOMOAI = App.Loader.NOMOAI
	local SupportDevelopment = App.Loader.SupportDevelopment
	local DevelopmentGoal = App.Loader.DevelopmentGoal
	local Supporters = App.Loader.Supporters
	local ImportantNotice = App.Loader.ImportantNotice
	local Footer = App.Loader.Footer


	HeroBanner:Create(Page, App)

	local Row1 = Components:CreateHorizontalContainer(Page)
	Row1.LayoutOrder = 2

	FeatureGroups:Create(Row1, App)
	ServerStatus:Create(Row1, App)
	NOMOAI:Create(Row1, App)

	local Row2 = Components:CreateHorizontalContainer(Page)
	Row2.LayoutOrder = 3

	SupportDevelopment:Create(Row2, App)
	DevelopmentGoal:Create(Row2, App)
	Supporters:Create(Row2, App)

	ImportantNotice:Create(Page, App)
	Footer:Create(Page, App)

end

return Home
]====],
        [ [====[Modules/Home/DevelopmentGoal.lua]====] ] = [====[local DevelopmentGoal = {}

function DevelopmentGoal:Create(Parent, App)

	local Theme = App.Theme
	local Components = App.Components

	local Card = Components:CreateCard(
		Parent,
		UDim2.new(.33,-8,0,190)
	)

	local Padding = Instance.new("UIPadding")
	Padding.PaddingTop = UDim.new(0,18)
	Padding.PaddingBottom = UDim.new(0,18)
	Padding.PaddingLeft = UDim.new(0,18)
	Padding.PaddingRight = UDim.new(0,18)
	Padding.Parent = Card

	local Layout = Instance.new("UIListLayout")
	Layout.Padding = UDim.new(0,12)
	Layout.Parent = Card

	local Title = Instance.new("TextLabel")
	Title.Size = UDim2.new(1,0,0,24)
	Title.BackgroundTransparency = 1
	Title.Font = Theme.FontBlack
	Title.Text = "Development Goal"
	Title.TextSize = 19
	Title.TextColor3 = Theme.Text
	Title.TextXAlignment = Enum.TextXAlignment.Left
	Title.Parent = Card

	local Goal = Instance.new("TextLabel")
	Goal.Size = UDim2.new(1,0,0,18)
	Goal.BackgroundTransparency = 1
	Goal.Font = Theme.FontBold
	Goal.Text = "$250 Goal"
	Goal.TextSize = 15
	Goal.TextColor3 = Theme.Accent
	Goal.TextXAlignment = Enum.TextXAlignment.Left
	Goal.Parent = Card

	local Bar = Instance.new("Frame")
	Bar.Size = UDim2.new(1,0,0,12)
	Bar.BackgroundColor3 = Theme.Card
	Bar.BorderSizePixel = 0
	Bar.Parent = Card

	local Corner = Instance.new("UICorner")
	Corner.CornerRadius = UDim.new(1,0)
	Corner.Parent = Bar

	local Fill = Instance.new("Frame")
	Fill.Size = UDim2.new(.28,0,1,0)
	Fill.BackgroundColor3 = Theme.Accent
	Fill.BorderSizePixel = 0
	Fill.Parent = Bar

	local FillCorner = Instance.new("UICorner")
	FillCorner.CornerRadius = UDim.new(1,0)
	FillCorner.Parent = Fill

	local Progress = Instance.new("TextLabel")
	Progress.Size = UDim2.new(1,0,0,18)
	Progress.BackgroundTransparency = 1
	Progress.Font = Theme.Font
	Progress.Text = "$70 / $250 (28%)"
	Progress.TextSize = 14
	Progress.TextColor3 = Theme.SubText
	Progress.TextXAlignment = Enum.TextXAlignment.Left
	Progress.Parent = Card

	function Card:SetGoal(Current, Target)

		local Percent = math.clamp(Current / Target,0,1)

		Fill.Size = UDim2.new(Percent,0,1,0)

		Progress.Text =
			string.format(
				"$%d / $%d (%d%%)",
				Current,
				Target,
				math.floor(Percent*100)
			)

	end

	return Card

end

return DevelopmentGoal
]====],
        [ [====[Modules/Home/FeatureGroups.lua]====] ] = [====[local FeatureGroups = {}

function FeatureGroups:Create(Parent, App)

	local Theme = App.Theme
	local Components = App.Components

	local Card = Components:CreateCard(
		Parent,
		UDim2.new(.33,-8,0,285)
	)

	local Padding = Instance.new("UIPadding")
	Padding.PaddingTop = UDim.new(0,18)
	Padding.PaddingBottom = UDim.new(0,18)
	Padding.PaddingLeft = UDim.new(0,18)
	Padding.PaddingRight = UDim.new(0,18)
	Padding.Parent = Card

	local Layout = Instance.new("UIListLayout")
	Layout.Padding = UDim.new(0,10)
	Layout.Parent = Card

	local Title = Instance.new("TextLabel")
	Title.Size = UDim2.new(1,0,0,26)
	Title.BackgroundTransparency = 1
	Title.Font = Theme.FontBlack
	Title.Text = "Feature Groups"
	Title.TextSize = 19
	Title.TextColor3 = Theme.Text
	Title.TextXAlignment = Enum.TextXAlignment.Left
	Title.Parent = Card

	local Features = {
		"👤 Players",
		"🛡 Guards",
		"🕵 Detective",
		"💰 Farming",
		"⭐ VIP",
		"🎮 Games",
		"⚙ Settings"
	}

	for _,Name in ipairs(Features) do

		local Label = Instance.new("TextLabel")
		Label.Size = UDim2.new(1,0,0,20)
		Label.BackgroundTransparency = 1
		Label.Font = Theme.Font
		Label.Text = Name
		Label.TextSize = 15
		Label.TextColor3 = Theme.Text
		Label.TextXAlignment = Enum.TextXAlignment.Left
		Label.Parent = Card

	end

	return Card

end

return FeatureGroups
]====],
        [ [====[Modules/Home/FeatureStats.lua]====] ] = [====[--//========================================================--
--// SquidNoMo
--// 1.1 beta 1
--// Modules/Home/FeatureStats.lua
--//========================================================--

local FeatureStats = {}

local function makeCorner(parent, radius)
    local item = Instance.new("UICorner")
    item.CornerRadius = UDim.new(0, radius)
    item.Parent = parent
    return item
end

local function makeStroke(parent, color, thickness, transparency)
    local item = Instance.new("UIStroke")
    item.Color = color
    item.Thickness = thickness or 1
    item.Transparency = transparency or 0
    item.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
    item.Parent = parent
    return item
end

local function makeStatCard(App, parent, state, title, description, color, position)
    local Theme = App.Theme

    local card = App:CreateCard(parent, UDim2.fromOffset(355, 172), {
        Position = position,
        Color = state == "full"
            and Color3.fromRGB(5, 37, 22)
            or state == "partial"
                and Color3.fromRGB(37, 27, 5)
                or Color3.fromRGB(34, 10, 14),
        StrokeColor = color,
        StrokeTransparency = 0.12,
        Radius = 13,
        ZIndex = 30,
    })

    local iconHolder = App:CreateFrame(card, UDim2.fromOffset(60, 60), UDim2.fromOffset(18, 14), color, {
        Transparency = 1,
        ZIndex = 33,
    })

    if state == "partial" then
        App.Icons:CreateTriangleStatus(iconHolder, 58, color, 34)
        App:CreateText(iconHolder, "!", UDim2.fromScale(1, 1), UDim2.fromOffset(0, 4), {
            Font = Theme.FontBlack,
            TextSize = 25,
            Color = color,
            XAlignment = Enum.TextXAlignment.Center,
            ZIndex = 36,
        })
    else
        App.Icons:CreateStatus(iconHolder, state, 58, Theme, 34)
    end

    App:CreateText(card, title, UDim2.new(1, -104, 0, 30), UDim2.fromOffset(92, 14), {
        Font = Theme.FontBlack,
        TextSize = 18,
        Color = Theme.Text,
        ZIndex = 34,
    })

    App:CreateText(card, description, UDim2.new(1, -104, 0, 48), UDim2.fromOffset(92, 46), {
        Font = Theme.FontMedium,
        TextSize = 13,
        Color = Theme.Text,
        Wrapped = true,
        YAlignment = Enum.TextYAlignment.Top,
        ZIndex = 34,
    })

    local count = App:CreateText(card, "0", UDim2.fromOffset(140, 54), UDim2.fromOffset(20, 96), {
        Font = Theme.FontBlack,
        TextSize = 43,
        Color = color,
        ZIndex = 34,
    })

    App:CreateText(card, "FEATURES", UDim2.fromOffset(170, 24), UDim2.fromOffset(20, 145), {
        Font = Theme.FontBlack,
        TextSize = 14,
        Color = color,
        ZIndex = 34,
    })

    local percent = App:CreateText(card, "0%", UDim2.fromOffset(92, 24), UDim2.new(1, -108, 1, -32), {
        Font = Theme.FontBlack,
        TextSize = 15,
        Color = color,
        XAlignment = Enum.TextXAlignment.Right,
        ZIndex = 34,
    })

    return {
        Card = card,
        Count = count,
        Percent = percent,
    }
end

function FeatureStats:Create(parent, App)
    local Theme = App.Theme

    local root = App:CreateCard(parent, UDim2.new(1, 0, 0, 354), {
        Color = Color3.fromRGB(8, 13, 11),
        StrokeColor = Theme.Border,
        StrokeTransparency = 0.05,
        Radius = 15,
        ZIndex = 20,
    })
    root.Name = "FeatureStats"

    local titleIcon = App:CreateFrame(root, UDim2.fromOffset(30, 30), UDim2.fromOffset(18, 12), Theme.Accent, {
        Transparency = 1,
        ZIndex = 31,
    })
    App.Icons:Create(titleIcon, "Stats", 28, Theme.Accent, 32)

    App:CreateText(root, "FEATURE STATS", UDim2.fromOffset(360, 34), UDim2.fromOffset(54, 10), {
        Font = Theme.FontBlack,
        TextSize = 23,
        Color = Theme.Text,
        ZIndex = 32,
    })

    local notice = App:CreateFrame(root, UDim2.new(1, -36, 0, 40), UDim2.fromOffset(18, 48), Color3.fromRGB(29, 22, 5), {
        Radius = 9,
        StrokeColor = Theme.Warning,
        StrokeTransparency = 0.15,
        ZIndex = 31,
    })

    local warningIcon = App:CreateText(notice, "!", UDim2.fromOffset(30, 30), UDim2.fromOffset(10, 5), {
        Font = Theme.FontBlack,
        TextSize = 19,
        Color = Theme.Black,
        XAlignment = Enum.TextXAlignment.Center,
        ZIndex = 34,
    })
    warningIcon.BackgroundTransparency = 0
    warningIcon.BackgroundColor3 = Theme.Warning
    makeCorner(warningIcon, 7)

    App:CreateText(notice, "To change any settings, please use the categories in the tabs on the left.", UDim2.new(1, -58, 1, 0), UDim2.fromOffset(50, 0), {
        Font = Theme.FontBold,
        TextSize = 14,
        Color = Theme.WarningBright,
        ZIndex = 34,
    })

    local full = makeStatCard(
        App,
        root,
        "full",
        "FULLY ON",
        "All features\nare enabled.",
        Theme.Accent,
        UDim2.fromOffset(18, 101)
    )

    local partial = makeStatCard(
        App,
        root,
        "partial",
        "PARTIALLY ON",
        "Some features\nare enabled.",
        Theme.Warning,
        UDim2.fromOffset(391, 101)
    )

    local off = makeStatCard(
        App,
        root,
        "off",
        "NOT ON",
        "No features\nare enabled.",
        Theme.Error,
        UDim2.fromOffset(764, 101)
    )

    local track = App:CreateFrame(root, UDim2.new(1, -36, 0, 34), UDim2.fromOffset(18, 286), Theme.Row, {
        Radius = 8,
        ClipsDescendants = true,
        ZIndex = 31,
    })

    local fullFill = App:CreateFrame(track, UDim2.new(0, 0, 1, 0), UDim2.fromOffset(0, 0), Theme.Accent, {
        ZIndex = 32,
    })
    local partialFill = App:CreateFrame(track, UDim2.new(0, 0, 1, 0), UDim2.new(0, 0, 0, 0), Theme.Warning, {
        ZIndex = 32,
    })
    local offFill = App:CreateFrame(track, UDim2.new(0, 0, 1, 0), UDim2.new(0, 0, 0, 0), Theme.Error, {
        ZIndex = 32,
    })

    local fullBarText = App:CreateText(track, "0%", UDim2.new(0, 0, 1, 0), UDim2.fromOffset(0, 0), {
        Font = Theme.FontBlack,
        TextSize = 14,
        Color = Theme.Black,
        XAlignment = Enum.TextXAlignment.Center,
        ZIndex = 35,
    })

    local partialBarText = App:CreateText(track, "0%", UDim2.new(0, 0, 1, 0), UDim2.fromOffset(0, 0), {
        Font = Theme.FontBlack,
        TextSize = 14,
        Color = Theme.Black,
        XAlignment = Enum.TextXAlignment.Center,
        ZIndex = 35,
    })

    local offBarText = App:CreateText(track, "0%", UDim2.new(0, 0, 1, 0), UDim2.fromOffset(0, 0), {
        Font = Theme.FontBlack,
        TextSize = 14,
        Color = Theme.Text,
        XAlignment = Enum.TextXAlignment.Center,
        ZIndex = 35,
    })

    local totalLabel = App:CreateText(root, "0 / 0 FEATURES", UDim2.new(1, -36, 0, 24), UDim2.fromOffset(18, 324), {
        Font = Theme.FontBold,
        TextSize = 14,
        Color = Theme.Text,
        XAlignment = Enum.TextXAlignment.Center,
        ZIndex = 34,
    })

    local function refresh()
        local summary = App.FeatureRegistry:GetSummary()

        full.Count.Text = tostring(summary.full)
        full.Percent.Text = tostring(summary.fullPercent) .. "%"
        partial.Count.Text = tostring(summary.partial)
        partial.Percent.Text = tostring(summary.partialPercent) .. "%"
        off.Count.Text = tostring(summary.off)
        off.Percent.Text = tostring(summary.offPercent) .. "%"

        local fullScale = summary.fullPercent / 100
        local partialScale = summary.partialPercent / 100
        local offScale = summary.offPercent / 100

        fullFill.Size = UDim2.new(fullScale, 0, 1, 0)
        partialFill.Position = UDim2.new(fullScale, 0, 0, 0)
        partialFill.Size = UDim2.new(partialScale, 0, 1, 0)
        offFill.Position = UDim2.new(fullScale + partialScale, 0, 0, 0)
        offFill.Size = UDim2.new(offScale, 0, 1, 0)

        fullBarText.Position = UDim2.new(0, 0, 0, 0)
        fullBarText.Size = UDim2.new(fullScale, 0, 1, 0)
        fullBarText.Text = summary.fullPercent > 0 and (tostring(summary.fullPercent) .. "%") or ""

        partialBarText.Position = UDim2.new(fullScale, 0, 0, 0)
        partialBarText.Size = UDim2.new(partialScale, 0, 1, 0)
        partialBarText.Text = summary.partialPercent > 0 and (tostring(summary.partialPercent) .. "%") or ""

        offBarText.Position = UDim2.new(fullScale + partialScale, 0, 0, 0)
        offBarText.Size = UDim2.new(offScale, 0, 1, 0)
        offBarText.Text = summary.offPercent > 0 and (tostring(summary.offPercent) .. "%") or ""

        totalLabel.Text = string.format("%d / %d FEATURES", summary.loaded, summary.total)
    end

    refresh()

    task.spawn(function()
        while root.Parent and App.Gui do
            task.wait(2.0)
            refresh()
        end
    end)

    return root
end

return FeatureStats
]====],
        [ [====[Modules/Home/Footer.lua]====] ] = [====[local Footer = {}

function Footer:Create(Parent, App)

	local Theme = App.Theme

	local FooterFrame = Instance.new("Frame")
	FooterFrame.Name = "Footer"
	FooterFrame.Size = UDim2.new(1,0,0,36)
	FooterFrame.BackgroundTransparency = 1
	FooterFrame.LayoutOrder = 100
	FooterFrame.Parent = Parent

	local Left = Instance.new("TextLabel")
	Left.BackgroundTransparency = 1
	Left.Size = UDim2.new(.5,0,1,0)
	Left.Font = Theme.Font
	Left.Text = "SquidNoMo • " .. tostring(Theme.Version)
	Left.TextSize = 13
	Left.TextColor3 = Theme.SubText
	Left.TextXAlignment = Enum.TextXAlignment.Left
	Left.Parent = FooterFrame

	local Right = Instance.new("TextLabel")
	Right.BackgroundTransparency = 1
	Right.AnchorPoint = Vector2.new(1,0)
	Right.Position = UDim2.new(1,0,0,0)
	Right.Size = UDim2.new(.5,0,1,0)
	Right.Font = Theme.Font
	Right.Text = "github.com/JaysScriptz"
	Right.TextSize = 13
	Right.TextColor3 = Theme.SubText
	Right.TextXAlignment = Enum.TextXAlignment.Right
	Right.Parent = FooterFrame

	return FooterFrame

end

return Footer
]====],
        [ [====[Modules/Home/Hero.lua]====] ] = [====[--//========================================================--
--// SquidNoMo
--// 1.1 beta 1
--// Modules/Home/Hero.lua
--//========================================================--

local Hero = {}

local function makeCorner(parent, radius)
    local item = Instance.new("UICorner")
    item.CornerRadius = UDim.new(0, radius)
    item.Parent = parent
    return item
end

local function makeStroke(parent, color, thickness, transparency)
    local item = Instance.new("UIStroke")
    item.Color = color
    item.Thickness = thickness or 1
    item.Transparency = transparency or 0
    item.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
    item.Parent = parent
    return item
end

function Hero:Create(parent, App)
    local Theme = App.Theme

    local hero = App:CreateCard(parent, UDim2.new(1, 0, 0, 152), {
        Color = Color3.fromRGB(5, 20, 13),
        StrokeColor = Theme.AccentDark,
        StrokeTransparency = 0.03,
        Radius = 17,
        ClipsDescendants = true,
        ZIndex = 20,
    })
    hero.Name = "HeroBanner"

    local gradient = Instance.new("UIGradient")
    gradient.Color = ColorSequence.new({
        ColorSequenceKeypoint.new(0, Color3.fromRGB(5, 13, 10)),
        ColorSequenceKeypoint.new(0.42, Color3.fromRGB(4, 19, 12)),
        ColorSequenceKeypoint.new(1, Color3.fromRGB(0, 37, 18)),
    })
    gradient.Rotation = 0
    gradient.Parent = hero

    -- Radar rings reproduce the approved banner without external image assets.
    for index = 1, 6 do
        local ringSize = 96 + ((index - 1) * 42)
        local ring = App:CreateFrame(
            hero,
            UDim2.fromOffset(ringSize, ringSize),
            UDim2.new(0.79, -(ringSize / 2), 0.50, -(ringSize / 2)),
            Theme.Accent,
            {
                Transparency = 1,
                Radius = math.floor(ringSize / 2),
                StrokeColor = Theme.Accent,
                StrokeThickness = index == 1 and 2 or 1,
                StrokeTransparency = 0.34 + (index * 0.07),
                ZIndex = 22,
            }
        )
        ring.Name = "RadarRing" .. tostring(index)
    end

    for index = 1, 18 do
        local x = 0.48 + (((index * 37) % 48) / 100)
        local y = 0.12 + (((index * 53) % 76) / 100)
        local dotSize = (index % 4 == 0) and 6 or 3

        local dot = App:CreateFrame(
            hero,
            UDim2.fromOffset(dotSize, dotSize),
            UDim2.new(x, 0, y, 0),
            Theme.Accent,
            {
                Transparency = (index % 4 == 0) and 0.15 or 0.55,
                Radius = 99,
                ZIndex = 23,
            }
        )
        dot.Name = "RadarDot" .. tostring(index)
    end

    App:CreateText(hero, "SQUIDNOMO", UDim2.fromOffset(560, 58), UDim2.fromOffset(34, 16), {
        Font = Theme.FontBlack,
        TextSize = 50,
        Color = Theme.Text,
        ZIndex = 28,
    })

    App:CreateText(hero, "DASHBOARD", UDim2.fromOffset(420, 42), UDim2.fromOffset(35, 67), {
        Font = Theme.FontBlack,
        TextSize = 32,
        Color = Theme.Accent,
        ZIndex = 28,
    })

    App:CreateText(hero, "Optimized. Feature-Rich. Built for Squid Game X.", UDim2.fromOffset(650, 28), UDim2.fromOffset(36, 111), {
        Font = Theme.FontMedium,
        TextSize = 15,
        Color = Theme.Text,
        ZIndex = 28,
    })

    local logo = App.Icons:CreateLogo(hero, 118, {
        Position = UDim2.new(0.79, -59, 0.50, -59),
        Color = Theme.Accent,
        BackgroundColor = Color3.fromRGB(3, 14, 8),
        Glow = true,
        ZIndex = 29,
    })
    logo.Name = "BannerLogo"

    local minimizeButton = Instance.new("TextButton")
    minimizeButton.Name = "MinimizeButton"
    minimizeButton.AnchorPoint = Vector2.new(1, 0)
    minimizeButton.Position = UDim2.new(1, -14, 0, 13)
    minimizeButton.Size = UDim2.fromOffset(58, 58)
    minimizeButton.BackgroundTransparency = 1
    minimizeButton.BorderSizePixel = 0
    minimizeButton.AutoButtonColor = false
    minimizeButton.Text = ""
    minimizeButton.ZIndex = 40
    minimizeButton.Parent = hero

    App.Icons:CreateLogo(minimizeButton, 58, {
        Color = Theme.Accent,
        BackgroundColor = Theme.Window,
        Glow = false,
        ZIndex = 41,
    })

    local tooltip = App:CreateCard(hero, UDim2.fromOffset(142, 48), {
        Position = UDim2.new(1, -156, 0, 78),
        Color = Color3.fromRGB(8, 15, 12),
        StrokeColor = Theme.Accent,
        StrokeTransparency = 0.08,
        Radius = 8,
        ZIndex = 44,
    })
    tooltip.Visible = false

    App:CreateText(tooltip, "Click to minimize\nthe app", UDim2.new(1, -16, 1, -8), UDim2.fromOffset(8, 4), {
        Font = Theme.FontMedium,
        TextSize = 12,
        Color = Theme.Text,
        Wrapped = true,
        XAlignment = Enum.TextXAlignment.Center,
        ZIndex = 45,
    })

    App:Track(minimizeButton.MouseEnter:Connect(function()
        tooltip.Visible = true
    end))

    App:Track(minimizeButton.MouseLeave:Connect(function()
        tooltip.Visible = false
    end))

    App:Track(minimizeButton.MouseButton1Click:Connect(function()
        App:SetMinimized(true)
    end))

    local dragHandle = App:CreateFrame(
        hero,
        UDim2.new(0.70, 0, 1, 0),
        UDim2.fromOffset(0, 0),
        Theme.Window,
        {
            Transparency = 1,
            Active = true,
            ZIndex = 39,
        }
    )
    dragHandle.Name = "HeroDragHandle"
    App:EnableDragging(dragHandle)

    return hero
end

return Hero
]====],
        [ [====[Modules/Home/HeroBanner.lua]====] ] = [====[local HeroBanner = {}

function HeroBanner:Create(Parent, App)

	local Theme = App.Theme
	local Components = App.Components

	local Card = Components:CreateCard(
		Parent,
		UDim2.new(1,0,0,190)
	)

	Card.LayoutOrder = 1

	local Padding = Instance.new("UIPadding")
	Padding.PaddingTop = UDim.new(0,20)
	Padding.PaddingBottom = UDim.new(0,20)
	Padding.PaddingLeft = UDim.new(0,24)
	Padding.PaddingRight = UDim.new(0,24)
	Padding.Parent = Card

	local Title = Instance.new("TextLabel")
	Title.BackgroundTransparency = 1
	Title.Size = UDim2.new(1,0,0,40)
	Title.Font = Theme.FontBlack
	Title.Text = "SquidNoMo"
	Title.TextSize = 34
	Title.TextColor3 = Theme.Text
	Title.TextXAlignment = Enum.TextXAlignment.Left
	Title.Parent = Card

	local Subtitle = Instance.new("TextLabel")
	Subtitle.BackgroundTransparency = 1
	Subtitle.Position = UDim2.fromOffset(0,48)
	Subtitle.Size = UDim2.new(1,0,0,22)
	Subtitle.Font = Theme.Font
	Subtitle.Text = "Modern • Responsive • Modular"
	Subtitle.TextSize = 16
	Subtitle.TextColor3 = Theme.SubText
	Subtitle.TextXAlignment = Enum.TextXAlignment.Left
	Subtitle.Parent = Card

	local Description = Instance.new("TextLabel")
	Description.BackgroundTransparency = 1
	Description.Position = UDim2.fromOffset(0,82)
	Description.Size = UDim2.new(1,0,0,64)
	Description.Font = Theme.Font
	Description.TextWrapped = true
	Description.TextXAlignment = Enum.TextXAlignment.Left
	Description.TextYAlignment = Enum.TextYAlignment.Top
	Description.TextSize = 15
	Description.TextColor3 = Theme.Text
	Description.Text = "A complete modular utility designed with a responsive interface for desktop and mobile devices."
	Description.Parent = Card

	local Version = Instance.new("TextLabel")
	Version.AnchorPoint = Vector2.new(1,1)
	Version.Position = UDim2.new(1,0,1,0)
	Version.Size = UDim2.fromOffset(180,22)
	Version.BackgroundTransparency = 1
	Version.Font = Theme.FontBold
	Version.Text = tostring(Theme.Version)
	Version.TextSize = 15
	Version.TextColor3 = Theme.Accent
	Version.TextXAlignment = Enum.TextXAlignment.Right
	Version.Parent = Card

	return Card

end

return HeroBanner
]====],
        [ [====[Modules/Home/ImportantNotice.lua]====] ] = [====[local ImportantNotice = {}

function ImportantNotice:Create(Parent, App)

	local Theme = App.Theme
	local Components = App.Components

	local Card = Components:CreateCard(
		Parent,
		UDim2.new(1,0,0,245)
	)

	Card.LayoutOrder = 99

	local Padding = Instance.new("UIPadding")
	Padding.PaddingTop = UDim.new(0,18)
	Padding.PaddingBottom = UDim.new(0,18)
	Padding.PaddingLeft = UDim.new(0,20)
	Padding.PaddingRight = UDim.new(0,20)
	Padding.Parent = Card

	local Layout = Instance.new("UIListLayout")
	Layout.Padding = UDim.new(0,10)
	Layout.Parent = Card

	local Title = Instance.new("TextLabel")
	Title.Size = UDim2.new(1,0,0,24)
	Title.BackgroundTransparency = 1
	Title.Font = Theme.FontBlack
	Title.Text = "⚠ Important Notice"
	Title.TextSize = 20
	Title.TextColor3 = Theme.Warning
	Title.TextXAlignment = Enum.TextXAlignment.Left
	Title.Parent = Card

	local Body = Instance.new("TextLabel")
	Body.Size = UDim2.new(1,0,0,135)
	Body.BackgroundTransparency = 1
	Body.Font = Theme.Font
	Body.TextWrapped = true
	Body.TextYAlignment = Enum.TextYAlignment.Top
	Body.TextXAlignment = Enum.TextXAlignment.Left
	Body.TextSize = 14
	Body.TextColor3 = Theme.Text
	Body.Text =
[[• SquidNoMo is provided for educational and research purposes.

• Using third-party software may violate a game's Terms of Service.

• No feature can guarantee protection from detection or enforcement actions.

• You are responsible for how you use this software.

• By continuing, you acknowledge all associated risks.]]
	Body.Parent = Card

	local Risk = Instance.new("TextLabel")
	Risk.Size = UDim2.new(1,0,0,20)
	Risk.BackgroundTransparency = 1
	Risk.Font = Theme.FontBold
	Risk.Text = "Current Risk: Unknown"
	Risk.TextSize = 15
	Risk.TextColor3 = Theme.Accent
	Risk.TextXAlignment = Enum.TextXAlignment.Left
	Risk.Parent = Card

	return Card

end

return ImportantNotice
]====],
        [ [====[Modules/Home/NOMOAI.lua]====] ] = [====[local NOMOAI = {}

function NOMOAI:Create(Parent, App)

	local Theme = App.Theme
	local Components = App.Components

	local Card = Components:CreateCard(
		Parent,
		UDim2.new(.34,-8,0,260)
	)

	local Padding = Instance.new("UIPadding")
	Padding.PaddingTop = UDim.new(0,18)
	Padding.PaddingBottom = UDim.new(0,18)
	Padding.PaddingLeft = UDim.new(0,18)
	Padding.PaddingRight = UDim.new(0,18)
	Padding.Parent = Card

	local Layout = Instance.new("UIListLayout")
	Layout.Padding = UDim.new(0,10)
	Layout.Parent = Card

	local Title = Instance.new("TextLabel")
	Title.Size = UDim2.new(1,0,0,26)
	Title.BackgroundTransparency = 1
	Title.Font = Theme.FontBlack
	Title.Text = "NOMO AI"
	Title.TextSize = 19
	Title.TextColor3 = Theme.Text
	Title.TextXAlignment = Enum.TextXAlignment.Left
	Title.Parent = Card

	local Status = Instance.new("TextLabel")
	Status.Size = UDim2.new(1,0,0,20)
	Status.BackgroundTransparency = 1
	Status.Font = Theme.FontBold
	Status.Text = "● Online"
	Status.TextSize = 15
	Status.TextColor3 = Color3.fromRGB(0,220,120)
	Status.TextXAlignment = Enum.TextXAlignment.Left
	Status.Parent = Card

	local Output = Instance.new("TextLabel")
	Output.Size = UDim2.new(1,0,0,110)
	Output.BackgroundTransparency = 1
	Output.Font = Theme.Font
	Output.TextWrapped = true
	Output.TextXAlignment = Enum.TextXAlignment.Left
	Output.TextYAlignment = Enum.TextYAlignment.Top
	Output.TextSize = 15
	Output.TextColor3 = Theme.Text
	Output.Text =
		"Welcome back.\n\n" ..
		"The dashboard is online.\n" ..
		"All supported modules are ready.\n\n" ..
		"Select a category from the sidebar to begin."
	Output.Parent = Card

	local Hint = Instance.new("TextLabel")
	Hint.Size = UDim2.new(1,0,0,20)
	Hint.BackgroundTransparency = 1
	Hint.Font = Theme.Font
	Hint.Text = "Status updates will appear here."
	Hint.TextSize = 13
	Hint.TextColor3 = Theme.SubText
	Hint.TextXAlignment = Enum.TextXAlignment.Left
	Hint.Parent = Card

	function Card:SetMessage(Message)

		Output.Text = Message

	end

	return Card

end

return NOMOAI
]====],
        [ [====[Modules/Home/ServerStatus.lua]====] ] = [====[local ServerStatus = {}

function ServerStatus:Create(Parent, App)

	local Theme = App.Theme
	local Components = App.Components
	local Utilities = App.Utilities

	local Card = Components:CreateCard(
		Parent,
		UDim2.new(.33,-8,0,240)
	)

	local Padding = Instance.new("UIPadding")
	Padding.PaddingTop = UDim.new(0,18)
	Padding.PaddingBottom = UDim.new(0,18)
	Padding.PaddingLeft = UDim.new(0,18)
	Padding.PaddingRight = UDim.new(0,18)
	Padding.Parent = Card

	local Layout = Instance.new("UIListLayout")
	Layout.Padding = UDim.new(0,10)
	Layout.Parent = Card

	local Title = Instance.new("TextLabel")
	Title.Size = UDim2.new(1,0,0,26)
	Title.BackgroundTransparency = 1
	Title.Font = Theme.FontBlack
	Title.Text = "Server Status"
	Title.TextSize = 19
	Title.TextColor3 = Theme.Text
	Title.TextXAlignment = Enum.TextXAlignment.Left
	Title.Parent = Card

	local function CreateRow(Name, Value)

		local Row = Instance.new("Frame")
		Row.Size = UDim2.new(1,0,0,22)
		Row.BackgroundTransparency = 1
		Row.Parent = Card

		local Left = Instance.new("TextLabel")
		Left.Size = UDim2.new(.55,0,1,0)
		Left.BackgroundTransparency = 1
		Left.Font = Theme.Font
		Left.Text = Name
		Left.TextSize = 15
		Left.TextColor3 = Theme.SubText
		Left.TextXAlignment = Enum.TextXAlignment.Left
		Left.Parent = Row

		local Right = Instance.new("TextLabel")
		Right.AnchorPoint = Vector2.new(1,0)
		Right.Position = UDim2.new(1,0,0,0)
		Right.Size = UDim2.new(.45,0,1,0)
		Right.BackgroundTransparency = 1
		Right.Font = Theme.FontBold
		Right.Text = tostring(Value)
		Right.TextSize = 15
		Right.TextColor3 = Theme.Accent
		Right.TextXAlignment = Enum.TextXAlignment.Right
		Right.Parent = Row

		return Right

	end

	local FPS = CreateRow("FPS", Utilities:GetFPS())
	local Ping = CreateRow("Ping", Utilities:GetPing())
	local Players = CreateRow("Players", Utilities:GetPlayerCount())
	local Age = CreateRow("Server Age", Utilities:GetServerAge())

	task.spawn(function()

		while Card.Parent do

			task.wait(1)

			FPS.Text = tostring(Utilities:GetFPS())
			Ping.Text = tostring(Utilities:GetPing())
			Players.Text = tostring(Utilities:GetPlayerCount())
			Age.Text = tostring(Utilities:GetServerAge())

		end

	end)

	return Card

end

return ServerStatus
]====],
        [ [====[Modules/Home/StatusPanels.lua]====] ] = [====[--//========================================================--
--// SquidNoMo
--// 1.1 beta 1
--// Modules/Home/StatusPanels.lua
--//========================================================--

local UserInputService = game:GetService("UserInputService")

local StatusPanels = {}

local function createRow(App, card, iconName, labelText, valueText, y)
    local Theme = App.Theme

    local row = App:CreateFrame(card, UDim2.new(1, -32, 0, 29), UDim2.fromOffset(16, y), Theme.Row, {
        Radius = 7,
        StrokeColor = Theme.BorderSoft,
        StrokeTransparency = 0.50,
        ZIndex = 31,
    })

    local iconRoot = App:CreateFrame(row, UDim2.fromOffset(22, 22), UDim2.fromOffset(8, 3), Theme.Accent, {
        Transparency = 1,
        ZIndex = 33,
    })
    App.Icons:Create(iconRoot, iconName, 20, Theme.Text, 34)

    App:CreateText(row, labelText, UDim2.new(0.55, -38, 1, 0), UDim2.fromOffset(38, 0), {
        Font = Theme.FontMedium,
        TextSize = 13,
        Color = Theme.Text,
        ZIndex = 34,
    })

    local value = App:CreateText(row, valueText, UDim2.new(0.45, -12, 1, 0), UDim2.new(0.55, 0, 0, 0), {
        Font = Theme.FontMedium,
        TextSize = 13,
        Color = Theme.Accent,
        XAlignment = Enum.TextXAlignment.Right,
        ZIndex = 34,
    })

    return value
end

local function createTitle(App, card, iconName, title)
    local Theme = App.Theme

    local iconRoot = App:CreateFrame(card, UDim2.fromOffset(30, 30), UDim2.fromOffset(18, 10), Theme.Accent, {
        Transparency = 1,
        ZIndex = 33,
    })
    App.Icons:Create(iconRoot, iconName, 28, Theme.Accent, 34)

    App:CreateText(card, title, UDim2.new(1, -66, 0, 34), UDim2.fromOffset(54, 8), {
        Font = Theme.FontBlack,
        TextSize = 21,
        Color = Theme.Text,
        ZIndex = 34,
    })
end

function StatusPanels:Create(parent, App)
    local Theme = App.Theme

    local row = App:CreateFrame(parent, UDim2.new(1, 0, 0, 282), UDim2.fromOffset(0, 0), Theme.Background, {
        Transparency = 1,
        ZIndex = 20,
    })
    row.Name = "StatusPanels"

    local server = App:CreateCard(row, UDim2.new(0.5, -6, 1, 0), {
        Position = UDim2.fromOffset(0, 0),
        Color = Color3.fromRGB(8, 14, 11),
        StrokeColor = Theme.AccentDark,
        StrokeTransparency = 0.04,
        Radius = 15,
        ZIndex = 21,
    })

    local nomo = App:CreateCard(row, UDim2.new(0.5, -6, 1, 0), {
        Position = UDim2.new(0.5, 6, 0, 0),
        Color = Color3.fromRGB(8, 14, 11),
        StrokeColor = Theme.AccentDark,
        StrokeTransparency = 0.04,
        Radius = 15,
        ZIndex = 21,
    })

    createTitle(App, server, "Server", "SERVER STATS")
    createTitle(App, nomo, "Logo", "NOMO STATS")

    local serverValues = {}
    serverValues.Client = createRow(App, server, "UI", "Client", "--", 47)
    serverValues.FPS = createRow(App, server, "Stats", "FPS", "--", 79)
    serverValues.Ping = createRow(App, server, "Detective", "Ping", "--", 111)
    serverValues.ServerAge = createRow(App, server, "Calendar", "Server Age", "--", 143)
    serverValues.Uptime = createRow(App, server, "Calendar", "Uptime", "--", 175)
    serverValues.Connected = createRow(App, server, "Check", "Connected", "--", 207)
    serverValues.Players = createRow(App, server, "Players", "Players", "--", 239)

    local nomoValues = {}
    nomoValues.Status = createRow(App, nomo, "Check", "Status", "App Ready", 47)
    nomoValues.FeaturesLoaded = createRow(App, nomo, "Check", "Features Loaded", "0 / 0", 79)
    nomoValues.TouchSupport = createRow(App, nomo, "Touch", "Touch Support", UserInputService.TouchEnabled and "Enabled" or "Not Detected", 111)
    nomoValues.Errors = createRow(App, nomo, "Error", "Errors", "0", 143)
    nomoValues.LastUpdate = createRow(App, nomo, "Calendar", "Last Update", Theme.BuildDate, 175)
    nomoValues.BuildVersion = createRow(App, nomo, "Build", "Build Version", Theme.Version, 207)

    local function refresh()
        local snapshot = App.RuntimeStats:GetSnapshot()
        local summary = App.FeatureRegistry:GetSummary()

        serverValues.Client.Text = snapshot.Client
        serverValues.FPS.Text = snapshot.FPS
        serverValues.Ping.Text = snapshot.Ping
        serverValues.ServerAge.Text = snapshot.ServerAge
        serverValues.Uptime.Text = snapshot.Uptime
        serverValues.Connected.Text = snapshot.Connected
        serverValues.Players.Text = snapshot.Players

        nomoValues.Status.Text = "App Ready"
        nomoValues.FeaturesLoaded.Text = string.format("%d / %d", summary.loaded, summary.total)
        nomoValues.TouchSupport.Text = UserInputService.TouchEnabled and "Enabled" or "Not Detected"
        nomoValues.Errors.Text = tostring(App:GetErrorCount())
        nomoValues.LastUpdate.Text = Theme.BuildDate
        nomoValues.BuildVersion.Text = Theme.Version

        nomoValues.Errors.TextColor3 = App:GetErrorCount() > 0 and Theme.Warning or Theme.Accent
    end

    refresh()

    task.spawn(function()
        while row.Parent and App.Gui do
            task.wait(1.5)
            refresh()
        end
    end)

    return row
end

return StatusPanels
]====],
        [ [====[Modules/Home/SupportDevelopment.lua]====] ] = [====[local SupportDevelopment = {}

function SupportDevelopment:Create(Parent, App)

	local Theme = App.Theme
	local Components = App.Components

	local Card = Components:CreateCard(
		Parent,
		UDim2.new(.33,-8,0,190)
	)

	local Padding = Instance.new("UIPadding")
	Padding.PaddingTop = UDim.new(0,18)
	Padding.PaddingBottom = UDim.new(0,18)
	Padding.PaddingLeft = UDim.new(0,18)
	Padding.PaddingRight = UDim.new(0,18)
	Padding.Parent = Card

	local Layout = Instance.new("UIListLayout")
	Layout.Padding = UDim.new(0,12)
	Layout.Parent = Card

	local Title = Instance.new("TextLabel")
	Title.Size = UDim2.new(1,0,0,24)
	Title.BackgroundTransparency = 1
	Title.Font = Theme.FontBlack
	Title.Text = "Support Development"
	Title.TextSize = 19
	Title.TextColor3 = Theme.Text
	Title.TextXAlignment = Enum.TextXAlignment.Left
	Title.Parent = Card

	local Description = Instance.new("TextLabel")
	Description.Size = UDim2.new(1,0,0,55)
	Description.BackgroundTransparency = 1
	Description.Font = Theme.Font
	Description.TextWrapped = true
	Description.TextXAlignment = Enum.TextXAlignment.Left
	Description.TextYAlignment = Enum.TextYAlignment.Top
	Description.TextSize = 15
	Description.TextColor3 = Theme.Text
	Description.Text = "Support SquidNoMo to help fund future updates, maintenance and new features."
	Description.Parent = Card

	local Donate = Components:CreateButton(
		Card,
		"Support Project"
	)

	Donate.MouseButton1Click:Connect(function()

		print("Support Development Clicked")

	end)

	return Card

end

return SupportDevelopment
]====],
        [ [====[Modules/Home/Supporters.lua]====] ] = [====[local Supporters = {}

function Supporters:Create(Parent, App)

	local Theme = App.Theme
	local Components = App.Components

	local Card = Components:CreateCard(
		Parent,
		UDim2.new(.34,-8,0,210)
	)

	local Padding = Instance.new("UIPadding")
	Padding.PaddingTop = UDim.new(0,18)
	Padding.PaddingBottom = UDim.new(0,18)
	Padding.PaddingLeft = UDim.new(0,18)
	Padding.PaddingRight = UDim.new(0,18)
	Padding.Parent = Card

	local Layout = Instance.new("UIListLayout")
	Layout.Padding = UDim.new(0,8)
	Layout.Parent = Card

	local Title = Instance.new("TextLabel")
	Title.Size = UDim2.new(1,0,0,24)
	Title.BackgroundTransparency = 1
	Title.Font = Theme.FontBlack
	Title.Text = "Supporters"
	Title.TextSize = 19
	Title.TextColor3 = Theme.Text
	Title.TextXAlignment = Enum.TextXAlignment.Left
	Title.Parent = Card

	local Empty = Instance.new("TextLabel")
	Empty.Size = UDim2.new(1,0,0,22)
	Empty.BackgroundTransparency = 1
	Empty.Font = Theme.FontBold
	Empty.Text = "No supporters yet"
	Empty.TextSize = 15
	Empty.TextColor3 = Theme.Accent
	Empty.TextXAlignment = Enum.TextXAlignment.Left
	Empty.Parent = Card

	local List = Instance.new("Frame")
	List.Size = UDim2.new(1,0,0,100)
	List.BackgroundTransparency = 1
	List.Parent = Card

	local ListLayout = Instance.new("UIListLayout")
	ListLayout.Padding = UDim.new(0,6)
	ListLayout.Parent = List

	function Card:AddSupporter(Name)

		if Empty then
			Empty:Destroy()
			Empty = nil
		end

		local Label = Instance.new("TextLabel")
		Label.Size = UDim2.new(1,0,0,20)
		Label.BackgroundTransparency = 1
		Label.Font = Theme.Font
		Label.Text = "❤️  "..Name
		Label.TextSize = 14
		Label.TextColor3 = Theme.Text
		Label.TextXAlignment = Enum.TextXAlignment.Left
		Label.Parent = List

	end

	return Card

end

return Supporters
]====],
        [ [====[Modules/Players.lua]====] ] = [====[local PlayersPage = {}

local CATEGORIES = {
    {
        Name = "Movement & Camera",
        Short = "MOVE",
    },
    {
        Name = "Player ESP",
        Short = "ESP",
    },
    {
        Name = "Local Utilities",
        Short = "TOOLS",
    },
}

local function getFeature(App, id)
    local manager = App.FeatureManager
    local entry = manager
        and manager.Registry
        and manager.Registry[id]
    return entry and entry.Feature or nil
end

local function notify(App)
    if App.FeatureManager
        and type(App.FeatureManager.Notify)
            == "function"
    then
        App.FeatureManager:Notify()
    end
end

local function makeCorner(parent, radius)
    local corner = Instance.new("UICorner")
    corner.CornerRadius =
        UDim.new(0, radius or 12)
    corner.Parent = parent
end

local function createRoot(
    Page,
    App,
    topY,
    cardHeight
)
    local padding = App:GetUIStyleValue(
        "Players",
        "PagePadding",
        "MainPage"
    ) or App.Profile.ContentPadding

    local root = Instance.new("Frame")
    root.Name = "PlayerSubpageContent"
    root:SetAttribute(
        "SquidNoMoSubpage",
        true
    )
    root.Position =
        UDim2.fromOffset(padding, topY)
    root.Size = UDim2.new(
        1,
        -(padding * 2),
        0,
        10
    )
    root.BackgroundTransparency = 1
    root.BorderSizePixel = 0
    root.Active = false
    root.Selectable = false
    root.Parent = Page

    local grid = Instance.new("UIGridLayout")
    grid.SortOrder =
        Enum.SortOrder.LayoutOrder
    grid.CellPadding =
        UDim2.fromOffset(12, 12)
    grid.CellSize = UDim2.new(
        0.5,
        -6,
        0,
        cardHeight
    )
    grid.Parent = root

    -- Player cards contain interactive sliders/buttons, so we manage the canvas
    -- explicitly and keep the parent ScrollingFrame touch-active. This avoids the
    -- mobile case where child controls consume the gesture and the page never pans.
    Page.AutomaticCanvasSize = Enum.AutomaticSize.None
    Page.ScrollingDirection = Enum.ScrollingDirection.Y
    Page.ScrollingEnabled = true
    Page.Active = true
    Page.Selectable = false
    Page.ClipsDescendants = true
    Page.ElasticBehavior = Enum.ElasticBehavior.WhenScrollable
    Page.ScrollBarThickness = math.max(Page.ScrollBarThickness, App:IsMobile() and 10 or 6)
    Page.ScrollBarImageTransparency = App:IsMobile() and 0.05 or 0.18
    Page.ScrollBarImageColor3 = App:GetPageAccent("Players")

    local function updateCanvas()
        local height = math.max(
            cardHeight,
            grid.AbsoluteContentSize.Y
        )
        root.Size = UDim2.new(
            1,
            -(padding * 2),
            0,
            height
        )
        local viewport = math.max(0, Page.AbsoluteWindowSize.Y, Page.AbsoluteSize.Y)
        local bottomPadding = App:IsMobile() and 104 or 56
        local contentHeight = topY + height + bottomPadding
        Page.CanvasSize = UDim2.fromOffset(0, math.max(contentHeight, viewport + 2))
        Page.ScrollingEnabled = true
    end

    local connections = {}
    table.insert(connections, grid:GetPropertyChangedSignal(
        "AbsoluteContentSize"
    ):Connect(updateCanvas))
    table.insert(connections, Page:GetPropertyChangedSignal(
        "AbsoluteSize"
    ):Connect(updateCanvas))
    table.insert(connections, root:GetPropertyChangedSignal(
        "AbsoluteSize"
    ):Connect(updateCanvas))

    root.Destroying:Connect(function()
        for _, connection in ipairs(connections) do
            pcall(function() connection:Disconnect() end)
        end
    end)

    task.defer(updateCanvas)
    task.delay(0.08, updateCanvas)
    task.delay(0.25, updateCanvas)
    task.delay(0.60, updateCanvas)

    return root
end

local function createToggle(
    App,
    parent,
    title,
    description,
    accent,
    featureId,
    order
)
    local card = App:CreateCard(
        parent,
        UDim2.new(1, 0, 0, 132),
        {
            Color = App.Colors.CardAlt,
            BorderColor = accent,
            BorderTransparency = 0.18,
            Radius = 14,
        }
    )
    card.LayoutOrder = order

    App:CreateText(
        card,
        title,
        UDim2.new(1, -92, 0, 24),
        UDim2.fromOffset(14, 14),
        {
            Font = Enum.Font.GothamBold,
            TextSize =
                App:IsMobile() and 15 or 14,
            Color = App.Colors.Text,
            ZIndex = 1014,
        }
    )

    App:CreateText(
        card,
        description,
        UDim2.new(1, -98, 0, 58),
        UDim2.fromOffset(14, 44),
        {
            Font = Enum.Font.GothamMedium,
            TextSize =
                App:IsMobile() and 13 or 11,
            Color = App.Colors.Muted,
            Wrapped = true,
            YAlignment =
                Enum.TextYAlignment.Top,
            ZIndex = 1014,
        }
    )

    local button = Instance.new("TextButton")
    button.AnchorPoint = Vector2.new(1, 0)
    button.Position =
        UDim2.new(1, -14, 0, 14)
    button.Size = UDim2.fromOffset(58, 32)
    button.BackgroundColor3 =
        Color3.fromRGB(70, 66, 80)
    button.BorderSizePixel = 0
    button.AutoButtonColor = false
    button.Text = ""
    button.ZIndex = 1015
    button.Parent = card
    makeCorner(button, 999)

    local knob = Instance.new("Frame")
    knob.Size = UDim2.fromOffset(26, 26)
    knob.Position = UDim2.fromOffset(3, 3)
    knob.BackgroundColor3 =
        Color3.fromRGB(242, 239, 247)
    knob.BorderSizePixel = 0
    knob.ZIndex = 1016
    knob.Parent = button
    makeCorner(knob, 999)

    local feature =
        getFeature(App, featureId)

    local function isEnabled()
        if feature
            and type(feature.IsEnabled)
                == "function"
        then
            local ok, state = pcall(
                feature.IsEnabled,
                feature
            )
            return ok and state == true
        end

        return false
    end

    local function render()
        local enabled = isEnabled()
        button.BackgroundColor3 =
            enabled
            and accent
            or Color3.fromRGB(70, 66, 80)
        knob.Position = UDim2.fromOffset(
            enabled and 29 or 3,
            3
        )
    end

    button.Activated:Connect(function()
        local page = button:FindFirstAncestorWhichIsA("ScrollingFrame")
        if page and page:GetAttribute("SquidNoMoTouchDragging") then return end
        feature =
            feature
            or getFeature(App, featureId)

        if not feature then
            return
        end

        local method = isEnabled()
            and feature.Disable
            or feature.Enable

        if type(method) == "function" then
            local ok, result, detail =
                pcall(method, feature)
            if not ok or result == false then
                local message = not ok
                    and tostring(result)
                    or tostring(
                        detail
                        or "The feature rejected the toggle."
                    )
                warn(
                    "[SquidNoMo] "
                    .. title
                    .. " failed: "
                    .. message
                )
                if App.Notifications
                    and type(
                        App.Notifications.Error
                    ) == "function"
                then
                    App.Notifications:Error(
                        title,
                        message,
                        5
                    )
                end
            end
            notify(App)
            if type(App.QueueSettingsSave) == "function" then App:QueueSettingsSave() end
            render()
        end
    end)

    App:BindButtonFeedback(button, accent)
    render()
    return card
end

local function createSliderCard(
    App,
    parent,
    title,
    accent,
    featureId,
    minimum,
    maximum,
    defaultValue,
    order
)
    local card = App:CreateCard(
        parent,
        UDim2.new(1, 0, 0, 178),
        {
            Color = App.Colors.CardAlt,
            BorderColor = accent,
            BorderTransparency = 0.18,
            Radius = 14,
        }
    )
    card.LayoutOrder = order

    App:CreateText(
        card,
        title,
        UDim2.new(1, -86, 0, 24),
        UDim2.fromOffset(14, 14),
        {
            Font = Enum.Font.GothamBold,
            TextSize =
                App:IsMobile() and 15 or 14,
            Color = App.Colors.Text,
            ZIndex = 1014,
        }
    )

    local valueLabel = App:CreateText(
        card,
        tostring(defaultValue),
        UDim2.fromOffset(68, 24),
        UDim2.new(1, -82, 0, 14),
        {
            Font = Enum.Font.GothamBlack,
            TextSize =
                App:IsMobile() and 15 or 14,
            Color = accent,
            XAlignment =
                Enum.TextXAlignment.Right,
            ZIndex = 1014,
        }
    )

    local feature =
        getFeature(App, featureId)
    local current = defaultValue

    if feature
        and type(feature.Get) == "function"
    then
        local ok, value = pcall(
            feature.Get,
            feature
        )
        if ok
            and type(value) == "number"
        then
            current = value
        end
    end

    local controller

    local function applyValue(nextValue)
        current = math.clamp(
            math.floor(nextValue + 0.5),
            minimum,
            maximum
        )
        valueLabel.Text = tostring(current)

        feature =
            feature
            or getFeature(App, featureId)

        if feature
            and type(feature.Set)
                == "function"
        then
            pcall(
                feature.Set,
                feature,
                current
            )
            notify(App)
        end
    end

    controller = App:CreateSlider(card, {
        Position =
            UDim2.fromOffset(14, 50),
        Size =
            UDim2.new(1, -28, 0, 34),
        Min = minimum,
        Max = maximum,
        Value = current,
        AccentColor = accent,
        TrackHeight = 12,
        KnobSize = 28,
        OnChanged = applyValue,
    })

    local row = Instance.new("Frame")
    row.Position =
        UDim2.fromOffset(12, 104)
    row.Size =
        UDim2.new(1, -24, 0, 46)
    row.BackgroundTransparency = 1
    row.BorderSizePixel = 0
    row.Parent = card

    local layout =
        Instance.new("UIListLayout")
    layout.FillDirection =
        Enum.FillDirection.Horizontal
    layout.HorizontalAlignment =
        Enum.HorizontalAlignment.Center
    layout.VerticalAlignment =
        Enum.VerticalAlignment.Center
    layout.Padding = UDim.new(0, 6)
    layout.Parent = row

    for _, delta in ipairs({
        -10, -5, -1, 1, 5, 10,
    }) do
        local label = delta > 0
            and ("+" .. tostring(delta))
            or tostring(delta)

        local quick = App:CreateQuickButton(
            row,
            label,
            UDim2.fromOffset(48, 38),
            accent
        )

        quick.Activated:Connect(function()
            local page = quick:FindFirstAncestorWhichIsA("ScrollingFrame")
            if page and page:GetAttribute("SquidNoMoTouchDragging") then return end
            applyValue(current + delta)
            controller:SetValue(
                current,
                false
            )
        end)
    end

    controller:SetValue(current, false)
    return card
end

local function addColorSwatches(
    App,
    card,
    featureId,
    colors
)
    local row = Instance.new("Frame")
    row.Position =
        UDim2.fromOffset(14, 94)
    row.Size =
        UDim2.new(1, -28, 0, 26)
    row.BackgroundTransparency = 1
    row.Parent = card

    local layout =
        Instance.new("UIListLayout")
    layout.FillDirection =
        Enum.FillDirection.Horizontal
    layout.Padding = UDim.new(0, 10)
    layout.Parent = row

    local feature =
        getFeature(App, featureId)

    for _, color in ipairs(colors) do
        local swatch =
            Instance.new("TextButton")
        swatch.Size =
            UDim2.fromOffset(24, 24)
        swatch.BackgroundColor3 = color
        swatch.BorderSizePixel = 0
        swatch.AutoButtonColor = false
        swatch.Text = ""
        swatch.Parent = row
        makeCorner(swatch, 7)

        swatch.Activated:Connect(
            function()
                feature =
                    feature
                    or getFeature(
                        App,
                        featureId
                    )

                if feature
                    and type(
                        feature.SetColor
                    ) == "function"
                then
                    pcall(
                        feature.SetColor,
                        feature,
                        color
                    )
                    notify(App)
                end
            end
        )
    end
end

local function buildMovement(
    Page,
    App,
    topY
)
    local root =
        createRoot(Page, App, topY, 178)

    createSliderCard(
        App,
        root,
        "Walk Speed",
        Color3.fromRGB(0, 190, 255),
        "player.walk_speed",
        16,
        120,
        16,
        1
    )
    createSliderCard(
        App,
        root,
        "Jump Power",
        Color3.fromRGB(180, 76, 255),
        "player.jump_power",
        50,
        220,
        50,
        2
    )
    createSliderCard(
        App,
        root,
        "Gravity",
        Color3.fromRGB(255, 190, 58),
        "player.gravity",
        50,
        196,
        196,
        3
    )
    createToggle(
        App,
        root,
        "Infinite Jump",
        "Allows repeated jumps while airborne.",
        Color3.fromRGB(255, 88, 110),
        "player.infinite_jump",
        4
    )
    createToggle(
        App,
        root,
        "Auto Jump",
        "Automatically jumps while moving and grounded.",
        Color3.fromRGB(255, 140, 70),
        "player.auto_jump",
        5
    )
    createToggle(
        App,
        root,
        "Noclip",
        "Disables local character collision.",
        Color3.fromRGB(130, 110, 255),
        "player.noclip",
        6
    )
    createToggle(
        App,
        root,
        "Force Third Person",
        "Keeps the camera in a readable third-person range.",
        Color3.fromRGB(58, 210, 255),
        "player.force_third_person",
        7
    )
    createToggle(
        App,
        root,
        "Unlock Camera Zoom",
        "Raises the local maximum camera zoom distance.",
        Color3.fromRGB(255, 180, 70),
        "player.unlock_zoom",
        8
    )
    createToggle(
        App,
        root,
        "Auto Stand",
        "Recovers from sitting and platform-stand states.",
        Color3.fromRGB(80, 255, 150),
        "player.auto_stand",
        9
    )
end

local function buildESP(Page, App, topY)
    local root =
        createRoot(Page, App, topY, 132)

    local definitions = {
        {
            "Player ESP",
            "Highlights standard players.",
            Color3.fromRGB(0, 170, 255),
            "player.player_esp",
            {
                Color3.fromRGB(0, 170, 255),
                Color3.fromRGB(66, 255, 105),
                Color3.fromRGB(
                    255,
                    255,
                    255
                ),
            },
        },
        {
            "Guard ESP",
            "Highlights detected guards.",
            Color3.fromRGB(235, 55, 70),
            "player.guard_esp",
            {
                Color3.fromRGB(235, 55, 70),
                Color3.fromRGB(
                    255,
                    146,
                    54
                ),
                Color3.fromRGB(
                    255,
                    64,
                    164
                ),
            },
        },
        {
            "Detective ESP",
            "Highlights detected detectives.",
            Color3.fromRGB(0, 230, 150),
            "player.detective_esp",
            {
                Color3.fromRGB(
                    0,
                    230,
                    150
                ),
                Color3.fromRGB(
                    0,
                    198,
                    255
                ),
                Color3.fromRGB(
                    255,
                    214,
                    74
                ),
            },
        },
        {
            "Frontman ESP",
            "Highlights detected frontmen.",
            Color3.fromRGB(
                172,
                76,
                255
            ),
            "player.frontman_esp",
            {
                Color3.fromRGB(
                    172,
                    76,
                    255
                ),
                Color3.fromRGB(
                    225,
                    73,
                    255
                ),
                Color3.fromRGB(
                    240,
                    240,
                    255
                ),
            },
        },
        {
            "Distance ESP",
            "Displays distance information.",
            Color3.fromRGB(0, 205, 255),
            "player.distance_esp",
            {
                Color3.fromRGB(
                    0,
                    205,
                    255
                ),
                Color3.fromRGB(
                    90,
                    255,
                    210
                ),
                Color3.fromRGB(
                    255,
                    255,
                    255
                ),
            },
        },
        {
            "Health ESP",
            "Displays health information.",
            Color3.fromRGB(255, 82, 82),
            "player.health_esp",
            {
                Color3.fromRGB(
                    255,
                    82,
                    82
                ),
                Color3.fromRGB(
                    255,
                    172,
                    64
                ),
                Color3.fromRGB(
                    85,
                    255,
                    127
                ),
            },
        },
        {
            "Name ESP",
            "Displays player names above characters.",
            Color3.fromRGB(245, 245, 255),
            "player.name_esp",
            {
                Color3.fromRGB(245, 245, 255),
                Color3.fromRGB(80, 220, 255),
                Color3.fromRGB(255, 210, 70),
            },
        },
        {
            "Box ESP",
            "Draws an always-visible player outline.",
            Color3.fromRGB(255, 210, 70),
            "player.box_esp",
            {
                Color3.fromRGB(255, 210, 70),
                Color3.fromRGB(255, 82, 110),
                Color3.fromRGB(80, 255, 150),
            },
        },
    }

    for index, definition in ipairs(
        definitions
    ) do
        local card = createToggle(
            App,
            root,
            definition[1],
            definition[2],
            definition[3],
            definition[4],
            index
        )
        addColorSwatches(
            App,
            card,
            definition[4],
            definition[5]
        )
    end
end

local function buildUtilities(
    Page,
    App,
    topY
)
    local root =
        createRoot(Page, App, topY, 132)

    local definitions = {
        {
            "Anti AFK",
            "Prevents idle disconnects.",
            Color3.fromRGB(
                66,
                255,
                130
            ),
            "player.anti_afk",
        },
        {
            "Anti Lag",
            "Reduces expensive local effects.",
            Color3.fromRGB(
                0,
                170,
                255
            ),
            "player.anti_lag",
        },
        {
            "Hide Other Players",
            "Hides other characters locally.",
            Color3.fromRGB(
                188,
                84,
                255
            ),
            "player.hide_others",
        },
        {
            "Hide Local Character",
            "Hides your character locally.",
            Color3.fromRGB(
                255,
                159,
                67
            ),
            "player.hide_self",
        },
        {
            "Tool ESP",
            "Highlights tools and interactables.",
            Color3.fromRGB(
                255,
                210,
                60
            ),
            "player.tool_esp",
        },
        {
            "Auto Pick Up Baby",
            "Collects the nearby Baby objective when a supported pickup interaction appears.",
            Color3.fromRGB(
                255,
                132,
                190
            ),
            "player.auto_pickup_baby",
        },
        {
            "Mute Character Sounds",
            "Mutes character sounds locally.",
            Color3.fromRGB(
                100,
                200,
                255
            ),
            "player.mute_character_sounds",
        },
        {
            "Reset Character",
            "Requests one local character reset.",
            Color3.fromRGB(255, 105, 105),
            "player.reset",
        },
        {
            "Rejoin Server",
            "Requests a rejoin to the current server.",
            Color3.fromRGB(90, 205, 255),
            "player.rejoin",
        },
    }

    for index, definition in ipairs(
        definitions
    ) do
        createToggle(
            App,
            root,
            definition[1],
            definition[2],
            definition[3],
            definition[4],
            index
        )
    end
end

local function installTouchScrollFallback(Page, App)
    if type(App.InstallPageTouchScroll) == "function" then
        App:InstallPageTouchScroll(Page)
    end
end

function PlayersPage:Create(Page, App)
    installTouchScrollFallback(Page, App)
    Page.CanvasPosition = Vector2.zero

    local selected =
        App.Session.SelectedPlayerCategory
        or "Movement & Camera"

    local selector =
        App.Loader.CategoryStrip:Create(
            Page,
            App,
            {
                PageName = "Players",
                SessionKey =
                    "SelectedPlayerCategory",
                DefaultName =
                    "Movement & Camera",
                ScrollerName =
                    "PlayerCategoryScroller",
                ButtonWidth = 220,
                Items = CATEGORIES,
                OnSelected = function(item)
                    selected = item.Name
                    Page.CanvasPosition = Vector2.zero

                    local old =
                        Page:FindFirstChild(
                            "PlayerSubpageContent"
                        )
                    if old then
                        old:Destroy()
                    end

                    local selectorRoot =
                        Page:FindFirstChild(
                            "PlayersCategoryRoot"
                        )
                    local topY = 128

                    if selectorRoot then
                        topY =
                            selectorRoot
                                .Position.Y.Offset
                            + selectorRoot
                                .Size.Y.Offset
                            + 12
                    end

                    if item.Name
                        == "Movement & Camera"
                    then
                        buildMovement(
                            Page,
                            App,
                            topY
                        )
                    elseif item.Name
                        == "Player ESP"
                    then
                        buildESP(
                            Page,
                            App,
                            topY
                        )
                    else
                        buildUtilities(
                            Page,
                            App,
                            topY
                        )
                    end
                end,
            }
        )

    if selector and selector.Select then
        local index = 1

        for itemIndex, item in ipairs(
            CATEGORIES
        ) do
            if item.Name == selected then
                index = itemIndex
                break
            end
        end

        selector.Select(index)
    end
end

return PlayersPage
]====],
        [ [====[Modules/Players/ESP.lua]====] ] = [====[--//========================================================--
--// SquidNoMo
--// 1.1 beta 1
--// Players
--// ESP.lua
--//========================================================--

local ESP = {}

----------------------------------------------------------
-- Create
----------------------------------------------------------

function ESP:Create(Page, App)

	local Theme = App.Theme
	local Components = App.Components

	Page:ClearAllChildren()

	----------------------------------------------------------
	-- Layout
	----------------------------------------------------------

	local Layout = Instance.new("UIListLayout")

	Layout.FillDirection = Enum.FillDirection.Vertical
	Layout.HorizontalAlignment = Enum.HorizontalAlignment.Center
	Layout.SortOrder = Enum.SortOrder.LayoutOrder
	Layout.Padding = UDim.new(0,16)

	Layout.Parent = Page

	----------------------------------------------------------
	-- ESP Card
	----------------------------------------------------------

	local Card = Components:CreateCard(

		Page,
		Theme,
		UDim2.new(1,0,0,340)

	)

	Card.LayoutOrder = 1

	Components:CreateTitle(

		Card,
		Theme,
		"👁 Role ESP"

	)

	local Holder = Instance.new("Frame")

	Holder.BackgroundTransparency = 1

	Holder.Position = UDim2.fromOffset(20,55)

	Holder.Size = UDim2.new(1,-40,1,-75)

	Holder.Parent = Card

	local HolderLayout = Instance.new("UIListLayout")

	HolderLayout.Padding = UDim.new(0,12)

	HolderLayout.Parent = Holder

  	----------------------------------------------------------
	-- Player ESP
	----------------------------------------------------------

	local _, PlayerESP =
		Components:CreateToggle(

			Holder,
			Theme,
			"Player ESP"

		)

	PlayerESP:OnChanged(function(State)

		if App.Features
		and App.Features.Player
		and App.Features.Player.PlayerESP then

			if State then
				App.Features.Player.PlayerESP:Enable()
			else
				App.Features.Player.PlayerESP:Disable()
			end

		end

	end)

	----------------------------------------------------------
	-- Guard ESP
	----------------------------------------------------------

	local _, GuardESP =
		Components:CreateToggle(

			Holder,
			Theme,
			"Guard ESP"

		)

	GuardESP:OnChanged(function(State)

		if App.Features
		and App.Features.Player
		and App.Features.Player.GuardESP then

			if State then
				App.Features.Player.GuardESP:Enable()
			else
				App.Features.Player.GuardESP:Disable()
			end

		end

	end)

	----------------------------------------------------------
	-- Detective ESP
	----------------------------------------------------------

	local _, DetectiveESP =
		Components:CreateToggle(

			Holder,
			Theme,
			"Detective ESP"

		)

	DetectiveESP:OnChanged(function(State)

		if App.Features
		and App.Features.Player
		and App.Features.Player.DetectiveESP then

			if State then
				App.Features.Player.DetectiveESP:Enable()
			else
				App.Features.Player.DetectiveESP:Disable()
			end

		end

	end)

  	----------------------------------------------------------
	-- Frontman ESP
	----------------------------------------------------------

	local _, FrontmanESP =
		Components:CreateToggle(

			Holder,
			Theme,
			"Frontman ESP"

		)

	FrontmanESP:OnChanged(function(State)

		if App.Features
		and App.Features.Player
		and App.Features.Player.FrontmanESP then

			if State then
				App.Features.Player.FrontmanESP:Enable()
			else
				App.Features.Player.FrontmanESP:Disable()
			end

		end

	end)

	----------------------------------------------------------
	-- Finished
	----------------------------------------------------------

end

----------------------------------------------------------
-- Return Module
----------------------------------------------------------

return ESP
]====],
        [ [====[Modules/Players/Enhancements.lua]====] ] = [====[--//========================================================--
--// SquidNoMo
--// 1.1 beta 1
--// Players
--// Enhancements.lua
--//========================================================--

local Enhancements = {}

----------------------------------------------------------
-- Create
----------------------------------------------------------

function Enhancements:Create(Page, App)

	local Theme = App.Theme
	local Components = App.Components

	Page:ClearAllChildren()

	----------------------------------------------------------
	-- Layout
	----------------------------------------------------------

	local Layout = Instance.new("UIListLayout")

	Layout.FillDirection = Enum.FillDirection.Vertical
	Layout.HorizontalAlignment = Enum.HorizontalAlignment.Center
	Layout.SortOrder = Enum.SortOrder.LayoutOrder
	Layout.Padding = UDim.new(0,16)

	Layout.Parent = Page

	----------------------------------------------------------
	-- Enhancement Card
	----------------------------------------------------------

	local Card = Components:CreateCard(

		Page,
		Theme,
		UDim2.new(1,0,0,340)

	)

	Card.LayoutOrder = 1

	Components:CreateTitle(

		Card,
		Theme,
		"✨ Player Enhancements"

	)

	local Holder = Instance.new("Frame")

	Holder.BackgroundTransparency = 1

	Holder.Position = UDim2.fromOffset(20,55)

	Holder.Size = UDim2.new(1,-40,1,-75)

	Holder.Parent = Card

	local HolderLayout = Instance.new("UIListLayout")

	HolderLayout.Padding = UDim.new(0,12)

	HolderLayout.Parent = Holder

  	----------------------------------------------------------
	-- Walk Speed
	----------------------------------------------------------

	local _, WalkSpeed =
		Components:CreateSlider(

			Holder,
			Theme,
			"Walk Speed",
			16,
			100,
			16

		)

	WalkSpeed:OnChanged(function(Value)

		if App.Features
		and App.Features.Player
		and App.Features.Player.WalkSpeed then

			App.Features.Player.WalkSpeed:Set(Value)

		end

	end)

	----------------------------------------------------------
	-- Jump Power
	----------------------------------------------------------

	local _, JumpPower =
		Components:CreateSlider(

			Holder,
			Theme,
			"Jump Power",
			50,
			200,
			50

		)

	JumpPower:OnChanged(function(Value)

		if App.Features
		and App.Features.Player
		and App.Features.Player.JumpPower then

			App.Features.Player.JumpPower:Set(Value)

		end

	end)

  	----------------------------------------------------------
	-- Infinite Jump
	----------------------------------------------------------

	local _, InfiniteJump =
		Components:CreateToggle(

			Holder,
			Theme,
			"Infinite Jump"

		)

	InfiniteJump:OnChanged(function(State)

		if App.Features
		and App.Features.Player
		and App.Features.Player.InfiniteJump then

			if State then
				App.Features.Player.InfiniteJump:Enable()
			else
				App.Features.Player.InfiniteJump:Disable()
			end

		end

	end)

	----------------------------------------------------------
	-- Noclip
	----------------------------------------------------------

	local _, Noclip =
		Components:CreateToggle(

			Holder,
			Theme,
			"Noclip"

		)

	Noclip:OnChanged(function(State)

		if App.Features
		and App.Features.Player
		and App.Features.Player.Noclip then

			if State then
				App.Features.Player.Noclip:Enable()
			else
				App.Features.Player.Noclip:Disable()
			end

		end

	end)

	----------------------------------------------------------
	-- Finished
	----------------------------------------------------------

end

return Enhancements
]====],
        [ [====[Modules/Players/Main.lua]====] ] = [====[--//========================================================--
--// SquidNoMo
--// 1.1 beta 1
--// Players
--// Main.lua
--//========================================================--

local PlayersMain = {}

----------------------------------------------------------
-- Create
----------------------------------------------------------

function PlayersMain:Create(Page, App)

	local Theme = App.Theme
	local Components = App.Components

	Page:ClearAllChildren()

	----------------------------------------------------------
	-- Main Layout
	----------------------------------------------------------

	local Layout = Instance.new("UIListLayout")

	Layout.FillDirection = Enum.FillDirection.Vertical
	Layout.HorizontalAlignment = Enum.HorizontalAlignment.Center
	Layout.SortOrder = Enum.SortOrder.LayoutOrder
	Layout.Padding = UDim.new(0,16)

	Layout.Parent = Page

	----------------------------------------------------------
	-- Top Navigation Card
	----------------------------------------------------------

	local NavCard = Components:CreateCard(

		Page,
		Theme,
		UDim2.new(1,0,0,64)

	)

	NavCard.LayoutOrder = 1

	----------------------------------------------------------
	-- Navigation Container
	----------------------------------------------------------

	local NavContainer = Instance.new("Frame")

	NavContainer.Name = "Navigation"

	NavContainer.BackgroundTransparency = 1

	NavContainer.Size = UDim2.new(1,-24,1,-16)

	NavContainer.Position = UDim2.fromOffset(12,8)

	NavContainer.Parent = NavCard

	local NavLayout = Instance.new("UIListLayout")

	NavLayout.FillDirection = Enum.FillDirection.Horizontal

	NavLayout.HorizontalAlignment = Enum.HorizontalAlignment.Left

	NavLayout.VerticalAlignment = Enum.VerticalAlignment.Center

	NavLayout.Padding = UDim.new(0,14)

	NavLayout.Parent = NavContainer

	----------------------------------------------------------
	-- Content Area
	----------------------------------------------------------

	local Content = Instance.new("Frame")

	Content.Name = "Content"

	Content.BackgroundTransparency = 1

	Content.Size = UDim2.new(1,0,1,-80)

	Content.AutomaticSize = Enum.AutomaticSize.Y

	Content.LayoutOrder = 2

	Content.Parent = Page

	self.Content = Content
	self.NavContainer = NavContainer

  	----------------------------------------------------------
	-- Navigation Buttons
	----------------------------------------------------------

	local CurrentTab

	local Buttons = {}

	local function CreateTab(Name, Icon)

		local Button = Instance.new("TextButton")

		Button.Name = Name

		Button.Size = UDim2.fromOffset(170,44)

		Button.BackgroundColor3 = Theme.Card

		Button.BorderSizePixel = 0

		Button.AutoButtonColor = false

		Button.Font = Theme.FontBold

		Button.TextSize = 16

		Button.Text = Icon .. "  " .. Name

		Button.TextColor3 = Theme.Text

		Button.Parent = NavContainer

		local Corner = Instance.new("UICorner")

		Corner.CornerRadius = UDim.new(0,12)

		Corner.Parent = Button

		Buttons[Name] = Button

		return Button

	end

	local EnhancementsButton =
		CreateTab("Enhancements","✨")

	local ESPButton =
		CreateTab("ESP","👁")

	local UtilitiesButton =
		CreateTab("Utilities","🛠")

  	----------------------------------------------------------
	-- Page Loader
	----------------------------------------------------------

	local CurrentPage

	local function ClearPage()

		if CurrentPage then

			CurrentPage:Destroy()

			CurrentPage = nil

		end

	end

	local function SelectTab(Name)

		CurrentTab = Name

		for TabName, Button in pairs(Buttons) do

			if TabName == Name then

				Button.BackgroundColor3 = Theme.Accent
				Button.TextColor3 = Theme.Background

			else

				Button.BackgroundColor3 = Theme.Card
				Button.TextColor3 = Theme.Text

			end

		end

		ClearPage()

		CurrentPage = Instance.new("Frame")

		CurrentPage.Name = Name

		CurrentPage.BackgroundTransparency = 1

		CurrentPage.Size = UDim2.fromScale(1,1)

		CurrentPage.Parent = Content

		if Name == "Enhancements" then

			local Module = loadstring(game:HttpGet(

				App.Config.Repository ..
				"Modules/Players/Enhancements.lua"

			))()

			Module:Create(CurrentPage, App)

		elseif Name == "ESP" then

			local Module = loadstring(game:HttpGet(

				App.Config.Repository ..
				"Modules/Players/ESP.lua"

			))()

			Module:Create(CurrentPage, App)

		elseif Name == "Utilities" then

			local Module = loadstring(game:HttpGet(

				App.Config.Repository ..
				"Modules/Players/Utilities.lua"

			))()

			Module:Create(CurrentPage, App)

		end

  end
	----------------------------------------------------------
	-- Navigation Events
	----------------------------------------------------------

	EnhancementsButton.MouseButton1Click:Connect(function()

		SelectTab("Enhancements")

	end)

	ESPButton.MouseButton1Click:Connect(function()

		SelectTab("ESP")

	end)

	UtilitiesButton.MouseButton1Click:Connect(function()

		SelectTab("Utilities")

	end)

	----------------------------------------------------------
	-- Default Page
	----------------------------------------------------------

	SelectTab("Enhancements")

end

----------------------------------------------------------
-- Return Module
----------------------------------------------------------

return PlayersMain
  
]====],
        [ [====[Modules/Players/Utilities.lua]====] ] = [====[--//========================================================--
--// SquidNoMo
--// 1.1 beta 1
--// Players
--// Utilities.lua
--//========================================================--

local Utilities = {}

----------------------------------------------------------
-- Create
----------------------------------------------------------

function Utilities:Create(Page, App)

	local Theme = App.Theme
	local Components = App.Components

	Page:ClearAllChildren()

	----------------------------------------------------------
	-- Layout
	----------------------------------------------------------

	local Layout = Instance.new("UIListLayout")

	Layout.FillDirection = Enum.FillDirection.Vertical
	Layout.HorizontalAlignment = Enum.HorizontalAlignment.Center
	Layout.SortOrder = Enum.SortOrder.LayoutOrder
	Layout.Padding = UDim.new(0,16)

	Layout.Parent = Page

	----------------------------------------------------------
	-- Utilities Card
	----------------------------------------------------------

	local Card = Components:CreateCard(

		Page,
		Theme,
		UDim2.new(1,0,0,340)

	)

	Card.LayoutOrder = 1

	Components:CreateTitle(

		Card,
		Theme,
		"🛠 Player Utilities"

	)

	local Holder = Instance.new("Frame")

	Holder.BackgroundTransparency = 1

	Holder.Position = UDim2.fromOffset(20,55)

	Holder.Size = UDim2.new(1,-40,1,-75)

	Holder.Parent = Card

	local HolderLayout = Instance.new("UIListLayout")

	HolderLayout.Padding = UDim.new(0,12)

	HolderLayout.Parent = Holder

  	----------------------------------------------------------
	-- Anti AFK
	----------------------------------------------------------

	local _, AntiAFK =
		Components:CreateToggle(

			Holder,
			Theme,
			"Anti AFK"

		)

	AntiAFK:OnChanged(function(State)

		if App.Features
		and App.Features.Player
		and App.Features.Player.AntiAFK then

			if State then
				App.Features.Player.AntiAFK:Enable()
			else
				App.Features.Player.AntiAFK:Disable()
			end

		end

	end)

	----------------------------------------------------------
	-- Anti Lag
	----------------------------------------------------------

	local _, AntiLag =
		Components:CreateToggle(

			Holder,
			Theme,
			"Anti Lag"

		)

	AntiLag:OnChanged(function(State)

		if App.Features
		and App.Features.Player
		and App.Features.Player.AntiLag then

			if State then
				App.Features.Player.AntiLag:Enable()
			else
				App.Features.Player.AntiLag:Disable()
			end

		end

	end)

  	----------------------------------------------------------
	-- Reset Character
	----------------------------------------------------------

	local ResetButton =
		Components:CreateButton(

			Holder,
			Theme,
			"🔄 Reset Character"

		)

	ResetButton.MouseButton1Click:Connect(function()

		if App.Features
		and App.Features.Player
		and App.Features.Player.Reset then

			App.Features.Player.Reset:Execute()

		end

	end)

	----------------------------------------------------------
	-- Rejoin Server
	----------------------------------------------------------

	local RejoinButton =
		Components:CreateButton(

			Holder,
			Theme,
			"🌐 Rejoin Server"

		)

	RejoinButton.MouseButton1Click:Connect(function()

		if App.Features
		and App.Features.Player
		and App.Features.Player.Rejoin then

			App.Features.Player.Rejoin:Execute()

		end

	end)

	----------------------------------------------------------
	-- Finished
	----------------------------------------------------------

end

----------------------------------------------------------
-- Return Module
----------------------------------------------------------

return Utilities
]====],
        [ [====[Modules/Settings.lua]====] ] = [====[local Settings = {}

function Settings:Create(Page, App)
    App:BuildComingSoonPage(
        Page,
        "Settings",
        "General app settings, persistence, and diagnostics will be organized here."
    )
end

return Settings
]====],
        [ [====[Modules/UI.lua]====] ] = [====[local UIPage = {}

local UserInputService = game:GetService('UserInputService')

local CATEGORIES = {
    {Name = 'Layout & Scale', Short = 'LAYOUT'},
    {Name = 'Themes & Colors', Short = 'THEME'},
    {Name = 'Buttons & Effects', Short = 'STYLE'},
}

local PAGE_NAMES = {
    'Home',
    'Games',
    'Players',
    'Guards',
    'Detective',
    'Farming',
    'UI',
    'Settings',
}

local function corner(parent, radius)
    local value = Instance.new('UICorner')
    value.CornerRadius = UDim.new(0, radius or 12)
    value.Parent = parent
    return value
end

local function stroke(parent, color, thickness, transparency)
    local value = Instance.new('UIStroke')
    value.Color = color
    value.Thickness = thickness or 1
    value.Transparency = transparency or 0
    value.Parent = parent
    return value
end

local function formatNumber(value, suffix, decimals)
    decimals = decimals or 0
    local multiplier = 10 ^ decimals
    local rounded = math.floor(value * multiplier + 0.5)
        / multiplier
    return tostring(rounded) .. (suffix or '')
end

local function createColumn(App, row, title, subtitle, accent, order)
    local card = App:CreateCard(
        row,
        UDim2.new(0.333333, -8, 1, 0),
        {
            Color = App.Colors.Card,
            BorderColor = accent,
            BorderTransparency = 0.12,
            Radius = App:GetUIStyleValue(
                'UI',
                'CardRadius',
                'MainPage'
            ),
        }
    )
    card.LayoutOrder = order
    card.ClipsDescendants = true

    App:CreateText(
        card,
        title,
        UDim2.new(1, -28, 0, 25),
        UDim2.fromOffset(14, 12),
        {
            Font = Enum.Font.GothamBlack,
            TextSize = App:IsMobile() and 15 or 18,
            Color = accent,
            ZIndex = 1013,
        }
    )

    App:CreateText(
        card,
        subtitle,
        UDim2.new(1, -28, 0, 40),
        UDim2.fromOffset(14, 39),
        {
            Font = Enum.Font.GothamMedium,
            TextSize = App:IsMobile() and 10 or 11,
            Color = App.Colors.Text,
            Wrapped = true,
            YAlignment = Enum.TextYAlignment.Top,
            ZIndex = 1013,
        }
    )

    local holder = Instance.new('ScrollingFrame')
    holder.Name = title .. 'Controls'
    holder.Position = UDim2.fromOffset(12, 88)
    holder.Size = UDim2.new(1, -24, 1, -100)
    holder.BackgroundTransparency = 1
    holder.BorderSizePixel = 0
    holder.CanvasSize = UDim2.fromOffset(0, 0)
    holder.AutomaticCanvasSize = Enum.AutomaticSize.Y
    holder.ScrollBarThickness = App:GetUIStyleValue(
        'UI',
        'ScrollbarThickness',
        'MainPage'
    )
    holder.ScrollBarImageColor3 = accent
    holder.ScrollingDirection = Enum.ScrollingDirection.Y
    holder.ElasticBehavior = Enum.ElasticBehavior.WhenScrollable
    holder.Active = true
    holder.ZIndex = 1012
    holder.Parent = card

    local layout = Instance.new('UIListLayout')
    layout.FillDirection = Enum.FillDirection.Vertical
    layout.HorizontalAlignment = Enum.HorizontalAlignment.Center
    layout.SortOrder = Enum.SortOrder.LayoutOrder
    layout.Padding = UDim.new(0, 10)
    layout.Parent = holder

    local padding = Instance.new('UIPadding')
    padding.PaddingBottom = UDim.new(0, 10)
    padding.Parent = holder

    return holder
end

local function createTouchSlider(
    App,
    parent,
    config,
    getValue,
    setValue,
    order
)
    local accent = config.Accent or App:GetPageAccent('UI')
    local minimum = config.Minimum
    local maximum = config.Maximum
    local step = config.Step or 1
    local row = App:CreateCard(
        parent,
        UDim2.new(1, 0, 0, 142),
        {
            Color = App.Colors.CardAlt,
            BorderColor = accent,
            BorderTransparency = 0.66,
            Radius = 11,
        }
    )
    row.LayoutOrder = order

    App:CreateText(
        row,
        config.Title,
        UDim2.new(1, -98, 0, 22),
        UDim2.fromOffset(12, 9),
        {
            Font = Enum.Font.GothamBold,
            TextSize = App:IsMobile() and 12 or 13,
            Color = App.Colors.Text,
            ZIndex = 1014,
        }
    )

    local valueLabel = App:CreateText(
        row,
        '',
        UDim2.fromOffset(82, 22),
        UDim2.new(1, -94, 0, 9),
        {
            Font = Enum.Font.GothamBlack,
            TextSize = App:IsMobile() and 12 or 13,
            Color = accent,
            XAlignment = Enum.TextXAlignment.Right,
            ZIndex = 1014,
        }
    )

    local track = Instance.new('Frame')
    track.Position = UDim2.fromOffset(14, 47)
    track.Size = UDim2.new(1, -28, 0, 10)
    track.BackgroundColor3 = Color3.fromRGB(61, 54, 70)
    track.BorderSizePixel = 0
    track.ZIndex = 1014
    track.Parent = row
    corner(track, 999)

    local fill = Instance.new('Frame')
    fill.Size = UDim2.new(0, 0, 1, 0)
    fill.BackgroundColor3 = accent
    fill.BorderSizePixel = 0
    fill.ZIndex = 1015
    fill.Parent = track
    corner(fill, 999)

    local knob = Instance.new('Frame')
    knob.AnchorPoint = Vector2.new(0.5, 0.5)
    knob.Position = UDim2.new(0, 0, 0.5, 0)
    knob.Size = UDim2.fromOffset(24, 24)
    knob.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    knob.BorderSizePixel = 0
    knob.ZIndex = 1016
    knob.Parent = track
    corner(knob, 999)
    stroke(knob, accent, 2, 0.04)

    local hitbox = Instance.new('TextButton')
    hitbox.Position = UDim2.fromOffset(0, -18)
    hitbox.Size = UDim2.new(1, 0, 0, 46)
    hitbox.BackgroundTransparency = 1
    hitbox.BorderSizePixel = 0
    hitbox.AutoButtonColor = false
    hitbox.Text = ''
    hitbox.ZIndex = 1017
    hitbox.Parent = track

    local quickRow = Instance.new('Frame')
    quickRow.Position = UDim2.fromOffset(10, 82)
    quickRow.Size = UDim2.new(1, -20, 0, 46)
    quickRow.BackgroundTransparency = 1
    quickRow.BorderSizePixel = 0
    quickRow.ZIndex = 1014
    quickRow.Parent = row

    local quickLayout = Instance.new('UIListLayout')
    quickLayout.FillDirection = Enum.FillDirection.Horizontal
    quickLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
    quickLayout.VerticalAlignment = Enum.VerticalAlignment.Center
    quickLayout.SortOrder = Enum.SortOrder.LayoutOrder
    quickLayout.Padding = UDim.new(0, 5)
    quickLayout.Parent = quickRow

    local value = tonumber(getValue()) or minimum
    local dragging = false

    local function format(valueToFormat)
        if type(config.Formatter) == 'function' then
            return config.Formatter(valueToFormat)
        end
        return formatNumber(valueToFormat)
    end

    local function render(newValue)
        value = math.clamp(
            tonumber(newValue) or minimum,
            minimum,
            maximum
        )
        local alpha = (value - minimum)
            / math.max(0.0001, maximum - minimum)
        fill.Size = UDim2.new(alpha, 0, 1, 0)
        knob.Position = UDim2.new(alpha, 0, 0.5, 0)
        valueLabel.Text = format(value)
    end

    local function commit(newValue)
        local stepped = math.floor(
            ((newValue - minimum) / step) + 0.5
        ) * step + minimum
        stepped = math.clamp(stepped, minimum, maximum)
        setValue(stepped)
        render(stepped)
    end

    local function updateFromInput(input)
        local width = math.max(1, track.AbsoluteSize.X)
        local alpha = math.clamp(
            (input.Position.X - track.AbsolutePosition.X)
                / width,
            0,
            1
        )
        commit(minimum + ((maximum - minimum) * alpha))
    end

    App:Track(hitbox.InputBegan:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1
            or input.UserInputType == Enum.UserInputType.Touch
        then
            dragging = true
            updateFromInput(input)
        end
    end))

    App:Track(hitbox.InputEnded:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1
            or input.UserInputType == Enum.UserInputType.Touch
        then
            dragging = false
        end
    end))

    App:Track(UserInputService.InputChanged:Connect(function(input)
        if dragging and (
            input.UserInputType
                == Enum.UserInputType.MouseMovement
            or input.UserInputType
                == Enum.UserInputType.Touch
        ) then
            updateFromInput(input)
        end
    end))

    local adjustments = {-10, -5, -1, 1, 5, 10}
    for index, amount in ipairs(adjustments) do
        local button = Instance.new('TextButton')
        button.Size = UDim2.new(0.166667, -5, 1, 0)
        button.BackgroundColor3 = App.Colors.Card
        button.BackgroundTransparency = 0.12
        button.BorderSizePixel = 0
        button.AutoButtonColor = false
        button.Font = Enum.Font.GothamBlack
        button.Text = amount > 0
            and ('+' .. tostring(amount))
            or tostring(amount)
        button.TextSize = App:IsMobile() and 11 or 12
        button.TextColor3 = App.Colors.Text
        button.LayoutOrder = index
        button.ZIndex = 1015
        button.Parent = quickRow
        corner(button, 9)
        stroke(button, accent, 1, 0.34)
        App:BindButtonFeedback(button, accent)

        local held = false
        local function adjust()
            commit(value + (amount * step))
        end

        App:Track(button.InputBegan:Connect(function(input)
            if input.UserInputType
                    ~= Enum.UserInputType.MouseButton1
                and input.UserInputType
                    ~= Enum.UserInputType.Touch
            then
                return
            end

            held = true
            adjust()
            task.delay(0.38, function()
                while held and button.Parent do
                    task.wait(0.12)
                    if held then
                        adjust()
                    end
                end
            end)
        end))

        App:Track(button.InputEnded:Connect(function(input)
            if input.UserInputType
                    == Enum.UserInputType.MouseButton1
                or input.UserInputType
                    == Enum.UserInputType.Touch
            then
                held = false
            end
        end))
    end

    render(value)
    return {Render = render}
end

local function createToggle(
    App,
    parent,
    title,
    description,
    accent,
    getter,
    setter,
    order
)
    local row = App:CreateCard(
        parent,
        UDim2.new(1, 0, 0, 90),
        {
            Color = App.Colors.CardAlt,
            BorderColor = accent,
            BorderTransparency = 0.66,
            Radius = 11,
        }
    )
    row.LayoutOrder = order

    App:CreateText(
        row,
        title,
        UDim2.new(1, -92, 0, 22),
        UDim2.fromOffset(12, 10),
        {
            Font = Enum.Font.GothamBold,
            TextSize = App:IsMobile() and 12 or 13,
            Color = App.Colors.Text,
            ZIndex = 1014,
        }
    )

    App:CreateText(
        row,
        description,
        UDim2.new(1, -104, 0, 40),
        UDim2.fromOffset(12, 35),
        {
            Font = Enum.Font.GothamMedium,
            TextSize = App:IsMobile() and 9 or 10,
            Color = App.Colors.Muted,
            Wrapped = true,
            YAlignment = Enum.TextYAlignment.Top,
            ZIndex = 1014,
        }
    )

    local switch = Instance.new('Frame')
    switch.AnchorPoint = Vector2.new(1, 0.5)
    switch.Position = UDim2.new(1, -12, 0.5, 0)
    switch.Size = UDim2.fromOffset(56, 32)
    switch.BackgroundColor3 = Color3.fromRGB(68, 64, 78)
    switch.BorderSizePixel = 0
    switch.ZIndex = 1015
    switch.Parent = row
    corner(switch, 999)

    local knob = Instance.new('Frame')
    knob.Position = UDim2.fromOffset(3, 3)
    knob.Size = UDim2.fromOffset(26, 26)
    knob.BackgroundColor3 = Color3.fromRGB(248, 246, 250)
    knob.BorderSizePixel = 0
    knob.ZIndex = 1016
    knob.Parent = switch
    corner(knob, 999)

    local button = Instance.new('TextButton')
    button.Size = UDim2.fromScale(1, 1)
    button.BackgroundTransparency = 1
    button.BorderSizePixel = 0
    button.AutoButtonColor = false
    button.Text = ''
    button.ZIndex = 1017
    button.Parent = row
    App:BindButtonFeedback(button, accent)

    local function render()
        local enabled = getter() == true
        switch.BackgroundColor3 = enabled
            and accent
            or Color3.fromRGB(68, 64, 78)
        knob.Position = UDim2.fromOffset(
            enabled and 27 or 3,
            3
        )
    end

    button.Activated:Connect(function()
        setter(not getter())
        render()
    end)

    render()
end

local function createChoice(
    App,
    parent,
    title,
    choices,
    accent,
    getter,
    setter,
    order
)
    local row = App:CreateCard(
        parent,
        UDim2.new(1, 0, 0, 106),
        {
            Color = App.Colors.CardAlt,
            BorderColor = accent,
            BorderTransparency = 0.66,
            Radius = 11,
        }
    )
    row.LayoutOrder = order

    App:CreateText(
        row,
        title,
        UDim2.new(1, -24, 0, 22),
        UDim2.fromOffset(12, 9),
        {
            Font = Enum.Font.GothamBold,
            TextSize = App:IsMobile() and 12 or 13,
            Color = App.Colors.Text,
            ZIndex = 1014,
        }
    )

    local holder = Instance.new('ScrollingFrame')
    holder.Position = UDim2.fromOffset(10, 43)
    holder.Size = UDim2.new(1, -20, 0, 50)
    holder.BackgroundTransparency = 1
    holder.BorderSizePixel = 0
    holder.CanvasSize = UDim2.fromOffset(0, 0)
    holder.AutomaticCanvasSize = Enum.AutomaticSize.X
    holder.ScrollingDirection = Enum.ScrollingDirection.X
    holder.ScrollBarThickness = 3
    holder.ScrollBarImageColor3 = accent
    holder.Active = true
    holder.ZIndex = 1014
    holder.Parent = row

    local layout = Instance.new('UIListLayout')
    layout.FillDirection = Enum.FillDirection.Horizontal
    layout.HorizontalAlignment = Enum.HorizontalAlignment.Left
    layout.VerticalAlignment = Enum.VerticalAlignment.Top
    layout.SortOrder = Enum.SortOrder.LayoutOrder
    layout.Padding = UDim.new(0, 6)
    layout.Parent = holder

    local refs = {}
    local function render()
        local selectedValue = getter()
        for _, ref in ipairs(refs) do
            local selected = ref.Value == selectedValue
            ref.Button.BackgroundColor3 = selected
                and accent
                or App.Colors.Card
            ref.Button.BackgroundTransparency = selected
                and 0.08
                or 0.24
            ref.Stroke.Transparency = selected
                and 0.02
                or 0.55
            ref.Stroke.Thickness = selected and 2 or 1
        end
    end

    for index, choice in ipairs(choices) do
        local button = Instance.new('TextButton')
        button.Size = UDim2.fromOffset(
            math.clamp(80 + (#choice * 4), 96, 152),
            42
        )
        button.BackgroundColor3 = App.Colors.Card
        button.BackgroundTransparency = 0.24
        button.BorderSizePixel = 0
        button.AutoButtonColor = false
        button.Font = Enum.Font.GothamBold
        button.Text = choice
        button.TextSize = App:IsMobile() and 10 or 11
        button.TextColor3 = App.Colors.Text
        button.LayoutOrder = index
        button.ZIndex = 1015
        button.Parent = holder
        corner(button, 9)
        local outline = stroke(button, accent, 1, 0.55)
        App:BindButtonFeedback(button, accent)

        button.Activated:Connect(function()
            setter(choice)
            render()
        end)

        table.insert(refs, {
            Button = button,
            Stroke = outline,
            Value = choice,
        })
    end

    render()
end

local function createPresetGrid(
    App,
    parent,
    manager,
    draft,
    accent,
    rerender,
    order
)
    local row = App:CreateCard(
        parent,
        UDim2.new(1, 0, 0, 250),
        {
            Color = App.Colors.CardAlt,
            BorderColor = accent,
            BorderTransparency = 0.66,
            Radius = 11,
        }
    )
    row.LayoutOrder = order

    App:CreateText(
        row,
        'THEME PRESETS',
        UDim2.new(1, -24, 0, 22),
        UDim2.fromOffset(12, 10),
        {
            Font = Enum.Font.GothamBlack,
            TextSize = App:IsMobile() and 12 or 13,
            Color = accent,
            ZIndex = 1014,
        }
    )

    local grid = Instance.new('Frame')
    grid.Position = UDim2.fromOffset(10, 43)
    grid.Size = UDim2.new(1, -20, 1, -53)
    grid.BackgroundTransparency = 1
    grid.BorderSizePixel = 0
    grid.ZIndex = 1014
    grid.Parent = row

    local layout = Instance.new('UIGridLayout')
    layout.CellSize = UDim2.new(0.333333, -6, 0, 56)
    layout.CellPadding = UDim2.fromOffset(6, 6)
    layout.FillDirectionMaxCells = 3
    layout.SortOrder = Enum.SortOrder.LayoutOrder
    layout.Parent = grid

    local names = {
        'SquidNoMo',
        'Neon Pink',
        'Cyber Purple',
        'Ocean Blue',
        'Emerald',
        'Crimson',
        'Amber',
        'Monochrome',
        'High Contrast',
    }

    for index, name in ipairs(names) do
        local preset = manager.Themes[name]
        local color = Color3.fromHSV(
            (preset.AccentHue or 0) / 360,
            (preset.AccentSaturation or 0) / 100,
            (preset.AccentBrightness or 100) / 100
        )
        local button = Instance.new('TextButton')
        button.BackgroundColor3 = color
        button.BackgroundTransparency = 0.16
        button.BorderSizePixel = 0
        button.AutoButtonColor = false
        button.Font = Enum.Font.GothamBlack
        button.Text = name
        button.TextSize = App:IsMobile() and 9 or 10
        button.TextColor3 = Color3.fromRGB(255, 255, 255)
        button.LayoutOrder = index
        button.ZIndex = 1015
        button.Parent = grid
        corner(button, 9)
        stroke(button, Color3.fromRGB(255, 255, 255), 1, 0.56)
        App:BindButtonFeedback(button, color)

        button.Activated:Connect(function()
            manager:ApplyTheme(draft, name)
            rerender()
        end)
    end
end

function UIPage:Create(Page, App)
    local manager = App.UIStyleManager
    if type(manager) ~= 'table' then
        Page:ClearAllChildren()
        App:BuildErrorPage(
            Page,
            'UI',
            'The UI style manager is unavailable.'
        )
        return
    end

    local draft = manager:Clone(App.UIStyleProfile)
    local selectedCategory = App.Session.SelectedUICategory
        or 'Layout & Scale'
    local selectedScope = App.Session.UIEditScope
        or 'Entire App'
    local targetPage = App.Session.UIEditTargetPage
        or 'Players'
    local contentRoot = nil

    local function read(key)
        return manager:GetEditableValue(
            draft,
            selectedScope,
            targetPage,
            key
        )
    end

    local function write(key, value)
        manager:SetValue(
            draft,
            selectedScope,
            targetPage,
            key,
            value
        )
    end

    local function saveEditorState()
        App.Session.SelectedUICategory = selectedCategory
        App.Session.UIEditScope = selectedScope
        App.Session.UIEditTargetPage = targetPage
        App:QueueSettingsSave()
    end

    local renderCategory

    local function createScopeToolbar(root, y)
        local accent = App:GetPageAccent('UI')
        local toolbar = App:CreateCard(
            root,
            UDim2.new(1, 0, 0, 76),
            {
                Color = App.Colors.Card,
                BorderColor = accent,
                BorderTransparency = 0.18,
                Radius = 13,
            }
        )
        toolbar.Position = UDim2.fromOffset(0, y)

        local scopeHolder = Instance.new('Frame')
        scopeHolder.Position = UDim2.fromOffset(12, 12)
        scopeHolder.Size = UDim2.new(0.68, -18, 0, 52)
        scopeHolder.BackgroundTransparency = 1
        scopeHolder.BorderSizePixel = 0
        scopeHolder.Parent = toolbar

        local scopeLayout = Instance.new('UIListLayout')
        scopeLayout.FillDirection = Enum.FillDirection.Horizontal
        scopeLayout.HorizontalAlignment = Enum.HorizontalAlignment.Left
        scopeLayout.VerticalAlignment = Enum.VerticalAlignment.Center
        scopeLayout.SortOrder = Enum.SortOrder.LayoutOrder
        scopeLayout.Padding = UDim.new(0, 6)
        scopeLayout.Parent = scopeHolder

        local scopeRefs = {}
        local function refreshScopes()
            for _, ref in ipairs(scopeRefs) do
                local selected = ref.Value == selectedScope
                ref.Button.BackgroundColor3 = selected
                    and accent
                    or App.Colors.CardAlt
                ref.Button.BackgroundTransparency = selected
                    and 0.08
                    or 0.24
                ref.Stroke.Transparency = selected
                    and 0.02
                    or 0.58
            end
        end

        for index, scopeName in ipairs(manager.Scopes) do
            local button = Instance.new('TextButton')
            button.Size = UDim2.new(0.25, -5, 0, 46)
            button.BackgroundColor3 = App.Colors.CardAlt
            button.BackgroundTransparency = 0.24
            button.BorderSizePixel = 0
            button.AutoButtonColor = false
            button.Font = Enum.Font.GothamBold
            button.Text = scopeName
            button.TextSize = App:IsMobile() and 9 or 10
            button.TextColor3 = App.Colors.Text
            button.LayoutOrder = index
            button.ZIndex = 1014
            button.Parent = scopeHolder
            corner(button, 9)
            local outline = stroke(button, accent, 1, 0.58)
            App:BindButtonFeedback(button, accent)

            button.Activated:Connect(function()
                selectedScope = scopeName
                saveEditorState()
                renderCategory(selectedCategory)
            end)

            table.insert(scopeRefs, {
                Button = button,
                Stroke = outline,
                Value = scopeName,
            })
        end
        refreshScopes()

        local targetHolder = Instance.new('Frame')
        targetHolder.AnchorPoint = Vector2.new(1, 0)
        targetHolder.Position = UDim2.new(1, -12, 0, 12)
        targetHolder.Size = UDim2.new(0.32, -2, 0, 52)
        targetHolder.BackgroundColor3 = App.Colors.CardAlt
        targetHolder.BackgroundTransparency = 0.18
        targetHolder.BorderSizePixel = 0
        targetHolder.Parent = toolbar
        corner(targetHolder, 9)
        stroke(targetHolder, accent, 1, 0.56)

        local previous = Instance.new('TextButton')
        previous.Size = UDim2.fromOffset(44, 44)
        previous.Position = UDim2.fromOffset(4, 4)
        previous.BackgroundColor3 = App.Colors.Card
        previous.BackgroundTransparency = 0.12
        previous.BorderSizePixel = 0
        previous.AutoButtonColor = false
        previous.Font = Enum.Font.GothamBlack
        previous.Text = '<'
        previous.TextSize = 18
        previous.TextColor3 = App.Colors.Text
        previous.ZIndex = 1015
        previous.Parent = targetHolder
        corner(previous, 8)
        App:BindButtonFeedback(previous, accent)

        local nextButton = previous:Clone()
        nextButton.AnchorPoint = Vector2.new(1, 0)
        nextButton.Position = UDim2.new(1, -4, 0, 4)
        nextButton.Text = '>'
        nextButton.Parent = targetHolder
        App:BindButtonFeedback(nextButton, accent)

        local targetLabel = App:CreateText(
            targetHolder,
            targetPage,
            UDim2.new(1, -104, 1, 0),
            UDim2.fromOffset(52, 0),
            {
                Font = Enum.Font.GothamBlack,
                TextSize = App:IsMobile() and 10 or 11,
                Color = accent,
                XAlignment = Enum.TextXAlignment.Center,
                ZIndex = 1015,
            }
        )

        local function cycle(direction)
            local current = table.find(PAGE_NAMES, targetPage) or 1
            current = ((current - 1 + direction) % #PAGE_NAMES) + 1
            targetPage = PAGE_NAMES[current]
            targetLabel.Text = targetPage
            saveEditorState()
            if selectedScope == 'Current Page' then
                renderCategory(selectedCategory)
            end
        end

        previous.Activated:Connect(function()
            cycle(-1)
        end)
        nextButton.Activated:Connect(function()
            cycle(1)
        end)

        targetHolder.Visible = selectedScope == 'Current Page'
    end

    local function createActionBar(root, y)
        local accent = App:GetPageAccent('UI')
        local bar = App:CreateCard(
            root,
            UDim2.new(1, 0, 0, 76),
            {
                Color = App.Colors.Card,
                BorderColor = accent,
                BorderTransparency = 0.18,
                Radius = 13,
            }
        )
        bar.Position = UDim2.fromOffset(0, y)

        local actions = {
            {
                Text = 'APPLY CHANGES',
                Color = App.Colors.Success,
                Callback = function()
                    App:SetUIStyleProfile(draft, true)
                end,
            },
            {
                Text = 'UNDO DRAFT',
                Color = App:GetPageAccent('Players'),
                Callback = function()
                    draft = manager:Clone(App.UIStyleProfile)
                    renderCategory(selectedCategory)
                end,
            },
            {
                Text = 'RESTORE SCOPE',
                Color = App.Colors.Error,
                Callback = function()
                    manager:ResetScope(
                        draft,
                        selectedScope,
                        targetPage
                    )
                    renderCategory(selectedCategory)
                end,
            },
        }

        for index, actionInfo in ipairs(actions) do
            local button = Instance.new('TextButton')
            button.Position = UDim2.new(
                (index - 1) / 3,
                index == 1 and 12 or 4,
                0,
                14
            )
            button.Size = UDim2.new(
                0.333333,
                -16,
                0,
                48
            )
            button.BackgroundColor3 = actionInfo.Color
            button.BackgroundTransparency = 0.08
            button.BorderSizePixel = 0
            button.AutoButtonColor = false
            button.Font = Enum.Font.GothamBlack
            button.Text = actionInfo.Text
            button.TextSize = App:IsMobile() and 10 or 11
            button.TextColor3 = Color3.fromRGB(255, 255, 255)
            button.ZIndex = 1014
            button.Parent = bar
            corner(button, 10)
            stroke(
                button,
                Color3.fromRGB(255, 255, 255),
                1,
                0.66
            )
            App:BindButtonFeedback(button, actionInfo.Color)
            button.Activated:Connect(actionInfo.Callback)
        end
    end

    local function buildLayout(columns)
        local accent = App:GetPageAccent('UI')
        local shell = createColumn(
            App,
            columns,
            'WINDOW & SHELL',
            'Global application dimensions and scale.',
            accent,
            1
        )
        local pages = createColumn(
            App,
            columns,
            'PAGE LAYOUT',
            'Spacing for the selected page scope.',
            App:GetPageAccent('Games'),
            2
        )
        local elements = createColumn(
            App,
            columns,
            'SUBPAGES & ELEMENTS',
            'Category bubbles, text, and scrolling.',
            App:GetPageAccent('Players'),
            3
        )

        local function slider(holder, config, key, order)
            createTouchSlider(
                App,
                holder,
                config,
                function()
                    return read(key)
                end,
                function(value)
                    write(key, value)
                end,
                order
            )
        end

        slider(shell, {
            Title = 'Window Width',
            Minimum = 900,
            Maximum = 1600,
            Step = 5,
            Formatter = function(v)
                return formatNumber(v, ' px')
            end,
            Accent = accent,
        }, 'WindowWidth', 1)
        slider(shell, {
            Title = 'Window Height',
            Minimum = 540,
            Maximum = 900,
            Step = 5,
            Formatter = function(v)
                return formatNumber(v, ' px')
            end,
            Accent = accent,
        }, 'WindowHeight', 2)
        slider(shell, {
            Title = 'Application Scale',
            Minimum = 0.75,
            Maximum = 1.15,
            Step = 0.01,
            Formatter = function(v)
                return formatNumber(v * 100, '%')
            end,
            Accent = accent,
        }, 'AppScale', 3)
        slider(shell, {
            Title = 'Sidebar Width',
            Minimum = 170,
            Maximum = 340,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, ' px')
            end,
            Accent = accent,
        }, 'SidebarWidth', 4)

        slider(pages, {
            Title = 'Top Bar Height',
            Minimum = 44,
            Maximum = 92,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, ' px')
            end,
            Accent = App:GetPageAccent('Games'),
        }, 'TopbarHeight', 1)
        slider(pages, {
            Title = 'Footer Height',
            Minimum = 24,
            Maximum = 64,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, ' px')
            end,
            Accent = App:GetPageAccent('Games'),
        }, 'FooterHeight', 2)
        slider(pages, {
            Title = 'Page Padding',
            Minimum = 4,
            Maximum = 36,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, ' px')
            end,
            Accent = App:GetPageAccent('Games'),
        }, 'PagePadding', 3)
        slider(pages, {
            Title = 'Column Gap',
            Minimum = 4,
            Maximum = 32,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, ' px')
            end,
            Accent = App:GetPageAccent('Games'),
        }, 'ColumnGap', 4)
        slider(pages, {
            Title = 'Section Spacing',
            Minimum = 4,
            Maximum = 36,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, ' px')
            end,
            Accent = App:GetPageAccent('Games'),
        }, 'SectionSpacing', 5)

        slider(elements, {
            Title = 'Category Bubble Width',
            Minimum = 145,
            Maximum = 300,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, ' px')
            end,
            Accent = App:GetPageAccent('Players'),
        }, 'CategoryBubbleWidth', 1)
        slider(elements, {
            Title = 'Category Bubble Height',
            Minimum = 50,
            Maximum = 92,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, ' px')
            end,
            Accent = App:GetPageAccent('Players'),
        }, 'CategoryBubbleHeight', 2)
        slider(elements, {
            Title = 'Category Bar Height',
            Minimum = 82,
            Maximum = 160,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, ' px')
            end,
            Accent = App:GetPageAccent('Players'),
        }, 'CategoryBarHeight', 3)
        slider(elements, {
            Title = 'Text Scale',
            Minimum = 0.80,
            Maximum = 1.45,
            Step = 0.01,
            Formatter = function(v)
                return formatNumber(v * 100, '%')
            end,
            Accent = App:GetPageAccent('Players'),
        }, 'TextScale', 4)
        slider(elements, {
            Title = 'Scrollbar Thickness',
            Minimum = 2,
            Maximum = 14,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, ' px')
            end,
            Accent = App:GetPageAccent('Players'),
        }, 'ScrollbarThickness', 5)
    end

    local function buildThemes(columns)
        local accent = App:GetPageAccent('UI')
        local presets = createColumn(
            App,
            columns,
            'THEME PRESETS',
            'Start with a complete professional palette.',
            accent,
            1
        )
        local primary = createColumn(
            App,
            columns,
            'PRIMARY COLORS',
            'Fine-tune the accent using HSV controls.',
            App:GetPageAccent('Games'),
            2
        )
        local surfaces = createColumn(
            App,
            columns,
            'SURFACES & PAGE ACCENTS',
            'Control contrast and page-specific color.',
            App:GetPageAccent('Settings'),
            3
        )

        createPresetGrid(
            App,
            presets,
            manager,
            draft,
            accent,
            function()
                renderCategory(selectedCategory)
            end,
            1
        )

        createChoice(
            App,
            presets,
            'Accent Mode',
            {'Page Colors', 'Uniform Accent'},
            accent,
            function()
                return read('UniformPageAccents')
                    and 'Uniform Accent'
                    or 'Page Colors'
            end,
            function(choice)
                write(
                    'UniformPageAccents',
                    choice == 'Uniform Accent'
                )
            end,
            2
        )

        local function slider(holder, config, key, order)
            createTouchSlider(
                App,
                holder,
                config,
                function()
                    return read(key)
                end,
                function(value)
                    write(key, value)
                end,
                order
            )
        end

        slider(primary, {
            Title = 'Accent Hue',
            Minimum = 0,
            Maximum = 360,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, '°')
            end,
            Accent = App:GetPageAccent('Games'),
        }, 'AccentHue', 1)
        slider(primary, {
            Title = 'Accent Saturation',
            Minimum = 0,
            Maximum = 100,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, '%')
            end,
            Accent = App:GetPageAccent('Games'),
        }, 'AccentSaturation', 2)
        slider(primary, {
            Title = 'Accent Brightness',
            Minimum = 40,
            Maximum = 100,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, '%')
            end,
            Accent = App:GetPageAccent('Games'),
        }, 'AccentBrightness', 3)

        slider(surfaces, {
            Title = 'Background Brightness',
            Minimum = 1,
            Maximum = 20,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, '%')
            end,
            Accent = App:GetPageAccent('Settings'),
        }, 'BackgroundBrightness', 1)
        slider(surfaces, {
            Title = 'Card Brightness',
            Minimum = 4,
            Maximum = 32,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, '%')
            end,
            Accent = App:GetPageAccent('Settings'),
        }, 'CardBrightness', 2)
        slider(surfaces, {
            Title = 'Text Brightness',
            Minimum = 65,
            Maximum = 100,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, '%')
            end,
            Accent = App:GetPageAccent('Settings'),
        }, 'TextBrightness', 3)
        slider(surfaces, {
            Title = 'Selected Page Accent Hue',
            Minimum = 0,
            Maximum = 360,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, '°')
            end,
            Accent = App:GetPageAccent('Settings'),
        }, 'PageAccentHue', 4)
    end

    local function buildButtons(columns)
        local accent = App:GetPageAccent('UI')
        local buttons = createColumn(
            App,
            columns,
            'BUTTON STYLES',
            'Shape, size, borders, and press behavior.',
            accent,
            1
        )
        local toggles = createColumn(
            App,
            columns,
            'TOGGLES',
            'Configure switch dimensions and spacing.',
            App:GetPageAccent('Players'),
            2
        )
        local effects = createColumn(
            App,
            columns,
            'SLIDERS & EFFECTS',
            'Touch controls, glow, and animation speed.',
            App:GetPageAccent('Settings'),
            3
        )

        createChoice(
            App,
            buttons,
            'Button Style',
            {'Filled', 'Outline', 'Soft Glow', 'Flat', 'Glass'},
            accent,
            function()
                return read('ButtonStyle')
            end,
            function(value)
                write('ButtonStyle', value)
            end,
            1
        )

        local function slider(holder, config, key, order)
            createTouchSlider(
                App,
                holder,
                config,
                function()
                    return read(key)
                end,
                function(value)
                    write(key, value)
                end,
                order
            )
        end

        slider(buttons, {
            Title = 'Button Height',
            Minimum = 32,
            Maximum = 72,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, ' px')
            end,
            Accent = accent,
        }, 'ButtonHeight', 2)
        slider(buttons, {
            Title = 'Button Radius',
            Minimum = 2,
            Maximum = 32,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, ' px')
            end,
            Accent = accent,
        }, 'ButtonRadius', 3)
        slider(buttons, {
            Title = 'Border Thickness',
            Minimum = 0,
            Maximum = 4,
            Step = 0.25,
            Formatter = function(v)
                return formatNumber(v, ' px', 2)
            end,
            Accent = accent,
        }, 'BorderThickness', 4)
        slider(buttons, {
            Title = 'Press Scale',
            Minimum = 90,
            Maximum = 100,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, '%')
            end,
            Accent = accent,
        }, 'PressScale', 5)

        createChoice(
            App,
            toggles,
            'Toggle Style',
            {'Switch', 'Pill', 'Checkbox'},
            App:GetPageAccent('Players'),
            function()
                return read('ToggleStyle')
            end,
            function(value)
                write('ToggleStyle', value)
            end,
            1
        )
        slider(toggles, {
            Title = 'Toggle Width',
            Minimum = 42,
            Maximum = 86,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, ' px')
            end,
            Accent = App:GetPageAccent('Players'),
        }, 'ToggleWidth', 2)
        slider(toggles, {
            Title = 'Toggle Height',
            Minimum = 22,
            Maximum = 48,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, ' px')
            end,
            Accent = App:GetPageAccent('Players'),
        }, 'ToggleHeight', 3)
        slider(toggles, {
            Title = 'Toggle Spacing',
            Minimum = 2,
            Maximum = 24,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, ' px')
            end,
            Accent = App:GetPageAccent('Players'),
        }, 'ToggleSpacing', 4)

        slider(effects, {
            Title = 'Slider Track Thickness',
            Minimum = 4,
            Maximum = 18,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, ' px')
            end,
            Accent = App:GetPageAccent('Settings'),
        }, 'SliderTrack', 1)
        slider(effects, {
            Title = 'Slider Knob Size',
            Minimum = 14,
            Maximum = 34,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, ' px')
            end,
            Accent = App:GetPageAccent('Settings'),
        }, 'SliderKnob', 2)
        slider(effects, {
            Title = 'Glow Intensity',
            Minimum = 0,
            Maximum = 100,
            Step = 1,
            Formatter = function(v)
                return formatNumber(v, '%')
            end,
            Accent = App:GetPageAccent('Settings'),
        }, 'GlowIntensity', 3)
        slider(effects, {
            Title = 'Animation Speed',
            Minimum = 50,
            Maximum = 200,
            Step = 5,
            Formatter = function(v)
                return formatNumber(v, '%')
            end,
            Accent = App:GetPageAccent('Settings'),
        }, 'AnimationSpeed', 4)
        createToggle(
            App,
            effects,
            'Quick Adjustment Buttons',
            'Show the -10, -5, -1, +1, +5, and +10 helpers on supported sliders.',
            App:GetPageAccent('Settings'),
            function()
                return read('QuickAdjust') == true
            end,
            function(value)
                write('QuickAdjust', value)
            end,
            5
        )
    end

    renderCategory = function(categoryName)
        selectedCategory = categoryName or selectedCategory
        saveEditorState()

        if contentRoot then
            contentRoot:Destroy()
        end

        local pagePadding = App:GetUIStyleValue(
            'UI',
            'PagePadding',
            'MainPage'
        )
        local barHeight = App:GetUIStyleValue(
            'UI',
            'CategoryBarHeight',
            'Subpage'
        )

        contentRoot = Instance.new('Frame')
        contentRoot.Name = 'UICustomizationContent'
        contentRoot.Position = UDim2.fromOffset(
            pagePadding,
            pagePadding + barHeight + 16
        )
        contentRoot.Size = UDim2.new(
            1,
            -(pagePadding * 2),
            0,
            1260
        )
        contentRoot.BackgroundTransparency = 1
        contentRoot.BorderSizePixel = 0
        contentRoot.Parent = Page

        createScopeToolbar(contentRoot, 0)

        local columns = App:CreateEqualThreeColumnRow(
            contentRoot,
            90,
            1060,
            'UICustomizationColumns'
        )

        if selectedCategory == 'Themes & Colors' then
            buildThemes(columns)
        elseif selectedCategory == 'Buttons & Effects' then
            buildButtons(columns)
        else
            buildLayout(columns)
        end

        createActionBar(contentRoot, 1168)
    end

    App.Loader.CategoryStrip:Create(Page, App, {
        PageName = 'UI',
        SessionKey = 'SelectedUICategory',
        DefaultName = selectedCategory,
        ScrollerName = 'UICategoryScroller',
        ButtonWidth = 280,
        Items = CATEGORIES,
        OnSelected = function(item)
            renderCategory(item.Name)
        end,
    })
end

return UIPage
]====],
    },
}
