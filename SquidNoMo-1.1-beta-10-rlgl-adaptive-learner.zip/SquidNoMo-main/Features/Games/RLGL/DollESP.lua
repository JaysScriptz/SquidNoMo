local Environment = _G
if type(getgenv) == "function" then
    local ok, result = pcall(getgenv)
    if ok and type(result) == "table" then Environment = result end
end
local Manifest = type(Environment.__SquidNoMoBuildManifest) == "table" and Environment.__SquidNoMoBuildManifest or {}
local Runtime = Environment.__SquidNoMoGameRuntime
if type(Runtime) ~= "table"
    or tostring(Runtime.Revision) ~= tostring(Manifest.GameRuntimeRevision or "")
    or tonumber(Runtime.BuildNumber) ~= tonumber(Manifest.BuildNumber)
then
    error("SquidNoMo game runtime is unavailable; deploy and execute the complete current build")
end


return Runtime:CreateFeature({
    Game = "Red Light, Green Light",
    Id = "mapped.games.red_light_green_light.dollesp",
    Name = "Doll ESP",
    Description = "Highlights the active Younghee or robot doll model in the RLGL field.",
    Handler = "Highlight",
    TargetTokens = {"doll", "younghee", "young hee", "yeonghee", "mugunghwa", "robot"},
    ExcludeTokens = {"icon", "shop", "image"},
    TargetClasses = {"Model", "BasePart"},
    Color = Color3.fromRGB(255, 80, 110),
    Label = "DOLL",
    Interval = 0.65,
    IdleInterval = 1.0,
    WaitingMessage = "Waiting for the RLGL doll",
})
